# 前沿补充：Engram、mHC 与 DeepSeek-V4.1-Flash

核实日期 **2026-09-25**。最新交付已扩展为三个独立章节：**Engram、原始 mHC、DeepSeek-V4.1-Flash**。可运行代码包括 **Engram 条件记忆模块、原始 mHC 包装器，以及 CED/CSA2 数学参考 `models/deepseek_v41.py`**。六层 `TinyCEDReference` 验证缓存来源与跨层复用，并不是 DeepSeek-V4.1-Flash 的完整实现。最新章节、官方推理源码核对和验证边界见 [`deep-deepseek.md`](deep-deepseek.md)。

## 日期与官方资料可访问性

| 项目 | 一手证据 | 核实日期/版本 |
|---|---|---|
| mHC: Manifold-Constrained Hyper-Connections | arXiv 2512.24880 submission history | v1 **2025-12-31**；v2 **2026-01-05**。不能写成 2026 年首发 |
| Engram: Conditional Memory via Scalable Lookup | arXiv 2601.07372 submission history | v1 **2026-01-12**；v2 **2026-07-12** |
| DeepSeek-V4.1-Flash | 官方 Hugging Face 模型库、README、config、49 页技术报告 PDF | 官方库 `createdAt=2026-09-10T02:17:58Z`，与 gallery 的 2026-09-10 对应；本次确实读取官方正文 |

V4.1 官方报告下载成功（1,809,802 bytes、application/pdf），标题为 *DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression*。官方 HF API 当次 SHA 为 `dba1be0a40aa45a94ad051997016db3960a90277`。不是仅依据 gallery 宣称模型存在。报告/README 没有单独印刷的发布日期字段，因此 9 月 10 日的证据来自官方模型库创建记录与 gallery 的交叉印证。

## mHC：把一条残差路拓宽成多条，但约束混合矩阵

一眼看懂：**多残差流 → 读入一个子层 → 把子层更新写回各流，同时用非负双随机矩阵混合直通残差**。这改变层与层之间的连接；不替换 attention 或 MoE 本身。

原论文 §1 eq.3、§4.1、§4.2 eq.7–9。对一个 token：

```text
X_l ∈ R^(S×D)              S 个残差流，每流 D 维；论文实验 S=4
u = vec(X_l) ∈ R^(SD)
u' = RMSNorm(u)
z_pre  = α_pre  · Φ_pre u'  + b_pre      [S]
z_post = α_post · Φ_post u' + b_post     [S]
Z_res  = α_res  · reshape(Φ_res u') + B  [S,S]
p = sigmoid(z_pre)                      [S]
q = 2·sigmoid(z_post)                    [S]
P = Sinkhorn(exp(Z_res))                 [S,S]
f = F(p^T X_l)                          [D]
X_(l+1) = P X_l + q f^T                 [S,D]
```

`F` 是包含自身所需 pre-norm 的 attention/FFN 子层。图中 `p` 是“读哪些流”，`q` 是“写回哪些流”，`P` 是残差流之间的路由。**p/q 不要求和为 1；双随机约束只施加在 P。** 本公式将论文 row-vector 投影转成等价列向量写法；PyTorch 内部使用 `nn.Linear`。

双随机约束：`P_ij ≥ 0`, `Σ_j P_ij=1`, `Σ_i P_ij=1`。每条输出残差流是输入流的凸组合，并保持纯残差路径的跨流均值。多个精确双随机矩阵相乘仍是双随机矩阵。**这不等于 P=I，不是正交约束，也不是声称整个动态网络及其梯度都严格等距或有界。** 附加子层输出会改变信号，动态系数还依赖输入。

### Sinkhorn 的动画与有限迭代

```text
任意 S×S logits
   ↓ exp：元素变正
   ↓ 每列除以列和
   ↓ 每行除以行和
   ↺ 迭代 K 次（论文 K=20）
近似双随机矩阵
```

论文 eq.9 是 **先列归一化、再行归一化**。教学实现用 log-space 的 `logsumexp` 做同一缩放，避免直接 exp 溢出。有限 K 时，只能叫“近似双随机”：本实现最后一步归一化行，故列和仍有误差；浮点运算也有舍入误差。展示行和、列和与 1 的差值，比把每个值硬写为“精确 1”更严谨。

示意图建议：四条横向残差流贯穿页面；左侧 `p` 汇总进入 F，右侧 `q` 把同一个 F 输出分配到四流；四流直通部分经过一个 4×4 热力图 P。互动面板切换“无约束 / 行 softmax / Sinkhorn”并分别显示行、列和；行 softmax 不能保证列和。不要把 p/q 也画成 softmax。

### 可直接展示的代码

```python
# X: [B,T,S,D]; F 接收 [B,T,D]
pre, post, P = wrapper.mixing_matrices(X)
u = torch.einsum('bts,btsd->btd', pre, X)
y = sublayer(u)
X_next = torch.einsum('btij,btjd->btid', P, X) + post[..., None] * y[..., None, :]
```

`MHCWrapper` 默认 F 返回子层增量。如果传入已有的 `x + delta` 残差 block，设置 `sublayer_returns_residual=True`，内部先减去其输入，避免双加残差。包装整块是一种教学组合方式；原模型通常围绕 attention 和 MoE 子层分别使用连接。权重初始化为便于教学的近对角残差 mixing，并非官方 checkpoint 初始化复现。

## Engram：查一小段 token 的静态记忆，再让当前上下文决定用多少

Engram 与 MoE 是两个不同轴：MoE 选择执行哪些专家；Engram 通过离散 token/ngram 地址读取哪些 embedding 行。它**不是检索外部文档的 RAG，也不是持久化对话记忆**。表项是训练得到的参数；地址由 token 决定，门控由 hidden state 决定。

原论文 §2.2 eq.1–2、§2.3 eq.3–5、§2.4 eq.6：

```text
raw token IDs x_t                 原有 backbone tokenizer 不变
   ↓ 预计算词表映射 P
canonical IDs x'_t               仅用于 Engram lookup
   ↓ 2-gram / 3-gram / ... / N-gram 后缀
每个 order 使用 K 个 hash heads
   ↓ multiplicative-XOR hash，模各自不同的素数表长
E_(n,k)[hash(g_(t,n))]            [d_head]，每个 head 独立表
   ↓ 拼接所有 order/head
e_t                              [(N-1)K d_head]
   ├─ W_V → v_t                  [D]，多残差流共享
   └─ W_K,s → k_t,s              [D]，每条流独立
```

逐流融合（`H∈R^(B×T×S×D)`）：

```text
a_t,s = sigmoid( RMSNorm(h_t,s)^T RMSNorm(k_t,s) / sqrt(D) )   [1]
vtilde_t,s = a_t,s · v_t                                    [D]
Y = vtilde + SiLU(DWConv_causal(RMSNorm(vtilde)))              [B,T,S,D]
H ← H + Y
```

卷积 **kernel=4，dilation=N（最大 n-gram order）**；每流、每 feature 是独立的 depthwise channel。先对 gated value 作 RMSNorm，再卷积，再 SiLU，然后加回 gated value；最后模块更新加回主残差一次。不要将这两个加法合并漏掉，也不要把门控作用在所有词表行上。

### tokenizer 与 hash 的准确边界

原始 Engram 将 tokenizer ID 按规范化后的文本等价关系合并：NFKC、lowercase 等；公开 demo 具体还用 NFD、去组合重音、空白规整，并保留特殊空白及非法 Unicode 的回退。论文报告该 tokenizer 的有效词表约减少 23%，不是任意 tokenizer 的固定压缩率。

教学代码：默认映射为 identity，支持传入 `token_map`；`toy_token_normalization_map(["Apple"," apple ",...])` 展示 canonical ID 合并，**不加载生产 tokenizer**。它没有生产 tokenizer 的所有 special-token/非法 Unicode 处理；小整数 odd multipliers、固定 seed/layer ID、不同素数表长保留 multiplicative-XOR 的结构，但不是 checkpoint-compatible 的完整 hash 配方。

多头 hash 缓解碰撞，**不保证消除碰撞**。lookup 的 O(1) 指固定 N/K/维度下每 token 的寻址复杂度，不包括任意硬件上的传输延迟；教学 `nn.Embedding` 没有实现分片、RDMA、host prefetch 或生产稀疏优化器。

### 原论文和官方 demo 有一处门控差异

原论文 eq.4/6（含本次读取的 v2）使用 `sigmoid(score)`。官方 `engram_demo_v1.py` 还额外对 score 做 `sign(score)*sqrt(abs(score))` 再 sigmoid。教学模块默认 `gate_transform="paper"` 与本文公式一致；可选 `"official_demo"` 重现这项 demo 变换。不要将两者静默混写。

### 图解与互动建议

- “同 token、不同上下文”：相同 n-gram 查出的 e 不变；改变 h，gate a 改变。让 lookup 与 gate 分别亮起，讲清静态记忆和动态融合。
- “相同规范形式”：`Apple` / ` apple ` 映射同一个 canonical ID，而 backbone 的原始 IDs 保持不同。
- “碰撞不是语义相同”：两条 n-gram 可以在一个表碰撞，在其它 head 的表分离。不要把 hash 箭头标成语义近邻检索。
- 2-gram/3-gram 的末尾都在当前 t，左边越界用 pad；动画不得读取 t+1。Conv 图标写 `causal, dilation=N`。

## 最新集成：V4.1 有哪些必须单独标明的新点

以下来自官方报告，不只来自 gallery。**不属于本次两个研究模块的实现范围。**

1. **Causal Encoder-Decoder（§2.2）**：40 层=20 层因果 encoder+20 层 decoder。decoder 的 global KV 从最终 encoder states 投影，SWA KV 仍逐层生成。长 prompt prefill 主要执行 encoder，并用有限 SWA replay 补充 decoder 局部状态；不能简化成“decoder 在 prefill 完全不执行”。官方 headline 是 552B backbone、prefill 每 token 8B / decode 16B，另有 **196B Engram**；总 backbone+Engram 为 **748B**，此计数不含 vision encoder/DSpark。
2. **CSA2（§2.3.1）**：每层静态指定 Full / Reindex / Reuse。Full 新建 main KV、indexer K 及 top-k；Reindex 复用 KV/K，重算自身 indexer query 和 top-k；Reuse 复用 KV 与最近 top-k，不再 indexing。三种模式仍各自计算 query 和本层 SWA KV。decoder 的 hierarchical indexer 首次 Full 扫全历史并选最多 2048×8=16384 候选，后续 Reindex 仅在候选中取 top-512；**首次扫描仍随 T 增长**。
3. **Single-Pass mHC（§2.4.1 eq.6）**：原式 `F_l(A_l X_l)` 改为 `F_l(A_(l-1) X_l)`，input-mixing 系数延后一 block，解除当前系数计算依赖，才可用 Mega-mHC 融合实现单次 traversal。本模块实现原始 mHC，不把“单个 Python forward”误称 Single-Pass mHC。
4. **Engram 变体（§2.4.2）**：V4.1 **删除原 Engram 的短因果卷积**，并修改 embedding optimizer。196B 参数均分两模块；zero-based 层 1 与 14；orders `{2,3,4}`，每 order 8 heads、总 embedding 宽度 2048，每 head 约 16M 素数表项。表和 K/V projection 使用 FP8。代码 `use_conv=False` 只示范“省略卷积”这一结构开关，不能称完整 V4.1 Engram 训练实现。
5. **cache 口径**：官方 **890 bytes/token** 对应量化后的 growing global KV；gallery **3.125 KiB/token BF16** 是不同精度口径。均不代表总 serving 显存，不应遗漏 SWA、索引、临时状态和其它驻留参数，也不能据此直接比较本代码实测。

## 实现与实测

- `models/frontier_modules.py`：`MHCConfig`, `MHCWrapper`, `sinkhorn_residual`, `EngramConfig`, `EngramMemory`, `toy_token_normalization_map`。
- mHC 输入 `[B,T,S,D]`，Engram 返回同形状的 **增量**；S=1 时 Engram 也支持 `[B,T,D]`。两个模块均可反向传播；没有凭空声称新增完整旗舰模型。
- PyTorch 2.14.0+cpu，**8/8 测试通过**（0.623s）：Sinkhorn 有限误差及收敛、残差纯混合均值与凸范围、避免双加残差、参数梯度、token 规范化、context gate、ngram/卷积因果性、仅被访问 table 行非零梯度、论文/demo gate 差别。
- 独立组合示例通过：`shape=(2, 9, 4, 32), column_sum_error=6.87e-05, backward=ok`。20 次迭代产生的列和误差是正常的有限迭代现象，不应抹去。

```bash
.venv/bin/python -m unittest discover -s tests -p 'test_frontier_modules.py' -v
.venv/bin/python models/frontier_modules.py
```

## 一手来源（原始快照均在 sources/frontier-deepseek*）

- [mHC 原论文](https://arxiv.org/html/2512.24880v2)：§4.1–4.2 eq.7–9；[版本日期](https://arxiv.org/abs/2512.24880)。`frontier-deepseek-mhc-v2.html` / `frontier-deepseek-mhc-arxiv.html`。
- [Engram 原论文 v2](https://arxiv.org/pdf/2601.07372v2)：§2.2–2.4 eq.1–6；[版本日期](https://arxiv.org/abs/2601.07372)。`frontier-deepseek-engram-v2.pdf`（pdftotext 对PDF部分字典有warning，但正文公式成功读取；另用官方仓库PDF交叉核实）。
- [Engram 官方仓库](https://github.com/deepseek-ai/Engram)、[原始 PDF](https://github.com/deepseek-ai/Engram/blob/main/Engram_paper.pdf)、[官方 demo](https://github.com/deepseek-ai/Engram/blob/main/engram_demo_v1.py)。demo README 明确提醒 Attention/MoE/mHC 为 mocks；本模块没有把这些 mock 称为完整模型。
- [V4.1 官方报告](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash/blob/main/DeepSeek_V41_Tech_Report.pdf)、[官方模型卡](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash)、[官方 config](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash/blob/main/config.json)、[官方库 metadata](https://huggingface.co/api/models/deepseek-ai/DeepSeek-V4.1-Flash)。`frontier-deepseek-v41-*`。
