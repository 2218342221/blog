# DeepSeek-V3：原论文核实与实现边界

核对日期：2026-09-25。范围是原始 DeepSeek-V3 / V3-Base 架构，不混入后续 V3.2、V4 或 R1 的变化。

## 一屏可用的事实

- **671B 总参数，37B 每 token 激活参数**。37B 不是整模型存储量，也不是 8 个专家的参数总量；还包含每 token 必经的注意力等模块。原论文摘要、§4.2。
- **61 个 decoder block；前 3 层是 dense SwiGLU，其余 58 层是 MoE**。每个 MoE 层有 **256 个路由专家，逐 token 选 8 个；另有 1 个始终启用的共享专家**。不是全模型只选 8 个专家。§4.2。
- MLA：隐藏宽度 7168，128 个头；每头内容 Q/K 宽度 128、V 宽度 128，额外位置 Q/K 宽度 64；KV latent 宽度 512，Q latent 宽度 1536。§2.1.1、§4.2。
- 路由专家 SwiGLU 中间宽度 2048；dense FFN 中间宽度 18432；vocab 129280。后两项由官方 `config_671B.json` 核实。
- 8 组路由专家，每 token 最多选 4 组，再从这些组中选 8 专家。官方实现的每组分数为 **组内两个最高 corrected scores 之和**，不是组内最大值。`route_scale=2.5`。官方配置与 `Gate.forward`；论文 §2.1.2 的 node-limited routing。
- **“auxiliary-loss-free”不是完全没有辅助损失**：主要负载均衡靠专家选择偏置，仍保留极小的 sequence-wise 辅助损失，α=0.0001。§2.1.2、§4.2。
- **MTP 深度 D=1**：在主模型预测下一个 token 外，额外预测一个 token；模块顺序衔接、保留因果链，与“两个独立并行输出头”不同。普通生成可丢弃 MTP 模块。§2.2、§4.2。
- 预训练序列为 4K，之后通过 YaRN 分两阶段扩至 32K、128K。§4.3。此教学实现只覆盖未扩展 RoPE 的核心架构。

## MLA：公式和形状

约定单 token 输入列向量 `h_t∈R^D`；批量实现为 `[B,T,D]`。`H=128, N=128, R=64, V=128, C=512, Cq=1536`。原论文 eq.1–11。

```text
c_t = RMSNorm(W_DKV h_t)                [C]      ← 共同的 KV latent
k^C_t,i = W_UK,i c_t                    [N]
v_t,i   = W_UV,i c_t                    [V]
k^R_t   = RoPE_t(W_KR h_t)              [R]      ← 所有头共享
c^Q_t   = RMSNorm(W_DQ h_t)             [Cq]
q^C_t,i = W_UQ,i c^Q_t                  [N]
q^R_t,i = RoPE_t(W_QR,i c^Q_t)          [R]
score_t,j,i = ((q^C_t,i)^T k^C_j,i + (q^R_t,i)^T k^R_j) / sqrt(N+R)
a_t,j,i = softmax_{j≤t}(score_t,j,i)     因果 softmax
o_t,i = Σ_{j≤t} a_t,j,i v_j,i
u_t = W_O concat_i(o_t,i)               [D]
```

论文 §2.1.1 的紧凑公式省略了 latent 后的 RMSNorm；§4.2 明确说明添加这些 norm，官方代码 `q_norm`、`kv_norm` 可验证。上式按实现展开，**不要把 RMSNorm 嵌入低秩矩阵后再任意移动**。

为何位置分支要拆开：内容项能写为 `q_Cᵀ W_UK c = (W_UKᵀ q_C)ᵀ c`，把升维矩阵吸收到 query 侧；值输出也能写成 `W_UV Σ_j(a_j c_j)`。位置旋转放在独立的小分支，因此不阻碍内容分支的矩阵吸收。

正确的 cache 示意是**每 token、每层保存 `c_KV [512] + k_R [64]`**；不是缓存每个头展开后的 K/V，也不缓存 Q。理论上是 576 个标量。同样 128 头、每头 128 维的标准 MHA 为 `2×128×128=32768` 个标量；这个比较只数元素，同精度、无元数据，**不是本实现的实测显存或速度结果**。本实现为便于学习仍展开 K/V；数值测试另用吸收形式核验代数等价，不实现推理 cache。

### 建议图解

1. 输入分三路：Q 压缩/升维、KV 共用压缩/升维、共享位置 K。内容分支用蓝色，位置分支用紫色；只有 Q_R、K_R 穿过旋转圆盘。
2. 主图区保留 Q、K、V 形状；切换“展开计算”与“理论推理 cache”时，K/V 大矩阵收拢为 `[512]+[64]`。切换标题必须写“原论文可用的 cache 表达”，不能显示为本地实测。
3. 用平滑扫描亮起下三角矩阵表达因果 mask；不把低秩缓存描述为线性时间注意力。MLA 的完整前缀 attention 仍依赖所有历史 token。

## MoE：选择与加权必须分两条路径

对 token 表示 `u∈R^D`，设路由器 `E∈R^(N_r×D)`：

```text
s_i = sigmoid(E_i · u)                              affinity
r_i = s_i + b_i                                     only for selection
G = TopGroups(sum(top2(r_i in group)), M=4)          8 groups → at most 4
I = TopK({r_i : group(i)∈G}, K=8)                    select routed experts
g_i = 2.5 · s_i / Σ_{j∈I} s_j    if i∈I; else 0     use original s, not r
MoE(u) = SharedSwiGLU(u) + Σ_{i∈I} g_i RoutedSwiGLU_i(u)
```

每个 SwiGLU：`W_down[SiLU(W_gate u) ⊙ (W_up u)]`。路由分支的权重和是 **2.5**；共享专家另以系数 1 相加。decoder 外层再作 residual，不应在 MoE 和 block 中重复加残差。论文 eq.12–16 定义 affinity、归一化和 bias；2.5、组内 top2 细节由官方推理配置/代码补足。

负载均衡时，每个 training step 统计**全 batch**专家负载；过载专家 `b_i -= γ`，不足专家 `b_i += γ`。不应把 `b_i` 加入最终 gate 权重，也不把此更新描述成通过任务 loss 反传学习。教学代码将 bias 注册为 buffer，默认 0，可加载/手动修改；未实现训练循环中的负载更新、跨设备聚合和辅助损失。

### 建议图解

以少量彩色专家作缩尺示意，明确标记“图为 8 选 2；原模型为 256 选 8 + 1 共享”。每个 token 一直流过共享专家，再流过两名路由专家；滑块改变 `b_i` 时，只移动选择高亮，选中同一组专家时原始权重保持不变。展示一个“最高单项落在 A 组，但 top2 之和 B 组更高”的小例子，能避免把组路由误写为 max。

## 可选 MTP 图解：区分训练附加模块与主干

论文 §2.2 eq.21–25，原版 `D=1`：

```text
main h_i^0 → main shared output head → target token t_(i+1)
    │
    ├─ RMSNorm ───────────────┐
    │                        concat → M_1 [D×2D] → causal TRM_1 → shared head → target t_(i+2)
Emb(ground-truth t_(i+1))     │
    └─ RMSNorm ──────────────┘
```

训练时 MTP 在位置 i 可以读取已位于目标 `t_(i+2)` 之前的真实 `t_(i+1)`；它不能看到所预测的 `t_(i+2)`。不要把这条分支接回主干预测 `t_(i+1)` 的输入而造成未来泄漏。embedding 与输出 head 和主干共享，MTP Transformer block 独立。附加目标为 `L_MTP=(λ/D)Σ_k CE(P^k,t_shifted_by_(k+1))`；这是训练目标，不要求普通自回归推理保留该模块。**本代码不包含 MTP**，图上建议用虚线框标注“论文训练扩展”。

## 完整 block 与 PyTorch 对照

```text
x = x + MLA(RMSNorm(x))
x = x + FFN(RMSNorm(x))    # layer 0..2: dense; layer 3..60: MoE
logits = LMHead(RMSNorm(DecoderStack(TokenEmbedding(ids))))
```

- `models/deepseek_v3.py` 为独立可运行 PyTorch 实现，无其它模型模块依赖。
- `DeepSeekLM(DeepSeekConfig())` 默认 tiny，输入 `[B,T]`，输出 `[B,T,V]`。语言模型 loss 将 `logits[:, :-1]` 与 `ids[:, 1:]` 对齐。
- `deepseek_v3_671b_config()` 只返回原始核心维度的 dataclass，**不分配 671B 权重**。
- 覆盖：完整 decoder、latent RMSNorm、query 压缩、KV 共同压缩、decoupled RoPE、因果 mask、sigmoid/group top-k/bias 语义、路由和共享 SwiGLU、final norm/head。
- 未覆盖：预训练权重/官方 tokenizer、YaRN、增量 KV cache、MTP 模块和损失、bias 自动负载更新、序列平衡损失、FP8、分布式 dispatch、生产优化。不是原模型复现训练或质量评测。
- `tests/test_deepseek.py` 检查前向/反向、因果前缀不变、bias 仅影响选择、组内 top2、展开 MLA 与独立吸收式 contraction 数值一致，以及 preset。

测试命令：

```bash
.venv/bin/python -m unittest discover -s tests -p 'test_deepseek.py' -v
.venv/bin/python models/deepseek_v3.py
```

已实测：2026-09-25，Python 3.11 / PyTorch 2.14.0+cpu，**6/6 测试通过**（0.618s）。单文件前向/反向示例输出 `shape=(2, 12, 256), next_token_loss=5.6355`。这是随机 tiny 模型的功能验证，不是预训练模型质量、生成性能或 cache 压缩率测量。

## 原始来源

1. [DeepSeek-V3 Technical Report, arXiv:2412.19437v2](https://arxiv.org/html/2412.19437v2)：§2.1.1 MLA eq.1–11；§2.1.2 DeepSeekMoE eq.12–20；§2.2 MTP；§4.2 规模及超参；§4.3 上下文扩展。快照：`sources/deepseek-paper.html`。
2. [DeepSeek 官方推理实现](https://github.com/deepseek-ai/DeepSeek-V3/blob/main/inference/model.py)：`MLA`、`Gate`、`MoE`、`Block`。快照：`sources/deepseek-model.py`。
3. [DeepSeek 官方 671B 配置](https://github.com/deepseek-ai/DeepSeek-V3/blob/main/inference/configs/config_671B.json)。快照：`sources/deepseek-config-671B.json`。

事实来自上述一手资料；gallery 可作导航，但不能代替模型版本、公式与参数的依据。
