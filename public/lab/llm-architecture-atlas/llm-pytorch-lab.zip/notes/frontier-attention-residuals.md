# Attention Residuals（2026-03-16）

来源：Kimi Team, arXiv:2603.15031v1，§3（Full / Block AttnRes）与官方 GitHub README伪代码。

- 对同一token的历史层输出做softmax聚合，注意力轴是**深度/来源**，不是序列位置。
- 每个消费子层有一个可学习pseudo-query w_l，源值v_i作为V，RMSNorm(v_i)作为K。weights依赖输入，因为keys来自当前样本。
- h_l = Σ_i softmax_i(w_l^T RMSNorm(v_i)) v_i。Value不经过该RMSNorm；不应误写成归一化value的平均。
- Full版本保留每层输出；Block版本对块内输出做普通残差求和，只在已完成块与当前partial sum间attention，减少存储源数。Embedding也作为源。
- 官方说每个attention / MLP算一个layer；Kimi K3报告的Transformer layer和block计数不可不加区分直接对比。
- models/attention_residuals.py实现实际可训练的深度聚合器以及from_blocks接口，**不是完整Kimi K3，也不管理网络块边界**。
- tests/test_attention_residuals.py覆盖zero-query时原始V的均值、softmax来源轴归一化、token不跨位混合、参数与输入梯度，以及partial sum纳入。
- 源论文HTML转换不完整，实际核实依据为下载PDF文字及官方README。

https://arxiv.org/abs/2603.15031
https://github.com/MoonshotAI/Attention-Residuals
