# Engram、mHC、DeepSeek-V4.1：独立章节深化记录

日期：2026-09-25。后续使用本记录与 `frontier-deepseek.md` 时，以本记录的最新交付范围为准。HTML、源码与来源文件都在本任务目录内；没有写入博客。

## 交付

- `web/chapters/engram.html`：第 06 章，规范化 → 多阶、多头 n-gram 哈希查表 → 当前状态门控 → 短卷积增强 → 残差；分清 backbone IDs 和 Engram canonical IDs、共享 Value 和逐流 Key、容量和读取带宽。
- `web/chapters/mhc.html`：第 07 章，pre/post/res 三路、动态系数、sigmoid/2sigmoid/Sinkhorn、有限迭代误差、凸组合及纯残差均值、跨层乘积、完整可运行 wrapper。
- `web/chapters/deepseek-v41.html`：第 10 章，40 层布局、CED 来源、CSA2 Full/Reindex/Reuse、每通道不重叠压缩、完成组可见性、层级候选池、SWA/global 联合 softmax、attention sink、inverse RoPE、Single-Pass mHC、Engram/MoE/vision、DSpark、cache 字节推导。
- `web/chapters/deepseek.css` 与 `deepseek.js`：三个章节的局部样式；V4.1 层布局、模式切换、候选块预算、cache 字节交互。Engram 和 Sinkhorn 沿用 `web/frontier.js` 的既有 ID 与交互。
- `models/frontier_modules.py`：原始 Engram 与 mHC 的 PyTorch 教学实现，保留独立单元测试。
- `models/deepseek_v41.py`：CED/CSA2 数学参考，含 `CSA2Config`、`GlobalKVState`、`SelectionState`、`ChannelCompressor`、`hierarchical_candidates`、`CSA2Reference`、`TinyCEDReference`。

## V4.1 参考实现的范围

实现不重叠逐通道 softmax 压缩；只公开已完成组，RoPE 位置取组首；Full 新建 global KV、index K 和稀疏选择；Reindex 复用同一 cache 对象，用当前 index Q 重新选择；Reuse 复用同一 cache 和选择对象。当前层始终生成 main Q 与 SWA KV。支持 block-max 候选池、最新可见 block 保留、sink 只进分母、相同旋转 latent 同时作为 K/V、输出逆 RoPE，以及分组低秩输出投影。

`TinyCEDReference` 的 encoder 为 SWA → Full(m=2) → Reuse，decoder 为 Full(m=1，来源是 encoder states) → Reindex → Reuse。每层使用 dense FFN 和单残差流。它没有集成真实 MoE、Single-Pass mHC、Engram、vision、DSpark、YaRN、量化、增量服务 cache、bounded replay 或分布式执行。每次完整前缀重算，不能宣称获得官方 prefill shortcut 的收益。

离散 top-k 的选择不会将 CE 梯度传给 index scores；reference 返回 scores 以支持独立目标，但没有复现官方 indexer 训练目标。固定小批次 CE 降低证明接线可训练，不能证明 indexer 已训练或模型质量。

## 一手资料新增核对

已有原始资料及 URL 见 `frontier-deepseek.md`。本轮继续核对官方 Hugging Face `deepseek-ai/DeepSeek-V4.1-Flash` 的推理源码（仓库 SHA `dba1be0a40aa45a94ad051997016db3960a90277`）：

- `sources/frontier-deepseek-v41-model.py`：Compressor、Indexer、select_candidate_blocks、Attention、Block、SharedAttentionRuntime 与 Transformer。
- `sources/frontier-deepseek-v41-inference-config.json`：模型维度、层来源、压缩比例、候选块和稀疏预算、计算精度。
- `sources/frontier-deepseek-v41-inference-readme.md`：官方推理使用范围。
- `sources/frontier-deepseek-v41-kernel.py`：`sparse_attn` 中 sink 加入 softmax 分母；FP4/MXFP4 数据与 scale 布局。
- `sources/frontier-deepseek-v41-paper.pdf` / `.txt`：49 页报告，重点 §2.2 CED、§2.3 CSA2、§2.4.1–4 Single-Pass / Engram / DSpark / FP4、§4.2.1 配置。

需要保留的科学边界：

1. `mHC` v1 为 **2025-12-31**，v2 为 2026-01-05；Engram v1 为 **2026-01-12**，v2 为 2026-07-12。V4.1 官方库创建于 **2026-09-10**，不根据 gallery 单独推断可用性。
2. 原始 Engram 章节采用论文 sigmoid(normalized dot / sqrt(D)) 简式；官方 demo 与 V4.1 inference gate 含 signed-square-root，明确作为版本差异。V4.1 去掉短卷积；独立原论文 Engram 教学实现保留它。
3. 原始 mHC 只约束 residual mixing 为近似双随机；pre/post 不做 softmax。有限 Sinkhorn 不保证精确行列和。全网络及动态 Jacobian 不因这个约束而严格保范数。
4. Single-Pass 只将 **pre** 系数延迟一个子层，post/res 仍由当前 hidden 生成；attention 与 FFN 之间也继续传递 pre。原始 wrapper 不能当作该机制实现。
5. V4.1 的 layer indices 全为 zero-based；KV 来源 `[2,8,14,20]`，index 来源 `[2,8,14,20,24,28,32,36]`。计数为 2 SWA、4 Full、4 Reindex、30 Reuse。
6. decoder 首个 Full 自身 top-k 扫描全历史，发布候选池供后续 Reindex 用；不是整个架构都具有固定搜索成本。最新可见 block 强制保留。
7. 890 bytes/token 仅为 growing global main KV 与 index K：source factor `3/2+1=2.5`，main KV `512/2+512/16=288` bytes，index K `128/2+128/32=68` bytes，共 `2.5*(288+68)=890`。同布局 BF16 是 3200 bytes/token。未计 SWA、权重、运行时与 allocator。
8. V4.1 主干预训练不含 MTP；DSpark 后续独立引入，目标梯度不回传 backbone。3 个 draft blocks 生成 5 个位置 base logits，再结合 Markov head 与置信度调度，不是独立生成后直接接受。

## 已执行验证

- `tests/test_frontier_modules.py`：8/8 通过，覆盖原始 mHC 归一化与反向、残差适配、Engram 哈希/门控/因果性等。
- `tests/test_deepseek_v41.py`：6/6 通过，0.627 秒；覆盖分组、Full/Reindex/Reuse 对象语义、候选预算及最新块、encoder source 和当前层职责、因果性及独立前缀、反向与离散 indexer 的梯度边界。
- root 执行 `train_advanced.py` 后的 `validation/advanced-training.json`：117,976 参数，logits `[4,32,256]`，CPU 单线程，seed 2026，固定同一批次 20 steps，CE `5.714528 → 2.608208`，梯度有限，0.708 秒。章节明确标注机械验证。
- `node --check web/chapters/deepseek.js`：通过。
- 三章 ID 无重复，所有 `@SOURCE` 指向存在的模型文件。
- root 发现的 KaTeX 不支持 `\\mbox` 已改为 `W_{\\text{token-layer}}`。最终全页 KaTeX、浏览器和移动端验收由 root 统一执行。
