# iLLaDA / Attention Residuals 独立深度章节：来源与验证

本次在当前任务内新增：

- `web/chapters/illada.html`：独立 iLLaDA 章节，保留全部既有 diffusion 互动 ID。
- `web/chapters/attention-residuals.html`：独立 Attention Residuals 章节，保留 query / bars 互动 ID。
- `web/chapters/diffusion-depth.css`、`diffusion-depth.js`：新增 loss 玩具、Block 调度演示。
- `models/block_attnres.py`、`tests/test_block_attnres.py`：完整 Block-AttnRes tiny causal LM 研究组合。

没有修改 iLLaDA 模型架构、root build/body/app/README、打包或训练脚本。后续导航、公式渲染、源码高亮和总测试结果由 root 集成。

## 一手证据复用

### iLLaDA

- `sources/frontier-llada-il-paper.pdf` / `.html`：*Improved Large Language Diffusion Models*, arXiv:2606.25331v1, 2026-06-24；§2.1 random masking / 1/t 目标 / backbone，§2.2 全段随机污染的 SFT，§2.3 分块可变长生成、选择题 confidence scoring。
- `sources/frontier-llada-il-config.json` / `frontier-llada-il-modeling.py`：32 层、4096 维、32/8 GQA、FFN 14336、共享 embedding/head、RoPE theta=10000，`is_causal=False`。
- `sources/frontier-llada-paper.pdf`：LLaDA 修订稿 v3，2025-10-18，原始方法首发 2025-02；Eq(3) 序列级目标，Appendix A Eq(10)(11) 反向转移和 time-free predictor，Algorithm 4/5。
- `sources/frontier-llada-guidelines.md`：`p=eps+(1-eps)*U`，只对 mask 位置计算 CE/p，再除 B×T；序列求和式到 per-token 版本的工程证据。
- `sources/frontier-llada-generate.py`：等步长的固定 transfer quota、confidence 排序、已提交 token 保留、逐块 variable-length 生成。页面将它与独立 Bernoulli 的理论逆转移分开。
- URL / SHA256 清单：`sources/frontier-llada-manifest.json`；详细版本说明：`notes/frontier-llada.md`。

章节没有把 `[MASK]` 与 attention padding mask 混同；没有把接口类名 ForCausalLM 当作真实因果性证据；明确旧 LLaDA 的 conditional SFT 与 iLLaDA 全段污染的区别。虽然条件采样时 prompt IDs 固定，双向隐藏表示仍随解掩码改变，故不能不加修改直接复用标准 AR KV cache；这不排斥论文提及的扩散专用近似 cache 工作。

### Attention Residuals

- `sources/frontier-attnres-paper.pdf` / `.txt`：*Attention Residuals*, arXiv:2603.15031v1, 2026-03-16。
- §3.1 Eq(2–4)：每个消费子层一个可学习 pseudo-query；Key 用源值的 RMSNorm；Value 为原始源值；score 是点积，无额外 1/√D；softmax 沿来源维度。
- §3.2 Eq(5)：完整块为各子层输出 f(h) 的和；当前 partial 为块内已执行子层的增量和。
- §3.2 Eq(6)：新块首子层只读 embedding / completed blocks，后续才追加当前 partial；最终输出层聚合全部 block representations。Figure 2 / 官方 README 明确 block_size 统计 ATTN+MLP，普通 decoder block 含两个子层。
- 官方 README：`sources/frontier-attnres-readme.md`；原仓库 <https://github.com/MoonshotAI/Attention-Residuals>。
- 来源清单：`sources/frontier-attnres-manifest.json`；原模块笔记 `notes/frontier-attention-residuals.md`。

章节按朴素逐子层聚合明确标出 Full 每 token O(L²D)、Block O(LND)，储存深度源分别 O(LD)、O(ND)，N≈ceil(L/S)，另有 embedding / partial 的常数项。这是深度聚合工作量及源表示驻留量，不是整模型训练激活总内存；论文的系统优化与这个普通 PyTorch 实现分开。

## 完整 BlockAttnResLM 的调度选择

`BlockAttnResConfig` 默认：vocab 256、dim 64、3 decoder blocks、4 Q / 2 KV heads、FFN 192，`block_size=2` **子层**。总共 6 个 alternating attention / MLP 子层。复用 `llama3.py` 中的实际 GQA/RoPE/SwiGLU，但不复用其 residual addition，以免把聚合输入再加入 partial。

```python
completed = [embedding]
partial = None
for i, (mixer, f) in enumerate(zip(mixers, sublayers)):
    h = mixer.from_blocks(completed, partial)
    v = f(h)
    partial = v if partial is None else partial + v
    if (i + 1) % block_size == 0 or i == last:
        completed.append(partial)
        partial = None
h_final = readout(completed)
logits = lm_head(final_norm(h_final))
```

重要边界：

1. `partial=None` 不等于新增一个零 Value；零源也会改变 softmax 分母。
2. 每个消费子层使用各自的 `AttentionResiduals`，最后 readout 也有独立 query。
3. partial 累加的是 f(h)，不是 h+f(h)，也不是中间 residual hidden state。
4. 支持奇数 S 以及最后不足 S 个子层的块；S=1 与 Full 的逐增量保存实现一致。
5. 完整模型输入 `[B,T]`、输出 `[B,T,V]`，有 embedding / final norm / head，可做正常因果 next-token CE。
6. 这是 Llama-style 研究组合，不是 Kimi K3。K3 专用集成实例采用不同报告口径和模型模块，必须独立标注；没有把本例子当作 K3 权重或完整系统复现。

## Python 实测

命令：

```bash
.venv/bin/python -m unittest tests.test_attention_residuals tests.test_block_attnres -v
.venv/bin/python models/block_attnres.py
```

2026-09-25，PyTorch 2.14.0+cpu：**7/7 通过**（已有聚合器 3 项 + 新增完整调度 4 项），本次输出耗时 0.659 s。新增测试：

- 6 个常数输出 1…6、S=4、embedding=2 时，完整块应为 10 和 11，最终零 query 的输出为 `(2+10+11)/3`。还检查每个子层真实 source 数为 `[1,2,2,2,2,3]`。
- S=1 与独立 Full AttnRes 循环对照，不依赖 block scheduler。
- S=3 跨 decoder 边界时完整网络仍保持因果前缀，短 prefix 与完整序列对应位置一致。
- 所有参数有限梯度；首层单 source 的 query 梯度为 0 正常，深层和 readout query 的梯度非零。

独立运行完整模型：`logits=(2,10,256), next_token_loss=5.770648`，6 子层、S=2、181568 参数，反向传播成功。

root 的 `train_advanced.py` 实跑结果来自 `validation/advanced-training.json`：BlockAttnResLM 20 步，固定 batch `[4,32,256]`，CE `5.753190 → 2.195022`，梯度有限；它只验证优化链路，未声称论文精度或速度。

iLLaDA 结构保持不变；已记录的 `validation/diffusion.json` 为 123264 参数，20 步，固定 target/noise/mask/p，masked loss `5.179800 → 2.786543`。页面保留这个精确范围，不与 AR CE 横向比较。

## 新交互的数学与验收

### 4-token mask loss 玩具

固定 CE `[0.2,0.7,1.2,2.0]`；这是为了隔离“抽中概率”和“逆概率补偿”的数学玩具，不是真实预测器。

- 默认 `#dd-loss-p=0.5`，mask 位置为 1、3。正确值 `#dd-loss-correct=0.700`；误用 masked-count 分母则为 `1.400`。
- 把 p 改成 0.25，保持 mask 不变，正确本次值应为 `1.400`。
- 对全部 16 种 mask 模式枚举、按概率加权，`#dd-loss-expectation[data-expectation]` 在任意 p∈[0.1,1] 应为 `1.025`；容忍浮点舍入误差。
- 点击 `#dd-loss-tokens button[aria-pressed=true]` 使全部位置未遮后，正确本次值为 0；错误式明确显示 0/0 未定义。
- `#dd-loss-resample` 按当前 p 独立随机决定每个位置是否 mask；不强制抽中任何位置。

真实 loss 的 CE 随整段污染变化，因此页面使用条件恒等式 `E[m_i*ell_i(X_p)/p | p] = E[ell_i(X_p) | m_i=1,p]` 解释抽样权重，而未声称真实目标对 p 恒定。

### Block 深度调度

S=2、6 子层，`#dd-depth-step` 逐次推进，`#dd-depth-sources[data-source-count]` 为 `[1,2,2,3,3,4,4]`，最后是独立 readout。最后按钮 disabled，`#dd-depth-reset` 回 stage 0 / source count 1。

原 ID `diffusion-mask-grid`、`diffusion-step/play/reset/slots/status`、`attnres-query/value/bars` 每项均保留且章节内唯一；原 `frontier.js` 继续管理这些控件。新增 JS 使用 IIFE，不向 root 全局新增同名变量。

## 静态检查与集成边界

- 两个 HTML 顶层均为指定 `section.section.frontier-chapter`，ID 分别 `illada`、`attention-residuals`。
- HTML parser 检查：两章均无重复 ID。
- `node --check web/chapters/diffusion-depth.js` 通过。
- 使用现有 KaTeX 0.18.9 对两章 11 个 display formulas 逐一 `throwOnError:true` 渲染通过。曾发现 cases 换行后的 `[` 被误解为行距选项，已改成 `\left[...\right]` 并复验。
- 完整源码占位 `@SOURCE:models/block_attnres.py@` 位于 `details > pre.full-code > code`，由 root build 统一替换高亮源码。
- 最终整页浏览器布局、旧控件兼容、导航和字体打包由 root 集成验收；本子任务没有修改 root 构建脚本。
