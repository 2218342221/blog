# Llama 3 8B：用一个稠密解码器讲清现代 Transformer

**范围：2024-04-18 发布的原始 Llama 3 8B，8,192 token 上下文；不是 Llama 3.1。** 同类稠密 decoder 不再重复选入。本目录实现完整可反向传播的同构 tiny 模型，不包含训练权重。

## 已核实配置

| 项目 | 原始 Llama 3 8B | 本教学默认 tiny |
|---|---:|---:|
| decoder 层数 L | 32 | 2 |
| 模型宽度 D | 4,096 | 128 |
| query 头 Hq | 32 | 4 |
| key/value 头 Hkv | 8 | 2 |
| 每头维度 d=D/Hq | 128 | 32 |
| SwiGLU 中间维度 F | 14,336 | 384 |
| 完整词表 V | 128,256 | 256 |
| 最大输入长度 | 8,192 | 256 |
| RoPE θ | 500,000；无 scaling | 500,000 |
| RMSNorm ε | 10⁻⁵ | 10⁻⁵ |
| embedding / LM head | 不共享权重 | 不共享权重 |
| 线性投影 bias / attention dropout | 无 / 0 | 无 / 0 |

32 × 4,096 等主体参数见 [Llama 3 论文 §3.2 / Table 3](https://arxiv.org/html/2407.21783#S3.SS2)。April 发布日和 8K 上下文见 [Meta 原始 model card](https://github.com/meta-llama/llama3/blob/main/MODEL_CARD.md)。128,256 的精确词表大小等由 [PyTorch/Meta torchtune llama3_8b](https://github.com/pytorch/torchtune/blob/main/torchtune/models/llama3/_model_builders.py) 及 [公开 HF 配置](https://huggingface.co/NousResearch/Meta-Llama-3-8B/blob/main/config.json) 交叉核实。论文表中的 128,000 是其记法；不能拿它当完整 embedding 行数。

**取证边界：** Meta 官方 HF config 的 raw / blob 链接本次返回 401，需要该模型访问授权，因此没有把它标为已读来源。HF 精确配置来自 NousResearch 的公开副本，关键字段同时由 torchtune 证实。论文 §3.4.2 还介绍后续 128K 长上下文训练，不能把这一段移植为 April 模型配置。下载件及失败响应均保留在 `sources/llama3_*`。

## 1. 全局：先归一化，再计算，再加回残差

令 X∈ℝ[B,T,D]。每层：

```tex
H = X + GQA(RMSNorm_1(X))
Y = H + SwiGLU(RMSNorm_2(H))
logits = RMSNorm_final(X_L) W_out ∈ R^{B×T×V}
```

输入为 token ID [B,T]，embedding 后得到 [B,T,D]。32 层结构相同、参数独立。输出是每个位置对下一个 token 的未归一化分数，softmax 和采样属于模型外部使用流程。

**图：** 自下而上画 Embedding → 32 × Decoder → Final RMSNorm → Linear → logits；放大单层成两段，RMSNorm → GQA → ⊕，RMSNorm → SwiGLU → ⊕。两条残差线分别跨过各自子层；不要把两个归一化画成共用或 post-norm。动画可让 token 光点沿主路和残差旁路同时移动。

对应：`LlamaLM`、`LlamaBlock`；Meta 官方 `TransformerBlock.forward`。

## 2. RMSNorm：保留方向，以均方根调整尺度

对每个 token 的向量 x∈ℝᴰ：

```tex
RMSNorm(x)_i = γ_i x_i / sqrt((1/D) sum_j x_j² + ε), γ∈R^D
```

没有减去均值，也没有额外 bias；γ 是每个特征的可学习缩放。本实现与 Meta 一样先用 float32 计算统计量。

**图：** 4 根带正负号的柱子 → “平方 / 平均 / +ε / 开方”小计算带 → 统一缩放 → γ 逐维缩放。保留坐标轴，让读者看到这不是强行中心化到零。

对应：`RMSNorm.forward`。来源：[RMSNorm 原论文 §4 / Eq.(4)](https://arxiv.org/abs/1910.07467)；ε 与具体应用以 Meta 实现为准。

## 3. GQA：四个 Q 头共享一组 K/V

数学中采用右乘权重；PyTorch `nn.Linear` 内部保存的是其转置。

```tex
Q=reshape_heads(XW_Q) ∈ R^{B×32×T×128}
K=reshape_heads(XW_K), V=reshape_heads(XW_V) ∈ R^{B×8×T×128}
g(h)=floor(h/4), h=0,...,31
A_h=softmax(Q'_h (K'_{g(h)})^T / sqrt(128) + M) V_{g(h)}
M_{t,s}=0 if s≤t else -∞
GQA(X)=Concat_h(A_h) W_O ∈ R^{B×T×4096}
```

Q′、K′ 表示做完 RoPE；V 不旋转。每个 Q 头仍有独立的注意力分布，共享的是 K/V 投影与缓存。注意力算子仍是序列长度的二次关系，GQA 的主旨并不是把全局注意力变为线性时间。

**图：** 展示 8 个分组，每组上方 4 个不同颜色/编号的 Q，下方一个 K 和一个 V，通过连线表达共享。可用头数切换器展示 MHA (32 KV) → GQA (8 KV) → MQA (1 KV)，所有状态保持 32 个 Q。右侧放因果下三角热力图，禁止未来区域打叉。

缓存量（真实带 cache 的推理实现；只算 K/V 张量，不含分配开销）：`2 × B × L × T × Hkv × d × bytes`。B=1、L=32、T=8192、BF16 时 GQA 约 1 GiB，其他条件相同的 32-KV-head MHA 约 4 GiB；不能把 4 倍缓存节省说成固定 4 倍速度提升。本教学实现没有缓存，并显式 `repeat_interleave` 便于读懂，因此不是缓存效率 benchmark。

对应：`GQAAttention` / `causal_gqa`。来源：[GQA 原论文 §2.2 / Figure 2](https://arxiv.org/abs/2305.13245)、Llama 3 §3.2、Meta `repeat_kv` 与 `Attention.forward`。

## 4. RoPE：位置成为二维旋转角

对每头维度 d=128，相邻的两个实数构成一对，共 64 对。第 j 对的频率 ω_j=θ^(−2j/d)，位置 t 的角度 φ=tω_j，θ=500000：

```tex
[q'_{2j}, q'_{2j+1}]^T = [[cos φ,-sin φ],[sin φ,cos φ]] [q_{2j},q_{2j+1}]^T
(R_m q)^T(R_n k) = q^T R_{n-m} k
```

相对位置信息进入 Q·K；不需要向 token embedding 加一个位置向量。增大 θ 会改变各频率，不能单凭 θ 推导模型已训练或可靠支持的上下文长度。

**图：** 单位圆上 q/k 两根向量；位置 slider 同时或分别旋转它们，实时显示角差。下面用 4 个小圆演示低 j 快转、高 j 慢转。清楚注明只画一个二维子空间；实际有 64 对。动画可暂停，并遵循 reduced-motion。

对应：`RoPE.forward`。Meta 官方使用相邻实/虚配对，教学代码以实数 sin/cos 写出同一运算。部分 HF 实现使用半区配对并相应排列 Q/K 权重，本实现未实现这种 checkpoint 权重转换，不承诺直接加载 HF 权重。来源：[RoFormer 原论文 §3.2](https://arxiv.org/abs/2104.09864)、Meta `apply_rotary_emb`。

## 5. SwiGLU：门支路 × 值支路 → 压回模型维度

```tex
G = SiLU(X W_gate), U=X W_up          # both [B,T,14336]
SiLU(z)=z sigmoid(z)
SwiGLU(X)=(G⊙U) W_down              # [B,T,4096]
W_gate,W_up ∈ R^{4096×14336}, W_down ∈ R^{14336×4096}
```

有三组线性权重；`SiLU` 只作用在门分支，而不是两条分支都激活。门值不被限制在 [0,1]，因此不要把它画成只会开/关的概率开关。

**图：** 输入分叉 → W_gate → SiLU 与 W_up 并列 → 逐元素乘号 → W_down；每段标形状。可提供小数字例子，拖动一个门输入，乘积柱随之变化；SiLU 曲线要保留负值区域。

对应：`SwiGLU.forward`，Meta w1=gate / w3=up / w2=down。来源：[GLU Variants Improve Transformer 原论文 §2 / Eq.(6)](https://arxiv.org/abs/2002.05202)、Meta `FeedForward.forward`。

## 实现与复现

```python
from models.llama3 import LlamaConfig, LlamaLM
import torch
model = LlamaLM()                    # 459,392 params, random tiny model
ids = torch.randint(256, (2, 12))
logits = model(ids)                  # [2, 12, 256]
production_config = LlamaConfig.llama3_8b()  # only a dataclass; does NOT allocate 8B
```

```bash
.venv/bin/python models/llama3.py
.venv/bin/python -m unittest discover -s tests -p test_llama3.py -v
```

完整 8B preset 参数量按这些矩阵计为 8,030,261,248（不初始化大模型）；FP32 权重约 32.1 GB，另有激活、梯度、优化器状态，不适合默认 CPU 演示。Tiny 模型使用 PyTorch 默认随机初始化；缩小了层数/宽度/词表/上下文，但保留 GQA + RoPE + RMSNorm + SwiGLU + 双残差 + 最终归一化 + 独立 LM head。

**边界：** 无 tokenizer、无预训练权重、无文本生成包装、无高效 KV cache、无 distributed/tensor parallel、无 packed-document/padding mask、无训练数据配方。输入每行视为一条无 padding 的独立序列。Meta 发布仓库是 inference-mode 加 cache；教学版允许 backward，以便通过因果性和梯度验证。

测试包括：下一 token loss 的全部参数有限梯度；修改未来 token 不影响前缀 logits；完整序列与单独前缀一致；GQA 与逐头逐位置独立手算 softmax 参考一致；RoPE 保范数及共同平移后的内积不变；8B preset 不分配模型。
