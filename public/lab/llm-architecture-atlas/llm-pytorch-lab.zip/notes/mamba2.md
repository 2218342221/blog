# Mamba-2 / SSD：来源核实与实现说明

核实日期：2026-09-25。选取 **纯 Mamba-2 2.7B** 作为选择性状态空间架构代表，核心资料是 Dao & Gu, *Transformers are SSMs: Generalized Models and Efficient Algorithms Through Structured State Space Duality* (2024, arXiv:2405.21060v1)。这里不把 Mamba-2-Attention 混合模型的结构或测评结果归给纯模型。

## 可直接用于页面的短结论

- Transformer 保留历史 K/V，Mamba-2 把历史逐步压入固定尺寸状态；这种压缩存在容量取舍，不能笼统宣称更优。
- Δ、B、C 随 token 改变；连续时间 A 是每个 head 的一个可学习负标量。离散衰减 a=exp(ΔA) 因 Δ 而随输入改变。
- SSD 把同一个算子写成**递归状态更新**和**带结构掩码的核注意力矩阵**。这是精确代数等价，不是与 softmax attention 等价。
- Mamba-2 的额外 RMSNorm 在 SiLU gate **之后**。把它写成 RMSNorm(y)×SiLU(z) 会改变模型。
- 原生 SSD 通过分块矩阵乘法和块间 scan 加速；本页面 PyTorch 实现提供顺序参考与显式矩阵参考，验证结构和等价性，不复现论文速度。

## 可核验的发布配置

来源：[官方 HF config](https://huggingface.co/state-spaces/mamba2-2.7b/blob/main/config.json)、[官方 v2.2.2 Mamba2 默认参数](https://github.com/state-spaces/mamba/blob/v2.2.2/mamba_ssm/modules/mamba2.py)、论文 §9.2.3。

| 项目 | 纯 Mamba-2 2.7B | 本地 tiny 教学配置 |
|---|---:|---:|
| d_model | 2560 | 64 |
| SSD residual blocks | 64 | 2 |
| expand | 2 | 2 |
| d_inner = expand×d_model | 5120 | 128 |
| P = headdim | 64 | 16 |
| H = d_inner/P | 80 | 8 |
| N = state dimension | 128 | 16 |
| G = B/C groups | 1 | 1 |
| causal depthwise conv kernel | 4 | 4 |
| vocab_size | config 50277；实现 pad 到 50288 | 256 |
| embedding / output head | tied | tied |
| attention layers | 0 | 0 |
| 单独的 FFN/MLP layers | 0 | 0 |

HF config 中 `ssm_cfg` 只有 `layer: Mamba2`，因此 N/P/expand/G 取上述官方类默认值。**不要误用 `mamba2_simple.py` 的默认 N=64、P=128 充当发布 2.7B 配置。** 附录 D.3 的 “GPT3 specification (32 layers)” 采用 Transformer 块规格；§9.2.3 与模型 config 明确纯模型是 64 个 SSD blocks。

## 模块图：必须保留的路径

```text
token ids [b,T]
  │ Embedding → [b,T,d]
  ▼
┌────────────────────────────────────────────── × L ─┐
│ u ─────────────── residual ──────────────────────┐ │
│ │ RMSNorm                                      │ │
│ │ Linear：一次产生 z、x_raw、B_raw、C_raw、Δ_raw  │ │
│ ├─ z ─────────────────────── SiLU ────────┐     │ │
│ ├─ Δ_raw → softplus(+bias) → Δ           │     │ │
│ └─ [x_raw, B_raw, C_raw]                  │     │ │
│       │ causal depthwise conv + SiLU     │     │ │
│       └─ x, B, C → SSD(Δ, A=-exp(A_log)) │     │ │
│                  │                       │     │ │
│                  └── + D·x → × gate ─────┘     │ │
│                              │ RMSNorm         │ │
│                              │ Linear out      │ │
│                              └────────── + ────┘ │
└──────────────────────────────────────────────────┘
  │ final RMSNorm
  └ Linear head → logits [b,T,V]
```

位置依赖来自因果卷积和状态递推；本模型没有额外的 RoPE/位置 embedding。卷积作用于 x/B/C，**不作用于 z 或 Δ**。Δ、B、C 是输入相关量；A_log 和 D 是模型参数。

## 精确公式与 shape

忽略 batch，设输入 U∈R^{T×d}，内部宽度 I=e·d=H·P，状态宽度 N，B/C 分组数 G | H。使用行/列向量约定时，下面状态定义为 P×N。

\[
[Z,X_0,B_0,C_0,R]=UW_{in},\quad
\Delta_{t,h}=\operatorname{softplus}(R_{t,h}+b_{\Delta,h}),\quad
A_h=-\exp(\theta_h).
\]

\[
(X,B,C)=\operatorname{split}\Big(\operatorname{SiLU}\big(\operatorname{DWConv}_{causal}(\operatorname{concat}(X_0,B_0,C_0))\big)\Big).
\]

维度：Z∈R^{T×I}；X∈R^{T×H×P}；B,C∈R^{T×G×N}；Δ∈R^{T×H}；A,D∈R^H。每个 head 选择所属组 g(h)=⌊h/(H/G)⌋。G=1 时所有 head 共用 B/C，但各自有 X、A、Δ、D。

\[
S_{t,h}=\underbrace{e^{\Delta_{t,h}A_h}}_{a_{t,h}\in(0,1)}S_{t-1,h}
       +\Delta_{t,h}X_{t,h}B_{t,g(h)}^\top,
\quad S_{-1,h}=0,\quad S_{t,h}\in\mathbb R^{P\times N}.
\]

\[
Y_{t,h}=S_{t,h}C_{t,g(h)}+D_hX_{t,h},\quad
O=\operatorname{RMSNorm}(\operatorname{flatten}(Y)\odot\operatorname{SiLU}(Z))W_{out}.
\]

RMSNorm(r)=γ⊙r/√(mean(r²)+ε)，无减均值。G>1 时额外 norm 分 G 组，每组 I/G 维；G=1 时对全部 I 维归一化。残差块为 U+Mixer(RMSNorm(U))。论文 §2 为简化符号使用离散 A，工程代码则显式使用 A_cont 与 Δ；页面应区分 A_h 与 a_{t,h}，避免把固定 A_h 误写成 token 相关。

**离散化边界：** 上式遵从官方 `Mamba2.step` 与 `ssd_minimal_discrete(x*dt, A*dt, ...)`，输入项是 Δ·X·Bᵀ。不要称它为对 B 使用精确 ZOH；精确常输入 ZOH 会包含 (e^{ΔA}−1)/A 而非 Δ。

## SSD 对偶：同一个结果，两种计算

对单个 head，递推展开得到：

\[
L_{ij}=\begin{cases}
\exp\left(\sum_{k=j+1}^{i}\Delta_kA\right)&i\ge j,\\
0&i<j.
\end{cases}
\qquad M=L\odot(CB^\top),\qquad
Y=M(\Delta\odot X)+D\odot X.
\]

注意对角线 L_ii=1，指数**不包含 j 自己**；Δ_j 已乘在写入向量上。B 对应 key，C 对应 query，X 对应 value。M 没有 softmax、没有 1/√N、没有强制行和为 1，其元素也不保证非负。

页面动图可以把同一次写入 j 依次经过 a_{j+1},a_{j+2},… 的连乘染色，再切换到下三角矩阵中同一列；两种视角应保留同一数值。对照公式来自论文 §5.1 Eq(16)，不是经验类比。

### 为什么能并行：关联 scan 与 chunk SSD

一次更新可以写作仿射映射 `(a_t, b_t)`：S↦a_t S+b_t，其中 b_t=Δ_t X_t B_tᵀ。先1再2的组合为：

\[
(a_2,b_2)\circ(a_1,b_1)=(a_2a_1,\;a_2b_1+b_2).
\]

组合满足结合律，故可用树形 prefix scan 计算前缀，而不用等待逐 token 的串行循环。这里的 “并行” 不允许看未来；因果性是算子的性质，执行顺序可以重排。

论文 §6 / Listing 1 的硬件高效 SSD 进一步把下三角矩阵分块：

1. 每块内部用小下三角矩阵计算 block 内输出（diagonal blocks）。
2. 把每块输入压缩为 block 末端状态（B-side / right factors）。
3. 对块末端状态做较短的块间 scan（A-side / center factors）。
4. 把流入状态展开到各块输出，叠加块内输出（C-side / left factors）。

块外严格下三角子矩阵具有≤N 的秩结构；高效实现利用这个分解，不显式保存 T×T 全矩阵。对于固定 N/P/块长，序列长度方向工作量为线性；这不表示状态维度、FFN/投影成本不存在。论文的 2–8× 为特定 GPU/形状下 SSD kernel 相对于 Mamba fused scan 的测量，不能归到本 CPU 教学实现或整个服务。

## PyTorch 实现 / 可复现实测

文件 `models/mamba2.py`：`Mamba2Config`, `Mamba2LM`, `ssd_recurrent`, `ssd_matrix`。LM 含 embedding、完整因果 residual stack、final norm、tied output head，可做 next-token cross-entropy 和反向传播。

```python
import torch
from models.mamba2 import Mamba2Config, Mamba2LM

model = Mamba2LM(Mamba2Config())
ids = torch.randint(0, 256, (2, 17))
logits = model(ids[:, :-1])  # [2,16,256]
loss = torch.nn.functional.cross_entropy(
    logits.flatten(0, 1), ids[:, 1:].flatten())
loss.backward()
```

核心递推代码（整个 batch/head 并行，time 顺序）：

```python
decay = torch.exp(dt[:, t] * A)  # [batch,heads]
write = torch.einsum("bhp,bhn->bhpn", x[:, t], B[:, t])
state = decay[..., None, None] * state + dt[:, t, :, None, None] * write
y = torch.einsum("bhpn,bhn->bhp", state, C[:, t]) + D[None,:,None] * x[:, t]
```

**实现边界：** 随机初始化，无预训练权重、无 tokenizer、不兼容官方 checkpoint 命名；顺序 reference 无 fused CUDA/硬件加速优势；matrix reference 需要 O(T²) memory，仅用于解释和验证；没有 generation cache、变长 packed sequence、tensor/sequence parallel、官方训练 recipe。官方模型可在推理时缓存固定尺寸 SSM state 与 conv state；本 tiny forward 重算整个 prefix，因此不能用它测缓存推理吞吐。BF16/FP16 时内部状态和 norm 升至 FP32，FP64 数值验证保留 FP64。训练反传存储会随 T 增长。

```bash
.venv/bin/python -m unittest tests.test_mamba2 -v
.venv/bin/python models/mamba2.py
```

测试设计：float64 随机样例比较 recurrence/matrix 的输出和 x/Δ/A/B/C/D 梯度；G=2 确保 grouped B/C 分配正确；整 LM 未来 token 扰动不改变 prefix logits、短 prefix 等价和卷积 kernel=1/4；两个 SSD backend 整模型等价；所有参数有限且非零梯度。

实测结果（2026-09-25，PyTorch 2.14.0+cpu）：3/3 unittest 通过，耗时 2.211 s；独立运行完整 LM 脚本输出 `logits=(2, 16, 256), loss=5.549239`，反向传播完成。这里的 loss 来自随机 token 和随机初始化，只验证可运行训练路径，不代表模型质量。测试期间提示未安装 NumPy，但纯 Torch 路径成功，不使用 NumPy。

## 原始资料定位

| 核实项 | 原始来源 |
|---|---|
| 连续/离散符号区别 | [论文 §2 / Remark 1](https://arxiv.org/html/2405.21060v1#S2) |
| scalar-identity A 与结构核注意力 | [论文 §5.1 / Eq(16)](https://arxiv.org/html/2405.21060v1#S5.SS1) |
| 四步分块 SSD | [论文 §6 / Listing 1](https://arxiv.org/html/2405.21060v1#S6) 与 [ssd_minimal.py](https://github.com/state-spaces/mamba/blob/main/mamba_ssm/modules/ssd_minimal.py) |
| 模块路径、gate 后 norm | [论文 §7.1 / Fig6](https://arxiv.org/html/2405.21060v1#S7.SS1) |
| 多 head / 共享 B,C | 论文 §7.2 / Eq(20) |
| SiLU feature map | 论文 §7.3 |
| 纯与 hybrid 的层数组合 | 论文 §9.2.3 / Table3 |
| 2.7B 配置与 padding、tie | [HF config](https://huggingface.co/state-spaces/mamba2-2.7b/blob/main/config.json) 与 [mixer_seq_simple.py](https://github.com/state-spaces/mamba/blob/main/mamba_ssm/models/mixer_seq_simple.py) |
| 真实每 head A/D、ΔB 写入、conv 路径 | [官方 mamba2.py v2.2.2](https://github.com/state-spaces/mamba/blob/v2.2.2/mamba_ssm/modules/mamba2.py) `__init__`, `forward`, `step` |
| gate 后 RMSNorm 的精确公式 | [layernorm_gated.py](https://github.com/state-spaces/mamba/blob/main/mamba_ssm/ops/triton/layernorm_gated.py) `rms_norm_ref` |

已保存原始资料在当前任务的 `sources/mamba*`。固定版本源码文件为 `mamba2_v2.2.2.py`；额外 main 快照用于交叉核验，其内容会随上游更新。
