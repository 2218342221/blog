# Kimi Linear、Attention Residuals 与 Kimi K3：新增架构取证

核实日期：2026-09-25。**Kimi Linear 48B-A3B（2025）** 与 **Kimi K3（2026）** 现均有独立深入章节和完整 tiny 文本 LM；**Attention Residuals（2026-03）** 有独立论文章节和研究网络。本文件保留原始取证，最新 K3 实现、7 项测试及边界调度见 [deep-kimi.md](deep-kimi.md)。Kimi K3 的事实已读取官方报告和官方 HF 配置，未把 gallery 元数据当成原文。

## 一屏事实

- Kimi Linear：发布标称 **48B 总参数 / 3B 每 token 激活**，27 个 decoder block，实际 **20 KDA + 7 MLA**。MLA 位于 1-based 层号 **4、8、12、16、20、24、27**。主体 3∶1，末尾只有 2 KDA + 1 MLA，不能画成 21+7。
- KDA 把 Gated DeltaNet 的每头标量遗忘，变成 **每个 key 通道自己的 α**；先衰减历史状态，再按当前 key 上的 value 预测误差纠错。
- KDA 的 Q/K/V 各自经过因果 depthwise ShortConv + SiLU，Q/K 再做 L2 归一化；输出是 **headwise RMSNorm(y) × sigmoid(gate)**。这与 Mamba-2 的 gate 后 norm 顺序不同。
- 全 MLA 层使用 **NoPE**。但仍保留 **128 维内容 + 64 维共享 Key 支路**，Q/K 总宽 192，除以 √192；64 维支路不再施加 RoPE，不能直接删掉。Q 直接投影，`q_lora_rank=null`。
- 第一层 FFN 为 dense SwiGLU，其余 26 层使用 **256 路由专家选 8 + 1 始终激活共享专家**；只有 1 个专家组，route scale **2.446**。与 DeepSeek-V3 的 8 组/选 4 组不同。
- 公开原模型上下文配置是 **1,048,576**。NoPE 不等于缺少顺序信息：KDA 递推和短因果卷积提供序列顺序依赖。整体混合模型仍有全注意力层，不能把全部模型称为对长度严格线性复杂度。

主要来源：[Kimi Linear 原论文 §3 Eq.(1)、§4 Eq.(10)](https://arxiv.org/html/2510.26692#S3)，[Moonshot 官方 config](https://huggingface.co/moonshotai/Kimi-Linear-48B-A3B-Base/blob/main/config.json)，[官方 modeling_kimi.py](https://huggingface.co/moonshotai/Kimi-Linear-48B-A3B-Base/blob/main/modeling_kimi.py)。

## 原配置与 tiny 的对应

| 项目 | 48B-A3B 发布配置 | 本实现默认 |
|---|---:|---:|
| 总层数 / MLA 层号 | 27 / 4,8,12,16,20,24,27 | 4 / 4 |
| 模型宽度 D | 2304 | 64 |
| KDA heads × key/value head dim | 32 × 128 | 4 × 16 |
| KDA 短卷积核 | 4 | 4 |
| KDA forget/output gate 的低秩 rank | 128 | 16 |
| MLA heads | 32 | 4 |
| MLA 每头内容 / 共享支路 / value | 128 / 64 / 128 | 16 / 8 / 16 |
| KV latent | 512 | 24 |
| 前置 dense 层数 / FFN 中间宽度 | 1 / 9216 | 1 / 128 |
| 路由专家数 / 每 token 选取 | 256 / 8 | 8 / 2 |
| 共享专家数 / 专家中间宽度 | 1 / 1024 | 1 / 48 |
| route scale | 2.446 | 2.446 |
| 词表 | 163840 | 256 |
| 最大输入长度 | 1048576 | 256 |
| embedding 与 LM head | 不绑权 | 不绑权 |

公开 config 的通用 `head_dim=72` 不应替代 KDA 专用 `linear_attn_config.head_dim=128`，也不是 MLA 的 192 维 Q/K。decoder 与 KDA output norm 的 ε=10⁻⁵；公开 HF `KimiMLAAttention` 的 KV latent norm 没有传 config ε，实际采用该类默认 **10⁻⁶**，教学版分开保留。

`KimiLinearConfig.kimi_linear_48b_a3b()` 只返回配置，不初始化巨大模型。默认 tiny 保留结构、门控与 FFN 类型，使用随机权重。

## KDA：遗忘、预测、纠错、读取

忽略 batch/head：qₜ,kₜ∈ℝᴷ，vₜ,oₜ∈ℝⱽ，Sₜ∈ℝᴷˣⱽ，αₜ∈(0,1)ᴷ，βₜ∈(0,1)。原模型 K=V=128。

```tex
S̄_t = diag(α_t) S_{t-1}
δ_t = v_t - S̄_t^T k_t
S_t = S̄_t + β_t k_t δ_t^T
    = (I - β_t k_t k_t^T) diag(α_t) S_{t-1} + β_t k_t v_t^T
o_t = S_t^T q_t
```

这是 [§3 Eq.(1)](https://arxiv.org/html/2510.26692#S3) 的等价展开。**diag(α) 在右侧作用于旧状态，必须先衰减，再预测旧 value**；把衰减放到纠错之后会改变算子。`diag(α)` 缩放状态的 key 行，不是 value 列。β=1、α=1、单位长度的同一 key 再次写入时，修正该关联，使当前 key 读出新 value；并非把新旧 value 一直相加。

实际神经参数化（[§4](https://arxiv.org/html/2510.26692#S4) 与官方/FLA 实现）：

```tex
q,k = L2Norm(SiLU(CausalDWConv(W_{q/k} x)))          # [B,T,H,K]
v   = SiLU(CausalDWConv(W_v x))                    # [B,T,H,V]
f   = reshape_heads(W_f↑ W_f↓ x)                  # [B,T,H,K]
log α_{t,h,c} = -exp(Alog_h) softplus(f_{t,h,c} + b_{h,c})
β = sigmoid(W_β x)                                # [B,T,H]
g = sigmoid(reshape_heads(W_g↑ W_g↓ x))            # [B,T,H,V]
output = W_o flatten_heads(RMSNorm_head(KDA(q,k,v,α,β)) ⊙ g)
```

forget/output gate 两个低秩投影的 rank 都等于单头维度，而非所有头的总宽度。`Alog` 是每头参数，`b` 是每头每通道参数；α 最终因输入变化。原论文的简式不单写 Query 缩放，FLA KDA 默认对 q 再乘 **K⁻¹ᐟ²**，本实现照此执行。FLA L2 计算为 `x / sqrt(sum(x²)+1e-6)`；不是 RMSNorm，也不是 PyTorch `F.normalize` 的 `max(norm, eps)` 约定。

对应代码：`KimiDeltaAttention`、`CausalShortConv`、`l2_normalize`、`kda_recurrent`。核心实现：

```python
forgotten = state * log_decay[:, t].exp()[..., None]
prediction = torch.einsum('bhk,bhkv->bhv', k[:, t], forgotten)
error = v[:, t] - prediction
state = forgotten + beta[:, t, :, None, None] * torch.einsum('bhk,bhv->bhkv', k[:, t], error)
y = torch.einsum('bhk,bhkv->bhv', q[:, t] / key_dim**0.5, state)
```

### 图建议

1. **27 格层序列**：逐一显示 KDA/MLA，别把末组补到 28 层；放大一个 KDA 块，q/k/v 的三条独立 conv→SiLU 路、q/k 的 L2、forget 与 beta 支路、output RMSNorm→sigmoid gate 都要可见。
2. **状态矩阵热图**：每行一个 key channel，用 α slider 显示不同遗忘速度；再画 k 对衰减后矩阵的读取、δ 的新旧 value 差、βkδᵀ 的秩一纠错。不能只画 `αS+kvᵀ`。
3. **同 key 重写交互**：固定旧 S=1、新 v=3、k=1、α=1；外积追加 `1+3β`，delta 为 `1+2β`。β=1 的输出分别4和3。示例不是模型能力测评。
4. **两类 gate 对照**：Kimi `Norm(y)·sigmoid(g)`，Mamba-2 `Norm(y·SiLU(g))`；用分叉图突出归一化顺序和激活函数都不同。

## NoPE MLA：保留共享支路，取消旋转

每 token 每头内容 N=128，共享 R=64，value V=128，latent C=512，H=32：

```tex
q_t = W_Q x_t                                     # [H,N+R], direct Q
[c_raw_t; s_t] = W_down x_t                         # [C+R]
c_t = RMSNorm(c_raw_t)                             # [C]
k_{t,h} = [W_K,h c_t ; s_t]                        # [N+R]
v_{t,h} = W_V,h c_t                                # [V]
a_{t,j,h} = softmax_{j≤t}(q_{t,h}^T k_{j,h}/sqrt(N+R))
y_t = W_O concat_h(sum_j a_{t,j,h} v_{j,h})
```

没有 RoPE，也没有 Q LoRA。sₜ 在 head 之间共享，但对应的 q 的 R 维是每头独立投影，不要把所有 Q 也画成共享。这个分支由实现继承下来的 `qk_rope_head_dim` 字段命名，**在 Kimi Linear 中不再是旋转位置编码**。

理论推理可以把 W_K 吸收到 query 一侧，把 W_V 放到加权 latent 求和之后，以紧凑 latent 形式读取历史；本实现 `NoPEMLA` 为便于理解展开 K/V，再进行因果 attention。测试用独立吸收式 contraction 检查结果，未实现缓存。KDA 固定尺寸状态不意味着整个混合模型没有随 T 增长的全注意力历史。

## 完整 PyTorch LM 与实际验证

文件：[models/kimi_linear.py](../models/kimi_linear.py)。每层为 `x += attention(RMSNorm(x))`，再 `x += FFN(RMSNorm(x))`。FFN 第一层 dense，其余为 MoE；最后再 norm 和独立 LM head。

```python
from models.kimi_linear import KimiLinearConfig, KimiLinearLM
import torch
model = KimiLinearLM()
ids = torch.randint(256, (2, 16))
logits = model(ids)                # [2,16,256]
large_config = KimiLinearConfig.kimi_linear_48b_a3b()  # config only
```

```bash
.venv/bin/python -m unittest discover -s tests -p test_kimi_linear.py -v
.venv/bin/python models/kimi_linear.py
```

实测 Python 3.11.2 / PyTorch 2.14.0+cpu，**5/5 tests 通过（0.632s）**：

- KDA 与显式密集转移矩阵、所有历史写入的独立展开一致，包括 q/k/v/α/β 梯度；使用不同 key/value 维度。
- 同 key 的 delta 写入覆盖目标关联，而非累计 value。
- NoPE MLA 与“W_K 吸收至 Q、W_V 延后”的独立计算一致。
- 完整混合 LM 无未来泄露；短前缀与完整输入的前缀输出一致；前向/反向及遗忘参数梯度有限且非零。
- 精确发布配置不初始化模型；测试 L2 ε 的真实位置。

直接脚本输出：`parameters=388,436, logits=(2,16,256), loss=5.778808`，反向完成。这是随机 tiny 验证，不是语言质量或吞吐基准。

### 明确的教学边界

- KDA 是逐 token Python 递推，不实现论文 §3.1 的高效 chunkwise/UT 算法；half/bfloat16 的状态用 FP32 累积，FP64 验证保留 FP64。
- MLA 显式展开 K/V；无增量 KDA state、conv state 或 MLA cache。原论文的最高6倍吞吐和75%缓存节省来自原始系统实验，不能归给此代码。
- 无原始权重、tokenizer、checkpoint loader、padding/packed masks、分布式专家调度或训练配方。`dt_bias=-2` 是有限且稳定的教学初始化，未宣称复现原始初始化/训练。
- MoE 复用 [deepseek_v3.py](../models/deepseek_v3.py) 的可微参考，改为单组、Kimi 的 top-k/专家数和 scale。bias 是默认0的 selection-only buffer，无自动负载更新；这由 SGLang 的 KimiMoE→TopK 路径交叉证实。
- **公开源码差异**：本次 HF `KimiMoEGate` 快照先 `scores_for_choice=scores.view(...)`，再 `+=bias`，会原地改动 `scores`。SGLang TopK 用加法新张量，保持选择分数和权重分数分离。本实现选择后者，不承诺与 HF 快照在非零 bias 下逐位等价。源件均保留以便复查。
- `models/kimi_linear.py` 保持2025结构，不包含后续改动。独立 `models/kimi_k3.py` 已实现 AttnRes、Stable LatentMoE、Gated MLA、SiTU，但不含视觉编码器；不要将两份模型的范围混淆。

## 2026 演进一：Attention Residuals 改变深度方向的信息选择

已读取 [原始论文 arXiv:2603.15031](https://arxiv.org/abs/2603.15031) 的 [官方 PDF](https://github.com/MoonshotAI/Attention-Residuals/blob/master/Attention_Residuals.pdf) 与 [官方 README](https://github.com/MoonshotAI/Attention-Residuals)。arXiv HTML 本次只有不完整的转换内容，未用于公式取证。

与序列方向 QK attention 不同，AttnRes 对**同一 token、不同来源层/块**做 softmax。消费子层 l 的 w_l∈ℝᴰ 是可学习 pseudo-query；v_i 包括 embedding 和先前层输出，shape `[sources,B,T,D]`：

```tex
α_{i→l} = softmax_i(w_l^T RMSNorm(v_i))
h_l = Σ_i α_{i→l} v_i
```

来源：[论文 §3.1 Eq.(2)–(4)](https://arxiv.org/abs/2603.15031)。RMSNorm 只用于 key 的打分；values 保持未归一化表示。w_l 不是从当前 token 额外生成的 Q；权重仍因 token 的 key 内容变化。不要画成 token 对 token 的注意力。

Full AttnRes 读取全部先前层输出。Block AttnRes 在块内求和形成 b_n，仅跨块对 embedding、已完成块以及当前 partial sum 做注意力，减小激活保留/跨流水线通信。每个 token 的保留表示从 O(LD) 减少到 O(ND)；该说法是深度方向表示成本，不是模型总内存，也不改变序列的 KV cache。论文 §3.2 / Eq.(5)、伪代码 Figure 2。

```python
V = torch.stack(sources)                       # [K,B,T,D]
K = rms_norm(V)
scores = torch.einsum('d,kbtd->kbt', query, K)
weights = scores.softmax(dim=0)                # source axis, not time axis
h = torch.einsum('kbt,kbtd->btd', weights, V)
```

**图建议：** 将深度画成竖直楼层，embedding + 已完成块 + 当前partial画成并列来源；一个 learned-query 指向这些来源，条形图显示权重。允许调方向观察“来源内容改变选择”；图注说明 slider 只是解释已学习参数，不是实际模型控制接口。原研究在 Kimi Linear 48B/3B 上训练1.4T验证，不能把它说成 October 2025 已发布权重默认具有 AttnRes。

## 2026 演进二：Kimi K3 集成 KDA、AttnRes、Stable LatentMoE

已读取 [Moonshot 官方 K3 技术报告](https://github.com/MoonshotAI/Kimi-K3/blob/main/k3_tech_report.pdf)、[官方 HF config](https://huggingface.co/moonshotai/Kimi-K3/blob/main/config.json)、[官方 modeling_kimi_linear.py](https://huggingface.co/moonshotai/Kimi-K3/blob/main/modeling_kimi_linear.py)。

| 项目 | K3 原文/配置核实 |
|---|---|
| 参数 | Table 1：2.78T 总量，104.2B 激活；摘要约写2.8T/104B |
| 主干 | 93层 = 69 KDA + 24 Gated MLA，NoPE |
| D / KDA heads × head dim | 7168 / 96 × 128 |
| 专家 | 896路由选16 + 2共享；routed latent宽3584，专家中间宽3072 |
| 深度连接 | Block AttnRes，每12个decoder层一块，8个网络块；加embedding共9个来源块 |
| 发布上下文 | 1,048,576 |
| 其它结构 | Stable LatentMoE、SiTU-GLU、原生视觉路径；不同于本 tiny Kimi Linear |

K3报告 §2.2 明确8块。官方 HF `_forward_attn_residual` 按 `layer_idx % attn_res_block_size` 分块，config=12，因此这里数的是decoder层。**不要把 AttnRes 原论文示例里“attention + MLP 算两个 layer”的计数直接套过来，再把12除2。** K3最后一块不满12层。

K3仍保留KDA Eq.(1)，但进一步采用下界遗忘门，发布配置 `gate_lower_bound=-5`、`use_full_rank_gate=true`；MLA增加output gate。不能把这些2026设置悄悄加入本次2025 Kimi Linear实现。其 Stable LatentMoE 在低维路由专家空间工作并加入稳定性设计，不能直接用普通MoE等同。

**版本区分：** K3报告 Table1 记训练有1层MTP，发布config为 `num_nextn_predict_layers=0`；正文使用“训练附加模块”与“发布主干配置”分别表述。报告参考文献指向July 2026官方博客；gallery具体日期不是这里的独立取证依据。

**章节落地：** 保留结构演进路径：“Kimi Linear: channel-wise delta + NoPE MLA” → “AttnRes: 同token跨深度选择” → “K3: 69KDA+24GatedMLA / BlockAttnRes / StableLatentMoE”。三者现在都有独立章节；K3 的完整 tiny 文本 LM 位于 `models/kimi_k3.py`，AttnRes 仍标为独立研究工作，不伪装成2025 Kimi Linear原发布权重的一部分。

## 来源清单与页面核查

下载件统一前缀 `sources/frontier-kimi-*`。完整URL、用途、SHA256及失败/不完整来源在 `sources/frontier-kimi-manifest.json`。

初版曾只读核查 `web/frontier.html` 的 Kimi / AttnRes 部分；该注记不代表最终交付范围。后续已新增独立 `web/chapters/kimi-linear.html` 与 `web/chapters/kimi-k3.html`，并补齐公式、架构图、交互和完整源代码，当前状态以 [deep-kimi.md](deep-kimi.md) 为准。
