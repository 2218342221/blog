# Kimi Linear 与 Kimi K3：深入章节与完整文本实现

核实日期：2026-09-25。两者分别展示2025的逐通道 delta 混合序列架构，以及2026沿序列、网络深度和专家宽度的进一步改造。原始资料已下载至 `sources/frontier-kimi-*`，20个来源的URL与SHA-256位于 `sources/frontier-kimi-manifest.json`。本次直接结合论文、官方配置与发布代码；gallery仅承担发现入口。

## 交付文件

| 内容 | 文件 |
|---|---|
| Kimi Linear 独立章节 | `web/chapters/kimi-linear.html` |
| Kimi K3 独立章节 | `web/chapters/kimi-k3.html` |
| 两章局部样式 / K3三组交互 | `web/chapters/kimi.css` / `web/chapters/kimi.js` |
| 完整微缩文本LM | `models/kimi_linear.py` / `models/kimi_k3.py` |
| 机制与模型测试 | `tests/test_kimi_linear.py` / `tests/test_kimi_k3.py` |
| 较细原始取证 | `notes/frontier-kimi.md` |

Linear章节保留总图、27层排列、Q/K/V短卷积与各门支路、衰减→预测→纠错的矩阵递推、NoPE MLA、专家路由、prefill/decode与内存计算。K3章节独立解释有界遗忘门、全秩输出门、Query低秩投影、稳定latent专家、SiTU、下一步Quantile Balancing、Block AttnRes精确边界，以及相应完整模型代码。

三组新交互为log-decay曲线、SiTU乘积、原版93层/12层每块的深度来源。均为公式或调度结构演示，不显示伪造的已训练注意力。Linear原有层格与delta重写交互仍由 `web/frontier.js` 驱动。

## 原版和微缩版的范围

Kimi Linear原版27层，MLA位于4、8、12、16、20、24、27，合计20 KDA + 7 MLA；tiny为3 KDA + 1 MLA。原版D=2304，H=32，KDA K=V=128，MLA内容128+共享64、V128，KV512；没有Query LoRA。首层dense FFN，其余256选8+1共享专家，route scale2.446。tiny保持这些算子与层类型，改变宽度和专家数量，共388,436参数。

K3发布文本配置93层，MLA位于4、8、…、92、93，合计69 KDA + 24 Gated MLA；tiny为3 KDA + 2 Gated MLA。原版D=7168，H=96，KDA K=V=128，MLA内容128+共享64、V128，Query rank1536、KV rank512；首层dense，后92层896选16+2共享专家。原版路由latent3584，专家中间宽度3072，dense中间宽33792。tiny保留完整文本路径，共401,932参数。

`KimiK3Config.kimi_k3_text_config()` 只返回发布规模配置，不分配巨型权重。实际默认微缩参数为D64、5层、4头×16维KDA、MLA内容16+共享8/V16、Query rank16、KV rank24、latent32、专家中间48、8选2+2共享。两份模型均使用随机初始化；没有原始checkpoint转换或预训练能力。

## K3机制与原始出处对应

| 机制 | 原报告 / 官方源 | 教学实现中的关键顺序 |
|---|---|---|
| 有界KDA | K3 §2.1.1 Eq.(5)、Figure3；`KimiDeltaAttention` | `-5 sigmoid(exp(A_log)*(raw+bias))`，遗忘logit仍低秩 |
| 全秩输出gate | K3 §2.1.2；官方 `use_full_rank_gate` 分支 | KDA先head RMSNorm，再乘sigmoid gate；只输出gate改全秩 |
| Gated MLA | K3 §2.1.2 Eq.(7)；官方 `KimiMLAAttention` | Query压缩→norm→升维；注意力后sigmoid gate，Wo前；无额外head RMSNorm |
| Stable LatentMoE | K3 §2.3 Eq.(11)、§2.3.1 | router读full-width x；路由专家处理latent；加权聚合后norm再expand；共享专家保留全宽 |
| SiTU | K3 §2.3.2 Eq.(12)、Figure4、AppendixB | `4*tanh(g/4)*sigmoid(g) * 25*tanh(u/25)` |
| Quantile Balancing | K3 §2.3.3 Eqs.(13–14)、Figure5、AppendixC/D | 当前前向用旧bias；从当前统计获得的新bias只在之后的训练批次安装 |
| Block AttnRes | K3 §2.2 Eqs.(8–10)；官方 `_forward_attn_residual`、`_apply_output_attn_res` | 先mix旧partial→边界归档→attention输出加入partial→独立FFN mix→FFN输出加入partial；最终独立output mix |

官方报告：https://github.com/MoonshotAI/Kimi-K3/blob/main/k3_tech_report.pdf

官方配置：https://huggingface.co/moonshotai/Kimi-K3/blob/main/config.json

官方实现：https://huggingface.co/moonshotai/Kimi-K3/blob/main/modeling_kimi_linear.py

Kimi Linear论文：https://arxiv.org/abs/2510.26692

Attention Residuals论文：https://arxiv.org/abs/2603.15031

## 易混淆点与版本差异

1. **full-rank只对应输出gate。** 遗忘门仍使用单头维度rank的down/up两矩阵。KDA与MLA输出gate都是full-width输入到全部head输出通道的一次线性投影。
2. **有界遗忘不等于不遗忘。** 理论每步log-decay在(-5,0)，保留率在(e^-5,1)，16步累积log在(-80,0)。实际浮点sigmoid可能数值饱和；多个token仍连续衰减。
3. **A_log初始化依据原报告为0。** 发布modeling构造函数中的uniform参数是加载权重前的占位初始化。本tiny使用报告A_log=0，但沿用教学dt_bias=-2，不宣称复现完整初始化/训练配方。
4. **NoPE保留共享64维Key支路。** 原字段名含rope不意味着Kimi仍旋转；没有RoPE，但该支路仍参与QK缩放中的192维。K3恢复Query rank1536；2025 Linear是直接Query投影。
5. **SiTU的sigmoid读原始logit。** `sigmoid(4*tanh(g/4))`是错误替换。界100只约束down projection之前的逐通道乘积，不能声称整个FFN输出有界100。
6. **LatentMoE的norm在混合后。** `Norm(sum pE)`不等于`sum pNorm(E)`。共享专家绕开latent压缩；代码将共享专家沿中间维合并为等价的大SiTU FFN。
7. **QB只调选择。** weights由raw sigmoid分数归一化，bias只进入Top-k。单独`quantile_bias_next_step`函数给出精确顺序统计参考，要求整数目标负载m*k/n，负载解释假定不同margin；不含全局直方图，也不保证同时改变全部cutoff后每批完全平衡。模型forward和toy训练均不自动更新bias。
8. **AttnRes block size计decoder层。** K3配置12直接用于`layer_idx % 12`，不用再除2。93层形成8块，最后9层；加embedding最终9来源。tiny blocksize2得到3个网络块。
9. **不能将mix输入直接加回partial。** 每次选择的h只作为子层输入；partial累加当前块的子层输出。把代码改成`partial=h+F(h)`会重复引入已完成块。
10. **发布文本与报告全系统有别。** 原报告有MoonViT-V2视觉路径及训练MTP；发布config nextn层数为0。完整tiny文本主干不包括视觉/MTP、预训练权重、incremental cache、融合或chunk kernel、专家通信、分布式QB与原始训练配方。

## 实际验证

`tests/test_kimi_linear.py` 的5项测试已通过：delta密集转移与梯度独立参考、同key覆盖而非累加、NoPE MLA吸收式参考、完整LM因果性/前缀一致性/反向、发布配置与L2的epsilon位置。

`tests/test_kimi_k3.py` 的7项测试已通过，独立运行用时0.654s：

- SiTU乘积界、原点局部近似及sigmoid原始logit。
- 有界log-decay和只有输出gate全秩。
- LatentMoE逐token独立专家混合参考。
- Gated MLA直接注意力参考，覆盖Query压缩和gate位置。
- 显式来源列表与可手算子层映射，跨块检查AttnRes归档/累加/最终聚合。
- QB的下一步顺序统计、bias中心化及输入不变。
- 完整LM因果性、前缀一致性、反向传播及原版配置。

独立CPU脚本固定seed42输出：

```text
parameters=401,932, logits=(2, 12, 256), loss=5.796896
```

统一训练脚本的K3结果已读取 `validation/advanced-training.json`：CPU、PyTorch2.14.0+cpu、1线程、seed2026、batch4、长度32、20步；同一固定batch CE **5.751036 → 1.078424**，所有梯度有限。它检验微缩网络可以优化同一小语料，不是held-out评估或原始K3训练能力的复现。

复现命令（在任务目录内）：

```bash
.venv/bin/python -m unittest discover -s tests -p test_kimi_k3.py -v
.venv/bin/python models/kimi_k3.py
node --check web/chapters/kimi.js
```

章节的`@SOURCE:...@`由主构建脚本替换为完整源码。样式仅作用于`#kimi-linear` / `#kimi-k3`；JS仅绑定K3自身的三组控件，不覆盖其它章节交互。

独立Chromium渲染与交互已检查：无page error；93个层号全部验证attention/FFN来源数量，额外记录1/12/13/24/25/93层边界；遗忘gate检查z=-8/0/8，SiTU极端输入乘积保持≤100。1280px与390px视口均无页面横向溢出。结构图在窄屏内水平滚动。结果在 `validation/kimi-browser.json`，截图在 `validation/kimi-k3-{top,depth,mobile}.png`；全页数学渲染由主构建进一步验证。
