# iLLaDA · 掩码扩散（2026 前沿代表，LLaDA 方法溯源）

核实日期 2026-09-25。本章只选择同一技术路线的最新代表 **iLLaDA**；LLaDA (2025) 用于原始方法、理论与实现溯源，不重复作为第二个模型章节。

## 已核实的来源和选择结论

- **iLLaDA / Improved Large Language Diffusion Models**，arXiv:2606.25331v1，**2026-06-24**。原论文 PDF/HTML、官方 GSAI-ML/iLLaDA-8B-Base 模型卡、config 和 modeling_illada.py 已保存。完整双向 masked diffusion，从零训练，2026 报告仍采用 LLaDA 的同一个随机掩码、1/t 加权训练目标。
- 原始 **LLaDA / Large Language Diffusion Models** 首发 2025-02；本地保存 arXiv:2502.09992v1 HTML 和 v3 PDF（2025-10-18 修订）。官方 ML-GSAI/LLaDA 的 GUIDELINES.md 与 generate.py 是公式到工程实现的交叉证据。
- iLLaDA 的更新包含 GQA、tied embedding、预训练和 SFT 配方、分块可变长生成、选择题评分方法；**不能说仅仅改了规模，也不是新的扩散转移算子**。本地 tiny 实现覆盖完整核心主干、masked objective、逐块解掩码路径；没有复现训练语料、训练规模、并行系统或实际质量。

## 适合页面的三个短句

1. **先遮住，再一起预测。** 同一轮里的每个位置都能看左右两侧可见 token。
2. **训练恢复当前位置。** 只对被遮住的位置计算 1/t 加权交叉熵，标签不右移。
3. **生成逐轮填空。** 已确认 token 保留，低置信位置留到下一轮；iLLaDA 完成一个 block 后继续追加，遇 EOS 停止。

这条路线与自回归 Transformer 可以使用相似的矩阵层，但概率分解、attention 可见性、训练目标和采样算法不同。不能把自回归的 prefix 不变测试套在双向 mask predictor 上。

## 真实尺寸与 tiny 对照

| 项目 | LLaDA 8B（2025，溯源） | iLLaDA 8B（2026，代表） | tiny 默认 |
|---|---:|---:|---:|
| layers | 32 | 32 | 2 |
| d_model | 4096 | 4096 | 64 |
| Q heads | 32 | 32 | 4 |
| KV heads | 32（MHA） | 8（GQA） | 1 |
| head dim | 128 | 128 | 16 |
| FFN/SwiGLU hidden | 12288 | 14336 | 224 |
| vocab size | 126464 | 155136 | 257 |
| mask ID | 126336 | 5（官方使用指南） | 256 |
| max sequence length | 4096 | 8192 | 512 |
| RoPE theta | 500000 | 10000 | 10000 |
| RMSNorm epsilon | 1e-5 | 1e-5 | 1e-5 |
| embedding ↔ head | 不共享 | 共享 | 共享 |
| attention | 全双向 | 全双向 | 全双向 |
| 注意力/MLP bias | 无 | 无 | 无 |

8B 数值只来自 config / 原论文 Table 1；`llada_8b_config()` / `illada_8b_config()` 仅创建配置，不分配权重。tiny 257 个符号支持 256 个 byte ID + mask；没有内置自然语言 tokenizer。

## 模块图与公式

```text
 noisy token ids:  [今天] [MASK] [天气] [MASK]
                      ↓ embedding
 ┌──────────────────────────────────────────── × L ┐
 │         RMSNorm → Q / K / V                     │
 │                    ↓ RoPE(Q,K)                  │
 │       全双向 GQA：所有位置 ⇄ 所有位置             │
 │                    ↓ W_O → + residual           │
 │         RMSNorm → SwiGLU → + residual            │
 └─────────────────────────────────────────────────┘
                      ↓ final RMSNorm
                   tied LM head
                      ↓
          每个位置的 token logits [B,T,V]
```

对于第 h 个 query head，所属 KV 组 g(h)=⌊h/(H_Q/H_KV)⌋：

\[
Q_h=\operatorname{RoPE}(UW_h^Q),\quad
K_g=\operatorname{RoPE}(UW_g^K),\quad V_g=UW_g^V,
\]
\[
O_h=\operatorname{softmax}\!\left(\frac{Q_hK_{g(h)}^\top}{\sqrt{d_h}}\right)V_{g(h)}.
\]

**没有因果下三角掩码。** `[MASK]` 本身是输入符号，仍可参与 attention；不是在 attention mask 中隐藏这些位置。padding/packed examples 的隔离与扩散 mask 是两个概念。本实现没有 padding/packed sequence 支持。

残差块与 FFN：
\[
U'=U+\operatorname{GQA}(\operatorname{RMSNorm}(U)),\qquad
U''=U'+\operatorname{SwiGLU}(\operatorname{RMSNorm}(U')),
\]
\[
\operatorname{SwiGLU}(x)=\big(\operatorname{SiLU}(xW_g)\odot xW_u\big)W_d.
\]

模型不需要输入 timestep t：原 LLaDA Appendix A Eq(11) 给出 masked token 的最优预测等于对可见 clean tokens 的条件分布，是 time-free 的。t 决定污染率及 loss 权重，而不是额外的网络输入。

## 训练：随机 t + 只算 mask + 1/t

理论前向污染：对每条样本取 t∼Uniform(0,1)，每个位置独立取 m_i∼Bernoulli(t)，令 x_t^i=M 若 m_i=1，否则为原 token x_0^i。

\[
\mathcal L_{seq}(\theta)=
-\mathbb E_{t,x_0,x_t}\left[\frac1t\sum_{i=1}^T
\mathbf1[x_t^i=M]\log p_\theta(x_0^i\mid x_t)\right].
\]

这是原 LLaDA Eq(3)、iLLaDA Eq(1) 的**序列求和**口径，控制模型序列 NLL 的上界。官方训练指南把 minibatch 的总和除以 B×T 得到每 token 归一化版本：

\[
\widehat{\mathcal L}_{token}
=\frac1{BT}\sum_{b=1}^{B}\sum_{i:m_{b,i}=1}
\frac{\operatorname{CE}(z_{b,i},x_{0,b,i})}{p_b}.
\]

工程指南采样 `p=ε+(1−ε)*U`, ε=1e-3，避免恰好 t=0 与过大权重；除数必须是**实际污染概率 p**。这是对理论 t∈(0,1) 端点的数值截断，不应声称与完整区间积分完全相同。**不能把总和再除以本次实际 mask 数**，也不能去掉 1/p。偶然没有 mask 时 loss=0，代码不强制额外遮住一个 token，以免改变污染分布。

```python
noisy, mask, p = corrupt_tokens(clean_ids, mask_token_id=256)
logits = model(noisy)                         # [B,T,V]，不 shift
ce = F.cross_entropy(logits[mask], clean_ids[mask], reduction="none")
loss = (ce / p[mask]).sum() / clean_ids.numel()
```

固定 before/after corruption 的正确做法：仅调用一次 `corrupt_tokens`，保存同一份 `noisy, mask, p`，训练前后都用 `masked_diffusion_loss(model(noisy), clean_ids, mask, p)`。不能用同一 clean sequence 上新采的随机 t / masks 比较损失变化。

## 反向过程与实际采样的区别

对 0≤s<t≤1，若 x_t^i 已经可见，保持不变；若它是 M，则理论近似反向单位置分布为：

\[
p_\theta(x_s^i\mid x_t)=
\begin{cases}
s/t,&x_s^i=M,\\
(1-s/t)\,p_\theta(x_0^i=x_s^i\mid x_t),&x_s^i\ne M.
\end{cases}
\]

这来自原 LLaDA Appendix A Eq(10)。论文 Algorithm 4 在候选 token 上用 greedy，再按 s/t 随机保留 mask；候选 token 是否按类别分布抽样又是一项独立选择。

**实际演示默认使用官方的低置信重掩码启发式**：每轮预测全部剩余 mask，给候选 token 计算 softmax 置信度，选出固定 quota 个最高置信候选成为 visible，其余保留 mask。已 visible 的 token 不会被覆盖。它把随机反向链改成 confidence 排序，**不是精确的 Bernoulli 转移核**。官方 `generate.py` 将待填数量整除 steps，再把余数分到早期轮；本实现使用同一 quota 规则。原论文 Algorithm 5 中 `n_un` 与 “Lowest” 的转写/文字存在易误解之处，实际保留高置信 token 的方向由正文 §2.4 和官方代码交叉核实。

```text
prompt | [M] [M] [M] [M]     ① 全部位置并行预测，提交最有信心的候选
prompt |  A  [M] [M]  D      ② 新的 A / D 会同时影响中间两个位置
prompt |  A   B   C   D      ③ block 完成；若无 EOS，追加新 mask block
prompt |  A   B   C   D | [M] [M] ...
```

动图建议：一个按钮切换“随机位置 quota / 置信度 quota”；每轮描边高亮当前参与候选竞争的位置，已提交 token 固定。另一张 attention 矩阵展示完整方阵，和自回归章节的下三角形成可点击对照；不要把采样轮误称为 decoder layer。

采样 temperature=0 使用 greedy；temperature>0 使用 logits+temperature×Gumbel 选候选，与官方 Gumbel-max 方法的 argmax 等价但采用更稳定的对数形式。随机 tiny 模型可能偏爱 mask 符号，所以采样显式把 mask-token logit 置为−∞；clean token 支持集本来就不包含吸收态 M，由此保证有限步完整解掩码。

## iLLaDA 真正新增的内容

以 2026 原报告 §2 / Table 1 为准：

- **主干：** MHA→GQA (32/8)，FFN 14336，embedding/head 共享；8K，RoPE theta=10000（官方 config）。GQA 可降低扩散专用近似 cache 方法的状态占用；不表示标准自回归 KV cache 可以不加修改直接复用。本 tiny 不实现 cache。
- **预训练：** 从零训练，12T tokens；8K 序列以 30% 概率随机拆成两段，使用 packed variable-length attention 隔离不同样本；学习率先 warmup/constant，观察 plateau 后转 cosine。tiny 未复现这些数据/系统策略。
- **SFT：** 25B-token 指令语料重复 12 epochs；prompt+response+单个 EOS 拼接成连续语料，然后对整个训练序列随机遮盖，**prompt、response、EOS 都可被 mask**。这是与旧 LLaDA conditional SFT 的重要差别。本函数对所有 clean positions 等概率污染，能表达这个核心目标，但不声称复现语料加工。
- **生成：** 只追加当前 block 的 mask；block 内完成 confidence unmask，再检查 EOS/stop token；未结束则追加下一块。相对于一开始铺满最大预算的 masks，能节省无效长度。块大小/步数存在质量与成本取舍，不能直接宣称比 AR 更快。
- **选择题：** 每轮在剩余 candidate 真实 token 中选择最高置信位置揭示，并累计对应 log score；论文明确这只是候选比较 surrogate，**不是 likelihood estimate**。本地模型代码未实现该评测评分，也不展示不可复现的 benchmark。

## 固定 API

```python
LLaDAConfig(...)                              # 默认见尺寸表
model = LLaDALM(config)
logits = model(input_ids)                     # [B,T] → [B,T,V]
noisy, mask, p = corrupt_tokens(
    clean_ids, config.mask_token_id,
    eps=1e-3, probabilities=None, generator=None)
loss = masked_diffusion_loss(logits, clean_ids, mask, p)
out = sample_llada(
    model, prompt, gen_length=16, steps=8, block_length=None,
    temperature=0.0, remasking="low_confidence",
    eos_token_id=None, generator=None)         # 返回包含 prompt 的 Tensor
```

`probabilities` 可显式传 `[B]` / `[B,1]` / `[B,T]`；默认每样本一个 p，再广播到 T。`steps` 的单位是**每 block 的网络调用轮数**，上限为当前 block 长度。`gen_length` 是最多新增 token 数；`block_length=None` 表示单个固定长度 block。EOS 停止仅支持 B=1，检查已完成的 block 后裁到首个生成 EOS，prompt 中已有 EOS 不触发停止。返回值没有包含未消去的 mask。

## 实测验证

```bash
.venv/bin/python -m unittest tests.test_llada -v
.venv/bin/python models/llada.py
```

2026-09-25，PyTorch 2.14.0+cpu：**8/8 测试通过，0.631 s**。测试覆盖：

1. 已知 uniform logits 下手算 1/p 及 B×T 分母；unmasked labels 换成无效 ID 仍不影响结果，未被用于 CE。
2. 无 mask 的批次返回有限零损失且零梯度。
3. seeded corruption 可重现，p=1 时全部遮住，未遮位置保留原值。
4. 人工设置 uniform attention 后，第一个位置精确读到最后位置；完整网络对右侧 token 扰动敏感。
5. 完整模型所有参数获得有限非零梯度；embedding/head 确实共享。
6. 两种 quota 采样都保持 prompt，逐块增加长度，有限轮后无 mask，恢复调用前 train/eval 状态。
7. 单个生成 EOS 触发变量长度停止，prompt 内 EOS 不触发。
8. 两份原尺寸 config 只构造配置，不分配 8B 权重。

独立脚本实跑：`logits=(2,16,257), diffusion_loss=5.918737`；`generated_shape=(1,11), remaining_masks=0`。这是随机参数/随机 tokens 的结构检查，不表示语义生成质量。额外的训练效果由 root 的独立扩散训练演示负责，不沿用 AR next-token loss。

## 可点击的一手来源

- [iLLaDA 2026 原论文](https://arxiv.org/html/2606.25331v1)：§2.1 Eq(1)/Table1、§2.2 SFT、§2.3 generation & scoring、§4 limitations。
- [iLLaDA 官方模型卡](https://huggingface.co/GSAI-ML/iLLaDA-8B-Base)、[config](https://huggingface.co/GSAI-ML/iLLaDA-8B-Base/blob/main/config.json)、[modeling_illada.py](https://huggingface.co/GSAI-ML/iLLaDA-8B-Base/blob/main/modeling_illada.py)：GQA、tied embeddings、split-half RoPE、`is_causal=False`；类名 `ForCausalLM` 是 API 名称，不能据此把 attention 误读为 causal。
- [LLaDA 原始方法论文](https://arxiv.org/abs/2502.09992)：§2.1/§2.2/§2.4、Appendix A、Appendix B.2。
- [LLaDA 官方训练指南](https://github.com/ML-GSAI/LLaDA/blob/main/GUIDELINES.md)：去除因果 mask、ε 截断、CE/p/(B×T)。
- [官方 generate.py](https://github.com/ML-GSAI/LLaDA/blob/main/generate.py)：get_num_transfer_tokens、低置信 quota、var_generate。
- [LLaDA 原始 config](https://huggingface.co/GSAI-ML/LLaDA-8B-Base/blob/main/config.json)：原 2025 版本的尺寸对照。

资料快照为 `sources/frontier-llada*`，manifest 记录来源 URL、抓取日期和 SHA256。官方代码与论文采用各自来源许可证；本文件只是教学重写，不能当作权重转换工具或 checkpoint 等价实现。
