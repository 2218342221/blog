"""Run four real tiny causal LMs on a byte-level next-token teaching task.

This script trains random weights for a few CPU steps. It is a mechanics check,
not pretraining, a language-quality benchmark, or a checkpoint reproduction.
The generated sample is intentionally reported as a random/tiny-trained sample.
"""
import argparse
import json
import time
from pathlib import Path

import torch
import torch.nn.functional as F

from models.llama3 import LlamaLM
from models.deepseek_v3 import DeepSeekLM
from models.mamba2 import Mamba2LM
from models.kimi_linear import KimiLinearLM

MODELS = {"llama3": LlamaLM, "deepseek_v3": DeepSeekLM, "mamba2": Mamba2LM, "kimi_linear": KimiLinearLM}
CORPUS = (
    "the model reads a token and predicts the next token. "
    "attention reads history. experts transform tokens. state stores history. "
    "we learn the structure with small pytorch models. "
) * 32


def make_batch(data, batch_size, length, generator):
    starts = torch.randint(len(data) - length, (batch_size,), generator=generator)
    ids = torch.stack([data[int(i):int(i) + length + 1] for i in starts])
    return ids[:, :-1], ids[:, 1:]


@torch.no_grad()
def generate(model, prompt: bytes, n_tokens: int, context_limit=128):
    """Greedy generation. Recompute a (possibly cropped) prefix; no KV/state cache."""
    model.eval()
    ids = torch.tensor([list(prompt)], dtype=torch.long)
    for _ in range(n_tokens):
        logits = model(ids[:, -context_limit:])
        ids = torch.cat((ids, logits[:, -1].argmax(-1, keepdim=True)), dim=1)
    return bytes(ids[0].tolist()).decode("utf-8", errors="replace")


def run(name, steps=20, batch_size=4, seq_len=32, seed=2026):
    torch.manual_seed(seed)
    rng = torch.Generator().manual_seed(seed)
    model = MODELS[name]()  # Defaults are tiny; never allocate a paper-sized model.
    data = torch.tensor(list(CORPUS.encode("utf-8")), dtype=torch.long)
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=0.0)
    eval_x, eval_y = make_batch(data, batch_size, seq_len, rng)

    def eval_loss():
        model.eval()
        with torch.no_grad():
            logits = model(eval_x)
            return F.cross_entropy(logits.flatten(0, 1), eval_y.flatten()).item()

    initial = eval_loss()
    start = time.perf_counter()
    for _ in range(steps):
        model.train()
        x, target = make_batch(data, batch_size, seq_len, rng)
        optimizer.zero_grad(set_to_none=True)
        logits = model(x)
        # Logits at position t predict the token at t+1. Never train on x itself.
        loss = F.cross_entropy(logits.flatten(0, 1), target.flatten())
        if not torch.isfinite(loss):
            raise RuntimeError(f"{name}: nonfinite loss")
        loss.backward()
        for parameter in model.parameters():
            if parameter.grad is not None and not torch.isfinite(parameter.grad).all():
                raise RuntimeError(f"{name}: nonfinite gradient")
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
    final = eval_loss()
    elapsed = time.perf_counter() - start
    with torch.no_grad():
        shape = list(model(eval_x).shape)
    sample = generate(model, b"the model ", 24)
    return {
        "model": name, "parameters": sum(p.numel() for p in model.parameters()),
        "logits_shape": shape, "steps": steps, "batch_size": batch_size,
        "sequence_length": seq_len, "seed": seed, "initial_loss": round(initial, 6),
        "final_loss": round(final, 6), "training_seconds": round(elapsed, 3),
        "sample": sample, "finite_gradients": True,
        "evaluation": "same fixed minibatch, same tiny corpus; not held-out quality",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=["all", *MODELS], default="all")
    parser.add_argument("--steps", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--seq-len", type=int, default=32)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--json", type=Path, help="Write observed results to this file")
    args = parser.parse_args()
    if args.steps < 1 or args.batch_size < 1 or not 2 <= args.seq_len <= 96:
        parser.error("steps/batch-size must be positive; seq-len must be in [2,96]")
    torch.set_num_threads(1)
    names = list(MODELS) if args.model == "all" else [args.model]
    result = {"torch_version": torch.__version__, "device": "cpu", "threads": 1,
              "results": [run(n, args.steps, args.batch_size, args.seq_len, args.seed)
                          for n in names]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
