"""Train the iLLaDA-style tiny masked diffusion LM on an internal byte corpus.

The task is reconstruction at masked positions, not next-token prediction.
Losses before/after are evaluated with the same corruption on the same tiny
training corpus, so they are a mechanics check, not held-out model quality.
"""
import argparse
import json
import time
from pathlib import Path
import torch
from models.llada import LLaDAConfig, LLaDALM, corrupt_tokens, masked_diffusion_loss, sample_llada
from train_demo import CORPUS


def run(steps=20, seed=2026):
    torch.set_num_threads(1)
    torch.manual_seed(seed)
    generator=torch.Generator().manual_seed(seed)
    model=LLaDALM(LLaDAConfig())
    data=torch.tensor(list(CORPUS.encode()),dtype=torch.long)
    batch_size,length=4,32
    def batch():
        starts=torch.randint(len(data)-length,(batch_size,),generator=generator)
        return torch.stack([data[int(s):int(s)+length] for s in starts])
    target=batch()
    fixed_noisy,fixed_mask,fixed_p=corrupt_tokens(target,256,probabilities=torch.tensor([.25,.50,.75,.90]),generator=generator)
    def evaluate():
        model.eval()
        with torch.no_grad():
            return masked_diffusion_loss(model(fixed_noisy),target,fixed_mask,fixed_p).item()
    initial=evaluate()
    opt=torch.optim.AdamW(model.parameters(),lr=2e-3,weight_decay=0)
    start=time.perf_counter()
    for _ in range(steps):
        model.train(); clean=batch()
        noisy,mask,prob=corrupt_tokens(clean,256,generator=generator)
        opt.zero_grad(set_to_none=True)
        loss=masked_diffusion_loss(model(noisy),clean,mask,prob)
        if not torch.isfinite(loss):raise RuntimeError('Nonfinite diffusion loss')
        loss.backward()
        for p in model.parameters():
            if p.grad is not None and not torch.isfinite(p.grad).all():raise RuntimeError('Nonfinite gradient')
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
        opt.step()
    final=evaluate()
    prompt=torch.tensor([list(b'the model ')])
    generated=sample_llada(model,prompt,gen_length=16,steps=4,block_length=8)
    assert torch.equal(generated[:,:prompt.shape[1]],prompt)
    assert not (generated==256).any()
    return {'model':'illada','implementation':'models/llada.py','parameters':sum(p.numel() for p in model.parameters()),
            'logits_shape':list(model(fixed_noisy).shape),'steps':steps,'batch_size':batch_size,'sequence_length':length,
            'seed':seed,'initial_loss':round(initial,6),'final_loss':round(final,6),
            'training_seconds':round(time.perf_counter()-start,3),'finite_gradients':True,
            'sample':bytes(generated[0].tolist()).decode('utf-8',errors='replace'),
            'objective':'inverse-mask-probability weighted reconstruction; no label shift',
            'evaluation':'fixed target/noise/mask on tiny training corpus; not comparable to causal CE quality',
            'torch_version':torch.__version__,'device':'cpu'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--steps',type=int,default=20);p.add_argument('--json',type=Path)
    args=p.parse_args()
    if args.steps<1:p.error('steps must be positive')
    result=run(args.steps)
    payload=json.dumps(result,ensure_ascii=False,indent=2)
    print(payload)
    if args.json:args.json.parent.mkdir(parents=True,exist_ok=True);args.json.write_text(payload+'\n')
