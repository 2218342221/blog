# PyTorch 架构实验代码包

本包包含六套模型的 tiny 主干、三项研究模块、Block AttnRes 网络示例及 V4.1 核心架构参考。
附训练/生成脚本、55 项测试与来源说明，各实现范围见源码 docstring 与 notes。
完整交互综述与 HTML 下载：https://2218342221.github.io/blog/lab/llm-architecture-atlas/
本包包含教学代码、测试和来源说明。

```bash
python -m venv .venv
source .venv/bin/activate
pip install torch --index-url https://download.pytorch.org/whl/cpu
python train_demo.py --model all --steps 20
python train_diffusion.py --steps 20
python train_advanced.py --steps 20
python -m unittest discover -s tests -v
```

Python 3.10+ / torch 2.2+；实测 Python 3.11.2 / torch 2.14.0+cpu。
模型文件 models/llama3.py、deepseek_v3.py、mamba2.py、kimi_linear.py、llada.py、kimi_k3.py 提供完整tiny主干。
Engram/mHC在frontier_modules.py；AttnRes聚合与网络调度分别在attention_residuals.py、block_attnres.py。
V4.1为核心架构参考，具体包含和省略的机制以该模块说明为准。所有代码须保留models目录依赖。
扩散使用同位置还原损失，不能右移标签或用因果测试。
默认随机权重和缩小架构；无预训练能力、无 checkpoint loader、无高效增量 cache。
MLA 显式展开KV；Mamba-2提供递推和显式矩阵参考，不复现官方 fused 内核速度。
train_demo.py 使用内置字节语料，loss 是同一固定小batch上的机械验证，不是模型质量排名。
每个模型的公式、原始配置、引用URL及实现边界详见 notes/，实际观测见 validation/。
