"""CPU mechanics checks for the new integrated text/reference networks.

Kimi K3 is a complete tiny text backbone. Block AttnRes is a research network
using Llama-style sublayers. DeepSeek-V4.1 is a CED/CSA2 core reference with
dense FFNs, not the complete flagship. No pretrained weights are loaded.
"""
import argparse
import json
from pathlib import Path

import torch

import train_demo
from models.kimi_k3 import KimiK3LM
from models.block_attnres import BlockAttnResLM
from models.deepseek_v41 import TinyCEDReference

MODELS = {"kimi_k3": KimiK3LM, "block_attnres": BlockAttnResLM,
          "deepseek_v41": TinyCEDReference}
SCOPES = {
    "kimi_k3": "complete tiny Kimi K3 text backbone; no vision/MTP/production kernels",
    "block_attnres": "Block AttnRes research network with Llama-style causal sublayers",
    "deepseek_v41": "CED/CSA2 core reference with dense FFNs; not the full V4.1 model",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=["all", *MODELS], default="all")
    parser.add_argument("--steps", type=int, default=20)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.steps < 1:
        parser.error("--steps must be positive")
    torch.set_num_threads(1)
    train_demo.MODELS.update(MODELS)
    names = list(MODELS) if args.model == "all" else [args.model]
    results = []
    for name in names:
        observation = train_demo.run(name, steps=args.steps)
        observation["scope"] = SCOPES[name]
        results.append(observation)
    report = {"torch_version": torch.__version__, "device": "cpu", "threads": 1,
              "results": results,
              "interpretation": "same fixed minibatch, random tiny models; no quality ranking"}
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    print(text)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(text)


if __name__ == "__main__":
    main()
