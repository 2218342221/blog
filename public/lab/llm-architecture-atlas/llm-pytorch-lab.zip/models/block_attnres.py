"""Complete tiny Block-AttnRes decoder, using the Llama-style sublayers.

Source: Attention Residuals, arXiv:2603.15031, Sec. 3.2 Eqs. (5)-(6), Fig. 2.
This research demonstration composes the depth aggregator with actual causal
GQA / SwiGLU, embeddings, final depth aggregation, RMSNorm and a vocabulary
head. It is not Kimi K3 or a reproduction of the paper's full training system.

block_size counts ATTENTION AND MLP SUBLAYERS, not decoder blocks. Sublayer
outputs accumulate within each depth block; their attention inputs do not.
No checkpoints, tokenizer, packed examples, generation cache, two-phase fused
inference or distributed pipeline communication are included.
"""
from dataclasses import dataclass

import torch
from torch import Tensor, nn
from torch.nn import functional as F

try:
    from .attention_residuals import AttentionResiduals
    from .llama3 import LlamaConfig, GQAAttention, RMSNorm, SwiGLU
except ImportError:  # Direct execution: python models/block_attnres.py.
    from attention_residuals import AttentionResiduals
    from llama3 import LlamaConfig, GQAAttention, RMSNorm, SwiGLU


@dataclass(frozen=True)
class BlockAttnResConfig:
    vocab_size: int = 256
    dim: int = 64
    n_layers: int = 3  # Decoder blocks, each contributing TWO sublayers.
    n_heads: int = 4
    n_kv_heads: int = 2
    hidden_dim: int = 192
    block_size: int = 2  # Attention/MLP SUBLAYERS per depth block.
    max_seq_len: int = 128
    rope_theta: float = 500000.0
    norm_eps: float = 1e-5

    def __post_init__(self):
        if self.block_size < 1:
            raise ValueError("block_size must count a positive number of sublayers")
        self.llama_config()  # Reuse validation of attention dimensions.

    def llama_config(self) -> LlamaConfig:
        return LlamaConfig(vocab_size=self.vocab_size, dim=self.dim,
                           n_layers=self.n_layers, n_heads=self.n_heads,
                           n_kv_heads=self.n_kv_heads, hidden_dim=self.hidden_dim,
                           max_seq_len=self.max_seq_len, rope_theta=self.rope_theta,
                           rms_norm_eps=self.norm_eps)


class PreNormSublayer(nn.Module):
    """Return f(h), with NO extra h+f(h); the depth scheduler owns accumulation."""
    def __init__(self, config: LlamaConfig, attention: bool):
        super().__init__()
        self.norm = RMSNorm(config.dim, config.rms_norm_eps)
        self.operation = GQAAttention(config) if attention else SwiGLU(config)

    def forward(self, x: Tensor) -> Tensor:
        return self.operation(self.norm(x))


class BlockAttnResLM(nn.Module):
    def __init__(self, config: BlockAttnResConfig | None = None):
        super().__init__()
        self.config = config or BlockAttnResConfig()
        cfg = self.config
        self.embedding = nn.Embedding(cfg.vocab_size, cfg.dim)
        llama = cfg.llama_config()
        self.sublayers = nn.ModuleList(
            PreNormSublayer(llama, attention=(i % 2 == 0))
            for i in range(2 * cfg.n_layers))
        # Different consuming sublayers must not share a single pseudo-query.
        self.mixers = nn.ModuleList(AttentionResiduals(cfg.dim, cfg.norm_eps)
                                   for _ in self.sublayers)
        self.readout = AttentionResiduals(cfg.dim, cfg.norm_eps)
        self.norm = RMSNorm(cfg.dim, cfg.norm_eps)
        self.lm_head = nn.Linear(cfg.dim, cfg.vocab_size, bias=False)

    def aggregate_hidden(self, embedding: Tensor) -> Tensor:
        """Maintain completed sums and a partial sum; then aggregate all blocks.

        Each source has shape [batch,time,dim]. The embedding is source b_0.
        No zero-valued partial source is added at the beginning of a block.
        Even a zero vector would change softmax normalization and the model.
        """
        completed = [embedding]
        partial = None
        for i, (mixer, sublayer) in enumerate(zip(self.mixers, self.sublayers)):
            h = mixer.from_blocks(completed, partial)
            contribution = sublayer(h)
            partial = contribution if partial is None else partial + contribution
            if (i + 1) % self.config.block_size == 0 or i + 1 == len(self.sublayers):
                completed.append(partial)
                partial = None
        # Eq. (6): the final output layer reads the completed representations,
        # with the embedding retained as a source, using its own learned query.
        return self.readout(completed)

    def forward(self, input_ids: Tensor) -> Tensor:
        """[batch,time] -> causal next-token logits [batch,time,vocabulary]."""
        if input_ids.ndim != 2 or not 1 <= input_ids.shape[1] <= self.config.max_seq_len:
            raise ValueError("Expected nonempty [batch,time] input within max_seq_len")
        hidden = self.aggregate_hidden(self.embedding(input_ids))
        return self.lm_head(self.norm(hidden))


if __name__ == "__main__":
    torch.manual_seed(2026)
    torch.set_num_threads(1)
    model = BlockAttnResLM()
    ids = torch.randint(0, model.config.vocab_size, (2, 10))
    logits = model(ids)
    loss = F.cross_entropy(logits[:, :-1].flatten(0, 1), ids[:, 1:].flatten())
    loss.backward()
    print(f"logits={tuple(logits.shape)}, next_token_loss={loss.item():.6f}")
    print(f"sublayers={len(model.sublayers)}, block_size={model.config.block_size}, "
          f"parameters={sum(p.numel() for p in model.parameters())}")
