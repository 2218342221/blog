"""Small, trainable DeepSeek-V3 *architecture* reference in plain PyTorch.

Sources: DeepSeek-V3 Technical Report, arXiv:2412.19437v2, §§2.1, 4.2;
https://github.com/deepseek-ai/DeepSeek-V3/blob/main/inference/model.py

This implements a complete decoder: MLA + dense/SwiGLU or DeepSeekMoE + LM
head. MLA deliberately expands K/V, so this is NOT a compressed-cache serving
implementation. No pretrained weights, tokenizer, YaRN, MTP loss/head, FP8,
distributed dispatch, automatic bias balancing, or sequence balance loss.
The 671B preset describes core pretraining dimensions; never instantiate it on
a laptop. Tiny defaults preserve the operators, not the original model quality.
"""

from dataclasses import dataclass

import torch
from torch import Tensor, nn
import torch.nn.functional as F


@dataclass(frozen=True)
class DeepSeekConfig:
    vocab_size: int = 256
    dim: int = 64
    n_layers: int = 3
    n_dense_layers: int = 1
    n_heads: int = 4
    q_lora_rank: int = 32
    kv_lora_rank: int = 24
    qk_nope_head_dim: int = 16
    qk_rope_head_dim: int = 8
    v_head_dim: int = 16
    inter_dim: int = 128
    moe_inter_dim: int = 48
    n_routed_experts: int = 8
    n_shared_experts: int = 1
    n_activated_experts: int = 2
    n_expert_groups: int = 2
    n_limited_groups: int = 1
    route_scale: float = 2.5
    rope_theta: float = 10000.0
    max_seq_len: int = 128
    norm_eps: float = 1e-6

    def __post_init__(self):
        positive = (self.vocab_size, self.dim, self.n_layers, self.n_heads,
                    self.kv_lora_rank, self.qk_nope_head_dim,
                    self.qk_rope_head_dim, self.v_head_dim, self.inter_dim,
                    self.moe_inter_dim, self.n_routed_experts,
                    self.n_expert_groups, self.max_seq_len)
        if min(positive) <= 0 or self.q_lora_rank < 0:
            raise ValueError("Dimensions must be positive (query rank may be 0).")
        if not 0 <= self.n_dense_layers <= self.n_layers:
            raise ValueError("Dense layer count must be between 0 and n_layers.")
        if self.qk_rope_head_dim % 2:
            raise ValueError("RoPE dimension must be even.")
        if self.n_shared_experts < 0:
            raise ValueError("Shared expert count cannot be negative.")
        if self.n_routed_experts % self.n_expert_groups:
            raise ValueError("Experts must divide evenly into routing groups.")
        if not 1 <= self.n_limited_groups <= self.n_expert_groups:
            raise ValueError("Invalid number of selected groups.")
        group_size = self.n_routed_experts // self.n_expert_groups
        if self.n_expert_groups > 1 and group_size < 2:
            raise ValueError("V3 group scoring needs at least two experts/group.")
        if not 1 <= self.n_activated_experts <= group_size * self.n_limited_groups:
            raise ValueError("Selected groups must contain enough experts.")
        if self.route_scale <= 0 or self.rope_theta <= 0 or self.norm_eps <= 0:
            raise ValueError("Scale, RoPE base and normalization epsilon must be positive.")


def deepseek_v3_671b_config() -> DeepSeekConfig:
    """Published core dimensions, without allocating any weights.

    The report pretrains at 4K before YaRN extension to 128K. This reference
    stops at unscaled RoPE; it is not a released-checkpoint loader.
    """
    return DeepSeekConfig(
        vocab_size=129280, dim=7168, n_layers=61, n_dense_layers=3,
        n_heads=128, q_lora_rank=1536, kv_lora_rank=512,
        qk_nope_head_dim=128, qk_rope_head_dim=64, v_head_dim=128,
        inter_dim=18432, moe_inter_dim=2048, n_routed_experts=256,
        n_shared_experts=1, n_activated_experts=8,
        n_expert_groups=8, n_limited_groups=4, route_scale=2.5,
        max_seq_len=4096,
    )


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        xf = x.float()
        normalized = xf * torch.rsqrt(xf.square().mean(-1, keepdim=True) + self.eps)
        return normalized.to(x.dtype) * self.weight


def apply_rope(x: Tensor, theta: float = 10000.0) -> Tensor:
    """Rotate adjacent feature pairs of x[B,T,H,R]; R must be even.

    Only the decoupled positional query/key branch passes through this function.
    All tokens start at position 0 because this reference has no generation cache.
    """
    _, time, _, rope_dim = x.shape
    inv_freq = theta ** (-torch.arange(0, rope_dim, 2, device=x.device).float() / rope_dim)
    angles = torch.arange(time, device=x.device).float()[:, None] * inv_freq[None, :]
    cos = angles.cos()[None, :, None, :]
    sin = angles.sin()[None, :, None, :]
    even, odd = x.float()[..., 0::2], x.float()[..., 1::2]
    return torch.stack((even * cos - odd * sin, even * sin + odd * cos), -1).flatten(-2).to(x.dtype)


class MLA(nn.Module):
    """Low-rank KV + compressed Q + decoupled RoPE (expanded K/V reference)."""

    def __init__(self, config: DeepSeekConfig):
        super().__init__()
        self.config = config
        qk_dim = config.qk_nope_head_dim + config.qk_rope_head_dim
        if config.q_lora_rank:
            self.q_down = nn.Linear(config.dim, config.q_lora_rank, bias=False)
            self.q_norm = RMSNorm(config.q_lora_rank, config.norm_eps)
            self.q_up = nn.Linear(config.q_lora_rank, config.n_heads * qk_dim, bias=False)
        else:
            self.q_down = nn.Identity()
            self.q_norm = nn.Identity()
            self.q_up = nn.Linear(config.dim, config.n_heads * qk_dim, bias=False)
        # One projection produces a shared KV latent and a separate positional key.
        self.kv_down = nn.Linear(config.dim, config.kv_lora_rank + config.qk_rope_head_dim, bias=False)
        self.kv_norm = RMSNorm(config.kv_lora_rank, config.norm_eps)
        self.kv_up = nn.Linear(
            config.kv_lora_rank,
            config.n_heads * (config.qk_nope_head_dim + config.v_head_dim),
            bias=False,
        )
        self.out = nn.Linear(config.n_heads * config.v_head_dim, config.dim, bias=False)
        self.softmax_scale = qk_dim ** -0.5

    def project_latents(self, x: Tensor) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        """Return q_content, q_position, normalized c_KV, rotated shared k_position.

        Shapes: [B,T,H,N], [B,T,H,R], [B,T,C], [B,T,1,R].
        """
        c = self.config
        batch, time, _ = x.shape
        q = self.q_up(self.q_norm(self.q_down(x))).view(
            batch, time, c.n_heads, c.qk_nope_head_dim + c.qk_rope_head_dim
        )
        q_content, q_position = q.split([c.qk_nope_head_dim, c.qk_rope_head_dim], -1)
        latent, k_position = self.kv_down(x).split([c.kv_lora_rank, c.qk_rope_head_dim], -1)
        return (q_content, apply_rope(q_position, c.rope_theta),
                self.kv_norm(latent), apply_rope(k_position.unsqueeze(2), c.rope_theta))

    def forward(self, x: Tensor) -> Tensor:
        c = self.config
        batch, time, _ = x.shape
        q_content, q_position, latent, k_position = self.project_latents(x)
        kv = self.kv_up(latent).view(batch, time, c.n_heads, c.qk_nope_head_dim + c.v_head_dim)
        k_content, value = kv.split([c.qk_nope_head_dim, c.v_head_dim], -1)
        query = torch.cat((q_content, q_position), -1).transpose(1, 2)
        key = torch.cat((k_content, k_position.expand(-1, -1, c.n_heads, -1)), -1).transpose(1, 2)
        value = value.transpose(1, 2)
        logits = (query.float() @ key.float().transpose(-2, -1)) * self.softmax_scale
        future = torch.ones(time, time, dtype=torch.bool, device=x.device).triu(1)
        attention = logits.masked_fill(future, float("-inf")).softmax(-1).to(value.dtype)
        mixed = (attention @ value).transpose(1, 2).reshape(batch, time, -1)
        return self.out(mixed)


class SwiGLU(nn.Module):
    def __init__(self, dim: int, inter_dim: int):
        super().__init__()
        self.gate = nn.Linear(dim, inter_dim, bias=False)
        self.up = nn.Linear(dim, inter_dim, bias=False)
        self.down = nn.Linear(inter_dim, dim, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        return self.down(F.silu(self.gate(x)) * self.up(x))


class DeepSeekRouter(nn.Module):
    """V3 sigmoid router with group restriction and selection-only correction bias.

    Input [N,D] -> mixture weights [N,K], expert indices [N,K]. Bias is a
    persistent buffer: a training loop may update it from full-batch expert load,
    but ordinary gradient descent must not fit it through mixture weights.
    """

    def __init__(self, config: DeepSeekConfig):
        super().__init__()
        self.config = config
        self.proj = nn.Linear(config.dim, config.n_routed_experts, bias=False)
        self.register_buffer("routing_bias", torch.zeros(config.n_routed_experts))

    def forward(self, x: Tensor) -> tuple[Tensor, Tensor]:
        c = self.config
        # Keep router arithmetic in float32 for stable sigmoid/normalization.
        affinity = F.linear(x.float(), self.proj.weight.float()).sigmoid()
        selection = affinity + self.routing_bias.float()
        if c.n_expert_groups > 1:
            grouped = selection.view(x.shape[0], c.n_expert_groups, -1)
            # V3's 8/4=2: each group score sums its two strongest corrected scores.
            group_scores = grouped.topk(2, dim=-1).values.sum(-1)
            groups = group_scores.topk(c.n_limited_groups, dim=-1).indices
            allowed = torch.zeros_like(group_scores, dtype=torch.bool)
            allowed.scatter_(1, groups, True)
            selection = grouped.masked_fill(~allowed.unsqueeze(-1), float("-inf")).flatten(1)
        indices = selection.topk(c.n_activated_experts, dim=-1).indices
        # The correction bias affects selected IDs only, never the mixture weights.
        weights = affinity.gather(1, indices)
        denominator = weights.sum(-1, keepdim=True).clamp_min(torch.finfo(weights.dtype).tiny)
        weights = c.route_scale * weights / denominator
        return weights.to(x.dtype), indices


class DeepSeekMoE(nn.Module):
    def __init__(self, config: DeepSeekConfig):
        super().__init__()
        self.config = config
        self.router = DeepSeekRouter(config)
        self.experts = nn.ModuleList([
            SwiGLU(config.dim, config.moe_inter_dim) for _ in range(config.n_routed_experts)
        ])
        # Concatenating independent SwiGLU hidden units is equivalent to summing
        # n_shared_experts separate experts; V3 uses exactly one shared expert.
        self.shared = (SwiGLU(config.dim, config.n_shared_experts * config.moe_inter_dim)
                       if config.n_shared_experts else None)

    def forward(self, x: Tensor) -> Tensor:
        shape = x.shape
        tokens = x.reshape(-1, shape[-1])
        weights, indices = self.router(tokens)
        routed = torch.zeros_like(tokens)
        # Readability over speed: only selected expert/token pairs execute.
        # index_add also keeps gradients to expert outputs and selected affinities.
        for expert_id, expert in enumerate(self.experts):
            token_ids, slots = torch.where(indices == expert_id)
            if token_ids.numel():
                contribution = expert(tokens[token_ids]) * weights[token_ids, slots, None]
                routed = routed.index_add(0, token_ids, contribution)
        if self.shared is not None:
            routed = routed + self.shared(tokens)
        return routed.reshape(shape)


class DeepSeekBlock(nn.Module):
    def __init__(self, config: DeepSeekConfig, layer_id: int):
        super().__init__()
        self.attn_norm = RMSNorm(config.dim, config.norm_eps)
        self.attn = MLA(config)
        self.ffn_norm = RMSNorm(config.dim, config.norm_eps)
        self.ffn = (SwiGLU(config.dim, config.inter_dim) if layer_id < config.n_dense_layers
                    else DeepSeekMoE(config))

    def forward(self, x: Tensor) -> Tensor:
        x = x + self.attn(self.attn_norm(x))
        return x + self.ffn(self.ffn_norm(x))


class DeepSeekLM(nn.Module):
    def __init__(self, config: DeepSeekConfig | None = None):
        super().__init__()
        self.config = config or DeepSeekConfig()
        c = self.config
        self.embedding = nn.Embedding(c.vocab_size, c.dim)
        self.layers = nn.ModuleList([DeepSeekBlock(c, i) for i in range(c.n_layers)])
        self.norm = RMSNorm(c.dim, c.norm_eps)
        self.lm_head = nn.Linear(c.dim, c.vocab_size, bias=False)

    def forward(self, input_ids: Tensor) -> Tensor:
        """input_ids[B,T] -> next-token logits[B,T,V], with a causal mask.

        For language-model training, compare logits[:, :-1] to input_ids[:, 1:].
        Padding masks and packed sequences are outside this minimal reference.
        """
        if input_ids.ndim != 2 or not 1 <= input_ids.shape[1] <= self.config.max_seq_len:
            raise ValueError("Expected nonempty [batch,time] IDs within max_seq_len.")
        x = self.embedding(input_ids)
        for layer in self.layers:
            x = layer(x)
        return self.lm_head(self.norm(x))


if __name__ == "__main__":
    torch.manual_seed(7)
    model = DeepSeekLM()
    ids = torch.randint(model.config.vocab_size, (2, 12))
    logits = model(ids)
    loss = F.cross_entropy(logits[:, :-1].reshape(-1, logits.shape[-1]), ids[:, 1:].reshape(-1))
    loss.backward()
    print(f"shape={tuple(logits.shape)}, next_token_loss={loss.item():.4f}")
