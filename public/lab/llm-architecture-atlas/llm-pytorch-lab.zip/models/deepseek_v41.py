"""DeepSeek-V4.1 CED/CSA2 mathematical reference, in ordinary PyTorch.

This is NOT the full 748B backbone+Engram system. It implements the mechanisms
described in the report §§2.2-2.3 and the official inference/model.py:
non-overlapping channel-wise compression, shared rotated KV latent, local SWA,
Full/Reindex/Reuse layer modes, hierarchical candidates, attention sink,
inverse output RoPE, and grouped low-rank output projection.

The explicit tensors below are layer-to-layer cache reuse within a full-sequence
forward, not an optimized incremental serving cache. Plain RoPE replaces YaRN;
FP4/FP8, distributed execution, Single-Pass mHC, Engram, real MoE, vision,
DSpark, bounded replay, pretrained weights and the indexer training loss are
outside this reference. TinyCEDReference adds dense FFNs to exercise a complete
token->logits path; its purpose is to verify CED/CSA2 composition, not claim
flagship training or performance reproduction.
"""

from dataclasses import dataclass
import math
from typing import Literal

import torch
from torch import Tensor, nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        work = x if x.dtype == torch.float64 else x.float()
        result = work * torch.rsqrt(work.square().mean(-1, keepdim=True) + self.eps)
        return result.to(x.dtype) * self.weight


@dataclass(frozen=True)
class CSA2Config:
    dim: int = 48
    n_heads: int = 4
    head_dim: int = 16
    rope_dim: int = 4
    q_rank: int = 24
    output_groups: int = 2
    output_rank: int = 12
    index_heads: int = 2
    index_dim: int = 8
    index_topk: int = 3
    window_size: int = 4
    candidate_block_size: int = 2
    candidate_topk_blocks: int = 2
    rope_theta: float = 160000.0
    norm_eps: float = 1e-6

    def __post_init__(self):
        values = (self.dim, self.n_heads, self.head_dim, self.rope_dim, self.q_rank,
                  self.output_groups, self.output_rank, self.index_heads,
                  self.index_dim, self.index_topk, self.window_size,
                  self.candidate_block_size, self.candidate_topk_blocks)
        if min(values) < 1 or self.n_heads % self.output_groups:
            raise ValueError("Positive sizes and n_heads divisible by output_groups are required.")
        if self.rope_dim % 2 or self.rope_dim > min(self.head_dim, self.index_dim):
            raise ValueError("RoPE tail must be even and fit both main/index head dimensions.")


@dataclass
class GlobalKVState:
    kv: Tensor                  # [B,J,Dh], already rotated; same latent is K and V
    index_key: Tensor           # [B,J,Di], projected from pre-RoPE compressed latent
    group_start: Tensor         # [J], RoPE position of each completed compression group
    group_end: Tensor           # [J], earliest query that may observe this whole group
    ratio: int


@dataclass
class SelectionState:
    indices: Tensor             # [B,T,K], -1 for no valid entry
    candidates: Tensor | None   # [B,T,J], optional shared candidate pool


def rotate_tail(x: Tensor, positions: Tensor, rope_dim: int, theta: float,
                inverse: bool = False) -> Tensor:
    """Adjacent-pair rotation for [B,T,D] or [B,T,H,D], only on the tail."""
    frequency = theta ** (-torch.arange(0, rope_dim, 2, device=x.device).float() / rope_dim)
    angle = positions.float()[:, None] * frequency[None, :]
    if inverse:
        angle = -angle
    broadcast = (1, positions.numel()) + (1,) * (x.ndim - 3) + (rope_dim // 2,)
    cos, sin = angle.cos().view(broadcast), angle.sin().view(broadcast)
    tail = x[..., -rope_dim:]
    even, odd = tail[..., 0::2], tail[..., 1::2]
    rotated = torch.stack((even * cos - odd * sin, even * sin + odd * cos), -1).flatten(-2)
    return torch.cat((x[..., :-rope_dim], rotated.to(x.dtype)), -1)


def hierarchical_candidates(scores: Tensor, visible: Tensor, block_size: int,
                            topk_blocks: int) -> Tensor:
    """Select blocks by max score, pin the latest reachable block as official code.

    scores [B,T,J], visible broadcastable to it. The result includes only visible
    positions, and contains at most block_size*topk_blocks entries per query.
    It does NOT eliminate the first Full-mode indexer's scan over all J entries.
    """
    if scores.shape[-1] == 0:
        return torch.zeros_like(scores, dtype=torch.bool)
    allowed = visible.expand_as(scores)
    masked = scores.masked_fill(~allowed, -torch.inf)
    padded = F.pad(masked, (0, -masked.shape[-1] % block_size), value=-torch.inf)
    blocks = padded.unflatten(-1, (-1, block_size)).amax(-1)
    newest = (allowed.sum(-1) - 1) // block_size
    ids = torch.arange(blocks.shape[-1], device=scores.device)
    blocks = blocks.masked_fill(ids == newest.unsqueeze(-1), torch.inf)
    picked = blocks.topk(min(topk_blocks, blocks.shape[-1]), -1)
    keep = torch.zeros_like(blocks, dtype=torch.bool)
    keep.scatter_(-1, picked.indices, picked.values > -torch.inf)
    return keep.repeat_interleave(block_size, -1)[..., :scores.shape[-1]] & allowed


class ChannelCompressor(nn.Module):
    """Each channel independently softmax-pools m non-overlapping source tokens."""
    def __init__(self, config: CSA2Config, ratio: int):
        super().__init__()
        if ratio < 1:
            raise ValueError("Compression ratio must be >=1.")
        self.ratio = ratio
        self.value = nn.Linear(config.dim, config.head_dim, bias=False)
        self.gate = nn.Linear(config.dim, config.head_dim, bias=False) if ratio > 1 else None
        self.norm = RMSNorm(config.head_dim, config.norm_eps)

    def forward(self, source: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        time = source.shape[1]
        complete = time // self.ratio
        cutoff = complete * self.ratio
        start = torch.arange(complete, device=source.device) * self.ratio
        end = start + self.ratio - 1
        if self.ratio == 1:
            return self.norm(self.value(source)), start, end
        value = self.value(source[:, :cutoff]).unflatten(1, (complete, self.ratio))
        score = self.gate(source[:, :cutoff]).unflatten(1, (complete, self.ratio))
        latent = (value * score.softmax(2)).sum(2)
        return self.norm(latent), start, end


class CSA2Reference(nn.Module):
    """One Full, Reindex, Reuse or SWA-only layer's attention operation.

    ``source`` may be the final causal-encoder states. Full mode builds global
    KV/index K from it; Reindex/Reuse return the SAME GlobalKVState object.
    Reuse also returns the SAME selected indices. All modes compute their own
    main query and local SWA KV. Discrete top-k has no gradient to ranking scores;
    score tensors are returned for separate objectives/inspection.
    """
    def __init__(self, mode: Literal["full", "reindex", "reuse", "swa"],
                 config: CSA2Config | None = None, *, ratio: int = 1,
                 candidate_source: bool = False):
        super().__init__()
        if mode not in ("full", "reindex", "reuse", "swa"):
            raise ValueError("Unknown CSA2 mode.")
        self.mode, self.ratio = mode, ratio
        self.config = c = config or CSA2Config()
        self.candidate_source = candidate_source
        if candidate_source and mode != "full":
            raise ValueError("This reference starts a candidate pool only in Full mode.")
        self.q_down = nn.Linear(c.dim, c.q_rank, bias=False)
        self.q_norm = RMSNorm(c.q_rank, c.norm_eps)
        self.q_up = nn.Linear(c.q_rank, c.n_heads * c.head_dim, bias=False)
        self.local_kv = nn.Linear(c.dim, c.head_dim, bias=False)
        self.local_norm = RMSNorm(c.head_dim, c.norm_eps)
        self.sink = nn.Parameter(torch.zeros(c.n_heads))
        self.out_group = nn.Parameter(torch.empty(
            c.output_groups, c.output_rank, c.n_heads * c.head_dim // c.output_groups))
        nn.init.kaiming_uniform_(self.out_group, a=math.sqrt(5))
        self.out = nn.Linear(c.output_groups * c.output_rank, c.dim, bias=False)
        if mode == "full":
            self.compressor = ChannelCompressor(c, ratio)
            self.index_key = nn.Linear(c.head_dim, c.index_dim, bias=False)
            self.index_norm = RMSNorm(c.index_dim, c.norm_eps)
        if mode in ("full", "reindex"):
            self.index_query = nn.Linear(c.q_rank, c.index_heads * c.index_dim, bias=False)
            self.index_weights = nn.Linear(c.dim, c.index_heads, bias=False)

    def forward(self, x: Tensor, global_state: GlobalKVState | None = None,
                selection: SelectionState | None = None, *, source: Tensor | None = None):
        c = self.config
        batch, time, dim = x.shape
        if dim != c.dim:
            raise ValueError("Unexpected hidden dimension.")
        positions = torch.arange(time, device=x.device)
        qr = self.q_norm(self.q_down(x))
        query = self.q_up(qr).view(batch, time, c.n_heads, c.head_dim)
        query = rotate_tail(query, positions, c.rope_dim, c.rope_theta)
        local = rotate_tail(self.local_norm(self.local_kv(x)), positions, c.rope_dim, c.rope_theta)
        local_mask = (positions[None, :] <= positions[:, None]) & (positions[None, :] > positions[:, None] - c.window_size)
        kv, masks, scores = local, local_mask[None].expand(batch, -1, -1), None

        if self.mode == "full":
            origin = x if source is None else source
            if origin.shape != x.shape:
                raise ValueError("Full-sequence source must have the same [B,T,D] shape.")
            latent, start, end = self.compressor(origin)
            ik = rotate_tail(self.index_norm(self.index_key(latent)), start, c.rope_dim, c.rope_theta)
            rotated = rotate_tail(latent, start, c.rope_dim, c.rope_theta)
            global_state = GlobalKVState(rotated, ik, start, end, self.ratio)
            selection = None

        if self.mode != "swa":
            if global_state is None or global_state.ratio != self.ratio:
                raise ValueError("A matching Full-mode global state must precede this layer.")
            count = global_state.kv.shape[1]
            visible = global_state.group_end[None, None, :] <= positions[None, :, None]
            candidates = None if selection is None else selection.candidates
            if self.mode in ("full", "reindex"):
                iq = self.index_query(qr).view(batch, time, c.index_heads, c.index_dim)
                iq = rotate_tail(iq, positions, c.rope_dim, c.rope_theta)
                weight = self.index_weights(x) / math.sqrt(c.index_dim * c.index_heads)
                scores = torch.einsum("bthd,bjd->bthj", iq, global_state.index_key).relu()
                scores = (scores * weight.unsqueeze(-1)).sum(2).masked_fill(~visible, -torch.inf)
                if self.candidate_source:
                    candidates = hierarchical_candidates(scores, visible, c.candidate_block_size, c.candidate_topk_blocks)
                # The first Full layer selects its own top-k over the full visible
                # range; only later Reindex layers are restricted to its candidates.
                ranking = scores if self.candidate_source or candidates is None else scores.masked_fill(~candidates, -torch.inf)
                if count:
                    picked = ranking.topk(min(c.index_topk, count), -1)
                    indices = torch.where(torch.isfinite(picked.values), picked.indices, -1).sort(-1).values
                else:
                    indices = torch.empty(batch, time, 0, dtype=torch.long, device=x.device)
                selection = SelectionState(indices, candidates)
            elif selection is None or selection.indices.shape[:2] != (batch, time):
                raise ValueError("Reuse mode requires the preceding selection for these queries.")

            indices = selection.indices
            if count:
                picked_mask = F.one_hot(indices.clamp_min(0), count).bool()
                picked_mask = (picked_mask & (indices >= 0).unsqueeze(-1)).any(-2)
            else:
                picked_mask = torch.zeros(batch, time, 0, dtype=torch.bool, device=x.device)
            picked_mask &= visible
            kv = torch.cat((local, global_state.kv), 1)
            masks = torch.cat((masks, picked_mask), -1)

        logits = torch.einsum("bthd,bjd->bthj", query, kv) / math.sqrt(c.head_dim)
        logits = logits.masked_fill(~masks.unsqueeze(2), -torch.inf)
        sink = self.sink[None, None, :, None].expand(batch, time, -1, -1)
        probability = torch.cat((logits, sink), -1).softmax(-1)[..., :-1]
        output = torch.einsum("bthj,bjd->bthd", probability, kv)
        output = rotate_tail(output, positions, c.rope_dim, c.rope_theta, inverse=True)
        grouped = output.reshape(batch, time, c.output_groups, -1)
        output = torch.einsum("btgd,grd->btgr", grouped, self.out_group).flatten(-2)
        return self.out(output), global_state, selection, scores


class _ReferenceBlock(nn.Module):
    def __init__(self, attention: CSA2Reference):
        super().__init__()
        self.attention = attention
        dim = attention.config.dim
        self.norm1, self.norm2 = RMSNorm(dim), RMSNorm(dim)
        self.ffn = nn.Sequential(nn.Linear(dim, 2 * dim), nn.SiLU(), nn.Linear(2 * dim, dim))

    def forward(self, x, state=None, selection=None, source=None):
        update, state, selection, scores = self.attention(self.norm1(x), state, selection, source=source)
        x = x + update
        return x + self.ffn(self.norm2(x)), state, selection, scores


class TinyCEDReference(nn.Module):
    """6-layer text scaffold for CED+CSA2 contracts, deliberately NOT full V4.1.

    3 causal encoder layers: SWA -> Full(m=2) -> Reuse.
    3 decoder layers: Full(m=1, encoder source) -> Reindex -> Reuse.
    Dense FFNs/single residual stream isolate attention behavior. No shortcut
    prefill or decode cache: every forward recomputes every token in all layers.
    """
    def __init__(self, config: CSA2Config | None = None, vocab_size: int = 256):
        super().__init__()
        c = self.config = config or CSA2Config()
        self.embedding = nn.Embedding(vocab_size, c.dim)
        self.encoder = nn.ModuleList([
            _ReferenceBlock(CSA2Reference("swa", c)),
            _ReferenceBlock(CSA2Reference("full", c, ratio=2)),
            _ReferenceBlock(CSA2Reference("reuse", c, ratio=2)),
        ])
        self.decoder = nn.ModuleList([
            _ReferenceBlock(CSA2Reference("full", c, candidate_source=True)),
            _ReferenceBlock(CSA2Reference("reindex", c)),
            _ReferenceBlock(CSA2Reference("reuse", c)),
        ])
        self.source_norm, self.norm = RMSNorm(c.dim), RMSNorm(c.dim)
        self.head = nn.Linear(c.dim, vocab_size, bias=False)

    def forward(self, input_ids: Tensor) -> Tensor:
        x, state, selection = self.embedding(input_ids), None, None
        for block in self.encoder:
            x, state, selection, _ = block(x, state, selection)
        encoder_source = self.source_norm(x)
        state = selection = None
        for index, block in enumerate(self.decoder):
            x, state, selection, _ = block(x, state, selection, encoder_source if index == 0 else None)
        return self.head(self.norm(x))


if __name__ == "__main__":
    torch.manual_seed(41)
    torch.set_num_threads(1)
    model = TinyCEDReference()
    ids = torch.randint(256, (2, 13))
    logits = model(ids)
    loss = F.cross_entropy(logits[:, :-1].flatten(0, 1), ids[:, 1:].flatten())
    loss.backward()
    print(f"CED/CSA2 reference logits={tuple(logits.shape)}, loss={loss.item():.4f}, backward=ok")
