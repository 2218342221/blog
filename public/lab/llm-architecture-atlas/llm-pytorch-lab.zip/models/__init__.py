"""Independently written, tiny educational language-model architectures."""
