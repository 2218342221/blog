"""Kimi Linear (2025) as a complete, trainable tiny PyTorch language model.

Primary sources: arXiv:2510.26692, Eqs. (1)/(10) and Section 4;
moonshotai/Kimi-Linear-48B-A3B-Base modeling_kimi.py and config.json;
FLA's KDA reference recurrence and gate. This is NOT Kimi K3 / AttnRes.

Four tiny blocks default to KDA,KDA,KDA,MLA, with one dense FFN followed
by MoE FFNs. KDA runs sequentially; MLA expands K/V. No pretrained weights,
checkpoint loader, tokenizer, fused/chunked kernels, generation cache or
original training recipe is included. MoE reuses our differentiable DeepSeek
reference, with Kimi's one group, sigmoid top-k and routed scale. The routing
bias is selection-only and zero by default; no automatic load balancing.
"""
from dataclasses import dataclass

import torch
from torch import Tensor, nn
from torch.nn import functional as F

try:
    from .deepseek_v3 import DeepSeekConfig, DeepSeekMoE, SwiGLU
except ImportError:  # Enables `python models/kimi_linear.py`.
    from deepseek_v3 import DeepSeekConfig, DeepSeekMoE, SwiGLU


@dataclass(frozen=True)
class KimiLinearConfig:
    vocab_size: int = 256
    dim: int = 64
    n_layers: int = 4
    mla_layers: tuple[int, ...] = (4,)  # ONE-based, as in the official config.
    n_dense_layers: int = 1
    n_kda_heads: int = 4
    kda_head_dim: int = 16
    conv_kernel: int = 4
    n_mla_heads: int = 4
    mla_content_dim: int = 16
    mla_shared_dim: int = 8  # Retained unrotated branch: NoPE does not delete it.
    mla_value_dim: int = 16
    kv_lora_rank: int = 24
    inter_dim: int = 128
    moe_inter_dim: int = 48
    n_routed_experts: int = 8
    n_activated_experts: int = 2
    n_shared_experts: int = 1
    route_scale: float = 2.446
    max_seq_len: int = 256
    norm_eps: float = 1e-5
    mla_latent_eps: float = 1e-6  # Official HF KimiMLAAttention's explicit default.

    def __post_init__(self):
        positive = (self.vocab_size, self.dim, self.n_layers, self.n_kda_heads,
                    self.kda_head_dim, self.conv_kernel, self.n_mla_heads,
                    self.mla_content_dim, self.mla_shared_dim, self.mla_value_dim,
                    self.kv_lora_rank, self.inter_dim, self.moe_inter_dim,
                    self.n_routed_experts, self.max_seq_len)
        if min(positive) <= 0:
            raise ValueError("Model dimensions must be positive")
        if len(set(self.mla_layers)) != len(self.mla_layers) or any(
                i < 1 or i > self.n_layers for i in self.mla_layers):
            raise ValueError("mla_layers must contain unique one-based layer indices")
        if not 0 <= self.n_dense_layers <= self.n_layers:
            raise ValueError("Invalid number of initial dense layers")
        if not 1 <= self.n_activated_experts <= self.n_routed_experts:
            raise ValueError("Invalid number of selected routed experts")
        if self.n_shared_experts < 0 or min(self.route_scale, self.norm_eps, self.mla_latent_eps) <= 0:
            raise ValueError("Invalid expert or normalization configuration")

    @classmethod
    def kimi_linear_48b_a3b(cls):
        """Published configuration only: does NOT allocate 48B parameters."""
        return cls(vocab_size=163840, dim=2304, n_layers=27,
                   mla_layers=(4, 8, 12, 16, 20, 24, 27), n_dense_layers=1,
                   n_kda_heads=32, kda_head_dim=128, conv_kernel=4,
                   n_mla_heads=32, mla_content_dim=128, mla_shared_dim=64,
                   mla_value_dim=128, kv_lora_rank=512, inter_dim=9216,
                   moe_inter_dim=1024, n_routed_experts=256,
                   n_activated_experts=8, n_shared_experts=1,
                   route_scale=2.446, max_seq_len=1048576)


def _accumulate(x: Tensor) -> Tensor:
    return x.float() if x.dtype in (torch.float16, torch.bfloat16) else x


def l2_normalize(x: Tensor, eps: float = 1e-6) -> Tensor:
    """FLA convention: epsilon is inside sqrt(sum(x^2) + eps)."""
    xf = _accumulate(x)
    return (xf * torch.rsqrt(xf.square().sum(-1, keepdim=True) + eps)).to(x.dtype)


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        xf = _accumulate(x)
        return (xf * torch.rsqrt(xf.square().mean(-1, keepdim=True) + self.eps)).to(x.dtype) * self.weight


def kda_recurrent(q: Tensor, k: Tensor, v: Tensor, log_decay: Tensor,
                  beta: Tensor, scale: float | None = None,
                  initial_state: Tensor | None = None) -> tuple[Tensor, Tensor]:
    """Eq. (1), in 'forget -> predict -> correct -> read' form.

    q,k: [B,T,H,K], already L2-normalized by the caller;
    v: [B,T,H,V]; log_decay: [B,T,H,K]; beta: [B,T,H].
    Returns output [B,T,H,V] and state [B,H,K,V]. State rows, not columns,
    are decayed independently. Half types accumulate in FP32; doubles stay FP64.
    FLA's default query scale is 1/sqrt(K); Eq. (1) absorbs this into q.
    """
    dtype = v.dtype
    q, k, v, log_decay, beta = map(_accumulate, (q, k, v, log_decay, beta))
    batch, time, heads, key_dim = q.shape
    if time < 1:
        raise ValueError("KDA requires a nonempty sequence")
    scale = key_dim ** -0.5 if scale is None else scale
    state = q.new_zeros(batch, heads, key_dim, v.shape[-1])
    if initial_state is not None:
        state = state + _accumulate(initial_state)
    outputs = []
    for t in range(time):
        forgotten = state * log_decay[:, t].exp()[..., None]
        prediction = torch.einsum('bhk,bhkv->bhv', k[:, t], forgotten)
        error = v[:, t] - prediction
        update = torch.einsum('bhk,bhv->bhkv', k[:, t], error)
        state = forgotten + beta[:, t, :, None, None] * update
        outputs.append(torch.einsum('bhk,bhkv->bhv', q[:, t] * scale, state))
    return torch.stack(outputs, dim=1).to(dtype), state


class CausalShortConv(nn.Module):
    def __init__(self, width: int, kernel: int):
        super().__init__()
        self.kernel = kernel
        self.conv = nn.Conv1d(width, width, kernel, groups=width, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        left_padded = F.pad(x.transpose(1, 2), (self.kernel - 1, 0))
        return F.silu(self.conv(left_padded).transpose(1, 2))


class KimiDeltaAttention(nn.Module):
    def __init__(self, cfg: KimiLinearConfig):
        super().__init__()
        self.cfg = cfg
        width = cfg.n_kda_heads * cfg.kda_head_dim
        self.q_proj = nn.Linear(cfg.dim, width, bias=False)
        self.k_proj = nn.Linear(cfg.dim, width, bias=False)
        self.v_proj = nn.Linear(cfg.dim, width, bias=False)
        self.q_conv = CausalShortConv(width, cfg.conv_kernel)
        self.k_conv = CausalShortConv(width, cfg.conv_kernel)
        self.v_conv = CausalShortConv(width, cfg.conv_kernel)
        self.forget_down = nn.Linear(cfg.dim, cfg.kda_head_dim, bias=False)
        self.forget_up = nn.Linear(cfg.kda_head_dim, width, bias=False)
        self.gate_down = nn.Linear(cfg.dim, cfg.kda_head_dim, bias=False)
        self.gate_up = nn.Linear(cfg.kda_head_dim, width, bias=False)
        self.beta_proj = nn.Linear(cfg.dim, cfg.n_kda_heads, bias=False)
        self.A_log = nn.Parameter(torch.empty(cfg.n_kda_heads).uniform_(1, 16).log())
        # Finite, reproducible teaching initialization. The release loads this from weights.
        self.dt_bias = nn.Parameter(torch.full((cfg.n_kda_heads, cfg.kda_head_dim), -2.0))
        # One D-vector is shared across heads, matching the release's head-wise norm.
        self.output_norm = RMSNorm(cfg.kda_head_dim, cfg.norm_eps)
        self.output = nn.Linear(width, cfg.dim, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        c = self.cfg
        shape = (*x.shape[:2], c.n_kda_heads, c.kda_head_dim)
        q = self.q_conv(self.q_proj(x)).reshape(shape)
        k = self.k_conv(self.k_proj(x)).reshape(shape)
        v = self.v_conv(self.v_proj(x)).reshape(shape)
        # L2 normalization is over each head's key channels, not RMSNorm.
        q = l2_normalize(q)
        k = l2_normalize(k)
        raw_decay = self.forget_up(self.forget_down(x)).reshape(shape)
        log_decay = -_accumulate(self.A_log).exp()[None, None, :, None] * F.softplus(
            _accumulate(raw_decay) + _accumulate(self.dt_bias))
        beta = _accumulate(self.beta_proj(x)).sigmoid()
        y, _ = kda_recurrent(q, k, v, log_decay, beta)
        gate = self.gate_up(self.gate_down(x)).reshape(shape).sigmoid()
        # Unlike Mamba-2, Kimi Linear normalizes BEFORE its sigmoid output gate.
        gated = self.output_norm(y) * gate
        return self.output(gated.flatten(-2))


class NoPEMLA(nn.Module):
    """Kimi's full attention: direct Q, latent KV, and an unrotated shared branch.

    NoPE removes rotation; the extra shared 64-dimensional K/Q branch is retained.
    This expanded implementation does not provide compressed/MQA serving caches.
    """
    def __init__(self, cfg: KimiLinearConfig):
        super().__init__()
        self.cfg = cfg
        qdim = cfg.mla_content_dim + cfg.mla_shared_dim
        self.q_proj = nn.Linear(cfg.dim, cfg.n_mla_heads * qdim, bias=False)
        self.kv_down = nn.Linear(cfg.dim, cfg.kv_lora_rank + cfg.mla_shared_dim, bias=False)
        self.kv_norm = RMSNorm(cfg.kv_lora_rank, cfg.mla_latent_eps)
        self.kv_up = nn.Linear(cfg.kv_lora_rank,
                               cfg.n_mla_heads * (cfg.mla_content_dim + cfg.mla_value_dim), bias=False)
        self.output = nn.Linear(cfg.n_mla_heads * cfg.mla_value_dim, cfg.dim, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        c = self.cfg
        batch, time, _ = x.shape
        q = self.q_proj(x).reshape(batch, time, c.n_mla_heads,
                                   c.mla_content_dim + c.mla_shared_dim)
        latent, shared = self.kv_down(x).split([c.kv_lora_rank, c.mla_shared_dim], dim=-1)
        kv = self.kv_up(self.kv_norm(latent)).reshape(
            batch, time, c.n_mla_heads, c.mla_content_dim + c.mla_value_dim)
        content, value = kv.split([c.mla_content_dim, c.mla_value_dim], dim=-1)
        key = torch.cat((content, shared[:, :, None, :].expand(-1, -1, c.n_mla_heads, -1)), -1)
        # Default SDPA scaling is 1/sqrt(content_dim + shared_dim), i.e. 1/sqrt(192).
        out = F.scaled_dot_product_attention(q.transpose(1, 2), key.transpose(1, 2),
                                             value.transpose(1, 2), is_causal=True, dropout_p=0.0)
        return self.output(out.transpose(1, 2).reshape(batch, time, -1))


class KimiLinearBlock(nn.Module):
    def __init__(self, cfg: KimiLinearConfig, layer_index: int):
        super().__init__()
        self.norm_attention = RMSNorm(cfg.dim, cfg.norm_eps)
        self.norm_ffn = RMSNorm(cfg.dim, cfg.norm_eps)
        self.attention = NoPEMLA(cfg) if layer_index + 1 in cfg.mla_layers else KimiDeltaAttention(cfg)
        if layer_index < cfg.n_dense_layers:
            self.ffn = SwiGLU(cfg.dim, cfg.inter_dim)
        else:
            # Kimi release: one expert group, so no node-group restriction.
            moe_cfg = DeepSeekConfig(
                dim=cfg.dim, moe_inter_dim=cfg.moe_inter_dim,
                n_routed_experts=cfg.n_routed_experts,
                n_activated_experts=cfg.n_activated_experts,
                n_shared_experts=cfg.n_shared_experts,
                n_expert_groups=1, n_limited_groups=1, route_scale=cfg.route_scale)
            self.ffn = DeepSeekMoE(moe_cfg)

    def forward(self, x: Tensor) -> Tensor:
        x = x + self.attention(self.norm_attention(x))
        return x + self.ffn(self.norm_ffn(x))


class KimiLinearLM(nn.Module):
    def __init__(self, config: KimiLinearConfig | None = None):
        super().__init__()
        self.config = config or KimiLinearConfig()
        self.embedding = nn.Embedding(self.config.vocab_size, self.config.dim)
        self.layers = nn.ModuleList(KimiLinearBlock(self.config, i) for i in range(self.config.n_layers))
        self.norm = RMSNorm(self.config.dim, self.config.norm_eps)
        self.lm_head = nn.Linear(self.config.dim, self.config.vocab_size, bias=False)

    def forward(self, input_ids: Tensor) -> Tensor:
        if input_ids.ndim != 2 or not 1 <= input_ids.shape[1] <= self.config.max_seq_len:
            raise ValueError("Expected [batch, nonempty time] IDs within max_seq_len")
        x = self.embedding(input_ids)
        for layer in self.layers:
            x = layer(x)
        return self.lm_head(self.norm(x)).float()


if __name__ == '__main__':
    torch.manual_seed(42)
    torch.set_num_threads(1)
    model = KimiLinearLM()
    tokens = torch.randint(256, (2, 17))
    logits = model(tokens[:, :-1])
    loss = F.cross_entropy(logits.flatten(0, 1), tokens[:, 1:].flatten())
    loss.backward()
    print(f'parameters={sum(p.numel() for p in model.parameters()):,}, logits={tuple(logits.shape)}, loss={loss.item():.6f}')
