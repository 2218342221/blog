"""Llama 3 (April 2024) decoder, expressed as a small PyTorch teaching model.

Default dimensions are tiny and randomly initialized: this is NOT a pretrained
8B model. ``LlamaConfig.llama3_8b()`` describes the original 8K-context 8B model,
not Llama 3.1. The equations and head layout follow Meta's llama3/model.py.

The implementation intentionally omits KV caching, generation, tokenizer, padding
masks, distributed tensor parallelism, and optimized/fused kernels. Attention
uses PyTorch SDPA after explicit KV-head repetition. Token IDs must already be
valid vocabulary IDs; each input row is an unpadded sequence.
"""
from dataclasses import dataclass
import torch
from torch import Tensor, nn
from torch.nn import functional as F


@dataclass(frozen=True)
class LlamaConfig:
    vocab_size: int = 256
    dim: int = 128
    n_layers: int = 2
    n_heads: int = 4
    n_kv_heads: int = 2
    hidden_dim: int = 384
    max_seq_len: int = 256
    rope_theta: float = 500_000.0
    rms_norm_eps: float = 1e-5

    def __post_init__(self):
        for name in ("vocab_size", "dim", "n_layers", "n_heads", "n_kv_heads",
                     "hidden_dim", "max_seq_len"):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive")
        if self.dim % self.n_heads != 0:
            raise ValueError("dim must be divisible by n_heads")
        if self.n_heads % self.n_kv_heads != 0:
            raise ValueError("n_heads must be divisible by n_kv_heads")
        if (self.dim // self.n_heads) % 2 != 0:
            raise ValueError("RoPE head dimension must be even")
        if self.rope_theta <= 0 or self.rms_norm_eps <= 0:
            raise ValueError("rope_theta and rms_norm_eps must be positive")

    @classmethod
    def llama3_8b(cls):
        """Configuration only; constructing LlamaLM with this needs ~32 GB FP32."""
        return cls(vocab_size=128_256, dim=4096, n_layers=32,
                   n_heads=32, n_kv_heads=8, hidden_dim=14_336,
                   max_seq_len=8192, rope_theta=500_000.0,
                   rms_norm_eps=1e-5)


class RMSNorm(nn.Module):
    """Normalize the last axis; statistics are accumulated in float32."""
    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        xf = x.float()
        normalized = xf * torch.rsqrt(xf.square().mean(-1, keepdim=True) + self.eps)
        return normalized.to(x.dtype) * self.weight


class RoPE(nn.Module):
    """Adjacent real/imaginary pairs, as in the original Meta implementation.

    q/k: [batch, heads, tokens, head_dim]. Absolute positions begin at zero
    because this teaching implementation recomputes the whole input each time.
    """
    def __init__(self, head_dim: int, theta: float):
        super().__init__()
        self.head_dim, self.theta = head_dim, theta

    def forward(self, x: Tensor) -> Tensor:
        positions = torch.arange(x.shape[-2], device=x.device, dtype=torch.float32)
        # Recompute in float32 so model.to(bfloat16) cannot quantize frequencies.
        inv_freq = self.theta ** (-torch.arange(0, self.head_dim, 2,
                                              device=x.device, dtype=torch.float32)
                                 / self.head_dim)
        angle = positions[:, None] * inv_freq[None, :]
        cos, sin = angle.cos()[None, None], angle.sin()[None, None]
        pairs = x.float().reshape(*x.shape[:-1], -1, 2)
        real, imag = pairs.unbind(-1)
        rotated = torch.stack((real * cos - imag * sin,
                               real * sin + imag * cos), dim=-1)
        return rotated.flatten(-2).to(x.dtype)


def causal_gqa(q: Tensor, k: Tensor, v: Tensor) -> Tensor:
    """Causal attention: Q[B,Hq,T,d], K/V[B,Hkv,T,d] -> [B,Hq,T,d].

    Each contiguous group of Hq/Hkv query heads shares one KV head. Repeating
    tensors here is pedagogical; it does not realize GQA's runtime cache savings.
    """
    if q.shape[1] % k.shape[1]:
        raise ValueError("query heads must be a multiple of KV heads")
    repetitions = q.shape[1] // k.shape[1]
    k = k.repeat_interleave(repetitions, dim=1)
    v = v.repeat_interleave(repetitions, dim=1)
    return F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=True)


class GQAAttention(nn.Module):
    def __init__(self, cfg: LlamaConfig):
        super().__init__()
        self.n_heads, self.n_kv_heads = cfg.n_heads, cfg.n_kv_heads
        self.head_dim = cfg.dim // cfg.n_heads
        self.wq = nn.Linear(cfg.dim, cfg.n_heads * self.head_dim, bias=False)
        self.wk = nn.Linear(cfg.dim, cfg.n_kv_heads * self.head_dim, bias=False)
        self.wv = nn.Linear(cfg.dim, cfg.n_kv_heads * self.head_dim, bias=False)
        self.wo = nn.Linear(cfg.n_heads * self.head_dim, cfg.dim, bias=False)
        self.rope = RoPE(self.head_dim, cfg.rope_theta)

    def forward(self, x: Tensor) -> Tensor:
        batch, length, _ = x.shape
        q = self.wq(x).view(batch, length, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.wk(x).view(batch, length, self.n_kv_heads, self.head_dim).transpose(1, 2)
        v = self.wv(x).view(batch, length, self.n_kv_heads, self.head_dim).transpose(1, 2)
        attended = causal_gqa(self.rope(q), self.rope(k), v)
        return self.wo(attended.transpose(1, 2).contiguous().view(batch, length, -1))


class SwiGLU(nn.Module):
    def __init__(self, cfg: LlamaConfig):
        super().__init__()
        # Meta names: w1 = gate, w3 = up, w2 = down.
        self.w1 = nn.Linear(cfg.dim, cfg.hidden_dim, bias=False)
        self.w3 = nn.Linear(cfg.dim, cfg.hidden_dim, bias=False)
        self.w2 = nn.Linear(cfg.hidden_dim, cfg.dim, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class LlamaBlock(nn.Module):
    def __init__(self, cfg: LlamaConfig):
        super().__init__()
        self.attention_norm = RMSNorm(cfg.dim, cfg.rms_norm_eps)
        self.attention = GQAAttention(cfg)
        self.ffn_norm = RMSNorm(cfg.dim, cfg.rms_norm_eps)
        self.feed_forward = SwiGLU(cfg)

    def forward(self, x: Tensor) -> Tensor:
        h = x + self.attention(self.attention_norm(x))
        return h + self.feed_forward(self.ffn_norm(h))


class LlamaLM(nn.Module):
    def __init__(self, cfg: LlamaConfig | None = None):
        super().__init__()
        self.cfg = cfg or LlamaConfig()
        self.tok_embeddings = nn.Embedding(self.cfg.vocab_size, self.cfg.dim)
        self.layers = nn.ModuleList(LlamaBlock(self.cfg) for _ in range(self.cfg.n_layers))
        self.norm = RMSNorm(self.cfg.dim, self.cfg.rms_norm_eps)
        # Original Llama 3 does not tie the embedding and output weights.
        self.output = nn.Linear(self.cfg.dim, self.cfg.vocab_size, bias=False)

    def forward(self, input_ids: Tensor) -> Tensor:
        if input_ids.ndim != 2:
            raise ValueError("input_ids must have shape [batch, tokens]")
        if not 0 < input_ids.shape[1] <= self.cfg.max_seq_len:
            raise ValueError("sequence length outside configured range")
        x = self.tok_embeddings(input_ids)
        for layer in self.layers:
            x = layer(x)
        return self.output(self.norm(x)).float()


if __name__ == "__main__":
    torch.manual_seed(7)
    model = LlamaLM()
    ids = torch.randint(model.cfg.vocab_size, (2, 12))
    logits = model(ids)
    loss = F.cross_entropy(logits[:, :-1].reshape(-1, model.cfg.vocab_size),
                           ids[:, 1:].reshape(-1))
    loss.backward()
    print(f"tiny Llama 3: parameters={sum(p.numel() for p in model.parameters()):,}")
    print(f"logits={tuple(logits.shape)}, next-token loss={loss.item():.4f}")
