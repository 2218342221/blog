"""Complete tiny Kimi K3 TEXT backbone, following the official 2026 report.

Covers bounded KDA, full-rank output gates, NoPE MLA with Q compression,
SiTU/normalized LatentMoE, and the exact decoder-block AttnRes schedule.
Default: five random tiny layers (3 KDA + 2 MLA), three residual blocks.
This is not the native multimodal K3 system: no vision, MTP, pretrained weights,
checkpoint loading, fused/chunked kernels, incremental cache or distributed QB.
An explicit, separately called next-step quantile-bias reference is provided;
forward never updates router bias from the current input batch.

Sources: sources/frontier-kimi-k3-report.pdf, Sections 2.1-2.3, Eqs. 5-14;
moonshotai/Kimi-K3/config.json and modeling_kimi_linear.py.
"""
from dataclasses import dataclass
import torch
from torch import Tensor, nn
from torch.nn import functional as F

try:
    from .kimi_linear import (KimiLinearConfig, KimiDeltaAttention, NoPEMLA,
                              RMSNorm, kda_recurrent, l2_normalize, _accumulate)
    from .deepseek_v3 import DeepSeekConfig, DeepSeekRouter
    from .attention_residuals import AttentionResiduals
except ImportError:
    from kimi_linear import (KimiLinearConfig, KimiDeltaAttention, NoPEMLA,
                             RMSNorm, kda_recurrent, l2_normalize, _accumulate)
    from deepseek_v3 import DeepSeekConfig, DeepSeekRouter
    from attention_residuals import AttentionResiduals


@dataclass(frozen=True)
class KimiK3Config(KimiLinearConfig):
    n_layers: int = 5
    mla_layers: tuple[int, ...] = (4, 5)
    n_shared_experts: int = 2
    route_scale: float = 1.0
    q_lora_rank: int = 16
    routed_latent_dim: int = 32
    attn_res_block_size: int = 2  # Counts decoder layers, each with attention + FFN.
    gate_lower_bound: float = -5.0
    situ_gate_cap: float = 4.0
    situ_up_cap: float = 25.0

    def __post_init__(self):
        super().__post_init__()
        if min(self.q_lora_rank, self.routed_latent_dim, self.attn_res_block_size,
               self.situ_gate_cap, self.situ_up_cap) <= 0 or self.gate_lower_bound >= 0:
            raise ValueError('Invalid K3 latent, block or gate configuration')

    @classmethod
    def kimi_k3_text_config(cls):
        """Official released text dimensions only; allocates no model weights."""
        return cls(vocab_size=163840, dim=7168, n_layers=93,
                   mla_layers=tuple(range(4, 93, 4)) + (93,), n_dense_layers=1,
                   n_kda_heads=96, kda_head_dim=128, conv_kernel=4,
                   n_mla_heads=96, mla_content_dim=128, mla_shared_dim=64,
                   mla_value_dim=128, kv_lora_rank=512, q_lora_rank=1536,
                   inter_dim=33792, moe_inter_dim=3072,
                   n_routed_experts=896, n_activated_experts=16, n_shared_experts=2,
                   routed_latent_dim=3584, attn_res_block_size=12,
                   max_seq_len=1048576)


def situ_product(gate: Tensor, up: Tensor, gate_cap: float = 4.0,
                 up_cap: float = 25.0) -> Tensor:
    """Eq. 12, before the FFN down projection. Product magnitude <= 100.

    The sigmoid uses the ORIGINAL gate logit, not its soft-capped value.
    The 100 bound does not apply after multiplication by the down-projection.
    """
    g, u = _accumulate(gate), _accumulate(up)
    product = gate_cap * torch.tanh(g / gate_cap) * g.sigmoid()
    product = product * (up_cap * torch.tanh(u / up_cap))
    return product.to(gate.dtype)


class SiTUMLP(nn.Module):
    def __init__(self, width: int, hidden: int, gate_cap: float = 4.0,
                 up_cap: float = 25.0):
        super().__init__()
        self.gate = nn.Linear(width, hidden, bias=False)
        self.up = nn.Linear(width, hidden, bias=False)
        self.down = nn.Linear(hidden, width, bias=False)
        self.gate_cap, self.up_cap = gate_cap, up_cap

    def forward(self, x: Tensor) -> Tensor:
        return self.down(situ_product(self.gate(x), self.up(x), self.gate_cap, self.up_cap))


def bounded_log_decay(raw: Tensor, a_log: Tensor, bias: Tensor,
                       lower_bound: float = -5.0) -> Tensor:
    """Eq. 5. raw[...,head,key]; a_log[head], bias[head,key]."""
    return lower_bound * torch.sigmoid(
        _accumulate(a_log).exp()[..., None] * (_accumulate(raw) + _accumulate(bias)))


class K3DeltaAttention(KimiDeltaAttention):
    def __init__(self, cfg: KimiK3Config):
        super().__init__(cfg)
        # ONLY the output gate changes to a full-rank projection.
        # Forget gate keeps the inherited head_dim-rank down/up projections.
        del self.gate_down, self.gate_up
        self.output_gate = nn.Linear(cfg.dim, cfg.n_kda_heads * cfg.kda_head_dim, bias=False)
        nn.init.zeros_(self.A_log)  # Report initialization; dt_bias remains teaching -2.

    def forward(self, x: Tensor) -> Tensor:
        c = self.cfg
        shape = (*x.shape[:2], c.n_kda_heads, c.kda_head_dim)
        q = l2_normalize(self.q_conv(self.q_proj(x)).reshape(shape))
        k = l2_normalize(self.k_conv(self.k_proj(x)).reshape(shape))
        v = self.v_conv(self.v_proj(x)).reshape(shape)
        raw = self.forget_up(self.forget_down(x)).reshape(shape)
        log_a = bounded_log_decay(raw, self.A_log, self.dt_bias, c.gate_lower_bound)
        beta = _accumulate(self.beta_proj(x)).sigmoid()
        y, _ = kda_recurrent(q, k, v, log_a, beta)
        gate = self.output_gate(x).reshape(shape).sigmoid()
        return self.output((self.output_norm(y) * gate).flatten(-2))


class K3GatedMLA(NoPEMLA):
    def __init__(self, cfg: KimiK3Config):
        super().__init__(cfg)
        self.q_proj = nn.Sequential(
            nn.Linear(cfg.dim, cfg.q_lora_rank, bias=False),
            RMSNorm(cfg.q_lora_rank, cfg.mla_latent_eps),
            nn.Linear(cfg.q_lora_rank, cfg.n_mla_heads *
                      (cfg.mla_content_dim + cfg.mla_shared_dim), bias=False))
        self.output_gate = nn.Linear(cfg.dim, cfg.n_mla_heads * cfg.mla_value_dim, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        c = self.cfg
        batch, time, _ = x.shape
        q = self.q_proj(x).reshape(batch, time, c.n_mla_heads,
                                   c.mla_content_dim + c.mla_shared_dim)
        latent, shared = self.kv_down(x).split([c.kv_lora_rank, c.mla_shared_dim], dim=-1)
        kv = self.kv_up(self.kv_norm(latent)).reshape(
            batch, time, c.n_mla_heads, c.mla_content_dim + c.mla_value_dim)
        content, value = kv.split([c.mla_content_dim, c.mla_value_dim], dim=-1)
        key = torch.cat((content, shared[:, :, None].expand(-1, -1, c.n_mla_heads, -1)), -1)
        q, key, value = map(_accumulate, (q, key, value))
        mixed = F.scaled_dot_product_attention(q.transpose(1, 2), key.transpose(1, 2),
                                               value.transpose(1, 2), is_causal=True, dropout_p=0.0)
        mixed = mixed.transpose(1, 2).reshape(batch, time, -1)
        gated = mixed * _accumulate(self.output_gate(x)).sigmoid()
        # Gate before Wo; no additional head-wise RMSNorm in the MLA branch.
        return self.output(gated.to(x.dtype))


@torch.no_grad()
def quantile_bias_next_step(scores: Tensor, old_bias: Tensor, topk: int) -> Tensor:
    """Small exact-order-statistic QB reference, Eq. 14 (not distributed histograms).

    scores[m,n] are raw sigmoid affinities. Requires integer target m*k/n and
    1 <= k < n. Assumes distinct margins for the target-load interpretation.
    Returns a centered NEW bias: callers may install it only on a later batch.
    Does not promise simultaneous perfect Top-k load balance after all cutoffs
    change, nor mutate routing for the current batch.
    """
    if scores.ndim != 2 or not 1 <= topk < scores.shape[1]:
        raise ValueError('Expected [tokens,experts], with 1 <= topk < experts')
    tokens, experts = scores.shape
    if tokens * topk % experts:
        raise ValueError('This exact reference requires an integer target load')
    target = tokens * topk // experts
    if target < 1:
        raise ValueError('At least one target token per expert is required')
    cutoffs = (scores + old_bias).topk(topk + 1, dim=-1).values[:, topk]
    margins = scores - cutoffs[:, None]
    next_bias = -margins.topk(target + 1, dim=0).values[-1]
    return next_bias - next_bias.mean()


class StableLatentMoE(nn.Module):
    def __init__(self, cfg: KimiK3Config):
        super().__init__()
        self.cfg = cfg
        self.router = DeepSeekRouter(DeepSeekConfig(
            dim=cfg.dim, n_routed_experts=cfg.n_routed_experts,
            n_activated_experts=cfg.n_activated_experts, n_expert_groups=1,
            n_limited_groups=1, route_scale=cfg.route_scale))
        self.compress = nn.Linear(cfg.dim, cfg.routed_latent_dim, bias=False)
        self.experts = nn.ModuleList(SiTUMLP(cfg.routed_latent_dim, cfg.moe_inter_dim,
                                            cfg.situ_gate_cap, cfg.situ_up_cap)
                                     for _ in range(cfg.n_routed_experts))
        self.aggregate_norm = RMSNorm(cfg.routed_latent_dim, cfg.norm_eps)
        self.expand = nn.Linear(cfg.routed_latent_dim, cfg.dim, bias=False)
        # Equivalent to summing independent full-width shared expert FFNs.
        self.shared = (SiTUMLP(cfg.dim, cfg.moe_inter_dim * cfg.n_shared_experts,
                               cfg.situ_gate_cap, cfg.situ_up_cap)
                       if cfg.n_shared_experts else None)

    def forward(self, x: Tensor) -> Tensor:
        shape = x.shape
        tokens = x.reshape(-1, shape[-1])
        weights, indices = self.router(tokens)  # Router sees full-width x, not z.
        z = self.compress(tokens)
        aggregate = torch.zeros_like(z)
        for expert_id, expert in enumerate(self.experts):
            token_ids, slots = torch.where(indices == expert_id)
            if token_ids.numel():
                contribution = expert(z[token_ids]) * weights[token_ids, slots, None]
                aggregate = aggregate.index_add(0, token_ids, contribution)
        y = self.expand(self.aggregate_norm(aggregate))  # Norm AFTER mixing, BEFORE expansion.
        if self.shared is not None:
            y = y + self.shared(tokens)
        return y.reshape(shape)


class KimiK3Block(nn.Module):
    def __init__(self, cfg: KimiK3Config, layer_index: int):
        super().__init__()
        self.cfg, self.layer_index = cfg, layer_index
        self.attention = K3GatedMLA(cfg) if layer_index + 1 in cfg.mla_layers else K3DeltaAttention(cfg)
        self.ffn = (SiTUMLP(cfg.dim, cfg.inter_dim, cfg.situ_gate_cap, cfg.situ_up_cap)
                    if layer_index < cfg.n_dense_layers else StableLatentMoE(cfg))
        self.norm_attention = RMSNorm(cfg.dim, cfg.norm_eps)
        self.norm_ffn = RMSNorm(cfg.dim, cfg.norm_eps)
        self.attn_res = AttentionResiduals(cfg.dim, cfg.norm_eps)
        self.ffn_res = AttentionResiduals(cfg.dim, cfg.norm_eps)

    def forward(self, partial: Tensor, completed: list[Tensor]) -> tuple[Tensor, list[Tensor]]:
        # Aggregate old partial first; only then commit it at a decoder-block boundary.
        h = self.attn_res.from_blocks(completed, partial) if completed else partial
        if self.layer_index % self.cfg.attn_res_block_size == 0:
            completed = [*completed, partial]  # layer 0 commits the embedding source.
            partial = None
        attention_out = self.attention(self.norm_attention(h))
        partial = attention_out if partial is None else partial + attention_out
        h = self.ffn_res.from_blocks(completed, partial)
        partial = partial + self.ffn(self.norm_ffn(h))
        return partial, completed


class KimiK3LM(nn.Module):
    def __init__(self, config: KimiK3Config | None = None):
        super().__init__()
        self.config = config or KimiK3Config()
        self.embedding = nn.Embedding(self.config.vocab_size, self.config.dim)
        self.layers = nn.ModuleList(KimiK3Block(self.config, i) for i in range(self.config.n_layers))
        self.output_res = AttentionResiduals(self.config.dim, self.config.norm_eps)
        self.norm = RMSNorm(self.config.dim, self.config.norm_eps)
        self.lm_head = nn.Linear(self.config.dim, self.config.vocab_size, bias=False)

    def forward(self, input_ids: Tensor) -> Tensor:
        if input_ids.ndim != 2 or not 1 <= input_ids.shape[1] <= self.config.max_seq_len:
            raise ValueError('Expected [batch,nonempty time] within max_seq_len')
        partial, completed = self.embedding(input_ids), []
        for layer in self.layers:
            partial, completed = layer(partial, completed)
        h = self.output_res.from_blocks(completed, partial)
        return self.lm_head(self.norm(h)).float()


if __name__ == '__main__':
    torch.manual_seed(42)
    torch.set_num_threads(1)
    model = KimiK3LM()
    ids = torch.randint(256, (2, 13))
    logits = model(ids[:, :-1])
    loss = F.cross_entropy(logits.flatten(0, 1), ids[:, 1:].flatten())
    loss.backward()
    print(f'parameters={sum(p.numel() for p in model.parameters()):,}, logits={tuple(logits.shape)}, loss={loss.item():.6f}')
