"""Two research modules in plain PyTorch: original mHC and original Engram.

These are core-operator references, NOT a DeepSeek-V4/V4.1 model or checkpoint
loader. mHC follows arXiv:2512.24880 equations 7-9; Engram follows
arXiv:2601.07372 equations 1-6. See notes/frontier-deepseek.md for exact scope.

V4.1 differs: its Single-Pass mHC delays pre-mixing coefficients by one block;
its Engram removes the convolution. Neither V4.1's inference fusion nor its
embedding optimizer/offloading is reproduced here.
"""

from dataclasses import dataclass
import math
import re
from typing import Sequence
import unicodedata

import torch
from torch import Tensor, nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        work = x if x.dtype == torch.float64 else x.float()
        normalized = work * torch.rsqrt(work.square().mean(-1, keepdim=True) + self.eps)
        return normalized.to(x.dtype) * self.weight


def sinkhorn_residual(logits: Tensor, iterations: int = 20) -> Tensor:
    """Positive, approximately doubly stochastic mixing; stable log-space form.

    Input [...,S,S]. Each iteration normalizes columns THEN rows, as mHC Eq.9.
    Finite iteration counts do not make both marginal sums exactly one: the
    final row normalization is exact up to rounding, while columns retain a
    convergence error. No claim of an exact Euclidean projection is made.
    """
    if logits.ndim < 2 or logits.shape[-1] != logits.shape[-2] or iterations < 1:
        raise ValueError("Expected square logits and at least one Sinkhorn iteration.")
    log_matrix = logits if logits.dtype == torch.float64 else logits.float()
    for _ in range(iterations):
        log_matrix = log_matrix - log_matrix.logsumexp(-2, keepdim=True)
        log_matrix = log_matrix - log_matrix.logsumexp(-1, keepdim=True)
    return log_matrix.exp()


@dataclass(frozen=True)
class MHCConfig:
    dim: int = 32
    streams: int = 4
    sinkhorn_iterations: int = 20
    norm_eps: float = 1e-6
    dynamic_scale_init: float = 0.01

    def __post_init__(self):
        if min(self.dim, self.streams, self.sinkhorn_iterations) < 1 or self.norm_eps <= 0:
            raise ValueError("mHC dimensions, iteration count and epsilon must be positive.")


class MHCWrapper(nn.Module):
    """Original mHC: X' = H_res X + H_post^T F(H_pre X).

    X is [batch,time,streams,dim]. ``sublayer`` receives [batch,time,dim] and
    must return that shape. F includes whatever pre-normalization it needs.
    If wrapping an existing block that already returns x + delta, set
    ``sublayer_returns_residual=True``; the wrapper subtracts its input once.
    This prevents accidentally adding the single-stream residual a second time.
    """

    def __init__(self, sublayer: nn.Module, config: MHCConfig | None = None,
                 *, sublayer_returns_residual: bool = False):
        super().__init__()
        self.config = config or MHCConfig()
        self.sublayer = sublayer
        self.sublayer_returns_residual = sublayer_returns_residual
        c = self.config
        self.coefficient_norm = RMSNorm(c.streams * c.dim, c.norm_eps)
        self.dynamic = nn.Linear(c.streams * c.dim, 2 * c.streams + c.streams ** 2, bias=False)
        self.dynamic_scale = nn.Parameter(torch.full((3,), c.dynamic_scale_init))
        self.pre_bias = nn.Parameter(torch.zeros(c.streams))
        self.post_bias = nn.Parameter(torch.zeros(c.streams))
        # A convenient near-identity teaching initialization, not checkpoint weights.
        self.residual_bias = nn.Parameter(4 * torch.eye(c.streams))

    def mixing_matrices(self, x: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        c = self.config
        if x.ndim != 4 or x.shape[-2:] != (c.streams, c.dim):
            raise ValueError("Expected [batch,time,streams,dim].")
        coeff = self.dynamic(self.coefficient_norm(x.flatten(-2)))
        pre, post, residual = coeff.split((c.streams, c.streams, c.streams ** 2), -1)
        pre = torch.sigmoid(self.dynamic_scale[0] * pre + self.pre_bias)
        post = 2 * torch.sigmoid(self.dynamic_scale[1] * post + self.post_bias)
        residual = self.dynamic_scale[2] * residual.unflatten(-1, (c.streams, c.streams))
        residual = sinkhorn_residual(residual + self.residual_bias, c.sinkhorn_iterations)
        return pre, post, residual

    def forward(self, x: Tensor) -> Tensor:
        pre, post, residual = self.mixing_matrices(x)
        branch_input = torch.einsum("bts,btsd->btd", pre, x)
        update = self.sublayer(branch_input)
        if update.shape != branch_input.shape:
            raise ValueError("The wrapped sublayer must preserve [batch,time,dim].")
        if self.sublayer_returns_residual:
            update = update - branch_input
        mixed = torch.einsum("btij,btjd->btid", residual.to(x.dtype), x)
        return mixed + post.unsqueeze(-1) * update.unsqueeze(-2)


def toy_token_normalization_map(decoded_tokens: Sequence[str]) -> Tensor:
    """Canonical IDs for a small *decoded-token* vocabulary; not a tokenizer.

    NFKC -> NFD -> remove combining accents -> lowercase -> collapse whitespace
    -> strip, while preserving an all-whitespace token as one space. This
    illustrates Engram's separate lookup vocabulary. Production additionally
    needs exact tokenizer decoding, special-token handling and invalid-Unicode
    fallback to raw token spellings; no remote tokenizer is loaded here.
    """
    canonical_ids: dict[str, int] = {}
    result = []
    for text in decoded_tokens:
        normalized = unicodedata.normalize("NFD", unicodedata.normalize("NFKC", text))
        normalized = "".join(char for char in normalized if unicodedata.category(char) != "Mn")
        normalized = re.sub(r"[ \t\r\n]+", " ", normalized.lower())
        normalized = " " if normalized == " " else normalized.strip()
        key = normalized or text
        if key not in canonical_ids:
            canonical_ids[key] = len(canonical_ids)
        result.append(canonical_ids[key])
    return torch.tensor(result, dtype=torch.long)


def _next_prime(candidate: int) -> int:
    candidate = max(2, candidate)
    while True:
        if all(candidate % divisor for divisor in range(2, math.isqrt(candidate) + 1)):
            return candidate
        candidate += 1


@dataclass(frozen=True)
class EngramConfig:
    vocab_size: int = 256
    dim: int = 32
    streams: int = 4
    max_ngram_size: int = 3
    heads_per_order: int = 2
    head_dim: int = 8
    table_size_min: int = 101
    pad_token_id: int = 0
    kernel_size: int = 4
    use_conv: bool = True
    seed: int = 0
    layer_id: int = 1
    norm_eps: float = 1e-6
    gate_transform: str = "paper"

    def __post_init__(self):
        if min(self.vocab_size, self.dim, self.streams, self.heads_per_order,
               self.head_dim, self.table_size_min, self.kernel_size) < 1:
            raise ValueError("Engram dimensions and table/kernel sizes must be positive.")
        if self.max_ngram_size < 2 or not 0 <= self.pad_token_id < self.vocab_size:
            raise ValueError("Engram needs orders >=2 and a valid padding ID.")
        if self.norm_eps <= 0 or self.gate_transform not in ("paper", "official_demo"):
            raise ValueError("Invalid normalization epsilon or gate transform.")


class EngramMemory(nn.Module):
    """N-gram lookup -> context-aware gates -> optional causal conv residual.

    ``forward(hidden, ids)`` returns only the memory update, to be added once to
    the residual stream. Hidden has [B,T,S,D] (or [B,T,D] when S=1); IDs [B,T].
    Default token mapping is identity for toy IDs. Pass ``token_map`` to model
    canonicalization without changing the backbone's own token IDs.

    Default gate follows paper Eq.4. The official public demo additionally
    applies sign(score)*sqrt(abs(score)); ``gate_transform='official_demo'``
    exposes that documented difference rather than silently changing Eq.4.
    """

    def __init__(self, config: EngramConfig | None = None, token_map: Tensor | None = None):
        super().__init__()
        self.config = config or EngramConfig()
        c = self.config
        mapping = torch.arange(c.vocab_size) if token_map is None else token_map.detach().long().clone()
        if mapping.shape != (c.vocab_size,) or (mapping < 0).any() or (mapping >= c.vocab_size).any():
            raise ValueError("token_map must assign one canonical ID in [0,vocab_size) per raw ID.")
        self.register_buffer("token_map", mapping)
        generator = torch.Generator().manual_seed(c.seed + 10007 * c.layer_id)
        # Small odd multipliers keep the toy hash within signed int64. Production
        # seeds/multiplier ranges and tokenizer vocabularies must match its tables.
        multipliers = 2 * torch.randint(1, 1_000_000, (c.max_ngram_size,), generator=generator) + 1
        self.register_buffer("hash_multipliers", multipliers)
        table_sizes, candidate = [], c.table_size_min
        for _ in range((c.max_ngram_size - 1) * c.heads_per_order):
            prime = _next_prime(candidate)
            table_sizes.append(prime)
            candidate = prime + 1
        self.table_sizes = tuple(table_sizes)
        self.tables = nn.ModuleList([nn.Embedding(size, c.head_dim) for size in table_sizes])
        memory_dim = len(table_sizes) * c.head_dim
        self.value_proj = nn.Linear(memory_dim, c.dim, bias=False)
        self.key_projs = nn.ModuleList([nn.Linear(memory_dim, c.dim, bias=False) for _ in range(c.streams)])
        self.query_norms = nn.ModuleList([RMSNorm(c.dim, c.norm_eps) for _ in range(c.streams)])
        self.key_norms = nn.ModuleList([RMSNorm(c.dim, c.norm_eps) for _ in range(c.streams)])
        if c.use_conv:
            self.conv_norms = nn.ModuleList([RMSNorm(c.dim, c.norm_eps) for _ in range(c.streams)])
            channels = c.streams * c.dim
            self.conv = nn.Conv1d(channels, channels, c.kernel_size,
                                  groups=channels, dilation=c.max_ngram_size, bias=False)

    def lookup_indices(self, input_ids: Tensor) -> Tensor:
        """Return [B,T,(N-1)*K] deterministic indices, independent of hidden states."""
        if input_ids.ndim != 2 or input_ids.shape[1] < 1:
            raise ValueError("Expected nonempty [batch,time] token IDs.")
        if input_ids.dtype not in (torch.int32, torch.int64) or (input_ids < 0).any() or (input_ids >= self.config.vocab_size).any():
            raise ValueError("Token IDs must be integers in [0,vocab_size).")
        canonical = self.token_map[input_ids]
        length = canonical.shape[1]
        shifts = [canonical]
        padding = int(self.token_map[self.config.pad_token_id])
        for offset in range(1, self.config.max_ngram_size):
            shifts.append(F.pad(canonical, (offset, 0), value=padding)[:, :length])
        mixed = shifts[0] * self.hash_multipliers[0]
        indices, table = [], 0
        for order in range(2, self.config.max_ngram_size + 1):
            mixed = torch.bitwise_xor(mixed, shifts[order - 1] * self.hash_multipliers[order - 1])
            for _ in range(self.config.heads_per_order):
                indices.append(mixed.remainder(self.table_sizes[table]))
                table += 1
        return torch.stack(indices, -1)

    def retrieve(self, input_ids: Tensor) -> Tensor:
        indices = self.lookup_indices(input_ids)
        return torch.cat([table(indices[..., index]) for index, table in enumerate(self.tables)], -1)

    def _as_streams(self, hidden: Tensor) -> tuple[Tensor, bool]:
        single = hidden.ndim == 3 and self.config.streams == 1
        if single:
            hidden = hidden.unsqueeze(-2)
        if hidden.ndim != 4 or hidden.shape[-2:] != (self.config.streams, self.config.dim):
            raise ValueError("Hidden must have [B,T,streams,dim], or [B,T,dim] for one stream.")
        return hidden, single

    def context_gates(self, hidden: Tensor, memory: Tensor) -> Tensor:
        hidden, _ = self._as_streams(hidden)
        gates = []
        for stream in range(self.config.streams):
            query = self.query_norms[stream](hidden[:, :, stream])
            key = self.key_norms[stream](self.key_projs[stream](memory))
            score = (query * key).sum(-1) / math.sqrt(self.config.dim)
            if self.config.gate_transform == "official_demo":
                score = score.sign() * score.abs().clamp_min(1e-6).sqrt()
            gates.append(score.sigmoid())
        return torch.stack(gates, -1).unsqueeze(-1)

    def forward(self, hidden: Tensor, input_ids: Tensor) -> Tensor:
        hidden, single = self._as_streams(hidden)
        if hidden.shape[:2] != input_ids.shape:
            raise ValueError("Hidden batch/time must match input IDs.")
        memory = self.retrieve(input_ids)
        gated = self.context_gates(hidden, memory) * self.value_proj(memory).unsqueeze(-2)
        update = gated
        if self.config.use_conv:
            normed = torch.stack([norm(gated[:, :, stream])
                                  for stream, norm in enumerate(self.conv_norms)], -2)
            channels = normed.flatten(-2).transpose(1, 2)
            left_padding = (self.config.kernel_size - 1) * self.config.max_ngram_size
            convolved = self.conv(F.pad(channels, (left_padding, 0)))
            update = update + F.silu(convolved.transpose(1, 2).reshape_as(gated))
        return update.squeeze(-2) if single else update


if __name__ == "__main__":
    torch.manual_seed(11)
    ids = torch.randint(256, (2, 9))
    hidden = torch.randn(2, 9, 4, 32, requires_grad=True)
    memory = EngramMemory()
    mhc = MHCWrapper(nn.Sequential(RMSNorm(32), nn.Linear(32, 32)))
    output = mhc(hidden + memory(hidden, ids))
    output.square().mean().backward()
    _, _, residual = mhc.mixing_matrices(hidden.detach())
    error = (residual.sum(-2) - 1).abs().max().item()
    print(f"shape={tuple(output.shape)}, column_sum_error={error:.3g}, backward=ok")
