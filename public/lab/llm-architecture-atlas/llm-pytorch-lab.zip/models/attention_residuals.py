"""Attention Residuals (2026), a trainable depth-aggregation reference.

Source: MoonshotAI/Attention-Residuals, arXiv:2603.15031, Eq. 2-4 and
Block AttnRes pseudocode. This is a research component, not a Kimi K3 model.
It aggregates feature sources at the SAME token position. It does not replace
sequence self-attention, create a KV cache, or implement distributed pipelines.
"""
from collections.abc import Sequence
import torch
from torch import Tensor, nn


class AttentionResiduals(nn.Module):
    """Learned pseudo-query attends across depth, with unnormalized values.

    sources: K tensors [batch,time,dim], or [sources,batch,time,dim].
    Keys are RMS-normalized along dim; softmax is over sources (axis zero),
    independently at every batch/token. Query is a learned vector per consumer
    sublayer, not a feature projection of the current token. Weights are still
    input-dependent because source keys depend on the token's representations.
    """
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.dim, self.eps = dim, eps
        self.query = nn.Parameter(torch.zeros(dim))
        self.norm_weight = nn.Parameter(torch.ones(dim))

    def forward(self, sources: Sequence[Tensor] | Tensor,
                return_weights: bool = False):
        values = sources if isinstance(sources, Tensor) else torch.stack(list(sources), 0)
        if values.ndim != 4 or values.shape[0] < 1 or values.shape[-1] != self.dim:
            raise ValueError('Expected [sources,batch,time,dim], with at least one source')
        work = values.float() if values.dtype in (torch.float16, torch.bfloat16) else values
        keys = work * torch.rsqrt(work.square().mean(-1, keepdim=True) + self.eps)
        keys = keys * self.norm_weight
        scores = torch.einsum('d,sbtd->sbt', self.query, keys)
        weights = scores.softmax(dim=0)  # Depth/source axis, NEVER the token axis.
        output = torch.einsum('sbt,sbtd->btd', weights, work).to(values.dtype)
        return (output, weights) if return_weights else output

    def from_blocks(self, completed: Sequence[Tensor], partial: Tensor | None = None,
                    return_weights: bool = False):
        """Block AttnRes input: completed blocks plus current partial residual sum.

        Caller owns block boundaries and accumulates sublayer outputs into the
        current partial block. Use a separate instance for each attention/FFN
        consumer. Initial token embeddings are one of the completed sources.
        This method implements aggregation only, not a full network schedule.
        """
        sources = list(completed) + ([] if partial is None else [partial])
        if not sources:
            raise ValueError('At least one embedding/block source is required')
        return self(sources, return_weights=return_weights)


if __name__ == '__main__':
    torch.manual_seed(2026)
    mix = AttentionResiduals(16)
    sources = torch.randn(4, 2, 5, 16, requires_grad=True)
    y, weights = mix(sources, return_weights=True)
    y.square().mean().backward()
    print(f'output={tuple(y.shape)}, weights.sum(depth)={weights.sum(0).mean().item():.6f}')
