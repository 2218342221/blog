"""Small, complete Mamba-2 causal language model using ordinary PyTorch.

References: Dao & Gu (2024), arXiv:2405.21060, and state-spaces/mamba
modules/mamba2.py, modules/ssd_minimal.py, ops/triton/layernorm_gated.py.

This is an independently written teaching implementation of the pure Mamba-2
architecture. It has random weights, no tokenizer, no official checkpoint
compatibility, no fused CUDA scan and no generation cache. The recurrent path
is sequential; the explicit SSD matrix path takes quadratic sequence memory.
Neither reproduces the performance of the paper's chunked SSD implementation.
"""

from dataclasses import dataclass
import math

import torch
from torch import Tensor, nn
import torch.nn.functional as F


@dataclass(frozen=True)
class Mamba2Config:
    vocab_size: int = 256
    d_model: int = 64
    n_layers: int = 2
    d_state: int = 16
    expand: int = 2
    headdim: int = 16
    ngroups: int = 1
    d_conv: int = 4
    norm_eps: float = 1e-5
    tie_embeddings: bool = True
    ssd_backend: str = "recurrent"

    def __post_init__(self):
        dimensions = (self.vocab_size, self.d_model, self.n_layers,
                      self.d_state, self.expand, self.headdim,
                      self.ngroups, self.d_conv)
        if any(d <= 0 for d in dimensions):
            raise ValueError("All dimensions must be positive")
        if self.d_inner % self.headdim or self.nheads % self.ngroups:
            raise ValueError("d_inner must divide by headdim; heads by ngroups")
        if self.ssd_backend not in ("recurrent", "matrix"):
            raise ValueError("ssd_backend must be 'recurrent' or 'matrix'")

    @property
    def d_inner(self) -> int:
        return self.expand * self.d_model

    @property
    def nheads(self) -> int:
        return self.d_inner // self.headdim


def _accumulate(x: Tensor) -> Tensor:
    """Keep double for equivalence checks; accumulate half types in float32."""
    return x.float() if x.dtype in (torch.float16, torch.bfloat16) else x


def _head_groups(x: Tensor, nheads: int) -> Tensor:
    """[batch,time,groups,state] -> [batch,time,heads,state]."""
    if nheads % x.shape[2]:
        raise ValueError("The number of heads must divide by B/C groups")
    return x.repeat_interleave(nheads // x.shape[2], dim=2)


def ssd_recurrent(x: Tensor, dt: Tensor, A: Tensor, B: Tensor, C: Tensor,
                  D: Tensor | None = None) -> tuple[Tensor, Tensor]:
    """Zero-initialized selective SSD recurrence, including an optional D skip.

    x: [batch,time,heads,headdim]; dt: [batch,time,heads], already softplus;
    A: [heads], negative; B,C: [batch,time,groups,state]; D: [heads].
    Returns y with x's shape and final state [batch,heads,headdim,state].
    The continuous scalar A and Delta*x input discretization match official
    Mamba-2; this is not an exact zero-order-hold B discretization.
    """
    input_dtype = x.dtype
    x, dt, A, B, C = map(_accumulate, (x, dt, A, B, C))
    batch, length, heads, head_dim = x.shape
    if length < 1:
        raise ValueError("SSD requires a nonempty sequence")
    B, C = _head_groups(B, heads), _head_groups(C, heads)
    state = x.new_zeros(batch, heads, head_dim, B.shape[-1])
    ys = []
    for t in range(length):
        decay = torch.exp(dt[:, t] * A)  # [batch,heads]
        write = torch.einsum("bhp,bhn->bhpn", x[:, t], B[:, t])
        state = decay[..., None, None] * state + dt[:, t, :, None, None] * write
        y = torch.einsum("bhpn,bhn->bhp", state, C[:, t])
        if D is not None:
            y = y + D[None, :, None] * x[:, t]
        ys.append(y)
    return torch.stack(ys, dim=1).to(input_dtype), state


def ssd_matrix(x: Tensor, dt: Tensor, A: Tensor, B: Tensor, C: Tensor,
               D: Tensor | None = None) -> Tensor:
    """Same SSD operator written as an explicit lower-triangular matrix.

    M[i,j,h] = 1[i>=j] * <C[i,h],B[j,h]>
               * exp(sum(k=j+1..i) dt[k,h]*A[h]).
    y[i,h] = sum(j<=i) M[i,j,h] * dt[j,h] * x[j,h] + D[h]*x[i,h].
    This transparent O(T^2) reference is NOT the fast chunked SSD algorithm.
    Segment sums avoid subtraction of two long prefix sums.
    """
    input_dtype = x.dtype
    x, dt, A, B, C = map(_accumulate, (x, dt, A, B, C))
    length, heads = x.shape[1:3]
    if length < 1:
        raise ValueError("SSD requires a nonempty sequence")
    B, C = _head_groups(B, heads), _head_groups(C, heads)
    alpha = (dt * A).transpose(1, 2)  # [batch,heads,time]
    lower = torch.ones(length, length, device=x.device, dtype=torch.bool).tril()
    strict_lower = lower & ~torch.eye(length, device=x.device, dtype=torch.bool)
    segments = alpha[..., :, None].expand(-1, -1, -1, length)
    segments = segments.masked_fill(~strict_lower, 0).cumsum(dim=-2)
    decay = segments.masked_fill(~lower, -torch.inf).exp()
    cb = torch.einsum("bihn,bjhn->bhij", C, B)
    y = torch.einsum("bhij,bjhp->bihp", decay * cb, x * dt[..., None])
    if D is not None:
        y = y + D[None, None, :, None] * x
    return y.to(input_dtype)


class RMSNorm(nn.Module):
    def __init__(self, width: int, eps: float, ngroups: int = 1):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(width))
        self.eps, self.ngroups = eps, ngroups

    def forward(self, x: Tensor) -> Tensor:
        dtype, shape = x.dtype, x.shape
        grouped = _accumulate(x).reshape(*shape[:-1], self.ngroups, -1)
        grouped = grouped * torch.rsqrt(grouped.square().mean(-1, keepdim=True) + self.eps)
        return (grouped.reshape(shape) * self.weight).to(dtype)


class Mamba2Mixer(nn.Module):
    def __init__(self, cfg: Mamba2Config):
        super().__init__()
        self.cfg = cfg
        conv_width = cfg.d_inner + 2 * cfg.ngroups * cfg.d_state
        self.in_proj = nn.Linear(cfg.d_model, cfg.d_inner + conv_width + cfg.nheads, bias=False)
        self.conv = nn.Conv1d(conv_width, conv_width, cfg.d_conv,
                              groups=conv_width, padding=0, bias=True)
        # Official initialization: Delta in [0.001,0.1], A in [-16,-1].
        dt = torch.exp(torch.empty(cfg.nheads).uniform_(math.log(0.001), math.log(0.1)))
        self.dt_bias = nn.Parameter(dt + torch.log(-torch.expm1(-dt)))
        self.A_log = nn.Parameter(torch.empty(cfg.nheads).uniform_(1, 16).log())
        self.D = nn.Parameter(torch.ones(cfg.nheads))
        self.gated_norm = RMSNorm(cfg.d_inner, cfg.norm_eps, cfg.ngroups)
        self.out_proj = nn.Linear(cfg.d_inner, cfg.d_model, bias=False)

    def forward(self, u: Tensor) -> Tensor:
        cfg = self.cfg
        batch, length, _ = u.shape
        group_width = cfg.ngroups * cfg.d_state
        z, xbc, raw_dt = self.in_proj(u).split(
            [cfg.d_inner, cfg.d_inner + 2 * group_width, cfg.nheads], dim=-1)
        # Left padding is causal even when T < kernel_size or kernel_size == 1.
        xbc = self.conv(F.pad(xbc.transpose(1, 2), (cfg.d_conv - 1, 0)))
        x, B, C = F.silu(xbc.transpose(1, 2)).split(
            [cfg.d_inner, group_width, group_width], dim=-1)
        x = x.reshape(batch, length, cfg.nheads, cfg.headdim)
        B = B.reshape(batch, length, cfg.ngroups, cfg.d_state)
        C = C.reshape(batch, length, cfg.ngroups, cfg.d_state)
        dt = F.softplus(_accumulate(raw_dt) + _accumulate(self.dt_bias))
        A = -_accumulate(self.A_log).exp()
        if cfg.ssd_backend == "matrix":
            y = ssd_matrix(x, dt, A, B, C, self.D)
        else:
            y, _ = ssd_recurrent(x, dt, A, B, C, self.D)
        y = y.reshape(batch, length, cfg.d_inner)
        # norm_before_gate=False: normalize AFTER multiplication by SiLU(z).
        gated = (_accumulate(y) * F.silu(_accumulate(z)))
        return self.out_proj(self.gated_norm(gated).to(u.dtype))


class Mamba2Block(nn.Module):
    def __init__(self, cfg: Mamba2Config):
        super().__init__()
        self.norm = RMSNorm(cfg.d_model, cfg.norm_eps)
        self.mixer = Mamba2Mixer(cfg)

    def forward(self, x: Tensor) -> Tensor:
        return x + self.mixer(self.norm(x))


class Mamba2LM(nn.Module):
    """Pure Mamba-2 stack: embedding -> residual SSD blocks -> norm -> logits."""
    def __init__(self, config: Mamba2Config | None = None):
        super().__init__()
        self.config = config or Mamba2Config()
        cfg = self.config
        self.embedding = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.layers = nn.ModuleList(Mamba2Block(cfg) for _ in range(cfg.n_layers))
        self.norm = RMSNorm(cfg.d_model, cfg.norm_eps)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        nn.init.normal_(self.embedding.weight, std=0.02)
        if cfg.tie_embeddings:
            self.lm_head.weight = self.embedding.weight

    def forward(self, input_ids: Tensor) -> Tensor:
        """input_ids [batch,time] -> next-token logits [batch,time,vocab_size]."""
        if input_ids.ndim != 2 or input_ids.shape[1] == 0:
            raise ValueError("input_ids must have shape [batch,nonempty time]")
        x = self.embedding(input_ids)
        for layer in self.layers:
            x = layer(x)
        return self.lm_head(self.norm(x))


if __name__ == "__main__":
    torch.manual_seed(42)
    model = Mamba2LM()
    ids = torch.randint(0, model.config.vocab_size, (2, 17))
    logits = model(ids[:, :-1])
    loss = F.cross_entropy(logits.flatten(0, 1), ids[:, 1:].flatten())
    loss.backward()
    print(f"logits={tuple(logits.shape)}, loss={loss.item():.6f}")
