"""Complete tiny bidirectional masked-diffusion LM in plain PyTorch.

The default tiny backbone follows iLLaDA (2026): GQA, RoPE, pre-RMSNorm,
SwiGLU and tied embeddings. Original LLaDA (2025) is available as a config
only preset for method provenance. Both use a time-free mask predictor and
the random-masking, inverse-probability-weighted diffusion loss.

Sources: arXiv:2502.09992 (Eq. 3 / Appendix A), arXiv:2606.25331 (Sec. 2),
ML-GSAI/LLaDA GUIDELINES.md and generate.py, official GSAI-ML HF configs.
Random weights; no tokenizer, checkpoint compatibility, packed-example mask,
large-scale training recipe, confidence-based benchmark scoring or KV cache.
"""

from dataclasses import dataclass

import torch
from torch import Tensor, nn
import torch.nn.functional as F


@dataclass(frozen=True)
class LLaDAConfig:
    vocab_size: int = 257  # 256 byte values plus a dedicated mask symbol.
    d_model: int = 64
    n_layers: int = 2
    n_heads: int = 4
    n_kv_heads: int = 1
    hidden_dim: int = 224
    max_seq_len: int = 512
    mask_token_id: int = 256
    rope_theta: float = 10000.0
    norm_eps: float = 1e-5
    tie_embeddings: bool = True

    def __post_init__(self):
        dims = (self.vocab_size, self.d_model, self.n_layers, self.n_heads,
                self.n_kv_heads, self.hidden_dim, self.max_seq_len)
        if min(dims) <= 0:
            raise ValueError("All dimensions must be positive")
        if self.d_model % self.n_heads or self.n_heads % self.n_kv_heads:
            raise ValueError("d_model must divide by Q heads, and Q heads by KV heads")
        if (self.d_model // self.n_heads) % 2:
            raise ValueError("RoPE requires an even head dimension")
        if not 0 <= self.mask_token_id < self.vocab_size:
            raise ValueError("mask_token_id must belong to the vocabulary")
        if self.norm_eps <= 0 or self.rope_theta <= 0:
            raise ValueError("Normalization epsilon and RoPE base must be positive")


def llada_8b_config() -> LLaDAConfig:
    """Official 2025 LLaDA dimensions; configuration only, not weights."""
    return LLaDAConfig(vocab_size=126464, d_model=4096, n_layers=32,
                       n_heads=32, n_kv_heads=32, hidden_dim=12288,
                       max_seq_len=4096, mask_token_id=126336,
                       rope_theta=500000.0, tie_embeddings=False)


def illada_8b_config() -> LLaDAConfig:
    """Official June 2026 iLLaDA dimensions; configuration only, not weights."""
    return LLaDAConfig(vocab_size=155136, d_model=4096, n_layers=32,
                       n_heads=32, n_kv_heads=8, hidden_dim=14336,
                       max_seq_len=8192, mask_token_id=5,
                       rope_theta=10000.0, tie_embeddings=True)


def _float_accum(x: Tensor) -> Tensor:
    return x.float() if x.dtype in (torch.float16, torch.bfloat16) else x


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        xf = _float_accum(x)
        return (xf * torch.rsqrt(xf.square().mean(-1, keepdim=True) + self.eps)
                * self.weight).to(x.dtype)


def apply_rope(x: Tensor, theta: float) -> Tensor:
    """Split-half RoPE, as used by both official model implementations.

    x: [batch,heads,time,head_dim]. There is no causal constraint in RoPE.
    """
    width, time = x.shape[-1], x.shape[-2]
    dtype = _float_accum(x).dtype
    inverse = theta ** (-torch.arange(0, width, 2, device=x.device, dtype=dtype) / width)
    angles = torch.arange(time, device=x.device, dtype=dtype)[:, None] * inverse[None]
    angles = torch.cat((angles, angles), dim=-1)
    left, right = _float_accum(x).chunk(2, dim=-1)
    rotated = torch.cat((-right, left), dim=-1)
    return (_float_accum(x) * angles.cos() + rotated * angles.sin()).to(x.dtype)


class BidirectionalAttention(nn.Module):
    def __init__(self, config: LLaDAConfig):
        super().__init__()
        self.config = config
        head_dim = config.d_model // config.n_heads
        self.q = nn.Linear(config.d_model, config.n_heads * head_dim, bias=False)
        self.k = nn.Linear(config.d_model, config.n_kv_heads * head_dim, bias=False)
        self.v = nn.Linear(config.d_model, config.n_kv_heads * head_dim, bias=False)
        self.out = nn.Linear(config.d_model, config.d_model, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        batch, length, _ = x.shape
        cfg = self.config
        head_dim = cfg.d_model // cfg.n_heads
        q = self.q(x).view(batch, length, cfg.n_heads, head_dim).transpose(1, 2)
        k = self.k(x).view(batch, length, cfg.n_kv_heads, head_dim).transpose(1, 2)
        v = self.v(x).view(batch, length, cfg.n_kv_heads, head_dim).transpose(1, 2)
        q, k = apply_rope(q, cfg.rope_theta), apply_rope(k, cfg.rope_theta)
        repeats = cfg.n_heads // cfg.n_kv_heads
        k, v = k.repeat_interleave(repeats, dim=1), v.repeat_interleave(repeats, dim=1)
        # Every position, including positions to the right, is visible.
        # A [MASK] token is data; it must NOT be hidden with an attention mask.
        mixed = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=False)
        return self.out(mixed.transpose(1, 2).reshape(batch, length, cfg.d_model))


class SwiGLU(nn.Module):
    def __init__(self, config: LLaDAConfig):
        super().__init__()
        self.gate = nn.Linear(config.d_model, config.hidden_dim, bias=False)
        self.up = nn.Linear(config.d_model, config.hidden_dim, bias=False)
        self.down = nn.Linear(config.hidden_dim, config.d_model, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        return self.down(F.silu(self.gate(x)) * self.up(x))


class LLaDABlock(nn.Module):
    def __init__(self, config: LLaDAConfig):
        super().__init__()
        self.attn_norm = RMSNorm(config.d_model, config.norm_eps)
        self.attention = BidirectionalAttention(config)
        self.ffn_norm = RMSNorm(config.d_model, config.norm_eps)
        self.ffn = SwiGLU(config)

    def forward(self, x: Tensor) -> Tensor:
        x = x + self.attention(self.attn_norm(x))
        return x + self.ffn(self.ffn_norm(x))


class LLaDALM(nn.Module):
    """A bidirectional mask predictor, not an autoregressive next-token model."""
    def __init__(self, config: LLaDAConfig | None = None):
        super().__init__()
        self.config = config or LLaDAConfig()
        cfg = self.config
        self.embedding = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.layers = nn.ModuleList(LLaDABlock(cfg) for _ in range(cfg.n_layers))
        self.norm = RMSNorm(cfg.d_model, cfg.norm_eps)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.apply(self._initialize)
        if cfg.tie_embeddings:
            self.lm_head.weight = self.embedding.weight

    @staticmethod
    def _initialize(module: nn.Module):
        if isinstance(module, (nn.Linear, nn.Embedding)):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, input_ids: Tensor) -> Tensor:
        """[batch,time] -> logits [batch,time,vocab]; no time embedding/label shift."""
        if input_ids.ndim != 2 or not 1 <= input_ids.shape[1] <= self.config.max_seq_len:
            raise ValueError("Expected nonempty [batch,time] IDs within max_seq_len")
        x = self.embedding(input_ids)
        for layer in self.layers:
            x = layer(x)
        return self.lm_head(self.norm(x))


def _probability_grid(probabilities: Tensor, shape: tuple[int, int], device) -> Tensor:
    p = torch.as_tensor(probabilities, device=device)
    if not p.is_floating_point():
        p = p.float()
    if p.ndim == 1:
        if p.shape[0] != shape[0]:
            raise ValueError("A 1D probability tensor must contain one value per sample")
        p = p[:, None]
    try:
        p = torch.broadcast_to(p, shape)
    except RuntimeError as error:
        raise ValueError("Mask probabilities must broadcast to [batch,time]") from error
    if not bool(torch.isfinite(p).all() and ((p > 0) & (p <= 1)).all()):
        raise ValueError("Effective mask probabilities must be finite and in (0,1]")
    return p


def corrupt_tokens(clean_ids: Tensor, mask_token_id: int, eps: float = 1e-3,
                   probabilities: Tensor | None = None,
                   generator: torch.Generator | None = None) -> tuple[Tensor, Tensor, Tensor]:
    """Independently mask tokens, with one random effective t per sample.

    Default p = eps + (1-eps)*Uniform(0,1), matching official GUIDELINES.md.
    Explicit probabilities [B], [B,1], or [B,T] allow reproducible corruption.
    Returns (noisy_ids, masked_positions, p_grid[B,T]). No forced extra mask:
    occasionally having zero masks is part of the unbiased Bernoulli estimator.
    """
    if clean_ids.ndim != 2 or clean_ids.numel() == 0:
        raise ValueError("clean_ids must be a nonempty [batch,time] tensor")
    if not 0 < eps < 1:
        raise ValueError("eps must lie in (0,1)")
    if bool((clean_ids == mask_token_id).any()):
        raise ValueError("Clean training data must not contain the reserved mask token")
    if probabilities is None:
        u = torch.rand(clean_ids.shape[0], device=clean_ids.device, generator=generator)
        probabilities = eps + (1 - eps) * u
    p = _probability_grid(probabilities, tuple(clean_ids.shape), clean_ids.device)
    masked = torch.rand(clean_ids.shape, device=clean_ids.device, generator=generator) < p
    return clean_ids.masked_fill(masked, mask_token_id), masked, p


def masked_diffusion_loss(logits: Tensor, target_ids: Tensor,
                          masked_positions: Tensor, probabilities: Tensor) -> Tensor:
    """Per-token normalized LLaDA/iLLaDA masked-diffusion training objective.

    loss = sum_{b,i in mask} CE(logits[b,i], target[b,i]) / p[b,i] / (B*T).
    Do NOT shift labels or divide by the number of realized masked tokens.
    Targets outside masked_positions are never read by cross entropy.
    The paper states a sequence-summed bound; dividing by T gives its per-token
    version, as in the official training guidelines. Epsilon truncates t near 0.
    """
    if logits.ndim != 3 or target_ids.shape != logits.shape[:2]:
        raise ValueError("Expected logits[B,T,V] and targets[B,T]")
    if masked_positions.shape != target_ids.shape or masked_positions.dtype != torch.bool:
        raise ValueError("masked_positions must be a boolean tensor with shape [B,T]")
    if target_ids.numel() == 0:
        raise ValueError("An empty training batch has no token-normalized loss")
    p = _probability_grid(probabilities, tuple(target_ids.shape), logits.device)
    if not bool(masked_positions.any()):
        return logits.sum() * 0.0
    ce = F.cross_entropy(_float_accum(logits[masked_positions]),
                         target_ids[masked_positions], reduction="none")
    return (ce / p[masked_positions]).sum() / target_ids.numel()


@torch.no_grad()
def sample_llada(model: LLaDALM, prompt: Tensor, gen_length: int = 16,
                 steps: int = 8, block_length: int | None = None,
                 temperature: float = 0.0, remasking: str = "low_confidence",
                 eos_token_id: int | None = None,
                 generator: torch.Generator | None = None) -> Tensor:
    """Append mask blocks, progressively reveal tokens, and keep prompt intact.

    Returns token IDs including the prompt. gen_length is the maximum new-token
    budget; steps is the number of model calls PER BLOCK (capped by block size).
    With block_length=None there is one fixed-length diffusion block. An EOS ID
    enables variable-length generation for batch size 1, stopping after a fully
    decoded block and trimming after the first generated EOS.

    low_confidence follows official confidence-ranked unmasking; random chooses
    random positions with the same fixed quota. Neither quota rule is claimed
    to be the exact independent Bernoulli reverse transition from Appendix A.
    No CFG, temperature schedule, EOS logit tricks, or KV reuse is implemented.
    """
    cfg = model.config
    if prompt.ndim != 2 or prompt.shape[0] == 0:
        raise ValueError("prompt must have shape [batch,time]")
    if gen_length <= 0 or steps <= 0 or temperature < 0:
        raise ValueError("Generation length/steps must be positive; temperature nonnegative")
    if prompt.shape[1] + gen_length > cfg.max_seq_len:
        raise ValueError("Prompt plus generation budget exceeds max_seq_len")
    if bool((prompt == cfg.mask_token_id).any()):
        raise ValueError("The visible prompt must not contain the reserved mask token")
    if remasking not in ("low_confidence", "random"):
        raise ValueError("remasking must be 'low_confidence' or 'random'")
    if eos_token_id is not None and (prompt.shape[0] != 1 or
            not 0 <= eos_token_id < cfg.vocab_size or eos_token_id == cfg.mask_token_id):
        raise ValueError("EOS stopping requires batch size 1 and a valid non-mask EOS ID")
    block_length = gen_length if block_length is None else block_length
    if block_length <= 0:
        raise ValueError("block_length must be positive")
    device = next(model.parameters()).device
    output = prompt.to(device).clone()
    prompt_length = output.shape[1]
    was_training = model.training
    model.eval()
    try:
        for offset in range(0, gen_length, block_length):
            width = min(block_length, gen_length - offset)
            block_start = output.shape[1]
            masks = torch.full((output.shape[0], width), cfg.mask_token_id,
                               dtype=torch.long, device=device)
            output = torch.cat((output, masks), dim=1)
            n_steps = min(steps, width)
            base, remainder = divmod(width, n_steps)
            for step in range(n_steps):
                editable = output == cfg.mask_token_id
                editable[:, :block_start] = False
                logits = model(output).clone()
                # Clean data cannot equal the absorbing [MASK] state. Enforcing
                # its exclusion also guarantees completion for random tiny LMs.
                logits[..., cfg.mask_token_id] = -torch.inf
                if temperature == 0:
                    candidates = logits.argmax(-1)
                else:
                    uniform = torch.rand(logits.shape, device=device, dtype=torch.float64,
                                         generator=generator).clamp_(1e-10, 1 - 1e-10)
                    gumbel = -torch.log(-torch.log(uniform))
                    candidates = (logits.double() + temperature * gumbel).argmax(-1)
                if remasking == "low_confidence":
                    confidence = logits.float().softmax(-1).gather(
                        -1, candidates[..., None]).squeeze(-1)
                else:
                    confidence = torch.rand(output.shape, device=device, generator=generator)
                confidence.masked_fill_(~editable, -torch.inf)
                count = base + int(step < remainder)
                chosen = confidence.topk(count, dim=-1).indices
                output.scatter_(1, chosen, candidates.gather(1, chosen))
            if eos_token_id is not None:
                hits = (output[0, prompt_length:] == eos_token_id).nonzero(as_tuple=False)
                if len(hits):
                    return output[:, :prompt_length + int(hits[0, 0]) + 1]
        return output
    finally:
        model.train(was_training)


if __name__ == "__main__":
    torch.manual_seed(7)
    model = LLaDALM()
    clean = torch.randint(0, model.config.mask_token_id, (2, 16))
    noisy, mask, p = corrupt_tokens(clean, model.config.mask_token_id)
    logits = model(noisy)
    loss = masked_diffusion_loss(logits, clean, mask, p)
    loss.backward()
    generated = sample_llada(model, clean[:1, :3], gen_length=8, block_length=4, steps=2)
    print(f"logits={tuple(logits.shape)}, diffusion_loss={loss.item():.6f}")
    print(f"generated_shape={tuple(generated.shape)}, remaining_masks={(generated == model.config.mask_token_id).sum().item()}")
