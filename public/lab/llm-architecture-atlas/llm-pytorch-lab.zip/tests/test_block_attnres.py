"""Block scheduling and complete-LM checks against independent references."""
import unittest

import torch
from torch import nn
from torch.nn import functional as F

from models.block_attnres import BlockAttnResConfig, BlockAttnResLM


class ConstantOutput(nn.Module):
    def __init__(self, value):
        super().__init__()
        self.value = value

    def forward(self, x):
        return torch.full_like(x, self.value)


class BlockAttnResTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    def setUp(self):
        torch.manual_seed(31)

    def test_block_sums_boundary_and_final_readout(self):
        # Six sublayers, block_size=4 -> completed sums 1+2+3+4 and 5+6.
        # With zero queries, output MUST be mean([embedding=2, 10, 11]).
        model = BlockAttnResLM(BlockAttnResConfig(block_size=4))
        model.sublayers = nn.ModuleList(ConstantOutput(i) for i in range(1, 7))
        source_counts = []
        handles = [m.register_forward_pre_hook(
            lambda _module, args: source_counts.append(len(args[0])))
            for m in model.mixers]
        x = torch.full((2, 3, 64), 2.0)
        result = model.aggregate_hidden(x)
        torch.testing.assert_close(result, torch.full_like(x, 23 / 3))
        self.assertEqual(source_counts, [1, 2, 2, 2, 2, 3])
        for h in handles:
            h.remove()

    def test_size_one_equals_full_depth_attention(self):
        model = BlockAttnResLM(BlockAttnResConfig(n_layers=2, block_size=1))
        with torch.no_grad():
            for mixer in list(model.mixers) + [model.readout]:
                mixer.query.normal_(std=0.3)
        x = torch.randn(2, 5, 64)
        # Independent Full AttnRes loop: retain EACH f(h), no block scheduler.
        sources = [x]
        for mixer, sublayer in zip(model.mixers, model.sublayers):
            sources.append(sublayer(mixer(sources)))
        reference = model.readout(sources)
        torch.testing.assert_close(model.aggregate_hidden(x), reference)

    def test_odd_sublayer_blocks_and_causal_prefix(self):
        # S=3 crosses a decoder boundary; it must still group by sublayer count.
        model = BlockAttnResLM(BlockAttnResConfig(n_layers=2, block_size=3)).eval()
        ids = torch.randint(0, 256, (2, 7))
        changed = ids.clone()
        changed[:, 3:] = (changed[:, 3:] + 29) % 256
        with torch.no_grad():
            output = model(ids)
            perturbed = model(changed)
            short = model(ids[:, :3])
        torch.testing.assert_close(output[:, :3], perturbed[:, :3], rtol=1e-5, atol=1e-6)
        torch.testing.assert_close(output[:, :3], short, rtol=1e-5, atol=1e-6)

    def test_whole_language_model_backward(self):
        model = BlockAttnResLM()
        ids = torch.randint(0, 256, (2, 9))
        output = model(ids)
        self.assertEqual(tuple(output.shape), (2, 9, 256))
        loss = F.cross_entropy(output[:, :-1].flatten(0, 1), ids[:, 1:].flatten())
        loss.backward()
        for name, parameter in model.named_parameters():
            self.assertIsNotNone(parameter.grad, name)
            self.assertTrue(torch.isfinite(parameter.grad).all(), name)
        # First query sees one source and has zero gradient by construction.
        self.assertEqual(model.mixers[0].query.grad.abs().sum().item(), 0)
        self.assertGreater(model.mixers[-1].query.grad.abs().sum().item(), 0)
        self.assertGreater(model.readout.query.grad.abs().sum().item(), 0)
        self.assertGreater(model.sublayers[0].operation.wq.weight.grad.abs().sum().item(), 0)
        self.assertEqual(len({id(m.query) for m in model.mixers}), len(model.sublayers))


if __name__ == "__main__":
    unittest.main()
