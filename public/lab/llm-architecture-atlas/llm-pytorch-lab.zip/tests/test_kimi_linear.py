"""Independent numerical and whole-decoder checks for Kimi Linear."""
import math
import unittest

import torch
from torch.nn import functional as F

from models.kimi_linear import (KimiLinearConfig, KimiLinearLM, KimiDeltaAttention,
                                NoPEMLA, kda_recurrent, l2_normalize)


class TestKimiLinear(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(19)
        torch.set_num_threads(1)

    def test_kda_matches_unrolled_dense_transitions_and_gradients(self):
        # Unequal key/value widths catch accidental state transposes.
        q = torch.randn(1, 5, 2, 3, dtype=torch.float64, requires_grad=True)
        k = l2_normalize(torch.randn(1, 5, 2, 3, dtype=torch.float64)).requires_grad_()
        v = torch.randn(1, 5, 2, 4, dtype=torch.float64, requires_grad=True)
        log_a = (-torch.rand(1, 5, 2, 3, dtype=torch.float64)).requires_grad_()
        beta = torch.rand(1, 5, 2, dtype=torch.float64, requires_grad=True)
        initial = torch.randn(1, 2, 3, 4, dtype=torch.float64)
        actual, last = kda_recurrent(q, k, v, log_a, beta, initial_state=initial)
        identity = torch.eye(3, dtype=torch.float64)
        # Construct F_t=(I-beta*k*k^T)Diag(alpha), then explicitly compose
        # every earlier write through all subsequent full transition matrices.
        transition = (identity - beta[..., None, None] *
                      (k[..., :, None] * k[..., None, :])) @ torch.diag_embed(log_a.exp())
        write = beta[..., None, None] * k[..., :, None] * v[..., None, :]
        reference = []
        for t in range(q.shape[1]):
            total = initial
            for step in range(t + 1):
                total = transition[:, step] @ total
            for start in range(t + 1):
                contribution = write[:, start]
                for step in range(start + 1, t + 1):
                    contribution = transition[:, step] @ contribution
                total = total + contribution
            reference.append(torch.einsum('bhk,bhkv->bhv', q[:, t] / math.sqrt(3), total))
        reference = torch.stack(reference, dim=1)
        torch.testing.assert_close(actual, reference, rtol=1e-11, atol=1e-11)
        torch.testing.assert_close(last, total, rtol=1e-11, atol=1e-11)
        weight = torch.randn_like(actual)
        inputs = (q, k, v, log_a, beta)
        grads_actual = torch.autograd.grad((actual * weight).sum(), inputs, retain_graph=True)
        grads_reference = torch.autograd.grad((reference * weight).sum(), inputs)
        for a, b in zip(grads_actual, grads_reference):
            torch.testing.assert_close(a, b, rtol=1e-10, atol=1e-10)

    def test_delta_rule_overwrites_a_repeated_key_instead_of_accumulating(self):
        keys = torch.tensor([[[[1., 0.]], [[1., 0.]]]])
        values = torch.tensor([[[[2., 3.]], [[7., -1.]]]])
        output, state = kda_recurrent(keys, keys, values, torch.zeros_like(keys),
                                      torch.ones(1, 2, 1), scale=1.0)
        torch.testing.assert_close(output, values)
        torch.testing.assert_close(state[0, 0, 0], values[0, -1, 0])
        torch.testing.assert_close(state[0, 0, 1], torch.zeros(2))

    def test_nope_mla_matches_absorbed_content_and_shared_branch(self):
        cfg = KimiLinearConfig(dim=24, n_mla_heads=2, mla_content_dim=5,
                               mla_shared_dim=3, mla_value_dim=4, kv_lora_rank=7)
        module = NoPEMLA(cfg).double()
        x = torch.randn(2, 6, 24, dtype=torch.float64)
        actual = module(x)
        q = module.q_proj(x).reshape(2, 6, 2, 8)
        q_c, q_s = q.split([5, 3], dim=-1)
        c, shared = module.kv_down(x).split([7, 3], dim=-1)
        c = module.kv_norm(c)
        weight = module.kv_up.weight.reshape(2, 9, 7)
        # Move W_K onto q and W_V after the attention-weighted latent sum.
        absorbed_q = torch.einsum('bthn,hnc->bthc', q_c, weight[:, :5])
        scores = (torch.einsum('bthc,bsc->bhts', absorbed_q, c) +
                  torch.einsum('bthr,bsr->bhts', q_s, shared)) / math.sqrt(8)
        mask = torch.ones(6, 6, dtype=torch.bool).triu(1)
        probs = scores.masked_fill(mask, -torch.inf).softmax(-1)
        mixed_latent = torch.einsum('bhts,bsc->bthc', probs, c)
        mixed = torch.einsum('bthc,hvc->bthv', mixed_latent, weight[:, 5:])
        reference = module.output(mixed.reshape(2, 6, -1))
        torch.testing.assert_close(actual, reference, rtol=1e-11, atol=1e-11)

    def test_full_lm_causal_and_forward_backward(self):
        cfg = KimiLinearConfig(dim=32, n_kda_heads=2, kda_head_dim=8,
                               n_mla_heads=2, mla_content_dim=8, mla_shared_dim=4,
                               mla_value_dim=8, kv_lora_rank=12, inter_dim=64,
                               moe_inter_dim=24)
        model = KimiLinearLM(cfg)
        self.assertEqual([type(layer.attention) for layer in model.layers],
                         [KimiDeltaAttention] * 3 + [NoPEMLA])
        ids = torch.randint(256, (2, 10))
        modified = ids.clone()
        modified[:, 6:] = (modified[:, 6:] + 77) % 256
        model.eval()
        with torch.no_grad():
            baseline, changed, prefix = model(ids), model(modified), model(ids[:, :6])
        torch.testing.assert_close(baseline[:, :6], changed[:, :6], rtol=0, atol=1e-6)
        torch.testing.assert_close(baseline[:, :6], prefix, rtol=2e-5, atol=2e-6)
        self.assertFalse(torch.allclose(baseline[:, 6:], changed[:, 6:]))
        model.train()
        logits = model(ids)
        self.assertEqual(logits.shape, (2, 10, 256))
        loss = F.cross_entropy(logits[:, :-1].reshape(-1, 256), ids[:, 1:].flatten())
        loss.backward()
        for name, param in model.named_parameters():
            if param.grad is not None:  # Sparse experts can legitimately receive no tokens.
                self.assertTrue(torch.isfinite(param.grad).all(), name)
        for layer in model.layers[:3]:
            for name in ['A_log', 'dt_bias']:
                grad = getattr(layer.attention, name).grad
                self.assertIsNotNone(grad)
                self.assertGreater(grad.abs().sum().item(), 0)
        self.assertNotEqual(model.embedding.weight.data_ptr(), model.lm_head.weight.data_ptr())

    def test_published_config_only_and_l2_epsilon_convention(self):
        cfg = KimiLinearConfig.kimi_linear_48b_a3b()
        self.assertEqual((cfg.dim, cfg.n_layers, cfg.n_kda_heads, cfg.kda_head_dim), (2304, 27, 32, 128))
        self.assertEqual(cfg.mla_layers, (4, 8, 12, 16, 20, 24, 27))
        self.assertEqual((cfg.n_layers-len(cfg.mla_layers),len(cfg.mla_layers)), (20,7))
        self.assertEqual((cfg.vocab_size, cfg.max_seq_len), (163840, 1048576))
        self.assertEqual((cfg.n_routed_experts,cfg.n_activated_experts,cfg.route_scale), (256,8,2.446))
        # Small inputs distinguish sqrt(sum(x^2)+eps) from clamp(norm,eps).
        x = torch.tensor([[1e-4, 0.]])
        torch.testing.assert_close(l2_normalize(x), x / torch.sqrt(torch.tensor(1e-8 + 1e-6)))


if __name__ == '__main__':
    unittest.main()
