"""Numerical and semantic tests for the mHC/Engram research modules."""

from dataclasses import replace
import unittest

import torch
from torch import nn

from models.frontier_modules import (
    EngramConfig, EngramMemory, MHCConfig, MHCWrapper, RMSNorm,
    sinkhorn_residual, toy_token_normalization_map,
)


class TestFrontierModules(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    def setUp(self):
        torch.manual_seed(27)

    def test_sinkhorn_convergence_and_finite_iteration_error(self):
        logits = torch.randn(3, 4, 4, dtype=torch.float64) * 3
        first = sinkhorn_residual(logits, 1)
        converged = sinkhorn_residual(logits, 200)
        self.assertTrue((converged > 0).all())
        torch.testing.assert_close(first.sum(-1), torch.ones(3, 4, dtype=torch.float64))
        # A row-normalized finite iterate need not yet have normalized columns.
        self.assertGreater((first.sum(-2) - 1).abs().max().item(), 0.01)
        torch.testing.assert_close(converged.sum(-1), torch.ones(3, 4, dtype=torch.float64))
        torch.testing.assert_close(converged.sum(-2), torch.ones(3, 4, dtype=torch.float64), atol=1e-9, rtol=1e-9)

    def test_mhc_residual_only_preserves_mean_and_convex_bounds(self):
        # An existing block returning x has zero residual delta. The adapter must
        # not inject x again into every output stream.
        config = MHCConfig(dim=6, streams=4, sinkhorn_iterations=100)
        module = MHCWrapper(nn.Identity(), config, sublayer_returns_residual=True).double()
        x = torch.randn(2, 5, 4, 6, dtype=torch.float64)
        result = module(x)
        _, _, matrix = module.mixing_matrices(x)
        expected = torch.einsum("btij,btjd->btid", matrix, x)
        torch.testing.assert_close(result, expected)
        torch.testing.assert_close(result.mean(-2), x.mean(-2), atol=1e-9, rtol=1e-9)
        self.assertTrue((result >= x.amin(-2, keepdim=True) - 1e-12).all())
        self.assertTrue((result <= x.amax(-2, keepdim=True) + 1e-12).all())

    def test_mhc_nonresidual_branch_and_gradients(self):
        dim = 8
        module = MHCWrapper(nn.Sequential(RMSNorm(dim), nn.Linear(dim, dim)), MHCConfig(dim=dim))
        x = torch.randn(2, 7, 4, dim, requires_grad=True)
        result = module(x)
        self.assertEqual(result.shape, x.shape)
        result.square().mean().backward()
        for parameter in module.parameters():
            self.assertIsNotNone(parameter.grad)
            self.assertTrue(torch.isfinite(parameter.grad).all())
            self.assertGreater(parameter.grad.abs().sum().item(), 0)
        self.assertTrue(torch.isfinite(x.grad).all())

    def test_toy_normalization_changes_lookup_only(self):
        vocab = ["<pad>", "Apple", " apple ", "café", "CAFE", "Ａ", "a", " \t"]
        mapping = toy_token_normalization_map(vocab)
        self.assertEqual(mapping[1], mapping[2])
        self.assertEqual(mapping[3], mapping[4])
        self.assertEqual(mapping[5], mapping[6])
        config = EngramConfig(vocab_size=len(vocab), streams=1, dim=8)
        memory = EngramMemory(config, mapping)
        first = torch.tensor([[1, 3, 5, 1]])
        equivalent = torch.tensor([[2, 4, 6, 2]])
        torch.testing.assert_close(memory.lookup_indices(first), memory.lookup_indices(equivalent))
        torch.testing.assert_close(memory.retrieve(first), memory.retrieve(equivalent))
        # Input IDs remain distinct for the backbone's lossless embedding/tokenizer.
        self.assertFalse(torch.equal(first, equivalent))

    def test_engram_gate_uses_hidden_context_not_only_lookup(self):
        config = EngramConfig(streams=1, dim=8, use_conv=False)
        memory = EngramMemory(config)
        ids = torch.tensor([[7, 11, 5, 13]])
        retrieved = memory.retrieve(ids)
        key = memory.key_projs[0](retrieved)
        aligned = memory.context_gates(key, retrieved)
        opposed = memory.context_gates(-key, retrieved)
        self.assertTrue((aligned > opposed).all())
        torch.testing.assert_close(aligned + opposed, torch.ones_like(aligned))
        torch.testing.assert_close(memory.retrieve(ids), retrieved)

    def test_engram_ngram_and_dilated_conv_are_causal(self):
        config = EngramConfig(dim=8, streams=2, max_ngram_size=4)
        module = EngramMemory(config).eval()
        ids = torch.randint(256, (2, 13))
        hidden = torch.randn(2, 13, 2, 8)
        perturbed_ids, perturbed_hidden = ids.clone(), hidden.clone()
        perturbed_ids[:, 7:] = (perturbed_ids[:, 7:] + 55) % 256
        perturbed_hidden[:, 7:] += 100
        with torch.no_grad():
            output = module(hidden, ids)
            perturbed = module(perturbed_hidden, perturbed_ids)
            prefix = module(hidden[:, :7], ids[:, :7])
        torch.testing.assert_close(output[:, :7], perturbed[:, :7])
        torch.testing.assert_close(output[:, :7], prefix, atol=1e-6, rtol=1e-5)
        self.assertFalse(torch.allclose(output[:, 7:], perturbed[:, 7:]))

    def test_engram_gradients_touch_only_retrieved_table_rows(self):
        config = EngramConfig(dim=8, streams=2)
        memory = EngramMemory(config)
        ids = torch.tensor([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])
        hidden = torch.randn(2, 5, 2, 8, requires_grad=True)
        memory(hidden, ids).square().mean().backward()
        addresses = memory.lookup_indices(ids)
        for head, table in enumerate(memory.tables):
            used = torch.zeros(table.num_embeddings, dtype=torch.bool)
            used[addresses[..., head].flatten()] = True
            self.assertTrue((table.weight.grad[~used] == 0).all())
            self.assertGreater(table.weight.grad[used].abs().sum().item(), 0)
        for parameter in memory.parameters():
            self.assertIsNotNone(parameter.grad)
            self.assertTrue(torch.isfinite(parameter.grad).all())
        self.assertGreater(hidden.grad.abs().sum().item(), 0)
        self.assertGreater(memory.value_proj.weight.grad.abs().sum().item(), 0)
        self.assertGreater(memory.conv.weight.grad.abs().sum().item(), 0)

    def test_single_stream_and_documented_gate_variant(self):
        config = EngramConfig(dim=8, streams=1, use_conv=False)
        paper = EngramMemory(config)
        demo = EngramMemory(replace(config, gate_transform="official_demo"))
        demo.load_state_dict(paper.state_dict())
        ids = torch.tensor([[3, 5, 7, 9]])
        hidden = torch.randn(1, 4, 8)
        self.assertEqual(paper(hidden, ids).shape, hidden.shape)
        # The public demo's signed-sqrt gate is deliberately an opt-in difference.
        self.assertFalse(torch.allclose(paper(hidden, ids), demo(hidden, ids)))
        self.assertFalse(hasattr(paper, "conv"))


if __name__ == "__main__":
    unittest.main()
