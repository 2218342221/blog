"""Numerical SSD duality, causal prefix invariance, and trainability checks."""
import unittest
from dataclasses import replace

import torch
import torch.nn.functional as F

from models.mamba2 import Mamba2Config, Mamba2LM, ssd_matrix, ssd_recurrent


class Mamba2Tests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(1337)

    def test_ssd_matrix_equals_recurrence_and_gradients(self):
        # More than one B/C group catches accidental sharing across all heads.
        batch, time, heads, width, groups, state = 2, 7, 4, 3, 2, 5
        args = [
            torch.randn(batch, time, heads, width, dtype=torch.float64),
            torch.rand(batch, time, heads, dtype=torch.float64) + 0.01,
            -torch.rand(heads, dtype=torch.float64) - 0.1,
            torch.randn(batch, time, groups, state, dtype=torch.float64),
            torch.randn(batch, time, groups, state, dtype=torch.float64),
            torch.randn(heads, dtype=torch.float64),
        ]
        recurrent_args = [x.clone().requires_grad_() for x in args]
        matrix_args = [x.clone().requires_grad_() for x in args]
        yr, last = ssd_recurrent(*recurrent_args)
        ym = ssd_matrix(*matrix_args)
        torch.testing.assert_close(yr, ym, rtol=1e-10, atol=1e-10)
        self.assertEqual(tuple(last.shape), (batch, heads, width, state))
        probe = torch.randn_like(yr)
        gr = torch.autograd.grad((yr * probe).sum(), recurrent_args)
        gm = torch.autograd.grad((ym * probe).sum(), matrix_args)
        for a, b in zip(gr, gm):
            torch.testing.assert_close(a, b, rtol=1e-9, atol=1e-9)

    def test_whole_model_is_causal_including_short_convolution(self):
        # k=1 also catches the common [:-(k-1)] empty-slice implementation bug.
        for kernel in (1, 4):
            model = Mamba2LM(Mamba2Config(d_conv=kernel)).eval()
            ids = torch.randint(0, 256, (2, 9))
            perturbed = ids.clone()
            perturbed[:, 3:] = (perturbed[:, 3:] + 17) % 256
            with torch.no_grad():
                full = model(ids)
                changed = model(perturbed)
                prefix = model(ids[:, :3])
                single = model(ids[:, :1])
            torch.testing.assert_close(full[:, :3], changed[:, :3], atol=1e-6, rtol=1e-5)
            torch.testing.assert_close(full[:, :3], prefix, atol=1e-6, rtol=1e-5)
            torch.testing.assert_close(full[:, :1], single, atol=1e-6, rtol=1e-5)

    def test_complete_lm_backends_and_backward(self):
        cfg = Mamba2Config(vocab_size=41, d_model=32, headdim=8,
                           d_state=8, ngroups=2)
        recurrent = Mamba2LM(cfg)
        matrix = Mamba2LM(replace(cfg, ssd_backend="matrix"))
        matrix.load_state_dict(recurrent.state_dict())
        ids = torch.randint(0, cfg.vocab_size, (2, 8))
        logits = recurrent(ids[:, :-1])
        self.assertEqual(tuple(logits.shape), (2, 7, cfg.vocab_size))
        torch.testing.assert_close(logits, matrix(ids[:, :-1]), atol=2e-6, rtol=2e-5)
        loss = F.cross_entropy(logits.flatten(0, 1), ids[:, 1:].flatten())
        loss.backward()
        for name, param in recurrent.named_parameters():
            self.assertIsNotNone(param.grad, name)
            self.assertTrue(torch.isfinite(param.grad).all(), name)
            self.assertGreater(param.grad.abs().sum().item(), 0, name)
        self.assertIs(recurrent.embedding.weight, recurrent.lm_head.weight)


if __name__ == "__main__":
    unittest.main()
