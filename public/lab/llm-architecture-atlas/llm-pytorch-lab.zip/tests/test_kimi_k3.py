"""Kimi K3 mechanisms and whole text-backbone checks, CPU only."""
import math
import unittest
import torch
from torch import nn
from torch.nn import functional as F
from models.kimi_k3 import (KimiK3Config, KimiK3LM, KimiK3Block, K3DeltaAttention,
                           K3GatedMLA, StableLatentMoE, situ_product,
                           bounded_log_decay, quantile_bias_next_step)


class Scale(nn.Module):
    def __init__(self, factor):
        super().__init__()
        self.factor = factor

    def forward(self, x):
        return self.factor * x


class TestKimiK3(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(23)
        torch.set_num_threads(1)

    def test_situ_bounds_and_local_swiglu_limit(self):
        gate = torch.tensor([-1e4, -20., -1., 0., 1., 20., 1e4], dtype=torch.float64)
        up = torch.tensor([1e4, -1e4, 500., 1., -300., 1000., 1e4], dtype=torch.float64)
        expected = (4 * torch.tanh(gate / 4) * torch.sigmoid(gate) *
                    25 * torch.tanh(up / 25))
        actual = situ_product(gate, up)
        torch.testing.assert_close(actual, expected)
        self.assertTrue((actual.abs() <= 100).all())
        g, u = torch.tensor([1e-3], dtype=torch.float64), torch.tensor([2e-3], dtype=torch.float64)
        torch.testing.assert_close(situ_product(g, u), F.silu(g)*u, rtol=1e-6, atol=1e-12)
        # Sigmoid of the original gate, not sigmoid(softcap(gate)).
        self.assertFalse(torch.allclose(actual, (4*torch.tanh(gate/4)).sigmoid()*4*torch.tanh(gate/4)*25*torch.tanh(up/25)))

    def test_bounded_gate_and_full_rank_output_only(self):
        raw = torch.tensor([[[[-100., 0., 100.]]]], dtype=torch.float64)
        log_a = bounded_log_decay(raw, torch.zeros(1, dtype=torch.float64), torch.zeros(1, 3, dtype=torch.float64))
        self.assertTrue(torch.isfinite(log_a).all())
        self.assertTrue(((log_a >= -5) & (log_a <= 0)).all())
        self.assertEqual(log_a[0, 0, 0, 1].item(), -2.5)
        cfg = KimiK3Config()
        module = K3DeltaAttention(cfg)
        self.assertEqual(module.forget_down.out_features, cfg.kda_head_dim)
        self.assertEqual(module.output_gate.in_features, cfg.dim)
        self.assertEqual(module.output_gate.out_features, cfg.n_kda_heads*cfg.kda_head_dim)
        self.assertFalse(hasattr(module, 'gate_down'))

    def test_stable_latent_moe_against_per_token_reference(self):
        cfg = KimiK3Config(dim=12, routed_latent_dim=6, moe_inter_dim=9,
                           n_routed_experts=4, n_activated_experts=2)
        module = StableLatentMoE(cfg).double()
        x = torch.randn(2, 3, 12, dtype=torch.float64)
        actual = module(x)
        tokens = x.reshape(-1, 12)
        weights, ids = module.router(tokens)
        reference = []
        for t, token in enumerate(tokens):
            z = F.linear(token, module.compress.weight)
            mixed = sum(weights[t, j]*module.experts[int(ids[t,j])](z) for j in range(2))
            # Norm after summation, in latent width 6; shared path receives width 12.
            normalized = mixed / torch.sqrt(mixed.square().mean() + cfg.norm_eps)
            routed = F.linear(normalized*module.aggregate_norm.weight, module.expand.weight)
            reference.append(routed + module.shared(token))
        torch.testing.assert_close(actual, torch.stack(reference).reshape_as(x), rtol=1e-10, atol=1e-10)

    def test_gated_mla_matches_direct_attention_reference(self):
        cfg = KimiK3Config(dim=24, q_lora_rank=6, n_mla_heads=2,
                           mla_content_dim=5, mla_shared_dim=3, mla_value_dim=4,
                           kv_lora_rank=7)
        module = K3GatedMLA(cfg).double()
        x = torch.randn(2, 4, 24, dtype=torch.float64)
        q = module.q_proj(x).reshape(2, 4, 2, 8).transpose(1, 2)
        latent, shared = module.kv_down(x).split([7, 3], -1)
        kv = module.kv_up(module.kv_norm(latent)).reshape(2, 4, 2, 9)
        key_c, value = kv.split([5, 4], -1)
        key = torch.cat([key_c, shared[:, :, None].expand(-1, -1, 2, -1)], -1).transpose(1, 2)
        scores = q @ key.transpose(-2, -1) / math.sqrt(8)
        probs = scores.masked_fill(torch.ones(4, 4, dtype=torch.bool).triu(1), -torch.inf).softmax(-1)
        mixed = (probs @ value.transpose(1, 2)).transpose(1, 2).reshape(2, 4, 8)
        reference = F.linear(mixed * module.output_gate(x).sigmoid(), module.output.weight)
        torch.testing.assert_close(module(x), reference, rtol=1e-11, atol=1e-11)

    def test_attnres_schedule_crosses_boundaries_without_double_counting(self):
        cfg = KimiK3Config(dim=4, attn_res_block_size=2)
        layers = [KimiK3Block(cfg, i).double() for i in range(5)]
        x = torch.randn(1, 2, 4, dtype=torch.float64)
        # Zero pseudo-queries make depth weights uniform. Different sublayer
        # maps keep the exact sequence and all boundary choices observable.
        for i, layer in enumerate(layers):
            layer.norm_attention = nn.Identity()
            layer.norm_ffn = nn.Identity()
            layer.attention = Scale((i+1)*0.13)
            layer.ffn = Scale((i+2)*0.17)
        actual_partial, actual_blocks = x, []
        reference_blocks, current_outputs = [x], []
        for i, layer in enumerate(layers):
            sources = reference_blocks + ([sum(current_outputs)] if current_outputs else [])
            attention_input = torch.stack(sources).mean(0)
            if i > 0 and i % 2 == 0:
                reference_blocks.append(sum(current_outputs))
                current_outputs = []
            current_outputs.append((i+1)*0.13*attention_input)
            ffn_input = torch.stack(reference_blocks + [sum(current_outputs)]).mean(0)
            current_outputs.append((i+2)*0.17*ffn_input)
            actual_partial, actual_blocks = layer(actual_partial, actual_blocks)
            torch.testing.assert_close(actual_partial, sum(current_outputs), rtol=1e-12, atol=1e-12)
            self.assertEqual(len(actual_blocks), len(reference_blocks))
            for a,b in zip(actual_blocks,reference_blocks):
                torch.testing.assert_close(a,b,rtol=1e-12,atol=1e-12)
        self.assertEqual(len(actual_blocks)+1, 4)  # 3 network blocks + embedding.

    def test_qb_next_step_is_centered_separate_and_matches_order_statistic(self):
        scores = torch.rand(8,4,dtype=torch.float64)
        bias = torch.tensor([0.07,-0.08,0.01,0.0],dtype=torch.float64)
        original_scores, original_bias = scores.clone(), bias.clone()
        actual = quantile_bias_next_step(scores,bias,topk=1)
        cutoffs = [sorted((scores[t]+bias).tolist(),reverse=True)[1] for t in range(8)]
        raw_next = torch.tensor([-sorted([scores[t,j].item()-cutoffs[t] for t in range(8)],reverse=True)[2]
                                 for j in range(4)],dtype=torch.float64)
        torch.testing.assert_close(actual,raw_next-raw_next.mean())
        torch.testing.assert_close(scores,original_scores)
        torch.testing.assert_close(bias,original_bias)
        self.assertAlmostEqual(actual.mean().item(),0.0,places=12)

    def test_full_text_lm_causal_backward_and_published_preset(self):
        cfg = KimiK3Config(dim=24, n_kda_heads=2, kda_head_dim=8,
                           n_mla_heads=2, mla_content_dim=8, mla_shared_dim=4,
                           mla_value_dim=8, kv_lora_rank=12, q_lora_rank=12,
                           routed_latent_dim=12, inter_dim=48, moe_inter_dim=20,
                           n_routed_experts=4, n_activated_experts=2)
        model = KimiK3LM(cfg)
        self.assertEqual([type(l.attention) for l in model.layers],[K3DeltaAttention]*3+[K3GatedMLA]*2)
        tokens = torch.randint(256,(2,9))
        changed=tokens.clone();changed[:,5:]=(changed[:,5:]+71)%256
        with torch.no_grad():
            baseline,altered,prefix=model(tokens),model(changed),model(tokens[:,:5])
        torch.testing.assert_close(baseline[:,:5],altered[:,:5],rtol=0,atol=1e-6)
        torch.testing.assert_close(baseline[:,:5],prefix,rtol=2e-5,atol=2e-6)
        logits=model(tokens)
        self.assertEqual(logits.shape,(2,9,256))
        loss=F.cross_entropy(logits[:,:-1].reshape(-1,256),tokens[:,1:].reshape(-1))
        loss.backward()
        for name,p in model.named_parameters():
            if p.grad is not None:
                self.assertTrue(torch.isfinite(p.grad).all(),name)
        self.assertGreater(model.output_res.query.grad.abs().sum().item(),0)
        self.assertGreater(model.layers[2].attention.A_log.grad.abs().sum().item(),0)
        self.assertGreater(model.layers[2].ffn.expand.weight.grad.abs().sum().item(),0)
        self.assertNotEqual(model.embedding.weight.data_ptr(),model.lm_head.weight.data_ptr())
        real=KimiK3Config.kimi_k3_text_config()
        self.assertEqual((real.n_layers,len(real.mla_layers)),(93,24))
        self.assertEqual((real.dim,real.routed_latent_dim,real.n_routed_experts,real.n_activated_experts),(7168,3584,896,16))
        self.assertEqual((real.attn_res_block_size,real.mla_layers[-1],real.n_shared_experts),(12,93,2))


if __name__=='__main__':
    unittest.main()
