"""Contract, causal, routing-semantic and MLA algebra checks; no pretrained weights."""

from dataclasses import replace
import unittest

import torch
import torch.nn.functional as F

from models.deepseek_v3 import (
    DeepSeekConfig, DeepSeekLM, DeepSeekMoE, DeepSeekRouter, MLA, SwiGLU,
    deepseek_v3_671b_config,
)


class TestDeepSeek(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    def setUp(self):
        torch.manual_seed(19)

    def test_forward_backward_complete_decoder(self):
        model = DeepSeekLM()
        ids = torch.randint(model.config.vocab_size, (2, 9))
        logits = model(ids)
        self.assertEqual(logits.shape, (2, 9, model.config.vocab_size))
        loss = F.cross_entropy(logits[:, :-1].reshape(-1, logits.shape[-1]), ids[:, 1:].reshape(-1))
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        required = (
            model.embedding.weight, model.layers[0].attn.q_up.weight,
            model.layers[1].ffn.router.proj.weight,
            model.layers[1].ffn.shared.down.weight, model.lm_head.weight,
        )
        for parameter in required:
            self.assertIsNotNone(parameter.grad)
            self.assertTrue(torch.isfinite(parameter.grad).all())
            self.assertGreater(parameter.grad.abs().sum().item(), 0)
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None))
        self.assertIsInstance(model.layers[0].ffn, SwiGLU)
        self.assertIsInstance(model.layers[1].ffn, DeepSeekMoE)

    def test_future_tokens_cannot_change_prefix(self):
        model = DeepSeekLM().eval()
        ids = torch.randint(model.config.vocab_size, (2, 10))
        changed = ids.clone()
        changed[:, 5:] = (changed[:, 5:] + 17) % model.config.vocab_size
        with torch.no_grad():
            original, perturbed = model(ids), model(changed)
        torch.testing.assert_close(original[:, :5], perturbed[:, :5], rtol=1e-5, atol=1e-6)
        self.assertFalse(torch.allclose(original[:, 5:], perturbed[:, 5:]))

    def test_routing_bias_changes_selection_not_weights(self):
        config = replace(DeepSeekConfig(), dim=4, n_expert_groups=1, n_limited_groups=1)
        router = DeepSeekRouter(config)
        x = torch.tensor([[1.0, 0.0, 0.0, 0.0]])
        with torch.no_grad():
            router.proj.weight.zero_()
            router.proj.weight[:, 0] = torch.arange(-3.0, 5.0)
        _, before = router(x)
        self.assertEqual(set(before[0].tolist()), {6, 7})
        with torch.no_grad():
            router.routing_bias[:2] = torch.tensor([5.0, 4.0])
        weights, selected = router(x)
        self.assertEqual(set(selected[0].tolist()), {0, 1})
        affinity = F.linear(x, router.proj.weight).sigmoid().gather(1, selected)
        expected = config.route_scale * affinity / affinity.sum(-1, keepdim=True)
        torch.testing.assert_close(weights, expected)
        with torch.no_grad():
            router.routing_bias[:2] += 0.1  # Keep the same selected order/set.
        unchanged_weights, unchanged_ids = router(x)
        torch.testing.assert_close(unchanged_ids, selected)
        torch.testing.assert_close(unchanged_weights, weights)
        self.assertFalse(router.routing_bias.requires_grad)
        torch.testing.assert_close(weights.sum(-1), torch.tensor([config.route_scale]))

    def test_group_score_sums_top_two_and_masks_other_groups(self):
        config = replace(DeepSeekConfig(), dim=4)
        router = DeepSeekRouter(config)
        x = torch.tensor([[1.0, 0.0, 0.0, 0.0]])
        probabilities = torch.tensor([0.99, 0.02, 0.01, 0.01, 0.8, 0.7, 0.1, 0.05])
        with torch.no_grad():
            router.proj.weight.zero_()
            router.proj.weight[:, 0] = torch.logit(probabilities)
        _, indices = router(x)
        # Group 0 has the largest single score, but group 1 wins the top-two sum.
        self.assertEqual(set(indices[0].tolist()), {4, 5})
        with torch.no_grad():
            router.routing_bias[1] = 1.0
        _, indices = router(x)
        self.assertEqual(set(indices[0].tolist()), {0, 1})

    def test_expanded_mla_equals_absorbed_latent_reference(self):
        config = DeepSeekConfig()
        attention = MLA(config).eval()
        x = torch.randn(2, 7, config.dim)
        # Independent contraction order: absorb W_UK into Q, then aggregate C_KV
        # before W_UV. This checks the algebra, not an actual cache implementation.
        qc, qr, latent, kr = attention.project_latents(x)
        weights = attention.kv_up.weight.view(
            config.n_heads, config.qk_nope_head_dim + config.v_head_dim, config.kv_lora_rank
        )
        absorbed_query = torch.einsum("bthd,hdc->bthc", qc, weights[:, :config.qk_nope_head_dim])
        scores = torch.einsum("bthc,bsc->bhts", absorbed_query, latent)
        scores = scores + torch.einsum("bthr,bsr->bhts", qr, kr.squeeze(2))
        scores = scores * attention.softmax_scale
        future = torch.ones(7, 7, dtype=torch.bool).triu(1)
        probabilities = scores.masked_fill(future, float("-inf")).softmax(-1)
        mixed_latent = torch.einsum("bhts,bsc->bthc", probabilities, latent)
        mixed_values = torch.einsum("bthc,hdc->bthd", mixed_latent, weights[:, -config.v_head_dim:])
        reference = attention.out(mixed_values.flatten(2))
        torch.testing.assert_close(attention(x), reference, rtol=1e-5, atol=1e-6)

    def test_original_preset_is_configuration_only(self):
        config = deepseek_v3_671b_config()
        self.assertEqual((config.n_layers, config.n_dense_layers), (61, 3))
        self.assertEqual((config.n_routed_experts, config.n_activated_experts, config.n_shared_experts), (256, 8, 1))
        self.assertEqual((config.n_expert_groups, config.n_limited_groups), (8, 4))
        self.assertEqual((config.dim, config.kv_lora_rank), (7168, 512))


if __name__ == "__main__":
    unittest.main()
