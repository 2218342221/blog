"""CSA2/CED reference checks; not a pretrained V4.1 evaluation."""
import unittest
import torch
import torch.nn.functional as F
from models.deepseek_v41 import (
    CSA2Config, CSA2Reference, ChannelCompressor, TinyCEDReference,
    hierarchical_candidates,
)


class TestDeepSeekV41Reference(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    def setUp(self):
        torch.manual_seed(41)

    def test_compressor_uses_complete_nonoverlapping_groups(self):
        c = CSA2Config(dim=4, head_dim=4, index_dim=4, rope_dim=2)
        compressor = ChannelCompressor(c, 2)
        with torch.no_grad():
            compressor.value.weight.copy_(torch.eye(4))
            compressor.gate.weight.zero_()
        x = torch.randn(1, 5, 4)
        value, start, end = compressor(x)
        expected = compressor.norm(x[:, :4].view(1, 2, 2, 4).mean(2))
        torch.testing.assert_close(value, expected)
        self.assertEqual(start.tolist(), [0, 2])
        self.assertEqual(end.tolist(), [1, 3])
        changed = x.clone(); changed[:, 4] += 1000
        torch.testing.assert_close(compressor(changed)[0], value)

    def test_full_reindex_reuse_share_exact_cache_and_selection(self):
        c = CSA2Config()
        full = CSA2Reference("full", c, candidate_source=True)
        reindex, reuse = CSA2Reference("reindex", c), CSA2Reference("reuse", c)
        x = torch.randn(2, 11, c.dim)
        _, cache, chosen, _ = full(x)
        _, same_cache, rechosen, score = reindex(x + 0.2, cache, chosen)
        self.assertIs(cache, same_cache)
        self.assertIs(chosen.candidates, rechosen.candidates)
        self.assertIsNotNone(score)
        _, last_cache, last_chosen, last_score = reuse(x - 0.3, cache, rechosen)
        self.assertIs(last_cache, cache)
        self.assertIs(last_chosen, rechosen)
        self.assertIsNone(last_score)
        for b in range(2):
            for t in range(11):
                for index in rechosen.indices[b, t].tolist():
                    if index >= 0:
                        self.assertTrue(chosen.candidates[b, t, index])

    def test_candidate_budget_and_latest_block_retention(self):
        scores = torch.tensor([[[100., 90., 80., 70., 1., 0.]]])
        visible = torch.ones_like(scores, dtype=torch.bool)
        selected = hierarchical_candidates(scores, visible, 2, 2)
        self.assertEqual(selected[0, 0].tolist(), [True, True, False, False, True, True])
        self.assertLessEqual(selected.sum().item(), 4)
        invisible = torch.zeros_like(visible)
        self.assertFalse(hierarchical_candidates(scores, invisible, 2, 2).any())

    def test_global_source_and_current_layer_have_separate_roles(self):
        full = CSA2Reference("full")
        x, source = torch.randn(1, 9, 48), torch.randn(1, 9, 48)
        first, cache1, _, _ = full(x, source=source)
        second, cache2, _, _ = full(x + 2, source=source)
        torch.testing.assert_close(cache1.kv, cache2.kv)
        torch.testing.assert_close(cache1.index_key, cache2.index_key)
        self.assertFalse(torch.allclose(first, second))
        _, cache3, _, _ = full(x, source=source + torch.randn_like(source))
        self.assertFalse(torch.allclose(cache1.kv, cache3.kv))

    def test_causality_completed_groups_and_prefix_equivalence(self):
        model = TinyCEDReference().eval()
        ids = torch.randint(256, (2, 13))
        modified = ids.clone(); modified[:, 7:] = (modified[:, 7:] + 11) % 256
        with torch.no_grad():
            full, changed, prefix = model(ids), model(modified), model(ids[:, :7])
        torch.testing.assert_close(full[:, :7], changed[:, :7], atol=2e-6, rtol=1e-5)
        torch.testing.assert_close(full[:, :7], prefix, atol=2e-6, rtol=1e-5)
        # One token cannot complete an m=2 global group; local SWA remains valid.
        tiny = model(ids[:, :1])
        self.assertTrue(torch.isfinite(tiny).all())

    def test_forward_backward_and_discrete_indexer_boundary(self):
        model = TinyCEDReference()
        ids = torch.randint(256, (2, 12))
        logits = model(ids)
        loss = F.cross_entropy(logits[:, :-1].flatten(0, 1), ids[:, 1:].flatten())
        loss.backward()
        self.assertEqual(tuple(logits.shape), (2, 12, 256))
        for parameter in (model.embedding.weight, model.head.weight,
                          model.decoder[0].attention.q_up.weight,
                          model.decoder[0].attention.compressor.value.weight):
            self.assertIsNotNone(parameter.grad)
            self.assertTrue(torch.isfinite(parameter.grad).all())
            self.assertGreater(parameter.grad.abs().sum().item(), 0)
        # Ranking decisions are discrete: CE alone does not train the indexer.
        self.assertIsNone(model.decoder[0].attention.index_query.weight.grad)
        attention = model.decoder[0].attention
        _, _, _, scores = attention(torch.randn(1, 8, 48))
        finite = scores[torch.isfinite(scores)]
        finite.square().mean().backward()
        self.assertGreater(attention.index_query.weight.grad.abs().sum().item(), 0)


if __name__ == "__main__":
    unittest.main()
