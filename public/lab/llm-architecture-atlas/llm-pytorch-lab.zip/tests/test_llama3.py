"""Small mathematical checks for the Llama 3 teaching decoder; CPU only."""
import math
import unittest

import torch
from torch.nn import functional as F

from models.llama3 import LlamaConfig, LlamaLM, RoPE, causal_gqa


class TestLlama3(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(11)
        torch.set_num_threads(1)

    def test_forward_backward_next_token(self):
        model = LlamaLM(LlamaConfig(vocab_size=37, dim=32, hidden_dim=80,
                                   n_heads=4, n_kv_heads=2))
        ids = torch.randint(37, (2, 9))
        logits = model(ids)
        self.assertEqual(logits.shape, (2, 9, 37))
        loss = F.cross_entropy(logits[:, :-1].reshape(-1, 37), ids[:, 1:].reshape(-1))
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        for name, parameter in model.named_parameters():
            self.assertIsNotNone(parameter.grad, name)
            self.assertTrue(torch.isfinite(parameter.grad).all(), name)
        self.assertNotEqual(model.tok_embeddings.weight.data_ptr(), model.output.weight.data_ptr())

    def test_future_tokens_cannot_change_prefix_logits(self):
        model = LlamaLM(LlamaConfig(dim=32, hidden_dim=80)).eval()
        ids = torch.randint(model.cfg.vocab_size, (2, 11))
        changed = ids.clone()
        changed[:, 5:] = (changed[:, 5:] + 17) % model.cfg.vocab_size
        with torch.no_grad():
            original, perturbed = model(ids), model(changed)
            prefix_only = model(ids[:, :5])
        torch.testing.assert_close(original[:, :5], perturbed[:, :5], rtol=0, atol=1e-6)
        torch.testing.assert_close(original[:, :5], prefix_only, rtol=1e-5, atol=1e-6)
        self.assertFalse(torch.allclose(original[:, 5:], perturbed[:, 5:]))

    def test_gqa_matches_independent_head_by_head_causal_reference(self):
        q = torch.randn(2, 6, 5, 8, dtype=torch.float64)
        k = torch.randn(2, 2, 5, 8, dtype=torch.float64)
        v = torch.randn(2, 2, 5, 8, dtype=torch.float64)
        actual = causal_gqa(q, k, v)
        reference = torch.empty_like(q)
        # Direct per-query computation: no repeated KV tensors and no SDPA.
        for head in range(6):
            kv_head = head // 3
            for pos in range(5):
                scores = torch.einsum('bd,btd->bt', q[:, head, pos], k[:, kv_head, :pos + 1])
                probabilities = torch.softmax(scores / math.sqrt(8), dim=-1)
                reference[:, head, pos] = torch.einsum('bt,btd->bd', probabilities,
                                                       v[:, kv_head, :pos + 1])
        torch.testing.assert_close(actual, reference, rtol=1e-12, atol=1e-12)

    def test_rope_preserves_norm_and_relative_dot_product(self):
        rope = RoPE(8, theta=500_000.0)
        x = torch.randn(2, 3, 7, 8)
        rotated = rope(x)
        torch.testing.assert_close(rotated.square().sum(-1), x.square().sum(-1),
                                   rtol=1e-5, atol=1e-5)
        # Shift both positions by one: their relative phase and dot product stay fixed.
        a, b = torch.randn(8), torch.randn(8)
        qs, ks = a.expand(1, 1, 7, 8), b.expand(1, 1, 7, 8)
        rq, rk = rope(qs), rope(ks)
        dot_24 = (rq[..., 2, :] * rk[..., 4, :]).sum()
        dot_35 = (rq[..., 3, :] * rk[..., 5, :]).sum()
        torch.testing.assert_close(dot_24, dot_35, rtol=1e-5, atol=1e-5)
        torch.testing.assert_close(rotated[..., 0, :], x[..., 0, :])

    def test_original_8b_config_without_allocating_model(self):
        cfg = LlamaConfig.llama3_8b()
        self.assertEqual((cfg.dim, cfg.n_layers, cfg.n_heads, cfg.n_kv_heads), (4096, 32, 32, 8))
        self.assertEqual((cfg.hidden_dim, cfg.vocab_size, cfg.max_seq_len), (14336, 128256, 8192))
        self.assertEqual(cfg.rope_theta, 500_000.0)
        self.assertEqual(cfg.rms_norm_eps, 1e-5)


if __name__ == '__main__':
    unittest.main()
