import unittest
import torch
from models.attention_residuals import AttentionResiduals


class AttentionResidualTests(unittest.TestCase):
    def test_zero_query_is_mean_of_original_values(self):
        torch.manual_seed(7)
        x = torch.randn(4, 2, 3, 8) * torch.arange(1, 5)[:, None, None, None]
        layer = AttentionResiduals(8)
        y, weights = layer(x, return_weights=True)
        torch.testing.assert_close(y, x.mean(0))
        torch.testing.assert_close(weights, torch.full((4,2,3), 0.25))

    def test_source_softmax_token_independence_and_gradients(self):
        torch.manual_seed(8)
        layer = AttentionResiduals(8).double()
        with torch.no_grad(): layer.query.copy_(torch.randn(8))
        x = torch.randn(3, 2, 4, 8, dtype=torch.double, requires_grad=True)
        y, w = layer(x, return_weights=True)
        torch.testing.assert_close(w.sum(0), torch.ones(2,4,dtype=torch.double))
        self.assertTrue((w > 0).all())
        changed = x.detach().clone(); changed[:, :, 3] *= -17
        torch.testing.assert_close(layer(changed)[:, :3], y[:, :3])
        y.square().mean().backward()
        for grad in [x.grad, layer.query.grad, layer.norm_weight.grad]:
            self.assertIsNotNone(grad)
            self.assertTrue(torch.isfinite(grad).all())
        self.assertGreater(layer.query.grad.abs().sum().item(), 0)

    def test_block_interface_includes_partial_sum(self):
        layer = AttentionResiduals(2)
        completed = [torch.zeros(1,1,2), torch.full((1,1,2), 3.0)]
        partial = torch.full((1,1,2), 6.0)
        torch.testing.assert_close(layer.from_blocks(completed, partial), torch.full((1,1,2), 3.0))
        with self.assertRaises(ValueError): layer.from_blocks([])


if __name__ == '__main__':
    unittest.main()
