"""Tests of masked diffusion, deliberately not autoregressive causal tests."""
import math
import unittest

import torch

from models.llada import (LLaDAConfig, LLaDALM, BidirectionalAttention,
                          corrupt_tokens, masked_diffusion_loss, sample_llada,
                          llada_8b_config, illada_8b_config)


class LLaDATests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    def setUp(self):
        torch.manual_seed(123)

    def test_inverse_probability_loss_and_unmasked_targets(self):
        # Uniform logits give CE=log(5); this catches averaging by masked count.
        logits = torch.zeros(2, 4, 5, dtype=torch.float64, requires_grad=True)
        target = torch.tensor([[1, 2, 3, 4], [0, 1, 2, 3]])
        mask = torch.tensor([[True, False, False, False], [True, True, False, False]])
        p = torch.tensor([0.5, 0.25], dtype=torch.float64)
        loss = masked_diffusion_loss(logits, target, mask, p)
        expected = math.log(5) * (1 / 0.5 + 2 / 0.25) / 8
        self.assertAlmostEqual(loss.item(), expected, places=12)
        different = target.clone()
        different[~mask] = -1000  # Ignored targets are never passed to CE.
        torch.testing.assert_close(loss, masked_diffusion_loss(logits, different, mask, p))
        loss.backward()
        self.assertEqual(logits.grad[~mask].abs().sum().item(), 0)
        self.assertGreater(logits.grad[mask].abs().sum().item(), 0)

    def test_no_mask_is_zero_without_nan(self):
        logits = torch.randn(2, 3, 7, requires_grad=True)
        loss = masked_diffusion_loss(logits, torch.zeros(2, 3, dtype=torch.long),
                                     torch.zeros(2, 3, dtype=torch.bool), torch.tensor([0.1, 0.2]))
        self.assertEqual(loss.item(), 0)
        loss.backward()
        self.assertEqual(logits.grad.abs().sum().item(), 0)

    def test_corruption_reproducibility_and_exact_probability_weights(self):
        ids = torch.arange(24).reshape(2, 12)
        a = corrupt_tokens(ids, 256, probabilities=torch.tensor([1.0, 0.25]),
                           generator=torch.Generator().manual_seed(55))
        b = corrupt_tokens(ids, 256, probabilities=torch.tensor([1.0, 0.25]),
                           generator=torch.Generator().manual_seed(55))
        for left, right in zip(a, b):
            torch.testing.assert_close(left, right)
        noisy, mask, p = a
        self.assertTrue(mask[0].all())
        torch.testing.assert_close(noisy[~mask], ids[~mask])
        self.assertTrue((noisy[mask] == 256).all())
        torch.testing.assert_close(p[:, 0], torch.tensor([1.0, 0.25]))

    def test_attention_really_reads_future_positions(self):
        # Force uniform attention with Q=K=0. V and output identity imply the
        # first token must contain the last token's contribution: mean, not zero.
        cfg = LLaDAConfig(d_model=4, n_heads=1, n_kv_heads=1, hidden_dim=8)
        attention = BidirectionalAttention(cfg)
        with torch.no_grad():
            attention.q.weight.zero_()
            attention.k.weight.zero_()
            attention.v.weight.copy_(torch.eye(4))
            attention.out.weight.copy_(torch.eye(4))
        x = torch.zeros(1, 3, 4)
        x[:, -1] = torch.tensor([3.0, 6.0, 9.0, 12.0])
        torch.testing.assert_close(attention(x)[:, 0], torch.tensor([[1.0, 2.0, 3.0, 4.0]]))
        model = LLaDALM().eval()
        ids = torch.tensor([[10, 256, 20, 30]])
        changed = ids.clone()
        changed[:, -1] = 31
        self.assertGreater((model(ids)[:, 1] - model(changed)[:, 1]).abs().max().item(), 1e-5)

    def test_complete_masked_lm_backward(self):
        model = LLaDALM()
        clean = torch.randint(0, 256, (2, 11))
        noisy, mask, p = corrupt_tokens(clean, 256, probabilities=torch.tensor([0.5, 0.7]))
        logits = model(noisy)
        self.assertEqual(tuple(logits.shape), (2, 11, 257))
        loss = masked_diffusion_loss(logits, clean, mask, p)
        loss.backward()
        for name, parameter in model.named_parameters():
            self.assertIsNotNone(parameter.grad, name)
            self.assertTrue(torch.isfinite(parameter.grad).all(), name)
            self.assertGreater(parameter.grad.abs().sum().item(), 0, name)
        self.assertIs(model.embedding.weight, model.lm_head.weight)

    def test_sampler_keeps_prompt_and_finishes_all_masks(self):
        model = LLaDALM()
        prompt = torch.tensor([[1, 2, 3], [4, 5, 6]])
        seen = []
        hook = model.register_forward_pre_hook(lambda _module, args: seen.append(args[0].clone()))
        for remasking in ("low_confidence", "random"):
            seen.clear()
            generated = sample_llada(model, prompt, gen_length=7, block_length=4,
                                     steps=3, remasking=remasking, temperature=0.5,
                                     generator=torch.Generator().manual_seed(8))
            self.assertEqual(tuple(generated.shape), (2, 10))
            torch.testing.assert_close(generated[:, :3], prompt)
            self.assertFalse((generated == 256).any())
            self.assertEqual(len(seen), 6)  # 3 steps in both blocks.
            for frame in seen:
                torch.testing.assert_close(frame[:, :3], prompt)
            self.assertEqual([frame.shape[1] for frame in seen], [7, 7, 7, 10, 10, 10])
        hook.remove()
        self.assertTrue(model.training)  # Sampling restores the caller's mode.

    def test_eos_stops_after_completed_block(self):
        model = LLaDALM()
        original_forward = model.forward
        def always_eos(ids):
            logits = torch.full((*ids.shape, model.config.vocab_size), -10.0)
            logits[..., 2] = 10
            return logits
        model.forward = always_eos
        prompt = torch.tensor([[2, 17]])  # A prompt EOS must not stop generation.
        generated = sample_llada(model, prompt, gen_length=12, block_length=4,
                                 steps=2, eos_token_id=2)
        torch.testing.assert_close(generated, torch.tensor([[2, 17, 2]]))
        model.forward = original_forward

    def test_original_presets_do_not_allocate_weights(self):
        original, latest = llada_8b_config(), illada_8b_config()
        self.assertEqual((original.n_heads, original.n_kv_heads), (32, 32))
        self.assertFalse(original.tie_embeddings)
        self.assertEqual((latest.n_heads, latest.n_kv_heads), (32, 8))
        self.assertEqual((latest.hidden_dim, latest.mask_token_id, latest.max_seq_len), (14336, 5, 8192))
        self.assertTrue(latest.tie_embeddings)


if __name__ == "__main__":
    unittest.main()
