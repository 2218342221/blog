# 《Go 语言代码静态分析技术与应用》

这是教材《Go 语言代码静态分析技术与应用》的完整 LaTeX 源码。

## 目录结构

- `main.tex` —— 主文件，用 `\input` 组织全部章节
- `preamble.tex` —— 全局样式（字体、配色、代码高亮、TikZ、提示框、定理环境等）
- `frontmatter/` —— 封面（`cover.tex`）与前言（`preface.tex`）
- `chapters/` —— 正文四篇十三章 + 四个附录
- `main.pdf` —— 已编译好的成品 PDF（122 页）

## 编译方法

需要 **XeLaTeX**（中文字体依赖 Noto Serif/Sans CJK SC，西文使用 TeX Gyre Termes/Heros，等宽使用 DejaVu Sans Mono）：

```bash
latexmk -xelatex -interaction=nonstopmode main.tex
```

或：

```bash
xelatex main.tex && xelatex main.tex
```

## 全书结构

- 第一篇 基础篇：静态分析概述、Go 编译器前端、AST
- 第二篇 核心技术篇：go/types 类型系统、SSA、控制流/数据流、指针分析与调用图
- 第三篇 工具与框架篇：go/analysis 框架、自定义分析器、工具生态
- 第四篇 应用篇：安全漏洞检测、并发缺陷检测、工程落地与 CI/CD 集成
- 附录：工具速查、核心 API 速查、环境搭建、参考资源
