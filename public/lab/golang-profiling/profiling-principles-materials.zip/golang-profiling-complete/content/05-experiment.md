# 同一请求，三种视角：可复现的跨工具实验

本章把原理缩小到可以手算的规模。输入是合成教学数据，数字由场景明确设定；解析和报告由真实工具执行。它验证数据格式、聚合和查询口径，不验证内核采样精度、eBPF 开销或生产环境尾延迟。配套目录同时保留生成脚本、输入文件、SQL 和原始输出。[pp-teaching][pf-request][pf-validation]

## 1. 先写清请求、线程和时间

场景有两个已明确归属于 request=demo 的 OS 线程。请求从相对 0 ms 开始，在 20 ms 完成。main 先执行 4 ms，然后处于 runnable 2 ms，随后 sleeping 10 ms，最后执行 4 ms；worker 在另一 CPU 上从 1 ms 执行到 16 ms。模型声明 main 等待 worker 完成后继续；这些业务归属与依赖是模型输入，不能仅凭 sched_switch 自动发现。

| 对象 | 时间区间 | 状态或作用 | 时长 |
| --- | --- | --- | --- |
| main | [0,4) ms | first_work，运行 | 4 ms |
| main | [4,6) ms | 可运行，尚未调度 | 2 ms |
| main | [6,16) ms | join_wait，睡眠 | 10 ms |
| main | [16,20) ms | finish_work，运行 | 4 ms |
| worker | [1,16) ms | worker_work，运行 | 15 ms |

手算得到 main CPU 为 8 ms，worker CPU 为 15 ms，请求总 CPU 为 23 ms；墙钟为 20 ms，平均 CPU 容量尺度为 1.15 核。main 的状态分解满足 8+2+10=20 ms。worker 的 15 ms 与 main 的前段运行重叠，因此不能将全部 CPU 相加作为请求延迟。这里所有时间都是教学数值，HTML 动画与 PDF 图共享相同场景。

## 2. eBPF 应该怎样观察这个场景

若通过 eBPF 观察切出事件，只记录当前 tid 和时间戳，可以统计切出频度，却不足以重建上述完整时间表。必须增加 next/prev 身份、切出状态、切入配对及相关唤醒事件，处理任务退出、TID 复用、丢失与边界。通过 perf 采样当前用户栈得到的是正在执行的栈；main 在睡眠时并没有一条相应的 CPU 样本。[eb-sched-trace][eb-sched-core][eb-stack-helper]

若使用固定 CPU 时间周期，可在内核 map 中按栈累计采样数，再乘该周期生成适合 pprof 的 CPU 权重。频率反馈或可变周期采样应累计各事件实际代表的权重，不能只用栈计数乘一个全局平均周期；cycles 等硬件事件也不能未经模型换算就称为 CPU 纳秒。若选择向 ring buffer 输出带时钟与身份的逐事件记录，经过正确的协议转换可以供时序分析。两条路径保留的信息不同：前者节约数据量，后者能够支持事件配对，但要承担更高传输与恢复成本。本章没有运行特权 BPF 加载；配套 C/libbpf 示例展示切出观察和失败账本，其覆盖范围比完整调度追踪更窄。[eb-ring-doc][eb-perf-abi]

## 3. pprof 只接收它确实拥有的量

生成器写出三条 Sample，唯一数值维度是 cpu/nanoseconds，值为 4,000,000、15,000,000、4,000,000。没有虚构样本次数，也没有写 period=10 ms；因为这三个精确数来自模型，并非 Go 默认 100 Hz 采样。文件级 duration 为 20 ms，三条均有 request=demo 标签。[pp-proto]

主线程的 `main.first_work` 和 `main.finish_work` 都位于 `main.handle_request` 栈下。工作线程的 `worker.work` 位于 `worker.loop` 栈下。工作线程不是主线程当前调用栈的一部分，所以没有人为增加共同的函数根。请求标签连接业务归属，栈仍表达各自执行上下文。

```bash
python3 examples/request/generate_pprof.py --verify
go tool pprof -symbolize=none -top examples/request/request.pprof
```

本次实际客户端是 Go 1.22.12。查询显示 Duration 20 ms、Total samples 23 ms（115%）；worker.work 的 flat 为 15 ms，main.first_work 和 main.finish_work 各 4 ms；main.handle_request 的 cum 为 8 ms。按 request=demo 筛选仍保留全部 23 ms。三次查询成功、八项断言通过，证据位于 verification/request-pprof.json。这里关闭符号化，是因为文件只包含构造的逻辑函数与调用栈，未写入 Location.Address 或 Mapping，也没有对应的真实 ELF。

让 worker 在时间轴上平移而保持相同 CPU 权重，普通 profile 仍可能不变。因此 pprof 不能从这三条权重推回 2 ms runnable、10 ms sleeping 或 20 ms 内的执行顺序。文件级 duration 只提供窗口，不替代逐事件时间。

## 4. Perfetto 从调度事件重建时间区间

另一生成器输出符合 ftrace 文本格式的 sched_switch、sched_waking 和 tracing_mark_write。绝对起点选择 10 秒，正文统一显示相对毫秒。main 在 4 ms 切出时状态为 R，在 6 ms 短暂切入后立即以 S 切出；16 ms 被唤醒并重新运行。应用 B/E 标记定义 request、first_work、join_wait 和 finish_work。输入属于合成调度记录，实际重建使用官方 Perfetto v58.2。[pf-request]

下载脚本会校验官方 release ZIP 的 SHA-256 并核对最终二进制版本。材料包不内嵌大型二进制；具备网络时在材料目录执行：

```bash
python3 scripts/fetch_perfetto.py
python3 examples/request/verify_perfetto.py
```

SQL 先确定请求窗口 $[a,b)$，再把已完成的区间 $[t,t+d)$ 裁剪为 $\max(0,\min(t+d,b)-\max(t,a))$。它避免把请求前后运行算入窗口，但并不自动解决业务归属。配套查询中用 tid 101/102 是受控模型的简化；真实长期追踪应使用生命周期身份与任务阶段。

八项断言全部通过：request=20 ms、join_wait=10 ms；main 的 Running=8 ms、R=2 ms、S=10 ms；sched_slice 中 main CPU=8 ms、worker CPU=15 ms、两者共23 ms。产生的零时长状态不增加总量；dur=-1 的未闭合区间被排除。排除未知区间只避免误算，不能在真实输入中自动保证剩余覆盖完整。[pf-request]

## 5. 两个兼容性对照实验

第一个对照直接把 request.pprof 输入 Perfetto v58.2。实际导入成功，聚合表保留 cpu/nanoseconds 和三项权重；slice 与 sched_slice 行数都为零。这说明它支持聚合格式，并没有从 profile 中恢复事件顺序。源码还表明这条导入路径没有处理每条 Sample 的标签，int64 被转为 double；使用前要评估这些信息是否重要。[pf-pprof][pf-validation]

第二个对照用实际 Go 1.22.12 程序生成原生 execution trace，再直接输入同一 Trace Processor。退出码为 1，报 Unknown trace type provided (ERR:fmt)。Go 1.25 源码的 importer/输出路径阅读与这个运行结果共同支持本章的格式边界；本实验未运行 Go viewer JSON 的完整转换，因此没有把该转换列为已验证能力。[pf-go-header][pf-go-json][pf-validation]

第三章还有一组独立的48条基线 Sample 实验，覆盖内联、递归、条件分母、差分、ASLR位置身份和归一化，共15次实际查询、14项语义断言。它与本章三条权重文件是两套独立教材输入，不能把其480 ms总量混入此处23 ms场景。[pp-teaching]

## 6. 实验完成后应能解释什么

同一个请求可以具有20 ms墙钟、23 ms CPU、主线程12 ms非运行时间。这三个数来自不同的求和集合，没有矛盾。eBPF可以提供部分系统事件或栈样本；pprof解释权重分布；Perfetto解释有证据支撑的状态与时间关系。任何一个工具都不能补回从未采集的请求身份、丢失的栈或被聚合删除的顺序。

复现时应首先检查 verification 中的版本与输入摘要，再看查询和输出。教学文件可以稳定复算；原生 Go trace 的大小和内容会随运行变化。若换用不同版本，先确认接口与表名，再将结果记录为新的验证，不应把本次结果改写成跨版本保证。
