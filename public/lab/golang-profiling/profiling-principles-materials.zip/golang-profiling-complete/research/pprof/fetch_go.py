import concurrent.futures
import hashlib
import json
from pathlib import Path
import urllib.request

root = Path(__file__).parent
names = ['cpuprof.go', 'profbuf.go', 'proc.go', 'signal_unix.go', 'os_linux.go',
         'mprof.go', 'malloc.go', 'sema.go', 'chan.go', 'pprof/pprof.go',
         'pprof/proto.go', 'pprof/protomem.go', 'pprof/label.go', 'pprof/runtime.go',
         'symtab.go', 'netpoll.go']

def fetch(name):
    url = 'https://raw.githubusercontent.com/golang/go/go1.25.0/src/runtime/' + name
    path = root / 'go1.25.0' / 'src/runtime' / name
    try:
        data = urllib.request.urlopen(url, timeout=40).read()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return dict(path=str(path.relative_to(root)), url=url, bytes=len(data),
                    sha256=hashlib.sha256(data).hexdigest(), status='ok')
    except Exception as exc:
        return dict(path=str(path.relative_to(root)), url=url, status='error', error=str(exc))

with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    results = list(pool.map(fetch, names))
(root / 'go-source-manifest.json').write_text(json.dumps(results, indent=2) + '\n')
for row in results:
    print(row['status'], row['path'], row.get('bytes', row.get('error')))
