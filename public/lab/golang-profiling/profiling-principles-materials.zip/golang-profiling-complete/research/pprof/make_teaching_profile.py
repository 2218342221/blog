"""Encode a small, explicitly fictional profile.proto without third-party modules.

The baseline has 48 Sample messages, each representing one nominal 10 ms CPU
sample. Other profiles use six aggregated messages. Nothing here is a measured
Go workload. Location addresses and the build ID are intentionally synthetic.
"""
from pathlib import Path
import gzip
import hashlib
import json

OUT = Path(__file__).parent / 'teaching'
OUT.mkdir(exist_ok=True)

def varint(n):
    n &= (1 << 64) - 1
    out = bytearray()
    while n >= 128:
        out.append((n & 127) | 128)
        n >>= 7
    out.append(n)
    return bytes(out)

def integer(field, n):
    return varint(field << 3) + varint(n)

def blob(field, value):
    if isinstance(value, str):
        value = value.encode()
    return varint((field << 3) | 2) + varint(len(value)) + value

FUNCS = ['Root', 'Handle', 'Parse', 'Encode', 'Hash', 'Walk', 'Batch', 'Alloc', 'HashRound']
# Leaf-to-root location IDs. Location 5 has two inline frames, HashRound then Hash.
GROUPS = [
    dict(name='A/parse', stack=[3, 2, 1], route='A', count=12),
    dict(name='A/hash', stack=[5, 4, 2, 1], route='A', count=8),
    dict(name='A/recurse', stack=[6, 6, 2, 1], route='A', count=6),
    dict(name='B/hash', stack=[5, 7, 1], route='B', count=10),
    dict(name='B/alloc', stack=[8, 7, 1], route='B', count=6),
    dict(name='A/encode', stack=[4, 2, 1], route='A', count=6),
]

def make(name, counts, expand=False, relocated=False):
    strings = ['', 'samples', 'count', 'cpu', 'nanoseconds', 'route', 'A', 'B',
               'input_bytes', 'bytes', 'teaching.bin', 'teaching-build-A',
               '/teaching/demo.go', *FUNCS,
               'FICTIONAL TEACHING DATA: no executable, no original time order']
    si = {s: i for i, s in enumerate(strings)}
    value_type = lambda typ, unit: integer(1, si[typ]) + integer(2, si[unit])
    profile = blob(1, value_type('samples', 'count')) + blob(1, value_type('cpu', 'nanoseconds'))
    id_shift, address_shift = (100, 0x1000) if relocated else (0, 0)
    mapping_id = 2 if relocated else 1
    rows = []
    for group, count in zip(GROUPS, counts):
        weights = [1] * count if expand else [count]
        for weight in weights:
            locations = [v + id_shift for v in group['stack']]
            sample = blob(1, b''.join(varint(v) for v in locations))
            sample += blob(2, varint(weight) + varint(weight * 10_000_000))
            sample += blob(3, integer(1, si['route']) + integer(2, si[group['route']]))
            sample += blob(3, integer(1, si['input_bytes']) + integer(3, 64 if group['route']=='A' else 256) + integer(4, si['bytes']))
            profile += blob(2, sample)
            rows.append(dict(stack=locations, route=group['route'], value=[weight, weight*10_000_000]))
    mapping = integer(1, mapping_id) + integer(2, 0x1000 + address_shift) + integer(3, 0x2000 + address_shift)
    mapping += integer(5, si['teaching.bin']) + integer(6, si['teaching-build-A'])
    for field in (7, 8, 9, 10):
        mapping += integer(field, 1)
    profile += blob(3, mapping)
    for loc_id in range(1, 9):
        loc = integer(1, loc_id+id_shift) + integer(2, mapping_id) + integer(3, 0x1000+16*loc_id+address_shift)
        function_ids = [9, 5] if loc_id == 5 else [loc_id]
        for function_id in function_ids:
            loc += blob(4, integer(1, function_id+id_shift) + integer(2, function_id*10+1))
        profile += blob(4, loc)
    for idx, fn in enumerate(FUNCS, 1):
        profile += blob(5, integer(1, idx+id_shift) + integer(2, si[fn]) + integer(3, si[fn]) + integer(4, si['/teaching/demo.go']) + integer(5, idx*10))
    for s in strings:
        profile += blob(6, s)
    profile += integer(9, 1_720_000_000_000_000_000) + integer(10, 400_000_000)
    profile += blob(11, value_type('cpu', 'nanoseconds')) + integer(12, 10_000_000)
    profile += integer(13, si[strings[-1]]) + integer(14, si['cpu'])
    data = gzip.compress(profile, mtime=0)
    path = OUT / (name + '.pprof')
    path.write_bytes(data)
    return dict(name=name, file=path.name, sample_messages=len(rows), represented_samples=sum(counts),
                cpu_ns=sum(counts)*10_000_000, duration_ns=400_000_000, groups=[dict(g, count=c) for g,c in zip(GROUPS,counts)],
                sha256=hashlib.sha256(data).hexdigest(), rows=rows)

base = [g['count'] for g in GROUPS]
profiles = [make('baseline', base, expand=True), make('changed', [8,4,4,14,10,8]),
            make('double-volume', [n*2 for n in base]), make('relocated', base, relocated=True)]
(OUT/'manifest.json').write_text(json.dumps(dict(note=__doc__, profiles=profiles),indent=2)+'\n')
for p in profiles:
    print(p['name'], 'messages=',p['sample_messages'],'represented_samples=',p['represented_samples'],'cpu_ms=',p['cpu_ns']/1e6)
