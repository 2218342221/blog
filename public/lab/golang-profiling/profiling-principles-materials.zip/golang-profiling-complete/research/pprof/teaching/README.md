# 可手算的 pprof 教学文件

这些 profile 是显式构造的教学数据。地址、Build ID、源码路径和采集时刻均为虚构，不存在对应的可执行文件。实际验证客户端为 `go version go1.22.12 linux/amd64`；教材解释的 Go producer 源码基线是 Go 1.25.0，两者不同。

从任务根目录重放：

```sh
python3 research/pprof/make_teaching_profile.py
python3 research/pprof/verify_teaching.py
```

生成器只使用 Python 标准库编码 protobuf 和 gzip。验证器真正调用本机 `go tool pprof`，将每次查询的标准输出和标准错误保存在此目录。使用 `-symbolize=none`，验证范围是格式、聚合与报告；没有验证 ELF 符号化、运行时信号采样、heap 收敛或生产开销。

| 文件 | Sample 消息 | 代表的名义事件 | CPU 权重 | 用途 |
| --- | ---: | ---: | ---: | --- |
| baseline.pprof | 48 | 48 | 480 ms | 分支、递归、内联和标签 |
| changed.pprof | 6 | 48 | 480 ms | 正负变化和函数级抵消 |
| double-volume.pprof | 6 | 96 | 960 ms | 当前 profile 归一化 |
| relocated.pprof | 6 | 48 | 480 ms | 局部 ID 和相对地址归一 |

四份文件共 66 条 protobuf Sample 消息。`manifest.json` 记录所有行、分组和 SHA-256。`verification.json` 记录 15 条实际命令和 14 项通过的语义断言。

关键证据：

- `baseline-top.txt`、`baseline-cum.txt`：HashRound flat=180 ms；Walk cum=60 ms，没有按递归深度翻倍。
- `no-inlines.txt`：关闭内联后，180 ms flat 归到 Hash。
- `route-a.txt`、`route-a-relative.txt`：同一个 80 ms 分别除以 480 ms 和 320 ms，得到 16.67% 与 25%。
- `focus-handle.txt`、`hide-handle.txt`：样本筛选与隐藏帧具有不同保留集合。
- `base.txt`、`diff.txt`：一般差分使用 200 ms 绝对变化总量；diff_base 使用 480 ms 基线总量，负值保留。
- `normalize.txt`：当前权重全部翻倍后归一化，函数净差为零，基线分母仍为 480 ms。
- `merge-relocated.txt`：等价重定位输入合并后总量为 960 ms，各函数权重翻倍。
- `raw.txt`、`traces.txt`、`callgraph.txt`：原始值向量、完整路径和真实 pprof DOT 输出。

400 ms duration 与 480 ms CPU 权重也是人为设置，用来解释多核容量尺度。Sample 的排列没有事件时间线含义。数值相符只能证明所列转换规则在这批输入和这个客户端上成立。
