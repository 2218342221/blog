from pathlib import Path
import hashlib,json
root=Path(__file__).parent
GO='6e676ab2b809d46623acb5988248d95d1eb7939c'
PP='ebaad5f31b4d25e6f51abf4d91b9611cff92db7b'
sources=[]
def add(id,title,repo,path,ranges,claims,limitations):
    prefix,sha=('go1.25.0',GO) if repo=='golang/go' else ('google-pprof',PP)
    local=root/prefix/path
    sources.append(dict(id='pp-'+id,title=title,url=f'https://github.com/{repo}/blob/{sha}/{path}',
        pinned_version=('Go 1.25.0; commit '+sha) if repo=='golang/go' else 'google/pprof commit '+sha,
        read_ranges=[dict(path=path,start=a,end=b) for a,b in ranges],key_claims=claims,limitations=limitations,
        local_cache=str(local.relative_to(root.parent.parent)),sha256=hashlib.sha256(local.read_bytes()).hexdigest(),accessed='2026-10-04'))
add('scope','pprof 项目定位','google/pprof','README.md',[(5,24)],['pprof读取profiling samples并生成文本和图形报告','数据生产者与分析器是不同职责'],['此项目自述明确不是Google官方产品；不把仓库所有者当作产品支持承诺'])
add('proto','profile.proto 数据契约','google/pprof','proto/profile.proto',[(20,37),(46,233)],['sample_type与value位置一一对应','location_id叶在前；Location.Line描述内联链','Sample聚合按value逐分量求和；period与duration不是每个Sample的时间戳'],['格式只能描述字段，具体采样与估计语义仍由producer决定'])
add('cpu-api','Go CPU采集生命周期','golang/go','src/runtime/pprof/pprof.go',[(806,894)],['StartCPUProfile使用固定100Hz','单个活动CPU profile；StopCPUProfile等待写出完成'],['针对Go1.25标准库API，不推广到其他语言或第三方producer'])
add('cpu-runtime','Go CPU信号入口与额外样本','golang/go','src/runtime/cpuprof.go',[(5,195),(226,258)],['信号处理器写入有界日志；异步reader读取','常规栈上限64；溢出和外部栈丢样使用特殊记录'],['丢样计数不等于完整观测误差；无法恢复丢失的原栈'])
add('cpu-linux','Linux线程CPU时钟与去重','golang/go','src/runtime/os_linux.go',[(574,696)],['每M线程CPU计时器使用CLOCK_THREAD_CPUTIME_ID和SIGEV_THREAD_ID','初始延迟随机化；失败回退进程级机制','validSIGPROF避免线程/进程定时器重复记账'],['Linux实现细节；不宣称Windows/macOS采用相同信号机制'])
add('sigprof','异步栈展开与标签读取','golang/go','src/runtime/proc.go',[(5574,5693)],['sigprof不能分配，使用有界栈和unwinder','cgo、VDSO、展开失败存在特定路径；采集当前G标签'],['未知或抽象帧不自动定位到某个业务函数'])
add('buffer','CPU日志双环缓冲与溢出','golang/go','src/runtime/profbuf.go',[(12,86),(303,328),(429,475)],['一个reader与一个writer的无锁环缓冲','栈/头与tags分别存储；溢出保留数量而丢失调用栈','序列位避免overflow清理中的ABA'],['writer在CPU入口还需序列化；不是所有runtime路径完全无锁'])
add('cpu-builder','原始CPU记录到聚合值向量','golang/go','src/runtime/pprof/proto.go',[(274,393),(397,483),(585,645)],['原始记录时间戳被忽略，按栈与tag聚合','值向量为count和count乘period','Location一次编码多条内联Line'],['不能据最终profile恢复事件顺序'])
add('heap-poisson','堆采样的指数步长','golang/go','src/runtime/malloc.go',[(1824,1884)],['nextSample使用均值MemProfileRate的指数随机步长','rate=1立即采样、0实质禁用','有限随机精度与整数边界属于实现'],['数学推导采用理想Poisson模型；未测生产采样偏差'])
add('heap-coverage','堆分配块、tiny allocator与内存槽覆盖','golang/go','src/runtime/malloc.go',[(1124,1144),(1171,1179),(1229,1243)],['tiny allocator将多个语言级小对象组合为一个块','采样按整个分配槽的elemsize扣减并传递给profilealloc'],['heap采集不等同所有语言级对象；不含栈上对象清单'])
add('profile-kinds','Go profile种类与归因契约','golang/go','src/runtime/pprof/pprof.go',[(122,171),(594,626)],['heap与allocs共享记录而使用不同默认维度','block按阻塞栈归因；mutex按临界区释放栈归因','多个并行等待者的竞争量可以超过墙钟时长'],['文档层面的统计契约；具体边界需结合runtime实现'])
add('heap-scale','堆样本逆概率外推','golang/go','src/runtime/pprof/protomem.go',[(15,66),(69,93)],['四维值向量分别校正累计和存活对象数/字节','包含概率1-exp(-S/R)','scaleHeapSample用平均分配大小并转为int64'],['不是精确逐对象清单；聚合和校正顺序不能任意交换'])
add('mprof','堆与同步统计桶和发布周期','golang/go','src/runtime/mprof.go',[(275,327),(364,479),(483,524),(795,880),(918,931)],['分配释放分期发布，最多可落后两个GC周期','block按持续时间抽样；mutex按竞争事件抽样','计数与时间分别进行逆概率校正'],['累计快照差分不自动按观测窗口裁剪事件'])
add('sema','同步等待记录点与mutex近似收费','golang/go','src/runtime/sema.go',[(127,199),(228,275)],['block在等待完成后发布，readyWithTime保存唤醒时刻','mutex在释放路径近似累计其他等待者成本','头尾等待均值乘等待者数避免O(N)扫描'],['同步等待估计不是每锁每请求精确积分；需考虑再次睡眠和窗口边界'])
add('goroutine','协作式goroutine快照','golang/go','src/runtime/mprof.go',[(1254,1409),(1412,1508)],['短STW确立集合后协作采栈，结束再短STW清理','Absent/InProgress/Satisfied状态防止采栈时运行','并非整个遍历期间持续STW'],['不是所有系统G清单，也不是运行时间或请求身份表'])
add('labels','Go标签安装和继承','golang/go','src/runtime/pprof/runtime.go',[(32,51)],['Do设置增强context标签，退出时恢复传入context标签','新G继承创建者标签；WithLabels本身不安装'],['现存worker需要在执行点安装标签'])
add('label-support','Go标签支持范围','golang/go','src/runtime/pprof/label.go',[(44,59),(96,127)],['Go1.25 CPU和goroutine profiles使用labels','标准库标签是字符串键值'],['其他producer支持数字或其他标签不等于Go所有profile都支持'])
add('pc','return PC与内联帧恢复','golang/go','src/runtime/symtab.go',[(95,167)],['CallersFrames区分返回地址与所关心指令，必要时减一','内联展开不等于存在多个物理栈帧'],['不应对已归一化的Location.Address再次无条件减一'])
add('symbolizer','pprof本地符号化与Build ID核验','google/pprof','internal/symbolizer/symbolizer.go',[(129,244)],['按mapping归组，已符号化通常跳过','读取实际二进制；双方BuildID存在且不符则拒绝该符号化','SourceLine生成Function和Line'],['缺失二进制或符号时不能保证完整源码行或原生栈'])
add('binutils','进程地址到对象文件地址','google/pprof','internal/binutils/binutils.go',[(609,677)],['结合ELF程序头和mapping计算base','ObjAddr=process address-base','nm快速映射不提供完整文件行号'],['不能把任意ELF映射简单等同pc减mapping.start'])
add('merge','pprof合并、局部ID与归一化','google/pprof','profile/merge.go',[(44,122),(155,245),(284,414),(426,465),(468,544)],['重映射局部ID，再按栈与标签合并value','mapping键含大小/偏移/BuildID或文件，Location规范化处理ASLR','Normalize缩放当前源profile到基线每一维总量','Duration合并为求和而非区间并集'],['类型兼容检查不证明负载、版本和统计总体可比'])
add('filter','样本筛选与帧隐藏','google/pprof','profile/filter.go',[(20,78),(229,274)],['focus/ignore决定整条样本保留','hide/show修改帧集合，隐藏完所有帧会丢弃样本','tagfocus基于样本标签'],['不能从隐藏后的图推断原始直接调用关系'])
add('scale','粒度聚合与整数量化','google/pprof','profile/profile.go',[(364,430),(445,489),(793,824)],['CheckValid核查值维度和引用','Aggregate删除未保留的地址、行号或内联层','ScaleN使用math.Round后转换为int64'],['按更粗粒度聚合后不能逆向恢复原始记录'])
add('diff','差分的操作顺序','google/pprof','internal/driver/fetch.go',[(58,89)],['diff_base向基线样本加入pprof::base标签','可选Normalize作用于当前profile，再基线乘-1并合并'],['普通差分保留正负变化；不是自动按请求量归一化'])
add('denominator','报告分母与过滤顺序','google/pprof','internal/driver/driver.go',[(74,107)],['默认先创建report保存总量再过滤；relative模式先过滤','报告配置与可见样本集合可有不同分母'],['相同函数权重在两种分母下百分比不同，不意味着成本变化'])
add('total','差分总量的绝对值与基线规则','google/pprof','internal/report/report.go',[(1279,1288),(1307,1335)],['通常sum(abs(sample value))','存在正的diff-base总量时用基线样本的绝对总量'],['不能把net zero报告解读为无变化'])
add('percent','百分比使用幅度','google/pprof','internal/measurement/measurement.go',[(165,179)],['Percentage计算绝对比例'],['差分的方向看带符号值，不能仅看flat%'])
add('graph','flat/cum和调用图累积规则','google/pprof','internal/graph/graph.go',[(330,391),(416,459),(657,690)],['逐样本根到叶遍历，seenNode/seenEdge避免重复累计','flat加入叶子；不输出自身到自身的普通图边','残余边可跨过未显示节点'],['边权不是调用次数；普通调用图不完整保存路径或递归深度'])
add('flame','火焰图栈数据与递归索引','google/pprof','internal/report/stacks.go',[(27,74),(82,103),(159,195)],['栈Value承载所选维度，Sources按根到叶排列','Sources.Places对同栈重复函数只登记最外层用于聚焦'],['无逐事件时间信息，横向布局不是时间轴'])
sources.append(dict(id='pp-teaching',title='48条教学CPU样本的实际查询验证',url='research/pprof/teaching/verification.json',
 pinned_version='go version go1.22.12 linux/amd64; synthetic fixture v1',read_ranges=[{'path':'research/pprof/teaching/verification.json','scope':'all cases and checks'}],
 key_claims=['15个真实go tool pprof查询成功','14项归因、过滤、递归、内联、合并和差分断言通过','基线48条Sample，其他3个变体各6条，合计66条protobuf Sample消息'],
 limitations=['样本是教学构造；没有运行真实producer或模拟随机采样','未编译执行所读最新pprof提交；实际客户端是Go1.22.12内置版本','关闭符号化并使用虚构地址，不能据此宣称实际ELF符号化已验证']))
(root.parent/'sources-pprof.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n')
(root/'go-pin.json').write_text(json.dumps({'tag':'go1.25.0','sha':GO,'resolved_by':'git ls-remote refs/tags/go1.25.0','retrieved':'2026-10-04'},indent=2)+'\n')
print(len(sources),'sources')
