from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import re
import subprocess

out=Path(__file__).parent/'teaching'
common=['go','tool','pprof','-symbolize=none','-nodecount=0','-nodefraction=0','-edgefraction=0']
cases={
 'baseline-top':['-top','baseline.pprof'],
 'baseline-cum':['-top','-cum','baseline.pprof'],
 'sample-count':['-top','-sample_index=samples','baseline.pprof'],
 'route-a':['-top','-tagfocus=route=A','baseline.pprof'],
 'route-a-relative':['-top','-tagfocus=route=A','-relative_percentages=true','baseline.pprof'],
 'focus-handle':['-top','-focus=Handle','baseline.pprof'],
 'hide-handle':['-top','-hide=Handle','baseline.pprof'],
 'no-inlines':['-top','-noinlines','baseline.pprof'],
 'diff':['-top','-diff_base=baseline.pprof','changed.pprof'],
 'base':['-top','-base=baseline.pprof','changed.pprof'],
 'normalize':['-top','-normalize','-diff_base=baseline.pprof','double-volume.pprof'],
 'merge-relocated':['-top','baseline.pprof','relocated.pprof'],
 'traces':['-traces','baseline.pprof'],
 'raw':['-raw','baseline.pprof'],
 'callgraph':['-dot','baseline.pprof'],
}
def run(item):
 name,args=item;cmd=common+args
 p=subprocess.run(cmd,cwd=out,capture_output=True,text=True,timeout=40)
 (out/(name+'.txt')).write_text(p.stdout)
 (out/(name+'.stderr.txt')).write_text(p.stderr)
 return {'case':name,'argv':cmd,'returncode':p.returncode}
with ThreadPoolExecutor(max_workers=5) as pool: results=list(pool.map(run,cases.items()))
version=subprocess.check_output(['go','version'],text=True).strip()
def has(name,pattern):
 return bool(re.search(pattern,(out/(name+'.txt')).read_text(),re.M))
checks={
 '48_count_equals_480ms_at_10ms':has('baseline-top',r'Total samples = 480ms') and has('sample-count',r'Total samples = 48'),
 'wall_400ms_cpu_480ms':has('baseline-top',r'Duration: 400ms.*120.00%'),
 'recursive_walk_cum_not_doubled':has('baseline-top',r'^\s+60ms\s+12.50%\s+[^\n]+\s+60ms\s+12.50%\s+Walk$'),
 'inline_leaf_attribution':has('baseline-top',r'^\s+180ms.*HashRound \(inline\)$'),
 'noinlines_attributes_to_hash':has('no-inlines',r'^\s+180ms.*Hash$'),
 'route_global_denominator':has('route-a',r'^\s+80ms\s+16.67%.*HashRound'),
 'route_relative_denominator':has('route-a-relative',r'^\s+80ms\s+25.00%.*HashRound'),
 'hide_retains_other_branch':has('hide-handle',r'^\s+0.*160ms.*Batch$'),
 'focus_removes_other_branch':not has('focus-handle',r'\sBatch$'),
 'diff_keeps_negative':has('diff',r'^\s+-40ms.*Parse$'),
 'normalization_removes_pure_volume':has('normalize',r'Showing nodes accounting for 0, 0% of 480ms total') and not has('normalize',r'^\s+[0-9-].*\s(Root|Handle|Parse|Encode|Walk|Alloc|Hash|HashRound)$'),
 'base_general_difference_denominator_200ms':has('base',r'Total samples = 200ms'),
 'diff_baseline_denominator_480ms':has('diff',r'Total samples = 480ms'),
 'relocation_merge_doubles_weight':has('merge-relocated',r'Total samples = 960ms'),
}
summary={'client':version,'data_kind':'synthetic, not measured CPU samples','cases':results,'checks':checks,
         'all_passed':all(r['returncode']==0 for r in results) and all(checks.values())}
(out/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
