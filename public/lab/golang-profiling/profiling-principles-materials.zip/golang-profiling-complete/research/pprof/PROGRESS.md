# pprof research progress

Current task only: 2026-10-04-3. Do not read previous task directories.

- Complete: `research/pprof.md`, 8 sections, 9,263 Chinese characters (18,173 total characters).
- Go source baseline: `go1.25.0`, commit `6e676ab2b809d46623acb5988248d95d1eb7939c`; all 16 selected files fetched and relevant ranges read.
- google/pprof pinned source: `ebaad5f31b4d25e6f51abf4d91b9611cff92db7b`, resolved through `git ls-remote`; source archive fetched successfully. The earlier GitHub API 403 was handled through the public Git/codeload path.
- `research/sources-pprof.json`: 30 source entries; commit URLs, read ranges, claims, limitations, and cached-source SHA-256 values. Every source ID is cited and every citation resolves.
- `research/pprof/figures.json`: 7 detailed diagram specifications, including nodes, edges, values, layout, teaching steps, caption, source IDs, and limitations.
- Actual validation client: installed `go version go1.22.12 linux/amd64`. The chapter distinguishes Go 1.25 producer semantics from this client. No second toolchain was downloaded; the pinned google/pprof source was not compiled.
- `make_teaching_profile.py`: baseline has 48 Sample messages; each of 3 variants has 6, for 66 total. Synthetic addresses, labels, function lines, and time are explicitly identified. No third-party Python modules.
- `verify_teaching.py`: 15 actual `go tool pprof` queries returned success; 14 semantic assertions passed. Original stdout/stderr, complete commands, manifest, file hashes, and version are retained in `teaching/`.
- Verified: recursive cum deduplication, inline attribution, route filter denominators, focus vs hide, signed differences, base=200 ms vs diff_base=480 ms, normalization of doubled volume, relocation merge, and raw/DOT parsing.
- `final-audit.json`: all content/source/figure/fixture consistency checks pass. One source range originally extended two lines beyond filter.go and has been corrected to the actual final line 274.
- Independent read-only subagent audit found no blocking technical or numeric errors; two wording fixes (tag key precision and simplified Chinese typo) have been applied.
- `teaching/README.md` documents reproduction and distinguishes synthetic inputs from real client queries.
- No pending shell sessions. No real CPU signal-pressure, heap convergence, or production workload experiment was run. No deployment or publication performed.
