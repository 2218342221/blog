package model
type Fingerprint uint64
const MetricNameLabel = "__name__"
