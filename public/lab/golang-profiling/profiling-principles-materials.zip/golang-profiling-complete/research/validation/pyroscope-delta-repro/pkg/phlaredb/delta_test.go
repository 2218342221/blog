package phlaredb
import (
    "fmt"
    "reflect"
    "testing"
    "github.com/prometheus/common/model"
    phlaremodel "github.com/grafana/pyroscope/pkg/model"
    schemav1 "github.com/grafana/pyroscope/pkg/phlaredb/schemas/v1"
)
func mk(a,b uint64) schemav1.InMemoryProfile {
    return schemav1.InMemoryProfile{SeriesFingerprint:model.Fingerprint(7),Samples:schemav1.Samples{StacktraceIDs:[]uint32{1,2},Values:[]uint64{a,b}}}
}
func TestFixedSourceResetOrdering(t *testing.T) {
    if !isDeltaSupported(phlaremodel.Labels{"__name__":"memory","__type__":"alloc_space"}) { t.Fatal("expected supported type") }
    cases:=[]struct{name string; sequence [][2]uint64; want []uint64; finalBaseline []uint64}{
        {"monotonic",[][2]uint64{{100,100},{160,120},{180,130}},[]uint64{20,10},nil},
        {"reset_first_sorted_stack",[][2]uint64{{100,100},{20,160},{30,180}},[]uint64{10,20},[]uint64{20,160}},
        {"reset_second_sorted_stack",[][2]uint64{{100,100},{160,20},{180,30}},[]uint64{120,10},[]uint64{60,20}},
    }
    for _,tc:=range cases {t.Run(tc.name,func(t *testing.T){
        d:=newDeltaProfiles()
        for i,v:=range tc.sequence {
            p:=mk(v[0],v[1]);out:=d.computeDelta(p)
            base:=[]uint64{d.highestSamples[7][1],d.highestSamples[7][2]}
            fmt.Printf("case=%s step=%d input=%v mutated=%v output=%v baseline=%v\n",tc.name,i+1,v,p.Samples.Values,out.Values,base)
            if i==1 && tc.finalBaseline!=nil && !reflect.DeepEqual(base,tc.finalBaseline) {t.Fatalf("unexpected reset baseline: %v",base)}
            if i==2 && !reflect.DeepEqual(out.Values,tc.want) {t.Fatalf("unexpected final output: got %v want %v",out.Values,tc.want)}
        }
    })}
}
