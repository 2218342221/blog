package v1
import ("sort"; "github.com/prometheus/common/model")
type InMemoryProfile struct { SeriesFingerprint model.Fingerprint; Samples Samples }
type Samples struct {
	StacktraceIDs []uint32
	Values        []uint64
	// Span associated with samples.
	// Optional: Spans == nil, if not present.
	Spans []uint64
}

func NewSamples(size int) Samples {
	return Samples{
		StacktraceIDs: make([]uint32, size),
		Values:        make([]uint64, size),
	}
}

func NewSamplesFromMap(m map[uint32]uint64) Samples {
	s := Samples{
		StacktraceIDs: make([]uint32, len(m)),
		Values:        make([]uint64, len(m)),
	}
	var i int
	for k, v := range m {
		if k != 0 && v > 0 {
			s.StacktraceIDs[i] = k
			s.Values[i] = v
			i++
		}
	}
	s.StacktraceIDs = s.StacktraceIDs[:i]
	s.Values = s.Values[:i]
	sort.Sort(s)
	return s
}

// Compact zero samples and optionally duplicates.
func (s Samples) Compact(dedupe bool) Samples {
	if len(s.StacktraceIDs) == 0 {
		return s
	}
	if dedupe {
		s = trimDuplicateSamples(s)
	}
	return trimZeroAndNegativeSamples(s)
}

func (s Samples) Clone() Samples {
	return cloneSamples(s)
}

func (s Samples) Range(n, m int) Samples {
	if n < 0 || n > m || m > s.Len() {
		return Samples{}
	}
	x := Samples{
		StacktraceIDs: s.StacktraceIDs[n:m],
		Values:        s.Values[n:m],
	}
	if len(s.Spans) > 0 {
		x.Spans = s.Spans[n:m]
	}
	return x
}

func trimDuplicateSamples(samples Samples) Samples {
	sort.Sort(samples)
	n := 0
	for j := 1; j < len(samples.StacktraceIDs); j++ {
		if samples.StacktraceIDs[n] == samples.StacktraceIDs[j] {
			samples.Values[n] += samples.Values[j]
		} else {
			n++
			samples.StacktraceIDs[n] = samples.StacktraceIDs[j]
			samples.Values[n] = samples.Values[j]
		}
	}
	return Samples{
		StacktraceIDs: samples.StacktraceIDs[:n+1],
		Values:        samples.Values[:n+1],
	}
}

func trimZeroAndNegativeSamples(samples Samples) Samples {
	n := 0
	for j, v := range samples.Values {
		if v > 0 {
			samples.Values[n] = v
			samples.StacktraceIDs[n] = samples.StacktraceIDs[j]
			if len(samples.Spans) > 0 {
				samples.Spans[n] = samples.Spans[j]
			}
			n++
		}
	}
	s := Samples{
		StacktraceIDs: samples.StacktraceIDs[:n],
		Values:        samples.Values[:n],
	}
	if len(samples.Spans) > 0 {
		s.Spans = samples.Spans[:n]
	}
	return s
}

func cloneSamples(samples Samples) Samples {
	return Samples{
		StacktraceIDs: copySlice(samples.StacktraceIDs),
		Values:        copySlice(samples.Values),
		Spans:         copySlice(samples.Spans),
	}
}

func (s Samples) Less(i, j int) bool {
	return s.StacktraceIDs[i] < s.StacktraceIDs[j]
}

func (s Samples) Swap(i, j int) {
	s.StacktraceIDs[i], s.StacktraceIDs[j] = s.StacktraceIDs[j], s.StacktraceIDs[i]
	s.Values[i], s.Values[j] = s.Values[j], s.Values[i]
	if len(s.Spans) > 0 {
		s.Spans[i], s.Spans[j] = s.Spans[j], s.Spans[i]
	}
}

func (s Samples) Len() int {
	return len(s.StacktraceIDs)
}

func copySlice[T any](s []T) []T { if s == nil { return nil }; d:=make([]T,len(s));copy(d,s);return d }
