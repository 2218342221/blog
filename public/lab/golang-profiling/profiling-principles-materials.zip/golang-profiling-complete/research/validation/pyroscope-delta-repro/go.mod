module github.com/grafana/pyroscope

go 1.22

require github.com/prometheus/common v0.0.0
replace github.com/prometheus/common => ./stubs/promcommon
