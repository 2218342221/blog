package model
type Labels map[string]string
func (l Labels) Get(k string) string { return l[k] }
const LabelNameType = "__type__"
