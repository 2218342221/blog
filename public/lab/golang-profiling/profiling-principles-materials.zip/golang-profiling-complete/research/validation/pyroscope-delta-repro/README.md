# Pyroscope v1.14.0 delta reset isolated reproduction

Run: `go test -count=1 -v ./pkg/phlaredb` in this directory. No network dependencies are required.

The complete upstream `pkg/phlaredb/delta.go` is copied byte for byte from the v1.14.0 source archive. `provenance.json` contains its SHA256. Samples and methods in upstream `profiles.go:364–489` are copied verbatim. Minimal surrounding stubs provide fingerprint, labels and the fields of InMemoryProfile used by these functions; copySlice is an equivalent local helper. This is not the upstream full build, full test suite or server ingestion experiment.

The input contains one supported memory/alloc_space series (same fingerprint), two stable stack IDs in ascending order, and consecutive profiles. `dedup_slice.go:107–154` allows multiple stack samples in one sample type and sorts them; `head.go:221–235` calls computeDelta once for that type and drops empty results. `profiles.go:336–339` states that a fingerprint is based on labels and stable for the same label set. A restarted process under unchanged labels, or out-of-order snapshots, can have mixed per-stack increases/decreases. The reproduction asserts only the fixed function behavior under that explicit input, not production prevalence.

Three controls are present: monotonic counters produce correct deltas; a reset at the first sorted stack preserves the raw new baseline; a reset at the second stack occurs after the first value is already mutated. The third sequence `[100,100] → [160,20] → [180,30]` emits `[] → [] → [120,10]`, while a reset baseline built from the unmodified second input would yield `[20,10]` on the final step. The test PASS means the observed fixed-version behavior matched these explicit expectations, not that the behavior is desirable.

No upstream fix was made. Possible repairs require separate validation: pre-scan for any reset before subtracting, or retain raw incoming values for resetting the baseline. This finding is not a claim about later Pyroscope releases.
