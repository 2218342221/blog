/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "src/trace_processor/importers/proto/proto_trace_reader.h"

#include <algorithm>
#include <cinttypes>
#include <cstddef>
#include <cstdint>
#include <map>
#include <memory>
#include <numeric>
#include <optional>
#include <string>
#include <string_view>
#include <tuple>
#include <utility>
#include <vector>

#include "perfetto/base/logging.h"
#include "perfetto/base/status.h"
#include "perfetto/ext/base/flat_hash_map.h"
#include "perfetto/ext/base/status_macros.h"
#include "perfetto/ext/base/status_or.h"
#include "perfetto/ext/base/string_utils.h"
#include "perfetto/protozero/field.h"
#include "perfetto/protozero/proto_decoder.h"
#include "perfetto/public/compiler.h"
#include "perfetto/trace_processor/basic_types.h"
#include "src/trace_processor/importers/common/args_tracker.h"
#include "src/trace_processor/importers/common/builtin_trace_importers.h"
#include "src/trace_processor/importers/common/clock_tracker.h"
#include "src/trace_processor/importers/common/event_tracker.h"
#include "src/trace_processor/importers/common/import_logs_tracker.h"
#include "src/trace_processor/importers/common/machine_tracker.h"
#include "src/trace_processor/importers/common/metadata_tracker.h"
#include "src/trace_processor/importers/common/parser_types.h"
#include "src/trace_processor/importers/common/process_tracker.h"
#include "src/trace_processor/importers/common/stats_tracker.h"
#include "src/trace_processor/importers/proto/default_modules.h"
#include "src/trace_processor/importers/proto/packet_analyzer.h"
#include "src/trace_processor/importers/proto/proto_importer_module.h"
#include "src/trace_processor/importers/proto/proto_trace_parser_impl.h"
#include "src/trace_processor/sorter/trace_sorter.h"
#include "src/trace_processor/storage/metadata.h"
#include "src/trace_processor/storage/stats.h"
#include "src/trace_processor/storage/trace_storage.h"
#include "src/trace_processor/tables/metadata_tables_py.h"
#include "src/trace_processor/types/trace_processor_context.h"
#include "src/trace_processor/types/variadic.h"
#include "src/trace_processor/util/decompressor.h"
#include "src/trace_processor/util/descriptors.h"
#include "src/trace_processor/util/trace_type.h"

#include "perfetto/protozero/proto_utils.h"
#include "protos/perfetto/common/builtin_clock.pbzero.h"
#include "protos/perfetto/common/trace_attributes.pbzero.h"
#include "protos/perfetto/common/trace_stats.pbzero.h"
#include "protos/perfetto/config/trace_config.pbzero.h"
#include "protos/perfetto/trace/clock_snapshot.pbzero.h"
#include "protos/perfetto/trace/extension_descriptor.pbzero.h"
#include "protos/perfetto/trace/perfetto/tracing_service_event.pbzero.h"
#include "protos/perfetto/trace/remote_clock_sync.pbzero.h"
#include "protos/perfetto/trace/trace.pbzero.h"
#include "protos/perfetto/trace/trace_packet.pbzero.h"

namespace perfetto::trace_processor {
namespace {

using ClockId = ClockTracker::ClockId;

class TracePacketSink
    : public TraceSorter::Sink<TracePacketData, TracePacketSink> {
 public:
  explicit TracePacketSink(ProtoTraceParserImpl* parser) : parser_(parser) {}
  void Parse(int64_t ts, TracePacketData data) {
    parser_->ParseTracePacket(ts, std::move(data));
  }

 private:
  ProtoTraceParserImpl* parser_;
};
class TrackEventSink
    : public TraceSorter::Sink<TrackEventData, TrackEventSink> {
 public:
  explicit TrackEventSink(ProtoTraceParserImpl* parser) : parser_(parser) {}
  void Parse(int64_t ts, TrackEventData data) {
    parser_->ParseTrackEvent(ts, std::move(data));
  }

 private:
  ProtoTraceParserImpl* parser_;
};
class FtraceEventSink : public TraceSorter::Sink<FtraceData, FtraceEventSink> {
 public:
  FtraceEventSink(ProtoTraceParserImpl* parser, uint32_t cpu)
      : parser_(parser), cpu_(cpu) {}
  void Parse(int64_t ts, FtraceData data) {
    parser_->ParseFtraceEvent(cpu_, ts, std::move(data));
  }

 private:
  ProtoTraceParserImpl* parser_;
  uint32_t cpu_;
};
class EtwEventSink : public TraceSorter::Sink<TracePacketData, EtwEventSink> {
 public:
  EtwEventSink(ProtoTraceParserImpl* parser, uint32_t cpu)
      : parser_(parser), cpu_(cpu) {}
  void Parse(int64_t ts, TracePacketData data) {
    parser_->ParseEtwEvent(cpu_, ts, std::move(data));
  }

 private:
  ProtoTraceParserImpl* parser_;
  uint32_t cpu_;
};
class InlineSchedSwitchSink
    : public TraceSorter::Sink<InlineSchedSwitch, InlineSchedSwitchSink> {
 public:
  explicit InlineSchedSwitchSink(ProtoTraceParserImpl* impl, uint32_t cpu)
      : impl_(impl), cpu_(cpu) {}
  void Parse(int64_t ts, InlineSchedSwitch data) {
    impl_->ParseInlineSchedSwitch(cpu_, ts, data);
  }

 private:
  ProtoTraceParserImpl* impl_;
  uint32_t cpu_;
};
class InlineSchedWakingSink
    : public TraceSorter::Sink<InlineSchedWaking, InlineSchedWakingSink> {
 public:
  explicit InlineSchedWakingSink(ProtoTraceParserImpl* impl, uint32_t cpu)
      : impl_(impl), cpu_(cpu) {}
  void Parse(int64_t ts, InlineSchedWaking data) {
    impl_->ParseInlineSchedWaking(cpu_, ts, data);
  }

 private:
  ProtoTraceParserImpl* impl_;
  uint32_t cpu_;
};

// Parses the major version number from a Perfetto tracing service version
// string of the form "Perfetto vNN.M-..." or "Perfetto vNN.M (...)".
// Returns nullopt if the string is absent or cannot be parsed.
std::optional<uint32_t> ParseTracingServiceMajorVersion(
    std::string_view version) {
  constexpr std::string_view kPrefix = "Perfetto v";
  if (version.find(kPrefix, 0) != 0) {
    return std::nullopt;
  }
  std::string_view major_str = version.substr(kPrefix.size());
  auto end = major_str.find_first_of(".-");
  if (end == std::string_view::npos) {
    return std::nullopt;
  }
  return base::StringToUInt32(std::string(major_str.substr(0, end)));
}

}  // namespace

ProtoTraceReader::ProtoTraceReader(TraceProcessorContext* ctx,
                                   bool is_machine_dispatcher)
    : context_(ctx),
      parser_(std::make_unique<ProtoTraceParserImpl>(ctx, &module_context_)),
      is_machine_dispatcher_(is_machine_dispatcher),
      protovm_(ctx),
      skipped_packet_key_id_(ctx->storage->InternString("skipped_packet")),
      invalid_incremental_state_key_id_(
          ctx->storage->InternString("invalid_incremental_state")),
      packet_sequence_id_key_id_(
          ctx->storage->InternString("packet_sequence_id")) {
  module_context_.trace_packet_stream = context_->sorter->CreateStream(
      std::make_unique<TracePacketSink>(parser_.get()));
  module_context_.track_event_stream = context_->sorter->CreateStream(
      std::make_unique<TrackEventSink>(parser_.get()));
  module_context_.ftrace_stream_factory = [this](uint32_t cpu) {
    return context_->sorter->CreateStream(
        std::make_unique<FtraceEventSink>(parser_.get(), cpu));
  };
  module_context_.etw_stream_factory = [this](uint32_t cpu) {
    return context_->sorter->CreateStream(
        std::make_unique<EtwEventSink>(parser_.get(), cpu));
  };
  module_context_.inline_sched_switch_stream_factory = [this](uint32_t cpu) {
    return context_->sorter->CreateStream(
        std::make_unique<InlineSchedSwitchSink>(parser_.get(), cpu));
  };
  module_context_.inline_sched_waking_stream_factory = [this](uint32_t cpu) {
    return context_->sorter->CreateStream(
        std::make_unique<InlineSchedWakingSink>(parser_.get(), cpu));
  };
  RegisterDefaultModules(&module_context_, context_);
  if (context_->register_additional_proto_modules) {
    context_->register_additional_proto_modules(&module_context_, context_);
  }
  // This needs to happen after the TrackEvent descriptors have been registered,
  // which happens in one of the modules. (See
  // https://github.com/google/perfetto/issues/6260)
  for (const std::string& raw_bytes :
       context_->config.extra_parsing_descriptors) {
    auto status = context_->descriptor_pool_->AddFromFileDescriptorSet(
        reinterpret_cast<const uint8_t*>(raw_bytes.data()), raw_bytes.size(),
        {}, true);
    if (!status.ok()) {
      context_->import_logs_tracker->RecordAnalysisLog(
          stats::extra_parsing_descriptors_error,
          [&](ArgsTracker::BoundInserter& ins) {
            ins.AddArg(context_->storage->InternString("message"),
                       Variadic::String(
                           context_->storage->InternString(status.message())));
          });
    }
  }
}

ProtoTraceReader::~ProtoTraceReader() = default;

base::Status ProtoTraceReader::Parse(TraceBlobView blob) {
  return tokenizer_.Tokenize(std::move(blob), [this](TraceBlobView packet) {
    return ParsePacket(std::move(packet));
  });
}

base::Status ProtoTraceReader::ParseExtensionDescriptor(ConstBytes descriptor) {
  protos::pbzero::ExtensionDescriptor::Decoder decoder(descriptor.data,
                                                       descriptor.size);

  const uint8_t* data = nullptr;
  size_t size = 0;
  std::optional<util::DecompressedBuffer> decompressed;
  if (decoder.has_extension_set()) {
    auto extension = decoder.extension_set();
    data = extension.data;
    size = extension.size;
  } else if (decoder.has_extension_set_gzip()) {
    auto gzipped = decoder.extension_set_gzip();
    decompressed = util::DecompressToBuffer(util::CompressionType::kGzip,
                                            gzipped.data, gzipped.size);
    if (!decompressed || decompressed->size == 0) {
      return base::ErrStatus(
          "Failed to decompress gzipped extension descriptor (ERR:tp-corrupt)");
    }
    data = decompressed->data.get();
    size = decompressed->size;
  } else {
    return base::OkStatus();
  }

  return context_->descriptor_pool_->AddFromFileDescriptorSet(
      data, size,
      /*skip_prefixes*/ {},
      /*merge_existing_messages=*/true);
}

base::Status ProtoTraceReader::ParsePacket(TraceBlobView packet) {
  protos::pbzero::TracePacket::Decoder decoder(packet.data(), packet.length());
  if (PERFETTO_UNLIKELY(decoder.bytes_left())) {
    return base::ErrStatus(
        "Failed to parse proto packet fully; the trace is probably corrupt. "
        "(ERR:tp-corrupt)");
  }

  // Compressed packets are expanded by the tokenizer; none should reach here.
  PERFETTO_CHECK(!decoder.has_compressed_packets() &&
                 !decoder.has_zstd_compressed_packets());

  // The top-level reader dispatches packets from other machines to a
  // per-machine reader; host and adopted-machine packets are parsed here.
  if (is_machine_dispatcher_) {
    const uint32_t machine_id = decoder.machine_id();
    if (PERFETTO_UNLIKELY(machine_id)) {
      // Resolve adoption once, on the first remote-machine packet.
      if (PERFETTO_UNLIKELY(!adopted_machine_id_.has_value())) {
        RETURN_IF_ERROR(ResolveAdoptedMachine(machine_id));
      }
      // Route packets from a non-adopted machine to their own reader.
      if (machine_id != *adopted_machine_id_) {
        auto [reader, inserted] =
            machine_to_proto_readers_.Insert(machine_id, nullptr);
        if (PERFETTO_UNLIKELY(inserted)) {
          RETURN_IF_ERROR(CreateRemoteMachineReader(machine_id, reader));
        }
        return reader->get()->ParsePacket(std::move(packet));
      }
    } else if (!host_machine_used_ && !decoder.has_synchronization_marker()) {
      // The host owns this packet, so it can no longer be adopted away.
      host_machine_used_ = true;
    }
  }
  PERFETTO_DCHECK(is_machine_dispatcher_ || decoder.has_machine_id());

  // Execute ProtoVM logic right after the "machine ID fork" as detailed in
  // go/perfetto-proto-vm.
  if (decoder.has_trace_provenance()) {
    protovm_.ProcessTraceProvenancePacket(decoder.trace_provenance());
  } else if (decoder.has_protovms()) {
    protovm_.ProcessProtoVmsPacket(decoder.protovms(), packet);
  } else if (auto new_packet = protovm_.TryProcessPatch(decoder, packet);
             new_packet) {
    packet = std::move(*new_packet);
    decoder =
        protos::pbzero::TracePacket::Decoder(packet.data(), packet.length());
  }

  uint32_t seq_id = decoder.trusted_packet_sequence_id();
  auto [scoped_state, inserted] = sequence_state_.Insert(seq_id, {});
  if (decoder.has_trusted_packet_sequence_id()) {
    if (!inserted) {
      if (uint32_t reasons = decoder.previous_packet_dropped(); reasons) {
        ++scoped_state->previous_packet_dropped_count;
        RecordDataLossCauses(scoped_state, reasons);
      }
    }
  }

  if (decoder.has_trace_attributes()) {
    HandleTraceAttributes(decoder.trace_attributes());
  }

  if (decoder.first_packet_on_sequence()) {
    HandleFirstPacketOnSequence(seq_id);
  }

  uint32_t sequence_flags = decoder.sequence_flags();
  if (decoder.incremental_state_cleared() ||
      sequence_flags &
          protos::pbzero::TracePacket::SEQ_INCREMENTAL_STATE_CLEARED) {
    HandleIncrementalStateCleared(decoder, packet);
  } else if (decoder.previous_packet_dropped()) {
    HandlePreviousPacketDropped(decoder, packet);
  }

  // It is important that we parse defaults before parsing other fields such as
  // the timestamp, since the defaults could affect them.
  if (decoder.has_trace_packet_defaults()) {
    auto field = decoder.trace_packet_defaults();
    ParseTracePacketDefaults(decoder, packet.slice(field.data, field.size));
  }

  if (decoder.has_interned_data()) {
    auto field = decoder.interned_data();
    ParseInternedData(decoder, packet.slice(field.data, field.size));
  }

  if (decoder.has_clock_snapshot()) {
    return ParseClockSnapshot(decoder.clock_snapshot(), seq_id);
  }

  if (decoder.has_trace_stats()) {
    ParseTraceStats(decoder.trace_stats());
  }

  if (decoder.has_remote_clock_sync()) {
    PERFETTO_DCHECK(!is_machine_dispatcher_);
    return ParseRemoteClockSync(decoder.remote_clock_sync());
  }

  if (decoder.has_service_event()) {
    PERFETTO_DCHECK(decoder.has_timestamp());
    int64_t ts = static_cast<int64_t>(decoder.timestamp());
    return ParseServiceEvent(ts, decoder.service_event());
  }

  if (decoder.has_extension_descriptor()) {
    return ParseExtensionDescriptor(decoder.extension_descriptor());
  }

  auto* state = GetIncrementalStateForPacketSequence(seq_id);
  if (decoder.sequence_flags() &
      protos::pbzero::TracePacket::SEQ_NEEDS_INCREMENTAL_STATE) {
    if (!seq_id) {
      return base::ErrStatus(
          "TracePacket specified SEQ_NEEDS_INCREMENTAL_STATE but the "
          "TraceWriter's sequence_id is zero (the service is "
          "probably too old)");
    }
    scoped_state->needs_incremental_state_total++;

    if (!state->IsIncrementalStateValid()) {
      if (context_->content_analyzer) {
        // Account for the skipped packet for trace proto content analysis,
        // with a special annotation.
        PacketAnalyzer::SampleAnnotation annotation;
        annotation.emplace_back(skipped_packet_key_id_,
                                invalid_incremental_state_key_id_);
        PacketAnalyzer::Get(context_)->ProcessPacket(packet, annotation);
      }
      scoped_state->needs_incremental_state_skipped++;
      context_->import_logs_tracker->RecordTokenizationLog(
          stats::packet_skipped_seq_needs_incremental_state_invalid,
          packet.offset(),
          [this, seq_id](ArgsTracker::BoundInserter& inserter) {
            inserter.AddArg(packet_sequence_id_key_id_,
                            Variadic::UnsignedInteger(seq_id));
          });
      return base::OkStatus();
    }
  }

  if (context_->content_analyzer && !decoder.has_track_event()) {
    PacketAnalyzer::Get(context_)->ProcessPacket(packet, {});
  }

  if (decoder.has_trace_config()) {
    ParseTraceConfig(decoder.trace_config());
  }

  return TimestampTokenizeAndPushToSorter(std::move(packet));
}

ProtoTraceReader::ClockResolution ProtoTraceReader::ResolveTimestampToTraceTime(
    ClockTracker::ClockId clock_id,
    int64_t* timestamp,
    TraceBlobView* packet) {
  // Before EOF, suppress errors: the clock snapshot may arrive later and
  // the packet will be retried at EOF. At EOF, allow errors so genuinely
  // broken clocks are reported.
  bool suppress_errors = !received_eof_;
  auto trace_ts = context_->clock_tracker->ToTraceTime(
      clock_id, *timestamp, packet->offset(), suppress_errors);
  if (PERFETTO_LIKELY(trace_ts.has_value())) {
    *timestamp = *trace_ts;
    return ClockResolution::kResolved;
  }

  // Conversion failed. Before EOF, try to defer for later resolution.
  if (!received_eof_ &&
      context_->sorter->SetSortingMode(TraceSorter::SortingMode::kFullSort)) {
    eof_deferred_packets_.push_back(std::move(*packet));
    return ClockResolution::kDeferred;
  }

  // Cannot defer: record the error and drop the packet.
  context_->import_logs_tracker->RecordTokenizationLog(
      stats::clock_sync_failure_undeferrable_packet_loss, packet->offset());
  return ClockResolution::kDropped;
}

base::Status ProtoTraceReader::TimestampTokenizeAndPushToSorter(
    TraceBlobView packet) {
  protos::pbzero::TracePacket::Decoder decoder(packet.data(), packet.length());

  uint32_t seq_id = decoder.trusted_packet_sequence_id();
  auto* state = GetIncrementalStateForPacketSequence(seq_id);

  protos::pbzero::TracePacketDefaults::Decoder* defaults =
      state->current_generation()->GetTracePacketDefaults();

  int64_t timestamp;
  if (decoder.has_timestamp()) {
    timestamp = static_cast<int64_t>(decoder.timestamp());

    // Use the packet's clock_id, falling back to sequence defaults, then
    // to the trace's default clock (e.g. BOOTTIME for proto traces).
    // If none is set, timestamp_clock_id stays 0 and no conversion
    // happens — the timestamp is assumed to be in trace time already.
    uint32_t timestamp_clock_id = decoder.timestamp_clock_id();
    if (PERFETTO_UNLIKELY(!timestamp_clock_id && defaults)) {
      timestamp_clock_id = defaults->timestamp_clock_id();
    }
    std::optional<ClockTracker::ClockId> default_clock;
    if (PERFETTO_UNLIKELY(!timestamp_clock_id)) {
      default_clock = context_->clock_tracker->trace_default_clock();
      if (default_clock) {
        timestamp_clock_id = default_clock->clock_id;
      }
    }

    if ((decoder.has_chrome_events() || decoder.has_chrome_metadata()) &&
        (!timestamp_clock_id ||
         timestamp_clock_id == protos::pbzero::BUILTIN_CLOCK_MONOTONIC)) {
      // Chrome event timestamps are in MONOTONIC domain, but may occur in
      // traces where (a) no clock snapshots exist or (b) no clock_id is
      // specified for their timestamps. Adjust to trace time if we have a clock
      // snapshot.
      // TODO(eseckler): Set timestamp_clock_id and emit ClockSnapshots in
      // chrome and then remove this.
      auto trace_ts = context_->clock_tracker->ToTraceTime(
          ClockId::Machine(protos::pbzero::BUILTIN_CLOCK_MONOTONIC), timestamp);
      if (trace_ts)
        timestamp = *trace_ts;
    } else if (timestamp_clock_id) {
      // If the TracePacket specifies a non-zero clock-id, translate the
      // timestamp into the trace-time clock domain.
      ClockTracker::ClockId converted_clock_id;
      if (default_clock) {
        // The clock came from the trace default: use it as-is, as it may be
        // scoped beyond the raw clock id (e.g. a perfetto_manifest override
        // moved this file onto its private TraceFile clock).
        converted_clock_id = *default_clock;
      } else if (ClockId::IsSequenceClock(timestamp_clock_id)) {
        if (!seq_id) {
          return base::ErrStatus(
              "TracePacket specified a sequence-local clock id (%" PRIu32
              ") but the TraceWriter's sequence_id is zero (the service is "
              "probably too old)",
              timestamp_clock_id);
        }
        converted_clock_id = ClockId::Sequence(context_->trace_id().value,
                                               seq_id, timestamp_clock_id);
      } else {
        converted_clock_id = ClockId::Machine(timestamp_clock_id);
      }
      auto resolution =
          ResolveTimestampToTraceTime(converted_clock_id, &timestamp, &packet);
      if (resolution == ClockResolution::kDeferred ||
          resolution == ClockResolution::kDropped) {
        return base::OkStatus();
      }
    }
  } else {
    timestamp = std::max(latest_timestamp_, context_->sorter->max_timestamp());
  }
  latest_timestamp_ = std::max(timestamp, latest_timestamp_);

  auto& modules = module_context_.modules_by_field;
  // One pass over the packet, dispatching registered fields as they are
  // found. This also covers fields in the out-of-tree `extensions 1000 to
  // 1999` range, which the typed |decoder| does not store.
  SelectiveTracePacketDecoder packet_fields(
      decoder.begin(), static_cast<size_t>(decoder.end() - decoder.begin()));
  for (const protozero::Field& f : packet_fields.unknown_fields()) {
    if (f.id() >= modules.size() || modules[f.id()].empty())
      continue;
    for (ProtoImporterModule* module : modules[f.id()]) {
      ModuleResult res = module->TokenizePacket(
          {packet_fields, &packet, timestamp, state->current_generation(),
           TracePacketField(f)});
      if (!res.ignored())
        return res.ToStatus();
    }
  }

  // Use parent data and length because we want to parse this again
  // later to get the exact type of the packet.
  module_context_.trace_packet_stream->Push(
      timestamp,
      TracePacketData{std::move(packet), state->current_generation()});

  return base::OkStatus();
}

void ProtoTraceReader::ParseTraceConfig(protozero::ConstBytes blob) {
  trace_config_raw_.assign(blob.data, blob.data + blob.size);

  using Config = protos::pbzero::TraceConfig;
  Config::Decoder trace_config(blob);
  if (trace_config.write_into_file()) {
    int i = 0;
    for (auto it = trace_config.buffers(); it; ++it, ++i) {
      Config::BufferConfig::Decoder buf(*it);
      if (buf.fill_policy() == Config::BufferConfig::FillPolicy::DISCARD) {
        context_->stats_tracker->IncrementIndexedStats(
            stats::config_write_into_file_discard, i);
      }
    }
  }

  if (trace_config.has_trace_attributes()) {
    HandleTraceAttributes(trace_config.trace_attributes());
  }
}

void ProtoTraceReader::HandleIncrementalStateCleared(
    const protos::pbzero::TracePacket::Decoder& packet_decoder,
    const TraceBlobView& packet) {
  if (PERFETTO_UNLIKELY(!packet_decoder.has_trusted_packet_sequence_id())) {
    context_->import_logs_tracker->RecordTokenizationLog(
        stats::incremental_state_cleared_missing_sequence_id, packet.offset());
    return;
  }
  GetIncrementalStateForPacketSequence(
      packet_decoder.trusted_packet_sequence_id())
      ->OnIncrementalStateCleared();
  for (auto& module : module_context_.modules) {
    module->OnIncrementalStateCleared(
        packet_decoder.trusted_packet_sequence_id());
  }
}

void ProtoTraceReader::HandleFirstPacketOnSequence(
    uint32_t packet_sequence_id) {
  for (auto& module : module_context_.modules) {
    module->OnFirstPacketOnSequence(packet_sequence_id);
  }
}

void ProtoTraceReader::HandleTraceAttributes(protozero::ConstBytes blob) {
  protos::pbzero::TraceAttributes::Decoder decoder(blob);
  for (auto it_buf = decoder.attribute(); it_buf; ++it_buf) {
    protos::pbzero::TraceAttributes_Attribute::Decoder decoded_attribute(
        *it_buf);
    auto key = decoded_attribute.key();
    // Prefix all custom attribute keys with `trace_attribute.`
    auto prefixed_key = "trace_attribute." + key.ToStdString();
    auto key_id = context_->storage->InternString(prefixed_key);
    if (decoded_attribute.has_long_value()) {
      auto value = Variadic::Integer(decoded_attribute.long_value());
      context_->metadata_tracker->SetDynamicMetadata(key_id, value);
    } else if (decoded_attribute.has_string_value()) {
      auto value = Variadic::String(
          context_->storage->InternString(decoded_attribute.string_value()));
      context_->metadata_tracker->SetDynamicMetadata(key_id, value);
    }
  }
}

void ProtoTraceReader::HandlePreviousPacketDropped(
    const protos::pbzero::TracePacket::Decoder& packet_decoder,
    const TraceBlobView& packet) {
  if (PERFETTO_UNLIKELY(!packet_decoder.has_trusted_packet_sequence_id())) {
    context_->import_logs_tracker->RecordTokenizationLog(
        stats::previous_packet_dropped_missing_sequence_id, packet.offset());
    return;
  }
  GetIncrementalStateForPacketSequence(
      packet_decoder.trusted_packet_sequence_id())
      ->OnPacketLoss();
}

void ProtoTraceReader::RecordDataLossCauses(SequenceScopedState* seq,
                                            uint32_t reasons) {
  using TracePacket = protos::pbzero::TracePacket;
  auto record = [&](uint32_t mask, uint32_t& count) {
    if (reasons & mask) {
      ++count;
    }
  };
  record(TracePacket::DATA_LOSS_READ_GAP, seq->data_loss_read_gap_count);
  record(TracePacket::DATA_LOSS_CHUNK_CORRUPTED,
         seq->data_loss_chunk_corrupted_count);
  record(TracePacket::DATA_LOSS_ORPHAN_CONTINUATION,
         seq->data_loss_orphan_continuation_count);
  record(TracePacket::DATA_LOSS_REASSEMBLY_GAP,
         seq->data_loss_reassembly_gap_count);
  record(TracePacket::DATA_LOSS_REASSEMBLY_BROKEN_CHAIN,
         seq->data_loss_reassembly_broken_chain_count);
  record(TracePacket::DATA_LOSS_OVERWRITE, seq->data_loss_overwrite_count);
  record(TracePacket::DATA_LOSS_WRITER_ABORT,
         seq->data_loss_writer_abort_count);
  record(TracePacket::DATA_LOSS_SMB_FULL, seq->data_loss_smb_full_count);
}

void ProtoTraceReader::ParseTracePacketDefaults(
    const protos::pbzero::TracePacket_Decoder& packet_decoder,
    TraceBlobView trace_packet_defaults) {
  if (PERFETTO_UNLIKELY(!packet_decoder.has_trusted_packet_sequence_id())) {
    context_->import_logs_tracker->RecordTokenizationLog(
        stats::trace_packet_defaults_missing_sequence_id,
        trace_packet_defaults.offset());
    return;
  }

  auto* state = GetIncrementalStateForPacketSequence(
      packet_decoder.trusted_packet_sequence_id());
  state->UpdateTracePacketDefaults(std::move(trace_packet_defaults));
}

void ProtoTraceReader::ParseInternedData(
    const protos::pbzero::TracePacket::Decoder& packet_decoder,
    TraceBlobView interned_data) {
  if (PERFETTO_UNLIKELY(!packet_decoder.has_trusted_packet_sequence_id())) {
    context_->import_logs_tracker->RecordTokenizationLog(
        stats::interned_data_missing_sequence_id, interned_data.offset());
    return;
  }

  auto* state = GetIncrementalStateForPacketSequence(
      packet_decoder.trusted_packet_sequence_id());

  // Don't parse interned data entries until incremental state is valid, because
  // they could otherwise be associated with the wrong generation in the state.
  if (!state->IsIncrementalStateValid()) {
    uint32_t seq_id = packet_decoder.trusted_packet_sequence_id();
    context_->import_logs_tracker->RecordTokenizationLog(
        stats::interned_data_skipped_incremental_state_invalid,
        interned_data.offset(),
        [this, seq_id](ArgsTracker::BoundInserter& inserter) {
          inserter.AddArg(packet_sequence_id_key_id_,
                          Variadic::UnsignedInteger(seq_id));
        });
    return;
  }

  // Store references to interned data submessages into the sequence's state.
  protozero::ProtoDecoder decoder(interned_data.data(), interned_data.length());
  for (protozero::Field f = decoder.ReadField(); f.valid();
       f = decoder.ReadField()) {
    auto bytes = f.as_bytes();
    state->InternMessage(f.id(), interned_data.slice(bytes.data, bytes.size));
  }
}

base::Status ProtoTraceReader::ParseClockSnapshot(ConstBytes blob,
                                                  uint32_t seq_id) {
  // A ClockSnapshot correlates two or more clock domains, which proves this
  // trace is not single-clock; perfetto_manifest clock pins are only valid
  // for single-clock traces. ClockTracker::AddSnapshot also rejects this,
  // but its error is logged and swallowed below; check here to fail the
  // load on what is a configuration error.
  if (context_->has_clock_override()) {
    return base::ErrStatus(
        "perfetto_manifest: clock overrides require the trace to use a "
        "single clock");
  }
  std::vector<ClockTracker::ClockTimestamp> clock_timestamps;
  protos::pbzero::ClockSnapshot::Decoder evt(blob.data, blob.size);
  for (auto it = evt.clocks(); it; ++it) {
    protos::pbzero::ClockSnapshot::Clock::Decoder clk(*it);
    ClockTracker::ClockId clock_id;
    if (ClockId::IsSequenceClock(clk.clock_id())) {
      if (!seq_id) {
        return base::ErrStatus(
            "ClockSnapshot packet is specifying a sequence-scoped clock id "
            "(%" PRIu32 ") but the TracePacket sequence_id is zero",
            clock_id.clock_id);
      }
      clock_id =
          ClockId::Sequence(context_->trace_id().value, seq_id, clk.clock_id());
    } else {
      clock_id = ClockId::Machine(clk.clock_id());
    }
    int64_t unit_multiplier_ns =
        clk.unit_multiplier_ns()
            ? static_cast<int64_t>(clk.unit_multiplier_ns())
            : 1;
    clock_timestamps.emplace_back(clock_id, clk.timestamp(), unit_multiplier_ns,
                                  clk.is_incremental());
  }

  if (evt.primary_trace_clock()) {
    auto clock =
        ClockId::Machine(static_cast<uint32_t>(evt.primary_trace_clock()));
    context_->clock_tracker->SetTraceDefaultClock(clock);
    context_->clock_tracker->SetGlobalClock(clock);
  } else {
    // For legacy proto traces without primary_trace_clock: if the snapshot
    // contains BOOTTIME but not TRACE_FILE, infer BOOTTIME as the trace time
    // clock. This matches the old behavior where BOOTTIME was hardcoded as
    // the default for proto traces.
    bool has_boottime = false;
    bool has_trace_file = false;
    for (const auto& ct : clock_timestamps) {
      if (ct.clock.id.clock_id == protos::pbzero::BUILTIN_CLOCK_BOOTTIME) {
        has_boottime = true;
      }
      if (ct.clock.id.clock_id == protos::pbzero::BUILTIN_CLOCK_TRACE_FILE) {
        has_trace_file = true;
      }
    }
    if (has_boottime && !has_trace_file) {
      auto clock = ClockId::Machine(protos::pbzero::BUILTIN_CLOCK_BOOTTIME);
      context_->clock_tracker->SetTraceDefaultClock(clock);
      context_->clock_tracker->SetGlobalClock(clock);
    }
  }

  base::StatusOr<uint32_t> snapshot_id =
      context_->clock_tracker->AddSnapshot(clock_timestamps);
  if (!snapshot_id.ok()) {
    PERFETTO_ELOG("%s", snapshot_id.status().c_message());
  }
  return base::OkStatus();
}

PERFETTO_NO_INLINE base::Status ProtoTraceReader::ResolveAdoptedMachine(
    uint32_t machine_id) {
  RETURN_IF_ERROR(CheckManifestSingleMachine());
  // Adopt the embedded machine onto the host context (relabelling its row) only
  // when the host has no data of its own, its row isn't already claimed by
  // another machine, the file is not a multi-machine manifest, and the machine
  // has no row/context yet. Otherwise route to the fork path, which reuses any
  // existing row for this machine; adopting here would relabel a second row to
  // the same raw id and surface a duplicate machine.
  const bool host_has_data = host_machine_used_;
  const bool host_row_claimed =
      context_->machine_tracker->raw_machine_id() != 0;
  const bool is_manifest_machine =
      context_->trace_state && context_->trace_state->machine_remap;
  const bool machine_already_materialized =
      context_->forked_context_state->machine_to_context.Find(
          static_cast<int64_t>(machine_id)) != nullptr;
  if (host_has_data || host_row_claimed || is_manifest_machine ||
      machine_already_materialized) {
    adopted_machine_id_ = 0;
    return base::OkStatus();
  }
  context_->machine_tracker->SetRawMachineId(machine_id);
  // Register the adopted machine in the per-machine dedup map so a later fork
  // for the same id (e.g. another co-located trace routed through
  // CreateRemoteMachineReader) reuses this context and row instead of inserting
  // a duplicate machine row.
  context_->forked_context_state->machine_to_context.Insert(
      static_cast<int64_t>(machine_id), context_);
  adopted_machine_id_ = machine_id;
  return base::OkStatus();
}

PERFETTO_NO_INLINE base::Status ProtoTraceReader::CreateRemoteMachineReader(
    uint32_t machine_id,
    std::unique_ptr<ProtoTraceReader>* out) {
  // Embedded ids are uint32, always below kFirstManifestMachineId (1<<32), so
  // they never collide with the manifest's synthetic raw ids; no check needed.
  int64_t raw_machine_id = machine_id;
  const auto* remap =
      context_->trace_state ? context_->trace_state->machine_remap : nullptr;
  if (remap) {
    int64_t* mapped = remap->Find(machine_id);
    if (!mapped) {
      return base::ErrStatus(
          "perfetto_manifest: machines: trace has a packet from undeclared "
          "machine id %u",
          machine_id);
    }
    raw_machine_id = *mapped;
  }
  auto* machine_context =
      context_->ForkContextForMachineInCurrentTrace(raw_machine_id);
  *out = std::make_unique<ProtoTraceReader>(machine_context,
                                            /*is_machine_dispatcher=*/false);
  auto parent_default = context_->clock_tracker->trace_default_clock();
  if (parent_default) {
    machine_context->clock_tracker->SetTraceDefaultClock(*parent_default);
  }
  machine_context->clock_tracker->AddDeferredClockSync(
      ClockId::Machine(protos::pbzero::BUILTIN_CLOCK_BOOTTIME));
  // TODO(lalitm): this doesn't seem the right place for this but I cannot think
  // of a much better place either.
  machine_context->process_tracker->SetPidZeroIsUpidZeroIdleProcess();
  return base::OkStatus();
}

base::Status ProtoTraceReader::CheckManifestSingleMachine() {
  if (context_->has_machine_override()) {
    return base::ErrStatus(
        "perfetto_manifest: a `machine` override attributes the file to one "
        "machine, but the file contains packets from multiple machines. "
        "Replace `machine` with a `machines` block that maps each embedded "
        "machine_id to a named machine, e.g. "
        R"("machines": [{"id": 0, "name": "phone"}, {"id": 7, "name": "vm"}].)");
  }
  if (context_->has_clock_override()) {
    return base::ErrStatus(
        "perfetto_manifest: a `clocks` override applies only to a "
        "single-machine file, but the file contains packets from multiple "
        "machines. Remove the `clocks` override and let the trace's own "
        "remote clock snapshots align the machines; if you need to anchor a "
        "specific embedded machine, split it into its own file and override "
        "that.");
  }
  return base::OkStatus();
}

base::Status ProtoTraceReader::ParseRemoteClockSync(ConstBytes blob) {
  // Remote clock syncs prove the trace is multi-machine/multi-clock. The
  // machine_id branch in ParsePacket normally rejects overridden traces
  // first, but a packet carrying remote_clock_sync without a machine_id
  // would bypass it (the DCHECK above is a no-op in release builds).
  RETURN_IF_ERROR(CheckManifestSingleMachine());
  protos::pbzero::RemoteClockSync::Decoder evt(blob);

  std::vector<SyncClockSnapshots> sync_clock_snapshots;
  // Decode the RemoteClockSync message into a struct for calculating offsets.
  for (auto it = evt.synced_clocks(); it; ++it) {
    sync_clock_snapshots.emplace_back();
    auto& sync_clocks = sync_clock_snapshots.back();

    protos::pbzero::RemoteClockSync::SyncedClocks::Decoder synced_clocks(*it);
    protos::pbzero::ClockSnapshot::ClockSnapshot::Decoder host_clocks(
        synced_clocks.host_clocks());
    for (auto clock_it = host_clocks.clocks(); clock_it; clock_it++) {
      protos::pbzero::ClockSnapshot::ClockSnapshot::Clock::Decoder clock(
          *clock_it);
      sync_clocks[clock.clock_id()].first = clock.timestamp();
    }

    std::vector<ClockTracker::ClockTimestamp> clock_timestamps;
    protos::pbzero::ClockSnapshot::ClockSnapshot::Decoder client_clocks(
        synced_clocks.client_clocks());
    for (auto clock_it = client_clocks.clocks(); clock_it; clock_it++) {
      protos::pbzero::ClockSnapshot::ClockSnapshot::Clock::Decoder clock(
          *clock_it);
      sync_clocks[clock.clock_id()].second = clock.timestamp();
      clock_timestamps.emplace_back(ClockId::Machine(clock.clock_id()),
                                    clock.timestamp(), 1, false);
    }

    // In addition for calculating clock offsets, client clock snapshots are
    // also added to clock tracker to emulate tracing service taking periodical
    // clock snapshots. This builds a clock conversion path from a local trace
    // time (e.g. Chrome trace time) to client builtin clock (CLOCK_MONOTONIC)
    // which can be converted to host trace time (CLOCK_BOOTTIME).
    context_->clock_tracker->AddSnapshot(clock_timestamps);
  }

  // Express each per-clock offset as a cross-machine edge in the single clock
  // graph: at a synced instant the host clock reads |host_anchor| and this
  // (client) machine's clock reads |host_anchor + offset|, so the two are
  // linked directly. The anchor is a real host reading (the last sync round
  // that observed this clock) rather than a literal 0: that keeps the snapshot
  // rows we materialise to the clock_snapshot table at meaningful, in-bounds
  // timestamps instead of converting the epoch (e.g. REALTIME 0) into a wildly
  // negative trace time.
  uint32_t client_machine = context_->machine_id().value;
  uint32_t host_machine = context_->trace_time_state->clock_id.machine_id;
  auto clock_offsets = CalculateClockOffsets(sync_clock_snapshots);
  for (auto it = clock_offsets.GetIterator(); it; ++it) {
    uint32_t builtin = it.key().clock_id;
    int64_t offset = it.value();

    // CalculateClockOffsets only emits an offset for a clock that was observed
    // on both sides, so at least one round carries a non-zero host reading.
    int64_t host_anchor = 0;
    for (const auto& round : sync_clock_snapshots) {
      if (auto* clocks = round.Find(builtin); clocks && clocks->first)
        host_anchor = static_cast<int64_t>(clocks->first);
    }

    context_->clock_tracker->AddQualifiedSnapshot(
        {{ClockId::Machine(host_machine, builtin), host_anchor},
         {ClockId::Machine(client_machine, builtin), host_anchor + offset}});
  }
  return base::OkStatus();
}

base::FlatHashMap<ClockTracker::ClockId /*Clock Id*/, int64_t /*Offset*/>
ProtoTraceReader::CalculateClockOffsets(
    std::vector<SyncClockSnapshots>& sync_clock_snapshots) {
  base::FlatHashMap<ClockTracker::ClockId, int64_t /*Offset*/> clock_offsets;

  // The RemoteClockSync message contains a sequence of |synced_clocks|
  // messages. Each |synced_clocks| message contains pairs of ClockSnapshots
  // taken on both the client and host sides.
  //
  // The "synced_clocks" messages are emitted periodically. A single round of
  // data collection involves four snapshots:
  //   1. Client snapshot
  //   2. Host snapshot (triggered by client's IPC message)
  //   3. Client snapshot (triggered by host's IPC message)
  //   4. Host snapshot
  //
  // These four snapshots are used to estimate the clock offset between the
  // client and host for each default clock domain present in the ClockSnapshot.
  std::map<uint32_t, std::vector<int64_t>> raw_clock_offsets;
  // Remote clock syncs happen in an interval of 30 sec. 2 adjacent clock
  // snapshots belong to the same round if they happen within 30 secs.
  constexpr uint64_t clock_sync_interval_ns = 30lu * 1000000000;
  for (size_t i = 1; i < sync_clock_snapshots.size(); i++) {
    // Synced clocks are taken by client snapshot -> host snapshot.
    auto& ping_clocks = sync_clock_snapshots[i - 1];
    auto& update_clocks = sync_clock_snapshots[i];

    auto ping_client =
        ping_clocks[protos::pbzero::BuiltinClock::BUILTIN_CLOCK_BOOTTIME]
            .second;
    auto update_client =
        update_clocks[protos::pbzero::BuiltinClock::BUILTIN_CLOCK_BOOTTIME]
            .second;
    // |ping_clocks| and |update_clocks| belong to 2 different rounds of remote
    // clock sync rounds.
    if (update_client - ping_client >= clock_sync_interval_ns)
      continue;

    for (auto it = ping_clocks.GetIterator(); it; ++it) {
      const auto clock_id = it.key();
      const auto [t1h, t1c] = it.value();
      const auto [t2h, t2c] = update_clocks[clock_id];

      if (!t1h || !t1c || !t2h || !t2c)
        continue;

      int64_t offset1 =
          (static_cast<int64_t>(t1c + t2c) / 2) - static_cast<int64_t>(t1h);
      int64_t offset2 =
          static_cast<int64_t>(t2c) - (static_cast<int64_t>(t1h + t2h) / 2);

      // Clock values are taken in the order of t1c, t1h, t2c, t2h. Offset
      // calculation requires at least 3 timestamps as a round trip. We have 4,
      // which can be treated as 2 round trips:
      //   1. t1c, t1h, t2c as the round trip initiated by the client. Offset 1
      //      = (t1c + t2c) / 2 - t1h
      //   2. t1h, t2c, t2h as the round trip initiated by the host. Offset 2 =
      //      t2c - (t1h + t2h) / 2
      raw_clock_offsets[clock_id].push_back(offset1);
      raw_clock_offsets[clock_id].push_back(offset2);
    }

    // Use the average of estimated clock offsets in the clock tracker.
    for (const auto& [clock_id, offsets] : raw_clock_offsets) {
      int64_t avg_offset =
          std::accumulate(offsets.begin(), offsets.end(), 0LL) /
          static_cast<int64_t>(offsets.size());
      clock_offsets[ClockId::Machine(clock_id)] = avg_offset;
    }
  }

  return clock_offsets;
}

base::Status ProtoTraceReader::ParseServiceEvent(int64_t ts, ConstBytes blob) {
  protos::pbzero::TracingServiceEvent::Decoder tse(blob);
  if (tse.tracing_started()) {
    context_->metadata_tracker->SetMetadata(metadata::tracing_started_ns,
                                            Variadic::Integer(ts));
  }
  if (tse.tracing_disabled()) {
    context_->metadata_tracker->SetMetadata(metadata::tracing_disabled_ns,
                                            Variadic::Integer(ts));
  }
  if (tse.all_data_sources_started()) {
    context_->metadata_tracker->SetMetadata(
        metadata::all_data_source_started_ns, Variadic::Integer(ts));
  }
  if (tse.all_data_sources_flushed()) {
    context_->metadata_tracker->AppendMetadata(
        metadata::all_data_source_flushed_ns, Variadic::Integer(ts));
    context_->sorter->NotifyFlushEvent();
  }
  if (tse.read_tracing_buffers_completed()) {
    context_->sorter->NotifyReadBufferEvent();
  }
  if (tse.has_slow_starting_data_sources()) {
    protos::pbzero::TracingServiceEvent::DataSources::Decoder msg(
        tse.slow_starting_data_sources());
    for (auto it = msg.data_source(); it; it++) {
      protos::pbzero::TracingServiceEvent::DataSources::DataSource::Decoder
          data_source(*it);
      std::string formatted = data_source.producer_name().ToStdString() + " " +
                              data_source.data_source_name().ToStdString();
      context_->metadata_tracker->AppendMetadata(
          metadata::slow_start_data_source,
          Variadic::String(
              context_->storage->InternString(base::StringView(formatted))));
    }
  }
  if (tse.has_clone_started()) {
    context_->stats_tracker->SetStats(stats::traced_clone_started_timestamp_ns,
                                      ts);
  }
  if (tse.has_buffer_cloned()) {
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_clone_done_timestamp_ns,
        static_cast<int>(tse.buffer_cloned()), ts);
  }
  return base::OkStatus();
}

void ProtoTraceReader::ParseTraceStats(ConstBytes blob) {
  protos::pbzero::TraceStats::Decoder evt(blob.data, blob.size);
  context_->stats_tracker->SetStats(
      stats::traced_producers_connected,
      static_cast<int64_t>(evt.producers_connected()));
  context_->stats_tracker->SetStats(stats::traced_producers_seen,
                                    static_cast<int64_t>(evt.producers_seen()));
  context_->stats_tracker->SetStats(
      stats::traced_data_sources_registered,
      static_cast<int64_t>(evt.data_sources_registered()));
  context_->stats_tracker->SetStats(
      stats::traced_data_sources_seen,
      static_cast<int64_t>(evt.data_sources_seen()));
  context_->stats_tracker->SetStats(
      stats::traced_tracing_sessions,
      static_cast<int64_t>(evt.tracing_sessions()));
  context_->stats_tracker->SetStats(stats::traced_total_buffers,
                                    static_cast<int64_t>(evt.total_buffers()));
  context_->stats_tracker->SetStats(
      stats::traced_chunks_discarded,
      static_cast<int64_t>(evt.chunks_discarded()));
  context_->stats_tracker->SetStats(
      stats::traced_patches_discarded,
      static_cast<int64_t>(evt.patches_discarded()));
  context_->stats_tracker->SetStats(
      stats::traced_flushes_requested,
      static_cast<int64_t>(evt.flushes_requested()));
  context_->stats_tracker->SetStats(
      stats::traced_flushes_succeeded,
      static_cast<int64_t>(evt.flushes_succeeded()));
  context_->stats_tracker->SetStats(stats::traced_flushes_failed,
                                    static_cast<int64_t>(evt.flushes_failed()));

  if (evt.has_filter_stats()) {
    protos::pbzero::TraceStats::FilterStats::Decoder fstat(evt.filter_stats());
    context_->stats_tracker->SetStats(stats::filter_errors,
                                      static_cast<int64_t>(fstat.errors()));
    context_->stats_tracker->SetStats(
        stats::filter_input_bytes, static_cast<int64_t>(fstat.input_bytes()));
    context_->stats_tracker->SetStats(
        stats::filter_input_packets,
        static_cast<int64_t>(fstat.input_packets()));
    context_->stats_tracker->SetStats(
        stats::filter_output_bytes, static_cast<int64_t>(fstat.output_bytes()));
    context_->stats_tracker->SetStats(
        stats::filter_time_taken_ns,
        static_cast<int64_t>(fstat.time_taken_ns()));
    for (auto [i, it] = std::tuple{0, fstat.bytes_discarded_per_buffer()}; it;
         ++it, ++i) {
      context_->stats_tracker->SetIndexedStats(
          stats::traced_buf_bytes_filtered_out, i, static_cast<int64_t>(*it));
    }
  }

  switch (evt.final_flush_outcome()) {
    case protos::pbzero::TraceStats::FINAL_FLUSH_SUCCEEDED:
      context_->stats_tracker->IncrementStats(
          stats::traced_final_flush_succeeded, 1);
      break;
    case protos::pbzero::TraceStats::FINAL_FLUSH_FAILED:
      context_->stats_tracker->IncrementStats(stats::traced_final_flush_failed,
                                              1);
      break;
    case protos::pbzero::TraceStats::FINAL_FLUSH_UNSPECIFIED:
      break;
  }

  int buf_num = 0;
  for (auto it = evt.buffer_stats(); it; ++it, ++buf_num) {
    protos::pbzero::TraceStats::BufferStats::Decoder buf(*it);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_buffer_size, buf_num,
        static_cast<int64_t>(buf.buffer_size()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_bytes_written, buf_num,
        static_cast<int64_t>(buf.bytes_written()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_bytes_overwritten, buf_num,
        static_cast<int64_t>(buf.bytes_overwritten()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_bytes_read, buf_num,
        static_cast<int64_t>(buf.bytes_read()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_padding_bytes_written, buf_num,
        static_cast<int64_t>(buf.padding_bytes_written()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_padding_bytes_cleared, buf_num,
        static_cast<int64_t>(buf.padding_bytes_cleared()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_chunks_written, buf_num,
        static_cast<int64_t>(buf.chunks_written()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_chunks_rewritten, buf_num,
        static_cast<int64_t>(buf.chunks_rewritten()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_chunks_overwritten, buf_num,
        static_cast<int64_t>(buf.chunks_overwritten()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_chunks_discarded, buf_num,
        static_cast<int64_t>(buf.chunks_discarded()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_chunks_read, buf_num,
        static_cast<int64_t>(buf.chunks_read()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_chunks_relocated, buf_num,
        static_cast<int64_t>(buf.chunks_relocated()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_chunks_committed_out_of_order, buf_num,
        static_cast<int64_t>(buf.chunks_committed_out_of_order()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_write_wrap_count, buf_num,
        static_cast<int64_t>(buf.write_wrap_count()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_patches_succeeded, buf_num,
        static_cast<int64_t>(buf.patches_succeeded()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_patches_failed, buf_num,
        static_cast<int64_t>(buf.patches_failed()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_readaheads_succeeded, buf_num,
        static_cast<int64_t>(buf.readaheads_succeeded()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_readaheads_failed, buf_num,
        static_cast<int64_t>(buf.readaheads_failed()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_abi_violations, buf_num,
        static_cast<int64_t>(buf.abi_violations()));
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_trace_writer_packet_loss, buf_num,
        static_cast<int64_t>(buf.trace_writer_packet_loss()));
  }

  struct BufStats {
    uint32_t packet_loss = 0;
    uint32_t incremental_sequences_dropped = 0;
    uint32_t data_loss_read_gap = 0;
    uint32_t data_loss_chunk_corrupted = 0;
    uint32_t data_loss_orphan_continuation = 0;
    uint32_t data_loss_reassembly_gap = 0;
    uint32_t data_loss_reassembly_broken_chain = 0;
    uint32_t data_loss_overwrite = 0;
    uint32_t data_loss_writer_abort = 0;
    uint32_t data_loss_smb_full = 0;
  };
  base::FlatHashMap<int32_t, BufStats> stats_per_buffer;
  for (auto it = evt.writer_stats(); it; ++it) {
    protos::pbzero::TraceStats::WriterStats::Decoder w(*it);
    auto seq_id = static_cast<uint32_t>(w.sequence_id());
    if (auto* s = sequence_state_.Find(seq_id)) {
      auto& stats = stats_per_buffer[static_cast<int32_t>(w.buffer())];
      stats.packet_loss += s->previous_packet_dropped_count;
      stats.incremental_sequences_dropped +=
          s->needs_incremental_state_skipped > 0 &&
          s->needs_incremental_state_skipped ==
              s->needs_incremental_state_total;
      stats.data_loss_read_gap += s->data_loss_read_gap_count;
      stats.data_loss_chunk_corrupted += s->data_loss_chunk_corrupted_count;
      stats.data_loss_orphan_continuation +=
          s->data_loss_orphan_continuation_count;
      stats.data_loss_reassembly_gap += s->data_loss_reassembly_gap_count;
      stats.data_loss_reassembly_broken_chain +=
          s->data_loss_reassembly_broken_chain_count;
      stats.data_loss_overwrite += s->data_loss_overwrite_count;
      stats.data_loss_writer_abort += s->data_loss_writer_abort_count;
      stats.data_loss_smb_full += s->data_loss_smb_full_count;
    }
  }

  for (auto it = stats_per_buffer.GetIterator(); it; ++it) {
    auto& v = it.value();
    auto buf = it.key();
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_sequence_packet_loss, buf, v.packet_loss);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_incremental_sequences_dropped, buf,
        v.incremental_sequences_dropped);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_data_loss_read_gap, buf, v.data_loss_read_gap);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_data_loss_chunk_corrupted, buf,
        v.data_loss_chunk_corrupted);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_data_loss_orphan_continuation, buf,
        v.data_loss_orphan_continuation);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_data_loss_reassembly_gap, buf,
        v.data_loss_reassembly_gap);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_data_loss_reassembly_broken_chain, buf,
        v.data_loss_reassembly_broken_chain);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_data_loss_overwrite, buf, v.data_loss_overwrite);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_data_loss_writer_abort, buf,
        v.data_loss_writer_abort);
    context_->stats_tracker->SetIndexedStats(
        stats::traced_buf_data_loss_smb_full, buf, v.data_loss_smb_full);
  }
}

base::Status ProtoTraceReader::OnPushDataToSorter() {
  received_eof_ = true;
  for (auto& packet : eof_deferred_packets_) {
    RETURN_IF_ERROR(TimestampTokenizeAndPushToSorter(std::move(packet)));
  }
  // Remote-machine readers are only ever reached by the dispatcher, never by
  // the ForwardingTraceParser, so their own clock-deferred packets would
  // otherwise never be flushed. Propagate EOF to them too.
  for (auto it = machine_to_proto_readers_.GetIterator(); it; ++it) {
    RETURN_IF_ERROR(it.value()->OnPushDataToSorter());
  }
  return base::OkStatus();
}

void ProtoTraceReader::OnEventsFullyExtracted() {
  for (auto& module : module_context_.modules) {
    module->OnEventsFullyExtracted();
  }

  if (trace_config_raw_.empty()) {
    return;
  }

  using Config = protos::pbzero::TraceConfig;
  Config::Decoder trace_config(trace_config_raw_.data(),
                               trace_config_raw_.size());
  if (!trace_config.write_into_file() || trace_config.flush_period_ms()) {
    return;
  }

  // Since v54, automatic flushes happen on every write_into_file, making
  // an explicit flush_period_ms unnecessary. Only emit the stat for older
  // service versions, or if the version is unknown (traces predating the
  // tracing_service_version field).
  auto version_val = context_->metadata_tracker->GetMetadata(
      metadata::tracing_service_version);
  std::optional<uint32_t> major;
  if (version_val.has_value() && version_val->type == SqlValue::kString) {
    major = ParseTracingServiceMajorVersion(version_val->string_value);
  }
  if (!major.has_value() || *major < 54) {
    context_->stats_tracker->IncrementStats(
        stats::config_write_into_file_no_flush);
  }
}

namespace {

constexpr uint8_t kTracePacketTag =
    protozero::proto_utils::MakeTagLengthDelimited(
        protos::pbzero::Trace::kPacketFieldNumber);
constexpr uint16_t kModuleSymbolsTag =
    protozero::proto_utils::MakeTagLengthDelimited(
        protos::pbzero::TracePacket::kModuleSymbolsFieldNumber);

bool IsProtoTraceWithSymbols(const uint8_t* ptr, size_t size) {
  const uint8_t* const end = ptr + size;

  uint64_t tag;
  const uint8_t* next = protozero::proto_utils::ParseVarInt(ptr, end, &tag);
  if (next == ptr || tag != kTracePacketTag) {
    return false;
  }

  ptr = next;
  uint64_t field_length;
  next = protozero::proto_utils::ParseVarInt(ptr, end, &field_length);
  if (next == ptr) {
    return false;
  }
  ptr = next;

  if (field_length == 0) {
    return false;
  }

  next = protozero::proto_utils::ParseVarInt(ptr, end, &tag);
  if (next == ptr) {
    return false;
  }

  return tag == kModuleSymbolsTag;
}

// Perfetto proto trace.
class ProtoImporter : public TraceImporter<ProtoImporter> {
 public:
  ProtoImporter() : TraceImporter(MakeDescriptor()) {}
  ~ProtoImporter() override;

  bool Sniff(const uint8_t* data, size_t size) const override {
    return size > 0 && data[0] == kTracePacketTag;
  }

  base::StatusOr<std::unique_ptr<ChunkedTraceReader>> CreateReader(
      TraceProcessorContext* context,
      uint32_t) const override {
    return std::unique_ptr<ChunkedTraceReader>(
        std::make_unique<ProtoTraceReader>(context));
  }

 private:
  static TraceTypeDescriptor MakeDescriptor() {
    TraceTypeDescriptor d;
    d.name = "proto";
    d.sort_policy = TraceSortPolicy::kConfigDriven;
    d.clock_policy = TraceClockPolicy::kBoottime;
    d.sets_default_clock = false;
    d.claims_global_clock = false;
    d.archive_priority = 0;
    d.pid_zero_is_idle = true;
    d.detection_priority = 230;
    return d;
  }
};

ProtoImporter::~ProtoImporter() = default;

// Standalone module symbols proto (a proto trace whose first packet is
// ModuleSymbols). Uses the same ProtoTraceReader.
class SymbolsImporter : public TraceImporter<SymbolsImporter> {
 public:
  SymbolsImporter() : TraceImporter(MakeDescriptor()) {}
  ~SymbolsImporter() override;

  bool Sniff(const uint8_t* data, size_t size) const override {
    return IsProtoTraceWithSymbols(data, size);
  }

  base::StatusOr<std::unique_ptr<ChunkedTraceReader>> CreateReader(
      TraceProcessorContext* context,
      uint32_t) const override {
    return std::unique_ptr<ChunkedTraceReader>(
        std::make_unique<ProtoTraceReader>(context));
  }

 private:
  static TraceTypeDescriptor MakeDescriptor() {
    TraceTypeDescriptor d;
    d.name = "symbols";
    d.sort_policy = TraceSortPolicy::kConfigDriven;
    d.archive_priority = 3;
    d.detection_priority = 210;
    return d;
  }
};

SymbolsImporter::~SymbolsImporter() = default;

}  // namespace

std::unique_ptr<TraceImporterBase> CreateProtoImporter() {
  return std::make_unique<ProtoImporter>();
}

std::unique_ptr<TraceImporterBase> CreateSymbolsImporter() {
  return std::make_unique<SymbolsImporter>();
}

}  // namespace perfetto::trace_processor
