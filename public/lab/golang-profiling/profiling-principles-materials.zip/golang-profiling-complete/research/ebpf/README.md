# eBPF 章节的证据与配套产物

主文：`../ebpf.md`。来源账本：`../sources-ebpf.json`。账本每项包含正式版本标签、完整提交 SHA、不可变官方源码链接、实际阅读区间、主张、局限、缓存路径与 SHA256。

分析基线是 Linux **v6.12**、libbpf **v1.5.0**，Go runtime 解释使用 **go1.25.0**。这些是固定样本，不声称最新。标签通过 `git ls-remote` 解析；Linux 使用 annotated tag 的 peeled commit，完整结果见 `pins.json`。`fetch-manifest-pinned.json` 记录按不可变 commit 下载的结果，`extra-manifest.json` 记录调度调用点的补充下载。未能下载的可选 `runtime2.go` 未被引用；Go 部分依据已成功下载、实际阅读的 HACKING.md 与 stack.go。

`diagram-specs.json` 包含七张时序、状态与数据布局图规格。`example/` 包含完整 C/libbpf 示例，演示目标进程调度切出事件、ring 输出和质量计数；具体契约和未完成的运行验证见其中 README。

```bash
python3 research/ebpf/build_registry.py
python3 research/ebpf/verify.py
```

以上命令应在当前任务目录运行。离线校验检查引用、版本、文件哈希、行号范围、图规格引用、算术和共享 C 结构的大小断言，不安装依赖或运行特权 BPF。结果保存在 `validation.json`。完整 BPF 程序及用户态加载器没有在当前环境完成编译与运行，不能以这些离线检查代替内核 canary。
