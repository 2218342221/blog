#!/usr/bin/env python3
"""Offline checks only. Does not load BPF, change the kernel, or install software."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
RESEARCH = ROOT.parent
sources = json.loads((RESEARCH / "sources-ebpf.json").read_text())
ids = {row["id"] for row in sources}
assert len(ids) == len(sources)
article = (RESEARCH / "ebpf.md").read_text()
refs = set(re.findall(r"\[(eb-[\w-]+)\]", article))
assert refs == ids, (refs - ids, ids - refs)
han = len(re.findall(r"[\u4e00-\u9fff]", article))
assert 8000 <= han <= 12000, han
assert len(re.findall(r"^## ", article, flags=re.M)) == 8
manifest = json.loads((ROOT / "fetch-manifest-pinned.json").read_text())
manifest += json.loads((ROOT / "extra-manifest.json").read_text())
downloads = {row["path"]: row for row in manifest}
for row in sources:
    cache = RESEARCH / row["cache_path"]
    data = cache.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert row["sha256"] == digest
    downloaded = downloads[str(cache.relative_to(ROOT))]
    assert "error" not in downloaded
    assert downloaded["sha256"] == digest
    assert row["commit"] in row["url"]
    for span in row["read_ranges"]:
        assert 1 <= span["start"] <= span["end"] <= len(data.splitlines())
diagrams = json.loads((ROOT / "diagram-specs.json").read_text())
assert len(diagrams) == 7
for diagram in diagrams:
    assert set(diagram["sources"]) <= ids

def align8(size):
    return (size + 7) // 8 * 8

pipeline_cost = 100000 * 80e-9 + 20000 * (120e-9 + 0.25 * 2000e-9 + 180e-9 + 400e-9)
assert abs(pipeline_cost - 0.032) < 1e-12
assert (4096 - 1) // align8(56 + 8) == 63
assert (8192 - 1) // align8(73 + 8) == 93
assert align8(24 + 8) == 32
assert 64 * 8 * 128 == 65536
assert 100000 == 2000 + 98000
assert 98000 == 97900 + 100
assert abs(2000 / 12000 - 1 / 6) < 1e-12

cc = shutil.which("cc")
clang = shutil.which("clang")
pkg = shutil.which("pkg-config")
libbpf_status = subprocess.run([pkg, "--exists", "libbpf"], capture_output=True).returncode if pkg else None
header_command = [cc, "-std=c11", "-Wall", "-Wextra", "-Werror", "-fsyntax-only", "-x", "c", str(ROOT / "example/events.h")]
header = subprocess.run(header_command, capture_output=True, text=True) if cc else None
assert header is not None and header.returncode == 0, header.stderr if header else "cc unavailable"
result = dict(
    checked_at="2026-10-04",
    chinese_han_characters=han,
    top_level_sections=8,
    source_entries=len(sources),
    citations="all references resolve; all source entries cited",
    source_cache="all cited immutable downloads match ledger SHA256 and line ranges",
    diagram_specs=len(diagrams),
    calculations=dict(
        status="hypothetical teaching values, recomputed offline",
        pipeline_cpu_seconds_per_second=pipeline_cost,
        ring_4096_payload56_records=63,
        ring_8192_payload73_records=93,
        example_payload24_record_bytes=32,
        histogram_value_bytes=65536,
        queue_full_continuous_approximation_seconds=(1048576 - 1 - 262144) / (20000 * 64 - 15000 * 64),
    ),
    environment=dict(cc=cc, clang=clang, pkg_config=pkg, pkg_config_libbpf_exit_code=libbpf_status),
    example_validation=dict(
        shared_header_syntax_and_size_assertions="passed",
        header_command=header_command,
        full_userspace_compile="not performed: installed libbpf development package unavailable",
        bpf_compile="not performed: clang unavailable",
        kernel_load_attach_run="not performed",
        privileged_actions="none",
        dependency_installation="none",
    ),
    uncited_download_failures=[row for row in manifest if "error" in row],
)
(ROOT / "validation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False, indent=2))
