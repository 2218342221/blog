#!/usr/bin/env python3
import concurrent.futures,hashlib,json,pathlib,urllib.request
root=pathlib.Path(__file__).resolve().parent
pins={"linux-v6.12":dict(repo="torvalds/linux",tag="v6.12",commit="adc218676eef25575469234709c2d87185ca223a",tag_object="06090c9b622a7e1f797e775db4c035e0d779b76e"),"libbpf-v1.5.0":dict(repo="libbpf/libbpf",tag="v1.5.0",commit="09b9e83102eb8ab9e540d36b4559c55f3bcdb95d"),"go-go1.25.0":dict(repo="golang/go",tag="go1.25.0",commit="6e676ab2b809d46623acb5988248d95d1eb7939c")}
manifest=json.loads((root/"fetch-manifest.json").read_text())
jobs=[(r["path"].split("/",1)[0],r["path"].split("/",1)[1]) for r in manifest]
jobs += [("linux-v6.12",x) for x in ["kernel/bpf/stackmap.c","kernel/events/callchain.c","arch/x86/events/core.c","kernel/bpf/trampoline.c","Documentation/bpf/bpf_design_QA.rst","include/linux/bpf_verifier.h"]]
jobs += [("go-go1.25.0",x) for x in ["src/runtime/stack.go","src/runtime/runtime2.go","src/runtime/HACKING.md"]]
def get(job):
 label,path=job;p=pins[label];url=f'https://raw.githubusercontent.com/{p["repo"]}/{p["commit"]}/{path}'
 target=root/label/path
 try:
  data=urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"GoLab-research/1.0"}),timeout=45).read()
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  result=dict(path=str(target.relative_to(root)),url=url,pinned_version=p["tag"],commit=p["commit"],bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),lines=len(data.splitlines()))
 except Exception as e:result=dict(path=label+"/"+path,url=url,error=str(e))
 print(json.dumps(result,ensure_ascii=False),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:out=list(pool.map(get,jobs))
(root/"fetch-manifest-pinned.json").write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n")
(root/"pins.json").write_text(json.dumps(pins,ensure_ascii=False,indent=2)+"\n")

