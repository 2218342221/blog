#!/usr/bin/env python3
"""Build the source ledger from explicitly reviewed ranges and pinned cache."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PINS = json.loads((ROOT / "pins.json").read_text())
SOURCES = []

def add(id_, title, label, path, ranges, claims, limitations):
    pin = PINS[label]
    cached = ROOT / label / path
    data = cached.read_bytes()
    lines = len(data.splitlines())
    assert all(1 <= start <= end <= lines for start, end in ranges), (path, lines)
    SOURCES.append(dict(
        id=id_, title=title,
        url=f'https://github.com/{pin["repo"]}/blob/{pin["commit"]}/{path}',
        pinned_version=pin['tag'], commit=pin['commit'],
        read_ranges=[dict(start=start, end=end) for start, end in ranges],
        key_claims=claims, limitations=limitations,
        cache_path=str(cached.relative_to(ROOT.parent)),
        sha256=hashlib.sha256(data).hexdigest(), line_count=lines,
        evidence_type="official documentation or implementation; fixed release snapshot",
    ))

L = "linux-v6.12"
B = "libbpf-v1.5.0"
G = "go-go1.25.0"

add("eb-libbpf-overview", "Linux: libbpf overview and CO-RE lifecycle", L,
    "Documentation/bpf/libbpf/libbpf_overview.rst", [(1,236)],
    ["open/load/attach/teardown 是不同阶段", "CO-RE 需要编译器、BTF、加载器合作", "skeleton 是对象访问和生命周期辅助代码"],
    ["不把布局适配表述为程序语义兼容证明", "不承诺所有目标内核具备相同能力"])
add("eb-libbpf-load", "libbpf: ELF collection, load ordering, section mapping and attach", B,
    "src/libbpf.c", [(8035,8072),(8550,8608),(9456,9476),(10820,10906),(12127,12222),(12460,12510),(12665,12710)],
    ["对象解析与加载具有明确顺序", "perf attach 支持 BPF link 和 ioctl 兼容路径", "uprobe 符号可解析为文件偏移", "fentry/fexit section 映射为 tracing 类型"],
    ["仅阅读列出的实际范围，不宣称逐行审完完整 libbpf.c", "实际选择路径取决于目标内核支持"])
add("eb-btf", "Linux: BPF Type Format and BTF.ext", L,
    "Documentation/bpf/btf.rst", [(1,70),(766,850),(994,1085)],
    ["BTF 表达类型、字符串、函数与行信息", "BTF.ext 包含 CO-RE 偏移和长度字段", "ELF 与内核 API 的 insn_off 单位需要区分"],
    ["文档的历史 pahole 能力描述不能泛化为现有所有版本", "BTF 不表达全部业务语义"])
add("eb-llvm-reloc", "Linux: LLVM ELF relocations and CO-RE relocation records", L,
    "Documentation/bpf/llvm_reloc.rst", [(1,215),(288,390)],
    ["普通 ELF relocation 与 CO-RE relocation 解决不同关联", "bpf_core_relo 包含 insn_off/type_id/access_str_off/kind", "CO-RE 涵盖字段、类型和枚举查询"],
    ["只展示固定版本定义，不推断未来重定位种类", "示例结构偏移不是真实内核布局"])
add("eb-core-relo", "libbpf: calculating and patching CO-RE relocations", B,
    "src/relo_core.c", [(879,960),(1024,1108),(1394,1422)],
    ["计算本地与目标字段/类型/枚举值", "修补指令立即数或访存偏移", "不支持的访问可毒化并在可达时被验证器拒绝"],
    ["结构重定位不保证单位、锁、生命周期或事件语义兼容", "缺失字段的替代分支必须由程序设计提供"])
add("eb-helpers", "libbpf: BPF C section and map-definition helper macros", B,
    "src/bpf_helpers.h", [(1,95)],
    ["SEC 将对象放入特定 ELF section", "__uint/__type 编码 map 定义", "包含 helper 声明前需要 Linux 类型或 vmlinux.h"],
    ["宏本身不授予内核能力", "当前环境没有安装可构建的 Clang/libbpf 依赖"])
add("eb-verifier-doc", "Linux: verifier register state, range tracking and pruning", L,
    "Documentation/bpf/verifier.rst", [(1,180),(288,430)],
    ["寄存器类型、范围、tnum、栈初始化与 helper 参数检查", "已验证状态与活跃性用于路径剪枝", "helper 调用约定会改变寄存器状态"],
    ["开头禁止循环的旧描述与同版本实际源码不一致，本文以源码为准", "验证不是业务正确性或统计有效性证明"])
add("eb-verifier-code", "Linux: verifier state containment, liveness and loop exploration", L,
    "kernel/bpf/verifier.c", [(6000,6120),(16300,16555),(17217,17335),(17577,17648),(17870,18015),(18312,18346)],
    ["regsafe 检查类型、范围、tnum 与身份关系", "states_equal 涉及调用帧、锁和 RCU 状态", "循环检测与复杂度预算不同于源代码长度", "状态剪枝需满足证明条件"],
    ["只对已阅读路径作机制解释，不宣称完整验证器形式化证明", "具体接受集合受内核版本和程序类型影响"])
add("eb-load-syscall", "Linux: BPF program load permissions, verifier and runtime selection", L,
    "kernel/bpf/syscall.c", [(2640,2710),(2835,2880)],
    ["加载检查能力和安全策略", "验证后选择执行引擎并返回对象引用", "加载与挂载是不同动作"],
    ["不把 root 或固定 capability 集合当作所有环境的充分条件", "未执行特权加载"])
add("eb-runtime-select", "Linux: interpreter dispatch and JIT runtime selection", L,
    "kernel/bpf/core.c", [(1708,1745),(2385,2449)],
    ["通用解释器与架构 JIT 路径并存", "ALWAYS_ON 或部分 kfunc 情况要求 JIT", "常量混淆可以改写程序"],
    ["不能承诺任意 JIT 失败都会回退解释器", "未量化某平台执行开销"])
add("eb-x86-jit", "Linux x86: iterative BPF JIT instruction layout", L,
    "arch/x86/net/bpf_jit_comp.c", [(3380,3455)],
    ["多轮生成稳定代码长度与地址布局", "长度收敛后分配并生成机器码镜像"],
    ["架构特定实现，不能推广为所有 JIT 的相同算法", "没有测量 JIT 与解释器性能差值"])
add("eb-trampoline", "Linux: BPF fentry/fexit trampoline construction and registration", L,
    "kernel/bpf/trampoline.c", [(1,135),(200,231),(393,477)],
    ["trampoline 根据附加程序与函数模型生成", "可经 ftrace direct 或架构 text poke 注册", "fexit 改变原函数调用组织"],
    ["具体支持依赖架构、内核和函数可挂载性", "未给出跨机制统一开销排名"])
add("eb-uprobe", "Linux: uprobe inode/offset identity and software breakpoints", L,
    "kernel/events/uprobes.c", [(50,78),(125,152),(560,609)],
    ["uprobe 按 inode 和文件偏移关联目标", "文件偏移和进程虚拟地址通过映射换算", "软件断点与原指令保存说明触发成本不能忽略"],
    ["实际陷入与异位执行细节具有架构差异", "不声称对 Go ABI 或任意返回路径均可直接套用 C 探针"])
add("eb-map-array-doc", "Linux: ARRAY/PERCPU_ARRAY layout and concurrency", L,
    "Documentation/bpf/map_array.rst", [(1,130)],
    ["数组元素预分配、清零、八字节对齐", "per-CPU map 默认访问当前 CPU 槽", "共享更新需要适当并发原语"],
    ["per-CPU 不自动提供多字段原子快照或全部上下文无竞态"])
add("eb-map-array-code", "Linux: per-CPU array lookup, copy and memory accounting", L,
    "kernel/bpf/arraymap.c", [(95,122),(235,268),(298,325),(351,422),(760,786)],
    ["BPF 查询通过 this_cpu_ptr 获取分片", "用户态复制遍历 possible CPUs", "内存用量乘以 num_possible_cpus 并包含元数据"],
    ["示例容量只计算 value 字节，不冒充完整分配开销", "持续读出不是同时全局快照"])
add("eb-ring-doc", "Linux: BPF ring buffer reservation, ordering and wakeups", L,
    "Documentation/bpf/ringbuf.rst", [(1,206)],
    ["共享 MPSC ring 支持跨 CPU 保留顺序", "reserve/submit/discard 有资源义务", "较早 busy 记录阻塞后续消费", "双重虚拟映射不使物理容量翻倍"],
    ["普通 reserve 的大小约束不代表 dynptr API 全部约束", "保留顺序不是业务因果顺序", "NMI 可能因锁竞争失败"])
add("eb-ring-code", "Linux: ring buffer capacity, pending position and publish protocol", L,
    "kernel/bpf/ringbuf.c", [(118,154),(190,231),(408,538)],
    ["记录长度为 payload 加八字节头再八字节对齐", "容量判断与 mask=R-1、consumer 和 pending 位置有关", "NMI 使用 trylock", "公开提交 helper 为 bpf_ringbuf_submit"],
    ["容量例子未包含单独元数据页", "不能把 reserve 失败全部解释为消费者已满", "并发成本数字是教学假设"])
add("eb-ring-consume", "libbpf: acquire/consume/release ring consumer", B,
    "src/ringbuf.c", [(234,279)],
    ["busy 停止、discard 跳过、回调后推进消费位置", "负回调结果也在越过当前记录后返回", "慢回调延迟空间回收"],
    ["只分析 libbpf v1.5.0 消费协议", "用户上传与持久化正确性仍需应用层处理"])
add("eb-perf-abi", "Linux perf ABI: sampling configuration and loss records", L,
    "include/uapi/linux/perf_event.h", [(340,366),(392,443),(875,891),(1090,1105)],
    ["period/frequency 由 freq 区分", "precise_ip 描述 skid 相关要求", "time_enabled/time_running 与复用覆盖有关", "LOST 与 LOST_SAMPLES 是 perf 数据质量记录"],
    ["perf 丢失记录不自动覆盖自建 BPF ring 的失败", "计数缩放不能恢复未采调用栈"])
add("eb-perf-core", "Linux perf: interrupt throttling and sample frequency feedback", L,
    "kernel/events/core.c", [(9652,9687)],
    ["中断阈值可触发节流", "频率模式根据观测时间调整采样周期"],
    ["名义频率不是严格数量保证", "没有测量当前主机节流状态"])
add("eb-perf-record", "Linux perf record: call graph modes and BPF off-CPU scope", L,
    "tools/perf/Documentation/perf-record.txt", [(278,323),(809,837)],
    ["用户 callgraph 支持 fp/dwarf/lbr 的不同策略", "固定版本 DWARF 用户栈默认转储 8192 B", "该版本内置 BPF off-CPU 路径要求 FP"],
    ["不能推广为所有 eBPF profiler 均不支持 DWARF", "用户与内核栈展开机制应分开"])
add("eb-stack-helper", "Linux BPF helper contract: context IDs, clocks and stack collection", L,
    "include/uapi/linux/bpf.h", [(55,90),(1884,1902),(1963,1987),(2038,2088),(2105,2125),(2405,2465),(3300,3355)],
    ["栈 helper 有深度和失败返回", "FAST_STACK_CMP 与 REUSE_STACKID 改变碰撞语义", "build ID 模式文件偏移不是装载基址偏移", "当前 task 的 tgid/pid 打包为 64 位；ktime 时间单位为纳秒"],
    ["文档建议提高系统限制不是本实验已执行动作", "记录存在与栈完整是两个质量维度"])
add("eb-stackmap", "Linux: stack trace hashing, collision and helper call chain", L,
    "kernel/bpf/stackmap.c", [(227,326)],
    ["栈 ID 由哈希映射到桶并受碰撞策略影响", "helper 经 get_perf_callchain 收集调用栈", "旧栈可因复用策略被替换"],
    ["ID 不能视为无限唯一永久身份", "计数 map 与栈表轮转需协同"])
add("eb-callchain", "Linux perf: callchain selection and uretprobe return repair", L,
    "kernel/events/callchain.c", [(190,268)],
    ["内核与用户调用栈路径分开", "用户 callchain 委派到架构函数", "可修复 uretprobe trampoline 产生的返回地址"],
    ["跨任务和特殊上下文存在限制", "不是 Go goroutine 全量快照"])
add("eb-x86-callchain", "Linux x86: user frame-pointer walk", L,
    "arch/x86/events/core.c", [(2910,2975)],
    ["从寄存器 BP 读取下一帧与返回地址", "处理 uprobe 入口 BP 尚未建立的特殊情况", "读取失败和深度上限终止展开"],
    ["这是固定 x86 内置路径，不代表所有架构或所有 profiler", "不是通用 DWARF unwinder"])
add("eb-go-runtime", "Go runtime HACKING: G/M/P, user/system/signal stacks", G,
    "src/runtime/HACKING.md", [(1,110)],
    ["G 是 goroutine，M 是 OS 线程，P 是执行资源", "M 可执行用户、runtime、系统调用或空闲", "每个 G 有可增长用户栈，M 有系统/信号栈"],
    ["runtime 文档自述可能落后，本文固定到明确提交", "线程身份不能替代 goroutine 或请求身份"])
add("eb-go-stack", "Go runtime: copying stacks and pointer adjustment", G,
    "src/runtime/stack.go", [(899,989)],
    ["copystack 分配复制并调整相关指针", "更新 G 栈边界和调度 SP", "栈移动有特定同步条件"],
    ["不把 runtime 私有结构当跨版本稳定 ABI", "未运行特定 Go unwinder 进行覆盖率验证"])
add("eb-sched-trace", "Linux: sched_switch event schema", L,
    "include/trace/events/sched.h", [(218,278)],
    ["事件携带 prev/next 任务与 prev_state", "仅时间戳和 current ID 无法区分所有切出原因"],
    ["最小实验有意不读取上下文字段", "线程事件不自动提供 goroutine 调度状态"])
add("eb-sched-core", "Linux scheduler: trace_sched_switch before context_switch", L,
    "kernel/sched/core.c", [(6678,6697)],
    ["在实际 context_switch 之前执行 trace_sched_switch", "支持最小实验将当前任务解释为切出任务"],
    ["固定 v6.12 调用点证据", "不从此推断所有事件均能配成 off-CPU 时长"])
add("eb-attach-api", "libbpf public API: object, tracepoint, ring and possible CPUs", B,
    "src/libbpf.h", [(210,239),(754,774),(1310,1337),(1680,1696)],
    ["open_file/attach_tracepoint/ring_buffer API 的具体签名", "possible CPU 数决定 per-CPU 用户缓冲区"],
    ["只做源码 API 审查，未在当前环境编译或加载示例", "实际错误与策略须在目标环境验证"])

add("eb-isa", "Linux BPF ISA: basic/wide encoding and program-local calls", L,
    "Documentation/bpf/standardization/instruction-set.rst", [(1,140),(145,265),(490,580),(716,744)],
    ["基本编码八字节，宽编码十六字节", "ldimm64 使用第二槽提供额外立即数", "调用编码区分静态 helper ID、程序内目标和 BTF ID"],
    ["ISA 规范不等于每个内核与架构支持所有指令组", "Linux helper 与 kfunc 的稳定性需看平台文档"])
add("eb-design-qa", "Linux BPF design Q&A: calling convention and API stability", L,
    "Documentation/bpf/bpf_design_QA.rst", [(30,75),(195,242)],
    ["R10 为可访问的帧指针，普通栈指针不直接暴露", "helper ABI 与 kfunc 生命周期承诺不同", "只可调用明确暴露的 helper/kfunc"],
    ["文档 zero overhead 措辞不作为测得的零开销承诺", "512 B 栈上限需要结合实际调用链验证源码解释"])
add("eb-kfuncs", "Linux: kfunc registration, argument contracts and lifecycle", L,
    "Documentation/bpf/kfuncs.rst", [(1,220),(290,445)],
    ["kfunc 按程序类型注册 BTF ID 集合", "参数和标志约束引用、可空性及可睡眠上下文", "kfunc 不具有用户 UAPI 相同的严格稳定性承诺"],
    ["存在名称或 BTF 不保证对当前程序类型可调用", "需按目标版本和配置检测支持"])
add("eb-verifier-state", "Linux: verifier call-frame and stack-slot representation", L,
    "include/linux/bpf_verifier.h", [(335,365)],
    ["固定 v6.12 MAX_CALL_FRAMES 为 8", "栈槽相对 R10，以八字节单元跟踪", "MAX_BPF_STACK 的固定基线为 512 B"],
    ["调用帧常量不允许任意递归或每帧独占相同上限", "tail call 混合调用还有更严格条件"])

(ROOT.parent / "sources-ebpf.json").write_text(
    json.dumps(SOURCES, ensure_ascii=False, indent=2) + "\n")
print(f"wrote {len(SOURCES)} verified source entries")
