#!/usr/bin/env python3
import concurrent.futures, hashlib, json, pathlib, urllib.request, time
ROOT=pathlib.Path(__file__).resolve().parent
spec={
"linux-v6.12":("torvalds/linux","v6.12",[
"Documentation/bpf/verifier.rst","Documentation/bpf/btf.rst",
"Documentation/bpf/libbpf/libbpf_overview.rst","Documentation/bpf/libbpf/libbpf_build.rst",
"Documentation/bpf/libbpf/program_types.rst","Documentation/bpf/ringbuf.rst",
"Documentation/bpf/map_array.rst","kernel/bpf/verifier.c","kernel/bpf/core.c",
"kernel/bpf/syscall.c","kernel/bpf/ringbuf.c","kernel/bpf/arraymap.c",
"kernel/events/core.c","kernel/events/uprobes.c","kernel/trace/bpf_trace.c",
"include/uapi/linux/bpf.h","include/uapi/linux/perf_event.h",
"arch/x86/net/bpf_jit_comp.c","tools/perf/Documentation/perf-record.txt"]),
"libbpf-v1.5.0":("libbpf/libbpf","v1.5.0",[
"src/libbpf.c","src/relo_core.c","src/btf.c","src/ringbuf.c",
"src/bpf.c","src/libbpf.h","src/bpf_helpers.h","src/bpf_tracing.h",
"src/bpf_core_read.h","README.md"])
}
jobs=[(label,repo,tag,path) for label,(repo,tag,paths) in spec.items() for path in paths]
def fetch(job):
 label,repo,tag,path=job; url=f"https://raw.githubusercontent.com/{repo}/{tag}/{path}"
 p=ROOT/label/path
 try:
  req=urllib.request.Request(url,headers={"User-Agent":"GoLab-research/1.0"})
  data=urllib.request.urlopen(req,timeout=40).read()
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  out=dict(path=str(p.relative_to(ROOT)),url=url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),lines=len(data.splitlines()))
 except Exception as e:out=dict(path=label+"/"+path,url=url,error=str(e))
 print(json.dumps(out,ensure_ascii=False),flush=True);return out
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: results=list(pool.map(fetch,jobs))
(ROOT/"fetch-manifest.json").write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n")

