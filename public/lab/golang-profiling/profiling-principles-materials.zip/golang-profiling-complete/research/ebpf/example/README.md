# 调度切出观察：最小 C/libbpf 示例

**验证状态：完整示例未编译、未加载、未进行特权运行。** 编写环境有 `cc` 与 `pkg-config`，没有发现 `clang` 或 libbpf 开发包；未安装依赖、修改内核参数或加载 BPF。已依据 Linux v6.12 / libbpf v1.5.0 固定源码核验使用的 API、reserve/submit 生命周期与算术；共享头文件单独通过 `cc -std=c11 -Wall -Wextra -Werror -fsyntax-only -x c events.h`，包含 24 B 事件和 16 B 计数结构的静态断言。这个检查不验证 BPF 字节码或加载器程序。下列命令供满足环境要求的学习者执行，不代表本环境已经得到运行结果。

## 测量契约

- 目标：目标 **host TGID** 对应进程的所有线程，在挂载有效期间触发的 `sched:sched_switch` 切出观察。
- 在 Linux v6.12，`trace_sched_switch` 在 `context_switch` 之前执行；因此 `bpf_get_current_pid_tgid()` 对应即将切出的任务。来源见本章 `[eb-sched-core]`。
- 它不计算 CPU 时间、off-CPU 时长、Go goroutine 等待时间或请求延迟。没有读取 `prev_state`，不区分抢占与阻塞。
- 无 tracepoint 字段或私有内核结构读取，因此不演示 CO-RE 字段重定位。BTF map 定义不等于已经使用 CO-RE。
- ring 中 payload 为 24 B，加 8 B 记录头后占 32 B；per-CPU `stats` 为 16 B，已按 8 B 对齐。
- `seen` 在目标过滤后计数；`reserve_failed` 只计该阶段失败；`received` 是消费者回调接收条数；`malformed` 是接收条数的子集，不重复计作内核丢失。
- host TGID 与容器 PID namespace 中看到的 PID 可能不同。测试进程应在当前环境明确可识别；不要把容器内 PID 直接当 host TGID。

## 环境和构建

Linux 主机需要 BPF、perf 与目标 tracepoint 支持，具有 BPF 后端的 Clang、Linux UAPI 头文件、libbpf 开发库（本示例核验 v1.5.0 API）及其 libelf/zlib 依赖。挂载权限取决于内核配置、程序类型、能力和策略；仅在自己有权限的实验环境运行，不要求关闭系统安全策略。

```bash
clang --version
pkg-config --modversion libbpf
make
```

Debian 类多架构头文件布局若提示缺少 `asm/types.h`，可在确认目录存在后指定：

```bash
make BPF_EXTRA_CFLAGS="-I/usr/include/$(cc -dumpmachine)"
```

这是构建参数，不是跨任意发行版的通用修复。若 Clang 未包含 BPF 后端或系统缺少依赖，先按实验环境的正规方式提供它们。

## 执行与验证

另一个终端运行一个已知测试进程，记录它的 host TGID。以环境已批准的身份执行：

```bash
./switches ./switches.bpf.o HOST_TGID
```

程序先 load，设置 config，建立消费者，最后 attach；十秒后或收到 SIGINT/SIGTERM 后 detach，drain，并读取 per-CPU 计数。只打印前五条记录以限制消费回调成本。主循环使用单调时钟，poll 粒度为 100 ms；实际有效挂载窗口包含开始与收尾的少量边界时间，不应称为精确十秒采样。

不要为演示写入虚构输出。正常完整收尾且没有计数溢出时，应核验：

```text
seen == reserve_failed + received
malformed == 0
```

`seen=0` 只表示零命中，应进一步确认 TGID、工作负载和有效窗口；不表示主机没有调度。程序收到 SIGKILL 或异常退出时不会完成最终对账。长期运行还需处理目标进程退出与 PID 重用；本示例要求学习者选择一个生命周期覆盖十秒窗口的测试进程。

`ring_buffer__consume()` 返回零也可能是遇到尚未提交的 busy 记录，本身不是全系统静止证明。本例在解除入口后立即尝试排空，并用计数相等检查检测收尾不完整；若仍有在途执行、失败回调或异常生命周期，可能报告不匹配并以非零退出。生产采集器需要明确的窗口收尾协议，不能把一次空消费当成无剩余数据的证明。

扩展实验：先在固定工作负载上建立基线；再在用户回调中加入可控延迟，观察 reserve_failed，而不是默认按比例补回样本。改为每条打印后若丢失增加，应区分用户消费变慢与内核程序本身变慢。若扩展为 off-CPU profiler，还必须读取切出状态、配对切入、处理递归状态/任务退出/身份复用/缺失事件，不能直接把本例时间戳相减称为请求延迟。
