#define _POSIX_C_SOURCE 200809L
#include <bpf/bpf.h>
#include <bpf/libbpf.h>
#include <errno.h>
#include <inttypes.h>
#include <limits.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "events.h"

static volatile sig_atomic_t stop;

struct consumer {
    uint64_t received;
    uint64_t malformed;
};

static void on_signal(int signo)
{
    (void)signo;
    stop = 1;
}

static int on_event(void *ctx, void *data, size_t size)
{
    struct consumer *c = ctx;
    const struct event *e = data;

    c->received++;
    if (size != sizeof(*e)) {
        c->malformed++;
        return 0;
    }
    /* Keep the consumer fast: do not print every event. */
    if (c->received <= 5)
        printf("ts_ns=%" PRIu64 " tgid=%u tid=%u cpu=%u\n",
               (uint64_t)e->ts_ns, e->tgid, e->tid, e->cpu);
    return 0;
}

static double monotonic_seconds(void)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts))
        return -1;
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

int main(int argc, char **argv)
{
    struct bpf_object *obj = NULL;
    struct bpf_program *prog;
    struct bpf_link *link = NULL;
    struct ring_buffer *rb = NULL;
    struct stats *values = NULL;
    struct consumer consumer = {0};
    struct sigaction action = { .sa_handler = on_signal };
    uint64_t seen = 0, failed = 0;
    __u32 key = 0, target;
    unsigned long parsed;
    char *end;
    int config_fd, stats_fd, events_fd, cpus, err, rc = 1;
    double start, now;

    if (argc != 3) {
        fprintf(stderr, "usage: %s switches.bpf.o HOST_TGID\n", argv[0]);
        return 2;
    }
    errno = 0;
    parsed = strtoul(argv[2], &end, 10);
    if (errno || *end || end == argv[2] || parsed == 0 || parsed > INT_MAX) {
        fprintf(stderr, "HOST_TGID must be a positive Linux process ID\n");
        return 2;
    }
    target = (__u32)parsed;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGINT, &action, NULL) || sigaction(SIGTERM, &action, NULL)) {
        perror("sigaction");
        goto cleanup;
    }

    obj = bpf_object__open_file(argv[1], NULL);
    if (!obj) {
        perror("bpf_object__open_file");
        goto cleanup;
    }
    err = bpf_object__load(obj);
    if (err) {
        fprintf(stderr, "load failed: %d; inspect libbpf/verifier diagnostics\n", err);
        goto cleanup;
    }
    config_fd = bpf_object__find_map_fd_by_name(obj, "config");
    stats_fd = bpf_object__find_map_fd_by_name(obj, "counters");
    events_fd = bpf_object__find_map_fd_by_name(obj, "events");
    prog = bpf_object__find_program_by_name(obj, "on_switch");
    if (config_fd < 0 || stats_fd < 0 || events_fd < 0 || !prog) {
        fprintf(stderr, "required object maps or program missing\n");
        goto cleanup;
    }
    if (bpf_map_update_elem(config_fd, &key, &target, BPF_ANY)) {
        perror("set target before attach");
        goto cleanup;
    }
    cpus = libbpf_num_possible_cpus();
    if (cpus <= 0) {
        fprintf(stderr, "possible CPU query failed: %d\n", cpus);
        goto cleanup;
    }
    values = calloc((size_t)cpus, sizeof(*values));
    if (!values) {
        perror("allocate per-CPU values");
        goto cleanup;
    }
    rb = ring_buffer__new(events_fd, on_event, &consumer, NULL);
    if (!rb) {
        perror("ring_buffer__new");
        goto cleanup;
    }
    link = bpf_program__attach_tracepoint(prog, "sched", "sched_switch");
    if (!link) {
        perror("attach sched:sched_switch");
        goto cleanup;
    }
    start = monotonic_seconds();
    if (start < 0) {
        perror("clock_gettime");
        goto cleanup;
    }
    while (!stop) {
        now = monotonic_seconds();
        if (now < 0) {
            perror("clock_gettime");
            goto cleanup;
        }
        if (now - start >= 10.0)
            break;
        err = ring_buffer__poll(rb, 100);
        if (err < 0 && err != -EINTR) {
            fprintf(stderr, "ring poll failed: %d\n", err);
            goto cleanup;
        }
    }
    /* Detach before draining and reading final per-CPU values. */
    err = bpf_link__destroy(link);
    link = NULL;
    if (err) {
        fprintf(stderr, "detach failed: %d\n", err);
        goto cleanup;
    }
    do {
        err = ring_buffer__consume(rb);
    } while (err > 0);
    if (err < 0) {
        fprintf(stderr, "ring drain failed: %d\n", err);
        goto cleanup;
    }
    if (bpf_map_lookup_elem(stats_fd, &key, values)) {
        perror("read per-CPU counters");
        goto cleanup;
    }
    for (int cpu = 0; cpu < cpus; cpu++) {
        seen += values[cpu].seen;
        failed += values[cpu].reserve_failed;
    }
    printf("seen=%" PRIu64 " reserve_failed=%" PRIu64
           " received=%" PRIu64 " malformed=%" PRIu64 "\n",
           seen, failed, consumer.received, consumer.malformed);
    if (seen != failed + consumer.received || consumer.malformed) {
        fprintf(stderr, "accounting mismatch: inspect lifecycle, ABI, and consumer errors\n");
        goto cleanup;
    }
    if (!seen)
        fprintf(stderr, "zero matches: verify host TGID, workload, and attach interval\n");
    rc = 0;

cleanup:
    bpf_link__destroy(link);
    ring_buffer__free(rb);
    bpf_object__close(obj);
    free(values);
    return rc;
}
