#ifndef GOLAB_EBPF_EVENTS_H
#define GOLAB_EBPF_EVENTS_H

#include <linux/types.h>

struct event {
    __u64 ts_ns;
    __u32 tgid;
    __u32 tid;
    __u32 cpu;
    __u32 reserved;
};

struct stats {
    __u64 seen;
    __u64 reserve_failed;
};

_Static_assert(sizeof(struct event) == 24, "event wire format changed");
_Static_assert(sizeof(struct stats) == 16, "per-CPU value stride changed");

#endif
