// SPDX-License-Identifier: GPL-2.0
#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>
#include "events.h"

struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, __u32);
} config SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, struct stats);
} counters SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 20);
} events SEC(".maps");

SEC("tracepoint/sched/sched_switch")
int on_switch(void *ctx)
{
    __u32 key = 0;
    __u64 pid_tgid = bpf_get_current_pid_tgid();
    __u32 tgid = pid_tgid >> 32;
    __u32 *target = bpf_map_lookup_elem(&config, &key);
    struct stats *s;
    struct event *e;

    (void)ctx;
    if (!target || *target == 0 || tgid != *target)
        return 0;
    s = bpf_map_lookup_elem(&counters, &key);
    if (!s)
        return 0;

    /* Atomic updates make this example independent of a no-reentry claim. */
    __sync_fetch_and_add(&s->seen, 1);
    e = bpf_ringbuf_reserve(&events, sizeof(*e), 0);
    if (!e) {
        __sync_fetch_and_add(&s->reserve_failed, 1);
        return 0;
    }

    e->ts_ns = bpf_ktime_get_ns();
    e->tgid = tgid;
    e->tid = (__u32)pid_tgid;
    e->cpu = bpf_get_smp_processor_id();
    e->reserved = 0;
    bpf_ringbuf_submit(e, 0);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
