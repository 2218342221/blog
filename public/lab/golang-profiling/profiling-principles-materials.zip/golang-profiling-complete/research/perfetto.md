# Perfetto：从共享内存采集到可解释的时序查询

本章固定研究 Perfetto **v58.2**，提交 `add693d8b338ba9599dbcbc3e300b1ab8c000897`，查证日期为 2026-10-04。源码位置均对应该提交；运行验证使用同版本官方 Linux amd64 Trace Processor。Go 格式与转换链路的源码分析固定在 Go 1.25.0，实际原生 trace 负例由本机 Go 1.22.12 生成。版本、教学构造与真实执行分别记录，避免把兼容性判断推广到所有历史或未来版本。[pf-release][pf-go-main][pf-validation]

## 1. 测量契约：Perfetto 能保留什么，不能凭空得到什么

Perfetto 是由采集协议、数据源、服务、文件格式、Trace Processor 和界面组成的系统。只打开界面并不意味着已经采集了调度事件；成功读取一个文件也不意味着文件里存在所需的因果证据。学习时应首先确定观察对象、事件来源、时间域、身份、完整性和归因规则，然后才选择图表。其核心价值是把多个来源的事件放到可查询的时间关系中，而不是把任何性能文件自动变成“根因”。[pf-service][pf-architecture]

Linux perf、pprof 与 Perfetto 所处的层次有交集。Linux perf 通常接入内核性能事件机制，处理计数、采样或跟踪；pprof 主要分析带栈、标签和类型的聚合权重；Perfetto 擅长接入多种时序数据并进行关联分析。Perfetto v58.2 的内置导入器确实包括 perf.data 和 pprof，但“支持输入格式”不等于“重新获得生产者没有记录的事实”。同一套界面可以显示聚合调用栈与线程时间线，这两者的证据强度仍不同。[pf-importers][pf-pprof]

设一个请求起止为 $[a,b)$，墙钟延迟为 $W=b-a$。若已经知道各线程哪些执行区间属于该请求，则总 CPU 成本为这些区间长度的和 $C$。多核并行时可以有 $C>W$；某个请求长时间等待时也可以有 $C\ll W$。CPU 成本回答资源消费，墙钟延迟回答完成时间，关键路径回答哪些前后依赖限制完成。这三个问题不能通过换一种可视化布局互相替代。

本章贯穿案例使用合成的、符合 ftrace 文本格式的 `sched_switch`、`sched_waking` 与 `tracing_mark_write` 事件，再交给官方程序真实解析。请求从 0 到 20 ms；主线程运行 0—4 和 16—20 ms，4—6 ms 可运行但未获调度，6—16 ms 睡眠；工作线程在另一 CPU 上运行 1—16 ms。因此主线程 CPU 为 8 ms、工作线程为 15 ms、请求总 CPU 为 23 ms。这个值与 20 ms 墙钟时间没有矛盾。[pf-request]

此例中的线程归属是教学模型显式给定的。真实线程池可同时处理多个请求，不能把“请求期间所有工作线程的 CPU”全部算给这个请求；OS 线程也可能运行多个 Go goroutine。应用阶段、请求标识与调度事实之间必须有可解释的连接。后文将通过区间相交查询计算已归属阶段的成本，而不会把时间重叠当作自动归因。

把关键路径形式化，可以将已证实的阶段与依赖构成有向无环图，节点权重是该阶段持续时间，完成时间受最长依赖链约束。并行分支的资源成本相加，汇合点的完成时间则取受依赖约束的最晚完成者。若依赖边遗漏，计算出的最长路径只是已有证据下的结果，不能声称覆盖真实请求。时间先后是必要线索，仍不能单独证明因果关系。

## 2. Producer、service 与 consumer：把热路径和会话控制分开

Producer 注册数据源并生成事件；consumer 配置与控制采集会话、读取数据；tracing service 居中管理连接、数据源生命周期、会话与中央缓冲区。一个 producer 通常对应一个进程，但同一进程可以有多个独立 producer；每个 producer 有自己的共享内存缓冲区 SMB，由它与 service 共享，同一 producer 内的数据源共同使用它。不能画成所有进程任意访问同一块可写内存。[pf-service]

典型 Unix 连接把控制面和数据面分开。启停、注册、配置、提交通知等走 IPC；事件序列化主要直接写入 SMB，避免每条事件都进行一次普通消息往返。service 收到 commit 后将完成的 chunk 拷入其私有中央缓冲区。这里减少的是 producer 侧的额外临时序列化与消息拷贝，**不是端到端零拷贝**。使用不支持共享内存的远程传输时，协议允许在 commit 中直接携带 chunk 字节；那是另一条数据路径。[pf-service][pf-commit]

这种边界首先是所有权与可信度的安排。应用 producer 可能退出、迟迟不交付，甚至给出非法标识和长度；service 不能把共享内存的内容天然当作可信。`CopyChunkUntrusted` 路径检查提交者可写入的目标缓冲区，并在中央记录中保留由服务侧确定的 producer 身份。数据里的一个数值 ID 不是访问其他会话缓冲区的授权凭证。私有中央存储也使服务能在 producer 回收 SMB 后继续保存数据。[pf-service-impl][pf-buffer-v1]

一次正常会话可以理解为：consumer 给出配置；service 找到匹配 producer 的数据源并下发设置；producer 创建写入器并生成数据；服务收取 chunk；consumer 停止、等待有关完成通知并读取结果。实际实现还涉及延迟启动、并发会话、超时、断连以及退出前 scraping，不能假定所有应用在开始与结束时刻同时停下。诊断结论需要检查真正覆盖的时间边界，而非只相信请求采集的时长。[pf-service][pf-service-impl]

读取中央缓冲区通常会推进读游标，不是对同一状态进行无限次幂等查询。后续 SQL 查询针对的是 Trace Processor 已导入的数据，与 consumer 对服务缓冲区的消费操作属于两层。前者可反复运行；后者会影响后续保留、读出与缺口行为。这一区别尤其影响长期流式写文件时的容量计算。[pf-buffer-v1]

**图 1：进程边界与所有权。** 左侧画 producer A、B 两个独立框，各框内包括两个 writer 和一块 SMB；中间画 service 及其私有 buffer 0、1；右侧画 consumer、文件、Trace Processor。实线粗箭头表示 SMB 到中央缓冲区的字节拷贝，细虚线表示配置与 commit 通知。SMB 只跨越所属 producer 与 service 的边界；不要把 A、B 的地址空间连在一起。图下注明远程共享内存模拟使用 IPC 承载数据，是可选分支。[pf-service][pf-commit]

## 3. 共享内存协议：页、chunk、分片与延迟补丁

SMB 是生产者到服务之间的**暂存区**，不是整份 trace 的保留区。其页尺寸在 producer 连接期间固定，要求为 4 KiB 的倍数并有上限；页可按有限方案分成若干 chunk，ABI 最多支持每页 14 个 chunk。页头描述布局与 chunk 状态，chunk 头携带 writer、序号、分片等信息。不能把这里的页直接等同于操作系统缺页单位，也不能任意选择每页一百个小 chunk。[pf-shmem]

一个 chunk 正常由单个 writer 独占写入，常对应一条线程本地事件流。writer 在已取得的 chunk 内前移写指针，像 arena 一样追加数据；用完后申请下一个 chunk，才需要进入生产者内部的协调路径。这个设计使常见写入避免每条事件争用全局锁，但并不意味着整个 SDK、IPC 或分配路径完全无锁。[pf-shmem][pf-arbiter][pf-writer]

完成 chunk 的典型状态转移是 `Free → BeingWritten → Complete → BeingRead → Free`。writer 取得空闲所有权后写字节，发布完成状态；service 取得可读所有权并拷贝，随后释放。状态发布与获取承载跨线程、跨进程的可见性要求，不能只把它当作几个普通布尔字段。共享内存模拟不采用完全相同的 BeingRead 路径；某些补丁优化还会延长 BeingWritten 状态，因此该图表示正常交付的主路径，不是穷尽所有内部转移。[pf-shmem][pf-arbiter]

TracePacket 与 chunk 没有一一对应关系。一个 chunk 可以包含多个小 packet，一个大 packet 也能跨多个 chunk，甚至在服务持续搬运且策略允许时大于整个 SMB。读取端必须收齐 packet 的有关片段才可交付；“已写出一个 chunk”不等于“已经获得一个独立可解析的事件”。这也解释了为什么丢失少量字节可能让比它更大的逻辑记录失效。[pf-buffer-v1][pf-writer]

Protobuf 的长度字段造成一个微妙问题：开始写嵌套消息时还不知道最终长度，结束时才能回填。如果嵌套消息跨 chunk，前一个 chunk 可能已经交给 service，甚至其 SMB 位置已被复用。Perfetto 的 writer 为长度预留 varint 空间，记录补丁位置；安全时在本地直接补齐，否则通过 out-of-band patch 修改中央缓冲区中对应 chunk 的预留字节。这是序列化完整性协议，不是允许应用随意修改历史事件含义。[pf-writer][pf-commit]

`CommitDataRequest` 的 `chunks_to_move` 用页号、chunk 号和目标缓冲区定位待搬运数据；`chunks_to_patch` 用 writer ID、chunk ID、偏移和新字节定位补丁。服务先处理 move，再处理 patch，因此同一次消息可包含同一个 chunk 的交付与回填。`has_more_patches` 表示是否仍有补丁待到达；未满足完整条件的 chunk 不能因“看上去已有字节”就被读成最终 packet。目标缓冲区、writer 与 chunk 的身份必须同时正确。[pf-commit][pf-service-impl]

设 packet 的外层长度字段位于 chunk 41，后续内容延伸到 chunk 42。写完 41 时只能交付第一段并标记待补；写完 42 后知道总长度，把补丁发往 41，再允许组装读取。若中央 ring 已覆盖 41，补丁不能复活丢失内容；系统必须保留缺口或丢弃不完整 packet。此例说明 commit 是缓冲区交接，patch 是完成编码，二者都不是应用事务提交。[pf-buffer-v1][pf-commit]

SMB 满时，writer 需要在数据损失和应用扰动之间选择。v58.2 包含 `kDrop`、`kStall` 和 `kStallThenDrop`：丢弃让应用继续但留下观测缺口；等待可降低瞬时损失却把诊断系统的拥塞传递给应用；先等后丢是折中。还必须区分等待策略的失败边界：这一固定实现的 stall 计数阈值为 300；持续耗尽达到阈值时，`kStall` 进入 `PERFETTO_FATAL`，而 `kStallThenDrop` 返回无效 Chunk。因此 `kStall` 不承诺无限等待，应用扰动也不只限于延迟增加。该阈值是此版本的实现细节，不能当作稳定 API 或固定超时时间。源码特别处理等待时推进 pending commit 的问题，因为服务和 producer 的 IPC 线程若不能获得进展，简单循环等待空块并不安全。不能把“无丢失模式”当作没有代价的配置。[pf-arbiter]

**图 2：chunk 所有权状态机。** 四个节点按上述状态成环，writer 负责 Free 到 Complete，service 负责 Complete 到 Free。节点下分别注明可写、不可继续写、可被拷贝、可复用；旁注直接补丁与共享内存模拟为例外路径。**图 3：跨 chunk 补长度。** 两行分别画 SMB 与中央缓冲区，时间从左到右；packet 跨 41、42 两块，长度位置画成空格。先画 move 41，再画 move 42 与 patch 41，最后画完整 packet 输出；另加“41 已覆盖则无法恢复”的失败分支。[pf-shmem][pf-commit]

## 4. 中央缓冲区、配置与三层数据损失

v58.2 默认使用 TraceBufferV1；V2 是需显式选择的实验模式。本章依据 V1 分析中央缓冲区，不能把 V2 的新标志或恢复行为泛化到所有采集。V1 拷贝 chunk payload，重新打包带可信 producer 身份的头部，以 16 字节对齐存放，并用 `(ProducerID, WriterID, ChunkID)` 建立索引。这些额外结构会占空间，所以文件或缓冲区容量不能全部视为事件有效负载。[pf-config][pf-buffer-v1]

`RING_BUFFER` 保留较新的数据：写指针追上未读区时按完整 chunk 覆盖旧内容。`DISCARD` 保留较早的未读数据，空间不足后拒绝新写入。V1 还有容易漏掉的细节：一旦第一次 discard 打断序列，后续写入会持续成为 no-op，即使读者后来追上也不自动恢复为普通可写状态。这不是一个“读快一点就自然恢复”的通用有界队列。[pf-buffer-v1]

中央存储按实际 commit 次序放置 chunk，不保证来自不同 writer 的全局时间顺序。读取时会按各 writer 的 chunk 序号重组 packet、检查碎片与缺口，保证单序列次序；跨 writer 的事件时间排序留给后续处理。某条序列有 1、2、5、6 时，缺口可阻止读者直接把后缀当作连续记录；旧前缀被读走或覆盖后，可读性也会变化。因此“缓冲区里还存在字节”和“现在能输出完整 packet”不是同一个问题。[pf-buffer-v1]

配置应由问题反推。研究尾部卡顿倾向 ring；必须观察启动过程时可能选择 discard；高频调度与低频应用事件可分到不同中央缓冲区，避免前者冲掉后者。下面只展示缓冲区与增量状态政策，实际数据源仍须在相应平台注册并接收配置：

```text
buffers { size_kb: 16384 fill_policy: RING_BUFFER }
buffers { size_kb: 4096  fill_policy: DISCARD }
duration_ms: 20000
incremental_state_config { clear_period_ms: 1000 }
```

数据源通过 `target_buffer` 或受支持的名称引用选择目的地。周期性增量清理只通知声明支持该能力的数据源，不能强迫任意 producer 重新发送所有历史状态。中央缓冲区大小也不是 producer SMB 大小，调整前者不能直接修复后者的瞬时拥塞。[pf-config]

第一层损失发生在内核各 CPU 的 ftrace buffer：探针产生事件后，用户态 `traced_probes` 来不及读取就可能覆盖。第二层发生在 producer SMB：服务调度延迟或突发写入超过暂存能力。第三层发生在中央缓冲区及其流式落盘过程：容量和读取频率不足，旧内容被覆盖或新内容被拒绝。三层处于不同位置，增大最后一层并不能追回第一层已丢失的 `sched_switch`。[pf-buffers]

容量估算要同时看平均速率、峰值和最长不可服务时间。中央 16 MiB、平均 2 MiB/s 时，粗略保留窗口为 $16/2=8$ s，尚未扣除头部、填充与速率波动。若每 5 s 才排空一次，理论产生量为 10 MiB，实际预算还需余量。SMB 峰值 8 MiB/s、服务暂停 10 ms 时，需要约 $8\times0.010=0.08$ MiB，即 81.92 KiB 的暂存余量；计算应使用峰值而不是全天平均。[pf-buffers]

反例更能揭示风险：每 10 s 突发写入 2 MiB，平均仅 0.2 MiB/s，但 256 KiB SMB 只有单次突发的八分之一。若突发足够快、服务无法同步排空，仍会溢出。这里 256 KiB 是教学假设，不宣称是所有 SDK、后端或版本的默认值。不同官方文档对默认 SMB 的描述有差异，工程配置应读取实际连接参数，而不从一个文档段落猜测。[pf-buffers][pf-service]

导入后应查询 `stats`。先检查 `severity='data_loss' AND value!=0`，再单独关注 `ftrace_cpu_overrun_end`、`traced_buf_trace_writer_packet_loss`、`traced_buf_chunks_overwritten`、`traced_buf_chunks_discarded` 和增量状态失效统计。仅过滤 data_loss 并不充分：官方文档示例中的 chunks_discarded 为 info，而 ring 覆盖即使符合既定政策，也可能缩短所需分析窗口。统计字段还是计数、字节数或每 CPU 指标，也应分别解释，不能把不同单位相加成“总丢失率”。[pf-buffers][pf-reader]

Flush 要求有关 producer 推进待提交数据并回报完成状态；它不是让所有应用在同一时刻冻结，也不是磁盘 fsync 的持久化承诺。超时、producer 退出后的 scraping 可以改善尾部可见性，却无法制造未记录的事件。最后应同时核对请求的配置、服务确认、Trace Processor 统计以及分析窗口是否闭合。[pf-service-impl]

**图 4：三层容量与两种保留政策。** 上半部串联每 CPU ftrace、producer SMB、中央 buffer，箭头标各自产生率与排空率；分别把 overrun、writer loss、overwrite/discard 放在对应节点。下半部用六个等宽块表示时间递增数据，容量四块，展示 ring 最终保留 3—6、discard 保留 1—4。注明中央块只是示意，真实 packet 可跨块且依赖字典，不能直接把四块等同于四段完整可读时间。[pf-buffers][pf-buffer-v1]

## 5. TrackEvent、字典状态与时钟：时间线语义从哪里来

TrackEvent 的 track 表达一条逻辑事件流。线程 track 适合线程内同步嵌套；自定义 track 可以表达跨线程请求的整体生命期；counter 表达数值变化；flow 表达阶段间的关联。设计埋点时应先区分“请求存在了多久”和“线程何时执行哪个阶段”。跨线程请求可以有一条自定义请求 track，再在各线程 track 中记录执行阶段，以 flow 标记派发与交接。[pf-trackevent]

把两个并行执行流放到同一条按栈嵌套的 track，可能制造并不存在的父子包含关系；把 begin 写到线程 A、end 写到线程 B，也不能默认得到正确同步嵌套。不同并行流通常应分轨，并明确关联标识的作用域。flow 箭头记录的是生产者声明的连接，单凭相同 ID 不能证明依赖完整、工作独占或该边一定在关键路径上。埋点语义是分析证据的一部分，不是画图以后自动产生的事实。[pf-trackevent]

频繁重复的名字、类别、栈或默认字段不必每个 packet 都写全。producer 可以先 intern 字符串，后续用整数引用；也可使用增量时间和默认 track 等状态来减小编码成本。这里的 ID 作用于特定 packet sequence，不能把 writer A 的字符串 7 与 writer B 的字符串 7 当作同一个名字。同一 writer 清理增量状态后，也可能重新使用编号。[pf-packet][pf-reader]

`trusted_packet_sequence_id` 帮助识别序列，`SEQ_INCREMENTAL_STATE_CLEARED` 表示状态重建边界，`SEQ_NEEDS_INCREMENTAL_STATE` 表示该 packet 依赖之前状态。读者发现前序丢失后，会把相应状态标记为无效；需要该状态的后续 packet 可能被跳过，直到清理与重建恢复可解释性。`previous_packet_dropped` 在序列开始处也可能保守出现，不能把每次标记都机械计作一次已证实的物理丢包。[pf-packet][pf-reader]

因此，压缩比和可恢复性存在直接权衡。字典引用越多，稳态编码越紧凑，但 ring 覆盖字典后会留下不可解释的后缀。若缓冲区保留原始字节 8 s，期间最近一次有效状态重建只覆盖后 6 s，可使用窗口就不应仍宣称为完整 8 s。周期清理能够缩短某些恢复等待，却增加重发成本，且依赖数据源实现；不能保证任何丢失都在一个周期内无条件恢复。[pf-config][pf-reader]

时间戳也需要状态。不同源可能使用 BOOTTIME、MONOTONIC、REALTIME 或自定义时钟。MONOTONIC 与 BOOTTIME 对系统休眠的处理不同，REALTIME 可能被校时改变；两个主机的同名时钟也没有天然共同零点。Perfetto 用 ClockSnapshot 建立时钟之间的对应关系，内置 ID、自定义全局 ID 和 sequence-local ID 具有不同作用域。序列局部时钟号不能脱离序列身份解释。[pf-clocks][pf-reader]

假设同一快照记录时钟 A 为 1000、B 为 2100，在适用区间内只按偏移换算，则 A 上 1104 对应 B 上 2204。这个四则运算示例不证明两个时钟永远同速，也不证明不同主机间已准确同步。漂移、快照稀疏、映射不连通与时钟跳变都会影响对齐。读者应检查可用同步关系与时间范围；源码对暂缺映射的 packet 可以延后处理，最终仍无法转换的情况会记录失败，不能悄悄把它当作纳秒零点相同。[pf-clocks][pf-reader]

对时钟精度还应给出误差预算。若两个已换算时刻的误差上界分别为 $\epsilon_1$、$\epsilon_2$，其差值的保守误差上界为二者之和。一个 5 微秒的阶段，若同步误差也在数微秒量级，就不宜据此断言跨源事件的严格先后。数据库统一使用纳秒单位只规定数值尺度，不意味着采集、同步与重建都有一纳秒精度。

**图 5：保留字节与可解释窗口。** 单条 sequence 从左至右画“重建字典—引用—引用—重建—引用”，ring 左边界切掉第一次字典。边界后的两条依赖事件用斜线遮盖，第二次重建后的事件保持正常；下方分别标原始字节窗口与可解释窗口。再画另一 sequence 正常解析，强调一个 writer 失效不代表所有事件都失效。[pf-packet][pf-reader]

## 6. Trace Processor：先恢复语义，再排序、建表与计算

Trace Processor 的输入处理不是“拿到 JSON 就插入 SQLite”。v58.2 的格式识别由 importer registry 管理，按检测优先级调用各导入器的 Sniff；具体可用集合还受构建配置和插件注册影响。压缩、容器和内部格式可能形成多层处理。官方架构文档能解释总体分工，但部分函数位置已变化，源码分析应沿本版本实际入口追踪，而不照抄旧图中的路径。[pf-detection][pf-importers][pf-architecture]

对于 Perfetto protobuf，tokenizer 处理外层字节与解压等工作，`ProtoTraceReader` 负责关键的 packet 语义：识别 sequence、处理丢失与增量清理、更新 defaults 与 interned data、处理时钟快照，再把带相应状态代际的 token 交给排序器。不能先把所有裸 packet 按 timestamp 排序，再解释字典；文件顺序中出现的清理可能导致相同 ID 在后一个代际变成另一个字符串。[pf-reader]

设 sequence S 第一代定义 `7=Parse`，事件 E 的 timestamp 为 20；随后清理并在第二代定义 `7=Encode`，事件 F 的 timestamp 为 10。不同时间来源或迟交付会让事件时间与输入顺序不完全一致。读者先按输入推进代际，把 E 绑定第一代、F 绑定第二代，再按时间输出 F、E。若只保存一个可变全局字典，E 可能被错误命名为 Encode。源码传递 `current_generation()` 正是维持这种解释上下文。[pf-reader][pf-sequence]

排序器按输入流维护队列，对需要的未排序后缀进行排序，再合并抽取合适的最早事件交给解析器。这样可以利用流内大体有序的性质，又允许跨流到达顺序不同；超出预期的乱序还需要被记录。最终 parser 或 tracker 根据事件重建 slice、进程线程身份、调度状态等语义记录。输入分块读取不意味着总内存恒定：排序可能需要暂存很多事件，导入后的列存储也会增长，pprof 导入器还会缓存整份 profile。[pf-sorter][pf-pprof]

存储层将大量字段放入专用列式表，重复字符串通过 string pool 共享，再暴露给 SQL 分析层。这样适合按时间、身份、状态和数值进行扫描与连接，不应描述成每个原始字节都转成普通 SQLite 行，也不能据此承诺所有查询零拷贝。表名与视图随版本演进；本章实际 v58.2 查询使用 `sched_slice`，另有 `slice`、`thread_state`、`thread_track`、`thread`、`process`、`counter`、`flow`、`args`、`stats` 等语义入口。[pf-storage][pf-request]

进程线程关联应使用 `upid`、`utid` 等生命周期身份。原始 pid、tid 可能复用，跨越较长 trace 时按裸 tid 连接会把不同线程实例合并。自定义逻辑 track 也不必然对应一个 OS 线程；必须先通过 track 类型和相应映射确认。查询字段看似都是整数，只说明数据库类型相同，不说明它们属于相同身份空间。[pf-storage][pf-thread-state]

调度状态来自事件重建：`sched_switch` 结束旧线程的 Running，按 prev_state 开始它的新状态，并为切入线程打开 Running；waking 将适用的阻塞状态转为 runnable。已经 running 或 runnable 的线程再次收到唤醒，不应简单重置成一次新的等待起点。缺失事件、首尾不闭合都可能造成未知状态，因此查询必须处理负持续时间或边界不完整，而不是无条件对全表求和。[pf-thread-state]

下面是配套已执行查询的核心。先定位请求 slice，再将主线程状态与请求窗口相交；`dur>=0` 排除未完成区间，重叠谓词确保交集为正，纳秒除以 $10^6$ 转为毫秒。在真实工作负载中，`tid=101` 这样的教学筛选应换成已验证的线程生命周期和阶段归属。[pf-request]

```sql
WITH request_window AS (
  SELECT s.ts AS lo, s.ts+s.dur AS hi
  FROM slice s JOIN thread_track tt ON s.track_id=tt.id
  JOIN thread t ON tt.utid=t.utid
  WHERE s.name='request' AND t.tid=101 AND s.dur>=0
), clipped AS (
  SELECT st.state, MIN(st.ts+st.dur,w.hi)-MAX(st.ts,w.lo) AS ns
  FROM thread_state st JOIN thread t USING(utid)
  CROSS JOIN request_window w
  WHERE t.tid=101 AND st.dur>=0
    AND st.ts<w.hi AND st.ts+st.dur>w.lo
)
SELECT state,SUM(ns)/1e6 AS ms FROM clipped GROUP BY state;
```

真实解析结果为 Running 8 ms、R 2 ms、S 10 ms，合计主线程窗口 20 ms。`R` 表示具备运行条件，不代表已经消耗 CPU；`S` 是本例的可中断睡眠状态，不是自动识别出的“等待哪个 Go channel”。应用的 `join_wait` slice 为 10 ms，调度状态提供其睡眠事实，两者互相补充。Go goroutine 的 runnable 则属于运行时调度层，不能与 OS 线程 R 直接画等号。[pf-thread-state][pf-request]

对 `sched_slice` 使用同样相交公式，教学指定的 main 与 worker 分别为 8、15 ms，总和 23 ms。关键路径不能取它们的简单总和：worker 1—16 ms 与 main 前段存在并行，main 后段要等 worker 完成。仅靠线程状态没有完整业务依赖；本例由明确的派发、等待和完成语义补足。实际场景应为每个归属阶段定义窗口，与调度区间相交，并把无法覆盖的时间单独记为未知，而不是强行归到等待或 CPU。

区间连接还要防止重复计费。若同一请求有嵌套的外层阶段和内层阶段，将二者同时与调度表相交再求和，会把相同 CPU 片段计两次。计算请求总成本时应选择互斥阶段，或者先求已归属执行窗口的并集；计算阶段 inclusive 成本则可以保留嵌套，但必须声明不能再把各行直接相加。多条同名 request slice 也应按实例分组，而不是用名字把所有窗口混成一个集合。

缺失一次切换事件的影响也不局限于一行。状态机依赖相邻边界关闭区间，一个边界缺失可能让之后的区间含义不确定。把不完整行过滤掉能避免明显错误，却不会自动补齐覆盖。因此最好同时输出已知 Running、Runnable、Sleeping 的交集长度，以及分析窗口中未被有效状态覆盖的长度；只有覆盖关系成立时，才能要求它们相加恰等于墙钟。

**图 6：带状态代际的排序流水线。** 画两个 sequence 输入，各自先经过字典/时钟恢复节点，再生成标有 generation 的事件，汇入全局时间合并，最后进入 parser、列存储与 SQL。用 `7=Parse` 和 `7=Encode` 展示编号复用，禁止在合并之后只接一张全局可变字典。**图 7：请求墙钟与 CPU。** 横轴 0—20 ms，画请求、main 状态、worker 状态三条泳道；main 绿色 0—4、16—20，黄色 4—6，蓝色 6—16，worker 绿色 1—16。下方并列列出 Wall=20、CPU=23、主线程 R=2、S=10；绿色必须注明 CPU 执行，不能按片段长度自动暗示函数调用精确耗时。[pf-reader][pf-sorter][pf-request]

## 7. Go trace、Chrome JSON、pprof 与 traceconv 的兼容边界

Go runtime trace 具有自己的版本化二进制编码，Go 1.25 源码明确使用 `go 1.%d trace\x00\x00\x00` 文件头。它不是 Perfetto Trace protobuf，也不是 Chrome Trace Event JSON。v58.2 的内置 importer 工厂有 protobuf、JSON、systrace、perf.data、pprof 等入口，没有相应原生 Go runtime trace 工厂。浏览器最终能显示某些相似泳道，不代表底层文件可以直接互换。[pf-go-header][pf-importers]

配套负例真正运行 Go 1.22.12，生成头部为 `go 1.22 trace\x00\x00\x00`、大小 1727 字节的原生文件，再交给官方 v58.2 Trace Processor。程序退出码为 1，报 `Unknown trace type provided (ERR:fmt)`。这验证了本版本和本输入的直接导入不成立；不是以扩展名或静态猜测替代运行，也不声称证明所有第三方转换方案均不可用。[pf-validation]

`go tool trace` 自己先解码 Go runtime 事件，再生成浏览器视图。Go 1.25 的 `/jsontrace` 处理器支持线程视图、goroutine/task 聚焦以及范围选择，输出采用 Chrome Trace Event 的 `traceEvents`、`ph`、`ts`、`dur`、`pid`、`tid` 等字段。若要走这一桥接，应记录生成所用 Go 版本、选择的视图与范围，获取实际 viewer JSON，再用目标 Perfetto 验证所保留事件，而不能把原始 `.trace` 改名 `.json`。[pf-go-json][pf-go-format]

视图转换存在语义损失。Go viewer 可把 P、goroutine 或其他逻辑实体安排为泳道，JSON 的数字 `tid` 不必等于内核 OS TID；拿它与 `sched_slice` 的原始 tid 直接连接，可能得到看似完整的错误结论。已转换的 slice/flow 也不自动保留原始 runtime trace 的全部调度约束、栈、任务关系和未展示事件。能够显示这些视图，不等于 Trace Processor 获得 Go 专用语义分析器。[pf-go-json][pf-go-format]

Go 1.25 命令行的 `-pprof=net|sync|syscall|sched` 会从 trace 派生相应 pprof 类权重；它们不是通用 CPU profile，转换后也不再保留完整事件顺序。`-d` 的 wire、parsed、footprint 是调试输出模式，不是标准 Chrome JSON 导出开关。教程应区分“调试文本”“浏览器 JSON”与“派生聚合 profile”，避免只因三者都能重定向到文件就称为同一种 trace。[pf-go-main]

另一方面，**Perfetto v58.2 的确能直接导入 pprof**。读取器解析映射、函数、位置和内联符号；为每个 sample type 建立 aggregate profile，按 pprof 的叶到根 location 顺序反转构建调用位置树，再将各 value 写入 aggregate sample。该路径保留类型与单位，不会读取 Period 后再次乘周期；它也不会由聚合值恢复逐事件时间或调度区间。[pf-pprof]

实际教学 `request.pprof` 中的 cpu/nanoseconds 权重 4,000,000、15,000,000、4,000,000 被真实 v58.2 导入原值；查询 `__intrinsic_aggregate_profile` 与 `__intrinsic_aggregate_sample` 成功，而 `sched_slice` 和 `slice` 行数均为零。内部表名适合本版本核验，不能作为永久稳定公共 API 的承诺。这个实验比“能不能打开”更强：它同时检查了保留的信息和没有产生的信息。[pf-validation]

转换仍需审计：本版本 pprof 读取路径没有处理每个 sample 的 labels；将 int64 权重转换为 double，超过 $2^{53}$ 后整数精确性可能下降。原文件中业务标签是否重要、整数是否可能很大，都影响这个分析入口能否满足任务。`traceconv json`、`traceconv profile` 是支持数据的输出转换模式，不是任意格式输入解码器，也不能把已经聚合的 pprof 逆变换成真实调用时间线。[pf-pprof][pf-traceconv]

**图 8：Go 与 Perfetto 的信息通路。** 顶部分支为“Go 原始 trace → Go 解码器 → viewer JSON → Perfetto 通用视图”，每条转换边写明视图筛选与语义降维；原始 trace 到 v58.2 直接导入的边以叉号表示本例失败。下部分支为“pprof → aggregate profile/sample”，旁边列出保留类型、单位、调用位置和权重，未恢复时间顺序和调度；从 aggregate 表指向 sched 表的反向箭头必须删除。另画 Go trace 到派生 pprof 的单向边，强调这是汇总。[pf-go-json][pf-pprof][pf-validation]

## 8. 可复现实验、误读检查与研究练习

复现实验先固定源码与可执行文件身份。配套保存 v58.2 tag、完整提交、release 资料和下载校验；官方 Linux amd64 ZIP 的 SHA-256 为 `32c739f71b2d39721afd294c0b038f2499a44a71b5b6bcdd85b83faca0b240b9`。运行 `--version` 返回同一完整提交。一个值得警惕的实际发现是：此源码 tag 内的 Python `tools/trace_processor` launcher 仍引用 v57.2 下载产物，因此“脚本来自 v58.2”不能替代对最终二进制的版本检查。[pf-release][pf-launcher][pf-validation]

在材料包根目录执行 `python3 examples/request/verify_perfetto.py`，脚本生成合成 ftrace，通过真实 Trace Processor 运行状态、CPU、slice 和 stats 查询，检查八项断言。`verification/request-perfetto.json` 保存版本、输入摘要、原始 SQL、退出状态、标准输出与解析结果；`verification/go-trace-import.json` 保存原生 Go 负例；`verification/pprof-perfetto-import.json` 保存聚合导入。这里验证的是解析与口径，不是生产环境开销，也没有实测 SMB 压力和内核过载。[pf-request][pf-validation]

对真实服务重复实验时，应补三类证据：启用哪些数据源和类别、采集窗口与线程身份；观察到哪些丢失和状态恢复；应用阶段如何映射到请求。只有这些条件清楚，SQL 数字才可用于比较。比如优化后 CPU 降低而延迟上升，可能来自并发度、排队或工作量改变；应检查相同工作量下的分布和请求分组，不把一次时间线当作整个服务的统计结论。

常见误读可按证据边界逐项纠正：SMB 不是最终保留文件；减少 writer 拷贝不是端到端零拷贝；Flush 不是全局暂停或 fsync；已有完整字节不代表增量字典仍可解释；flow ID 不是独占归因证明；线程 R 不是 CPU 执行，也不是 Go G 的 runnable；总 CPU 大于墙钟不构成错误；Chrome JSON 的 tid 不保证是 OS TID；直接导入 pprof 不会生成调度时间线；过滤所有 error 后没有记录也不能证明完整无丢失。[pf-service][pf-packet][pf-thread-state][pf-pprof]

采集开销本身也应实验检验。在相同负载、固定构建和相近环境下，分别运行关闭采集、仅启用必要类别、加入高频数据源三组，比较吞吐与延迟分布，同时记录输出速率、CPU 和丢失。等待型 SMB 策略可能减少缺口却增加业务停顿，丢弃型策略可能维持吞吐却降低解释覆盖；两者都需要纳入结论。只报告文件很小或界面很流畅，不能证明生产者热路径开销可以忽略。

练习一：把教学中央容量改为 24 MiB、速率改为 3 MiB/s，说明粗略窗口仍为 8 s；再加入每 2 s 一次 1 MiB 字典重发，计算长期平均速率变为 3.5 MiB/s，粗略窗口约 6.86 s，并指出实际瞬时拥塞仍需单独分析。练习二：给 SQL 增加一个 `dur=-1` 的尾部状态，解释为什么排除后应记录未覆盖时间，而不是把结果重新归一到 100%。练习三：令同一 OS 工作线程在请求期间执行另一个请求 3 ms，指出原来的全窗口 CPU 查询会高估归因，应改成已识别阶段窗口求交集。

练习四：丢弃字典重建 packet，但保留随后三个引用事件，区分“物理丢失一条 packet”和“语义不可用多条事件”。练习五：给 pprof 加业务 label 和大于 $2^{53}$ 的整数，比较本版本 aggregate 表与原文件，验证信息保留边界。练习六：为真实 Go 服务同时保存 runtime trace 和 OS 调度数据，设计显式标识与时钟对齐方案，列出仍无法证明的 goroutine 到请求映射，而不要凭名称相似直接关联。完成这些练习，才算掌握从记录协议到诊断结论之间的推理责任。
