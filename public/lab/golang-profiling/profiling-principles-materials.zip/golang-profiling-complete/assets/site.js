/* Offline course UI. No network requests, libraries, or analytics.
 * Optional overrides, set before this script:
 * window.PROFILING_QUIZZES = {"ch-1": {prompt, options: [...], answer: 0, explanation}};
 * window.PROFILING_SCENARIO = {durationMs: 20, main: [{start:0,end:4,state:"Running"}, ...], worker: [...]};
 * Chapter source is never rewritten; UI controls are appended after its content.
 */
(() => {
  'use strict';
  const STORAGE_KEY = 'go-profiling-principles-2026-10-04-v1';
  const PATH_LABELS = [
    ['建立测量模型', '先看清，工具在测什么'],
    ['eBPF · 内核观测', '从验证到事件传输'],
    ['pprof · 聚合剖析', '从采样到权重与热点'],
    ['Perfetto · 时序分析', '从采集到可解释的查询'],
    ['跨工具对照实验', '一个请求，三种视角'],
    ['组合诊断与验证', '让证据回答合适的问题']
  ];
  const DEFAULT_QUIZZES = [
    {
      prompt: '一个请求的墙钟为 20 ms、归属于它的 CPU 合计为 23 ms。最合理的解释是什么？',
      options: ['两个计时结果矛盾，至少有一个工具坏了。', '主线程 main 与工作线程 worker 可以并行执行，CPU 权重相加后可超过墙钟。', 'CPU 的单位应该改成调用次数。', '把 Runnable 和 Sleeping 再加到 23 ms，就得到请求延迟。'],
      answer: 1,
      explanation: '墙钟衡量经过的时间，CPU 衡量各执行单元消耗的计算时间。并行工作可以使总 CPU 超过墙钟；前提是 worker 的工作确实归属于该请求。'
    },
    {
      prompt: '一个 eBPF 程序通过 verifier 后，可以直接得出哪个结论？',
      options: ['采集到的指标一定完整、无偏。', '程序理解了请求之间的因果关系。', '在该内核与程序类型的规则下，它通过了相应的程序安全性检查。', '用户态消费者不可能丢失事件。'],
      answer: 2,
      explanation: 'Verifier 检查程序在相应规则下能否安全执行，不证明测量模型正确、采样覆盖完整或事件传输零损失。观察点、关联键、缓冲和消费者仍需分别检查。'
    },
    {
      prompt: 'pprof 中一个函数的 cum 很大、flat 很小，最稳妥的理解是什么？',
      options: ['它承载许多下游权重，但自身作为可见叶节点的权重较小。', '这个函数调用次数一定最多。', '它的一次调用恰好持续 cum 显示的时间。', '它一定就是应当首先优化的根因。'],
      answer: 0,
      explanation: 'flat 归于可见叶节点，cum 包含经过该节点的样本权重。它们依赖所选维度、粒度和过滤条件；不能直接推导调用次数、单次持续时间或因果根因。'
    },
    {
      prompt: '在调度状态时间线中，操作系统线程处于 Runnable，意味着什么？',
      options: ['它正在 CPU 上执行。', '它已具备运行条件，但还没有获得 CPU 执行。', '它一定在等待网络 I/O。', '它没有属于任何请求。'],
      answer: 1,
      explanation: 'Runnable 与 Running 是不同状态。就绪后的等待调度区间需要由相应的时序状态数据识别；仅凭状态不能补出请求身份或断定等待的全部原因。本例使用内核 sched_switch 的 OS 线程语义，不是 Go G 调度状态。'
    },
    {
      prompt: '贯穿案例中，main 两段工作为 4 ms 和 4 ms，worker 为 15 ms。哪一种说法正确？',
      options: ['main.handle_request 的函数 cum 必须等于整个请求的 23 ms。', 'worker 的 15 ms 应当从 CPU 总量删除。', '以 request=demo 聚合可得到 23 ms；各线程的物理调用栈仍应分别保留。', 'pprof 的三条加权记录足以恢复每一段工作的先后和重叠。'],
      answer: 2,
      explanation: '跨线程的业务归属由明确的 request 标签提供，不能伪造成共同物理调用栈。主栈 cum 为 8 ms、worker 栈为 15 ms；时序与依赖需要另一份证据。'
    },
    {
      prompt: '要把“找到了热点”推进到“这个优化确实有效”，下一步最有说服力的做法是什么？',
      options: ['只保留一张优化后的火焰图。', '把最大的 cum 函数改短，然后直接宣布完成。', '隐藏 unknown 和丢样记录，使图形更整洁。', '写出机制假设，在可比负载下重复测量，并核对业务指标、误差与工具开销。'],
      answer: 3,
      explanation: '热点是线索。可信结论还需要可反驳的机制假设、可比实验、业务工作量口径，以及对采样误差、覆盖缺口和诊断开销的检查。'
    }
  ];
  const DEFAULT_SCENARIO = {
    durationMs: 20,
    main: [{start:0,end:4,state:'Running'}, {start:4,end:6,state:'Runnable'},
      {start:6,end:16,state:'Sleeping'}, {start:16,end:20,state:'Running'}],
    worker: [{start:1,end:16,state:'Running'}]
  };
  const $ = (selector, base = document) => base.querySelector(selector);
  const $$ = (selector, base = document) => Array.from(base.querySelectorAll(selector));
  const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function node(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }
  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      return {current: typeof saved.current === 'string' ? saved.current : 'ch-1',
        completed: Array.isArray(saved.completed) ? saved.completed.filter(x => typeof x === 'string') : [],
        answers: saved.answers && typeof saved.answers === 'object' ? saved.answers : {}};
    } catch (_) { return {current: 'ch-1', completed: [], answers: {}}; }
  }

  function initCourse() {
    const chapters = $$('article.chapter');
    const state = loadState();
    const validIds = new Set(chapters.map(c => c.id));
    state.completed = [...new Set(state.completed.filter(id => validIds.has(id)))];
    const infos = chapters.map((chapter, index) => ({chapter, index, id: chapter.id,
      title: ($('h1', chapter)?.textContent || `第 ${index + 1} 章`).trim(),
      text: chapter.textContent.replace(/\s+/g, ' ').trim()}));
    let selectedId = null;
    function save() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) { /* Reading remains available when storage is denied. */ } }
    function announce(message) { const target = $('#course-announcement'); if (target) target.textContent = message; }
    function updateProgress() {
      const completed = new Set(state.completed);
      const progress = $('#course-progress');
      if (progress) { progress.max = chapters.length; progress.value = completed.size; progress.textContent = `${completed.size} / ${chapters.length}`; }
      const progressText = $('#progress-text');
      if (progressText) progressText.textContent = `已完成 ${completed.size} / ${chapters.length} 章`;
      infos.forEach(info => {
        const link = $(`#chapter-nav a[data-chapter="${info.id}"]`);
        const done = completed.has(info.id);
        if (link) {
          link.classList.toggle('is-complete', done);
          link.setAttribute('aria-label', `第 ${info.index + 1} 章：${info.title}${done ? '，已完成' : ''}`);
          const badge = $('.step-number', link);
          if (badge) badge.textContent = done ? '✓' : String(info.index + 1);
        }
        const button = $('.complete-button', info.chapter);
        if (button) { button.setAttribute('aria-pressed', String(done)); button.textContent = done ? '✓ 已学完 · 点击撤销' : '○ 标记学完'; }
      });
    }
    function selectChapter(id, options = {}) {
      if (!validIds.has(id)) return;
      selectedId = id;
      chapters.forEach(chapter => { chapter.hidden = chapter.id !== id; });
      $$('#chapter-nav a[data-chapter]').forEach(link => {
        if (link.dataset.chapter === id) link.setAttribute('aria-current', 'page');
        else link.removeAttribute('aria-current');
      });
      state.current = id;
      save();
      const start = $('#start-learning');
      if (start) { start.href = `#${id}`; start.textContent = (state.completed.length || id !== 'ch-1') ? '继续学习 →' : '开始学习 →'; }
      if (options.history && location.hash !== `#${id}`) {
        try { history.pushState({courseChapter: id}, '', `#${id}`); } catch (_) { location.hash = id; }
      }
      if (options.scroll) {
        $('#chapter-content')?.focus({preventScroll: true});
        document.getElementById(id).scrollIntoView({block: 'start', behavior: reducedMotion() ? 'auto' : 'smooth'});
      }
      if (options.announce) announce(`已切换到${infos.find(i => i.id === id).title}`);
    }
    const nav = $('#chapter-nav');
    if (nav && chapters.length) {
      const list = node('ol', 'path-list');
      infos.forEach(info => {
        const item = node('li');
        const link = node('a', 'chapter-link');
        link.href = `#${info.id}`;
        link.dataset.chapter = info.id;
        const badge = node('span', 'step-number', String(info.index + 1));
        badge.setAttribute('aria-hidden', 'true');
        const shortLabel = PATH_LABELS[info.index];
        const label = node('span', 'nav-text', shortLabel?.[0] || info.title);
        label.append(node('small', '', shortLabel?.[1] || `CHAPTER ${String(info.index + 1).padStart(2, '0')}`));
        link.title = info.title;
        link.append(badge, label);
        item.append(link);
        list.append(item);
      });
      nav.replaceChildren(list);
      const count = $('.path-count'); if (count) count.textContent = `${chapters.length} 章`;
    }
    infos.forEach(info => {
      const label = node('div', 'chapter-label');
      label.append(node('span', '', `CHAPTER ${String(info.index + 1).padStart(2, '0')} / ${String(chapters.length).padStart(2, '0')}`), node('span', 'reading-time', '读完后，做一道理解检验'));
      info.chapter.prepend(label);
      const overrides = window.PROFILING_QUIZZES;
      const quiz = (Array.isArray(overrides) ? overrides[info.index] : overrides?.[info.id]) || DEFAULT_QUIZZES[info.index];
      if (quiz && Array.isArray(quiz.options)) {
        const card = node('section', 'quiz-card');
        card.setAttribute('aria-label', `第 ${info.index + 1} 章理解检验`);
        const heading = node('div', 'quiz-heading');
        heading.append(node('span', '', '?'), node('strong', '', '停一下，检验理解'));
        const form = node('form');
        const fieldset = node('fieldset');
        fieldset.append(node('legend', '', quiz.prompt));
        const choices = node('div', 'quiz-options');
        const correctAnswer = quiz.answer ?? quiz.correctIndex;
        const feedback = node('div', 'quiz-feedback');
        feedback.id = `${info.id}-quiz-feedback`;
        feedback.setAttribute('aria-live', 'polite');
        const radios = quiz.options.map((option, index) => {
          const optionLabel = node('label', 'quiz-option');
          const radio = node('input');
          radio.type = 'radio'; radio.name = `${info.id}-quiz`; radio.value = String(index);
          radio.setAttribute('aria-describedby', feedback.id);
          const text = node('span', '', option);
          optionLabel.append(radio, text);
          choices.append(optionLabel);
          radio.addEventListener('change', () => {
            $$('.quiz-option', choices).forEach(element => element.classList.remove('is-selected', 'is-incorrect', 'is-correct'));
            optionLabel.classList.add('is-selected');
            feedback.textContent = '';
          });
          return radio;
        });
        fieldset.append(choices);
        const actions = node('div', 'quiz-actions');
        const submit = node('button', 'button button-primary button-small', '检查答案'); submit.type = 'submit';
        const reset = node('button', 'text-button', '重新作答'); reset.type = 'button';
        actions.append(submit, reset);
        form.append(fieldset, actions, feedback);
        card.append(heading, form);
        info.chapter.append(card);
        const showAnswer = (answer, live) => {
          if (!Number.isInteger(answer) || answer < 0 || answer >= radios.length) return;
          radios[answer].checked = true;
          const correct = answer === correctAnswer;
          $$('.quiz-option', choices).forEach(element => element.classList.remove('is-selected', 'is-incorrect', 'is-correct'));
          radios[answer].parentElement.classList.add(correct ? 'is-correct' : 'is-incorrect');
          feedback.classList.toggle('is-incorrect', !correct);
          feedback.textContent = `${correct ? '答对了！' : '再想一步。'}${quiz.explanation}`;
          if (live) { state.answers[info.id] = answer; save(); }
        };
        form.addEventListener('submit', event => {
          event.preventDefault();
          const checked = radios.find(radio => radio.checked);
          if (!checked) { feedback.textContent = '先选择一个答案，再检查你的判断。'; radios[0].focus(); return; }
          showAnswer(Number(checked.value), true);
        });
        reset.addEventListener('click', () => {
          radios.forEach(radio => { radio.checked = false; });
          $$('.quiz-option', choices).forEach(element => element.classList.remove('is-selected', 'is-correct', 'is-incorrect'));
          feedback.textContent = ''; delete state.answers[info.id]; save(); radios[0].focus();
        });
        showAnswer(state.answers[info.id], false);
      }
      const footer = node('div', 'chapter-footer');
      const complete = node('button', 'complete-button', '○ 标记学完');
      complete.type = 'button'; complete.setAttribute('aria-pressed', 'false');
      complete.addEventListener('click', () => {
        const done = state.completed.includes(info.id);
        state.completed = done ? state.completed.filter(id => id !== info.id) : [...state.completed, info.id];
        save(); updateProgress();
        announce(done ? `已撤销${info.title}的完成标记。` : `已完成${info.title}。当前完成 ${state.completed.length} / ${chapters.length} 章。`);
      });
      const pager = node('div', 'chapter-pager');
      if (info.index > 0) {
        const previous = node('button', 'previous-button', '← 上一章'); previous.type = 'button';
        previous.addEventListener('click', () => selectChapter(infos[info.index - 1].id, {history: true, scroll: true, announce: true}));
        pager.append(previous);
      }
      const next = node('button', 'button button-primary button-small', info.index < infos.length - 1 ? '继续下一章 →' : '回顾第一章 ↺'); next.type = 'button';
      next.addEventListener('click', () => selectChapter(infos[(info.index + 1) % infos.length].id, {history: true, scroll: true, announce: true}));
      pager.append(next); footer.append(complete, pager); info.chapter.append(footer);
    });
    function targetFromHash() {
      let id; try { id = decodeURIComponent(location.hash.slice(1)); } catch (_) { return null; }
      return id ? document.getElementById(id) : null;
    }
    const initialTarget = targetFromHash();
    const initialChapter = initialTarget?.closest('article.chapter');
    const initialId = initialChapter?.id || (validIds.has(state.current) ? state.current : chapters[0]?.id);
    if (initialId) selectChapter(initialId);
    // Retain the landing chapter when Back restores the original URL without a fragment.
    try { history.replaceState({...history.state, courseChapter: initialId}, ''); } catch (_) { /* File viewers may restrict history. */ }
    updateProgress();
    document.addEventListener('click', event => {
      const anchor = event.target.closest('a[href^="#"]');
      if (!anchor) return;
      let id; try { id = decodeURIComponent(anchor.getAttribute('href').slice(1)); } catch (_) { return; }
      const target = document.getElementById(id);
      if (!target) return;
      const article = target.closest('article.chapter');
      if (article) {
        event.preventDefault();
        selectChapter(article.id, {history: target === article, scroll: target === article, announce: true});
        if (target !== article) {
          try { history.pushState({courseChapter: article.id}, '', `#${id}`); } catch (_) { location.hash = id; }
          target.scrollIntoView({block: 'start', behavior: reducedMotion() ? 'auto' : 'smooth'});
        }
      }
      const sourceDetails = target.closest('details');
      if (sourceDetails) sourceDetails.open = true;
    });
    window.addEventListener('popstate', event => {
      const article = targetFromHash()?.closest('article.chapter');
      const restoredId = article?.id || event.state?.courseChapter;
      if (validIds.has(restoredId)) selectChapter(restoredId);
    });
    window.addEventListener('hashchange', () => {
      const target = targetFromHash();
      const article = target?.closest('article.chapter');
      if (article) { selectChapter(article.id); target.scrollIntoView({block: 'start'}); }
      const details = target?.closest('details'); if (details) details.open = true;
    });
    const initialDetails = initialTarget?.closest('details'); if (initialDetails) initialDetails.open = true;
    if (initialTarget) requestAnimationFrame(() => initialTarget.scrollIntoView({block: 'start'}));

    const search = $('#chapter-search');
    const results = $('#search-results');
    function closeSearch(clear = false) {
      if (!search || !results) return;
      results.hidden = true; search.setAttribute('aria-expanded', 'false');
      if (clear) search.value = '';
    }
    function performSearch() {
      const query = search.value.trim().toLocaleLowerCase();
      results.replaceChildren();
      if (!query) { closeSearch(); $('#search-announcement').textContent = ''; return; }
      const matches = infos.filter(info => info.text.toLocaleLowerCase().includes(query));
      results.append(node('p', 'search-summary', matches.length ? `在 ${matches.length} 章中找到“${search.value.trim()}”` : '没有找到匹配内容。试试更短的关键词。'));
      matches.forEach(info => {
        const at = info.text.toLocaleLowerCase().indexOf(query);
        const from = Math.max(0, at - 24);
        const snippet = `${from ? '…' : ''}${info.text.slice(from, from + 105)}${from + 105 < info.text.length ? '…' : ''}`;
        const button = node('button', 'search-result'); button.type = 'button';
        button.append(node('strong', '', info.title), node('span', '', snippet));
        button.addEventListener('click', () => { closeSearch(); selectChapter(info.id, {history: true, scroll: true, announce: true}); });
        results.append(button);
      });
      results.hidden = false; search.setAttribute('aria-expanded', 'true');
      $('#search-announcement').textContent = `搜索结果：${matches.length} 个匹配章节。`;
    }
    if (search && results) {
      search.addEventListener('input', performSearch);
      search.addEventListener('focus', () => { if (search.value.trim()) performSearch(); });
      search.addEventListener('keydown', event => {
        if (event.key === 'ArrowDown' && !results.hidden) { event.preventDefault(); $('button', results)?.focus(); }
        if (event.key === 'Escape') { closeSearch(true); search.focus(); }
      });
      results.addEventListener('keydown', event => {
        if (event.key === 'Escape') { search.focus(); closeSearch(); }
        const buttons = $$('button', results);
        const index = buttons.indexOf(document.activeElement);
        if (event.key === 'ArrowDown') { event.preventDefault(); buttons[(index + 1) % buttons.length]?.focus(); }
        if (event.key === 'ArrowUp') { event.preventDefault(); index <= 0 ? search.focus() : buttons[index - 1]?.focus(); }
      });
      document.addEventListener('click', event => { if (!event.target.closest('.search-area')) closeSearch(); });
      document.addEventListener('keydown', event => {
        if (event.key !== '/' || event.ctrlKey || event.altKey || event.metaKey) return;
        const active = document.activeElement;
        if (active?.matches('input, textarea, select') || active?.isContentEditable) return;
        event.preventDefault(); search.focus();
      });
    }
    return {selectChapter, getState: () => ({current: selectedId, completed: [...state.completed], answers: {...state.answers}})};
  }

  function initDemo() {
    const container = $('#request-demo'); if (!container) return null;
    const supplied = window.PROFILING_SCENARIO;
    const scenario = supplied && Number.isFinite(supplied.durationMs) && supplied.durationMs > 0 && Array.isArray(supplied.main) && Array.isArray(supplied.worker) ? supplied : DEFAULT_SCENARIO;
    const duration = scenario.durationMs;
    const slider = $('#demo-slider');
    const playButton = $('#demo-play');
    const playLabel = $('#demo-play-label');
    const status = $('#demo-status');
    let time = 0, playing = false, frameId = 0, previousFrame = null;
    const segmentElements = [];
    slider.max = String(duration);
    ['main', 'worker'].forEach(lane => {
      const element = $(`#demo-${lane}-lane`);
      element.replaceChildren();
      element.setAttribute('aria-label', `${lane}：${scenario[lane].map(s => `${s.start}至${s.end}毫秒 ${s.state}`).join('；')}`);
      scenario[lane].forEach(segment => {
        const block = node('span', `timeline-segment state-${segment.state.toLowerCase()}`, (segment.end - segment.start) / duration >= 0.14 ? segment.state : '');
        block.style.left = `${segment.start / duration * 100}%`;
        block.style.width = `${(segment.end - segment.start) / duration * 100}%`;
        block.title = `${lane}: ${segment.start}–${segment.end} ms · ${segment.state}`;
        element.append(block); segmentElements.push({block, segment});
      });
    });
    const ticks = $('#demo-ticks'); ticks.replaceChildren();
    for (let i = 0; i < 5; i++) ticks.append(node('span', '', `${Number((duration * i / 4).toFixed(2))}${i === 4 ? ' ms' : ''}`));
    const cpu = lane => scenario[lane].reduce((sum, segment) => sum + (segment.state === 'Running' ? Math.max(0, Math.min(time, segment.end) - segment.start) : 0), 0);
    function snapshot() { const main = cpu('main'), worker = cpu('worker'); return {time, wallMs: time, mainCpuMs: main, workerCpuMs: worker, cpuMs: main + worker, ratio: time > 0 ? (main + worker) / time : null, playing}; }
    function render() {
      const current = snapshot();
      $('#demo-wall').textContent = time.toFixed(1);
      $('#demo-cpu').textContent = current.cpuMs.toFixed(1);
      $('#demo-main-cpu').textContent = current.mainCpuMs.toFixed(1);
      $('#demo-worker-cpu').textContent = current.workerCpuMs.toFixed(1);
      $('#demo-ratio').textContent = current.ratio === null ? '—' : current.ratio.toFixed(2);
      $('#demo-ratio-unit').textContent = current.ratio === null ? '' : '核';
      $('#demo-time').textContent = `${time.toFixed(1)} / ${duration} ms`;
      $('#demo-cursor').style.left = `${time / duration * 100}%`;
      $('#demo-cursor-label').textContent = time.toFixed(1);
      slider.value = String(time);
      slider.style.setProperty('--range-progress', `${time / duration * 100}%`);
      slider.setAttribute('aria-valuetext', `当前时间 ${time.toFixed(1)} 毫秒，累计 CPU ${current.cpuMs.toFixed(1)} 毫秒`);
      playLabel.textContent = playing ? '暂停' : time >= duration ? '重播' : '播放';
      $('.play-icon', playButton).textContent = playing ? 'Ⅱ' : '▶';
      playButton.setAttribute('aria-label', playing ? '暂停时间线' : time >= duration ? '重新播放时间线' : '播放时间线');
      segmentElements.forEach(({block, segment}) => block.classList.toggle('is-current', time >= segment.start && time < segment.end));
    }
    function pause(message) {
      playing = false; cancelAnimationFrame(frameId); previousFrame = null; render();
      if (message) status.textContent = message;
    }
    function step(timestamp) {
      if (!playing) return;
      if (previousFrame !== null) time = Math.min(duration, time + (timestamp - previousFrame) * duration / 8000);
      previousFrame = timestamp;
      render();
      if (time >= duration) { pause(`到达终点：墙钟 ${duration} ms，累计 CPU ${snapshot().cpuMs.toFixed(1)} ms。可以重播或拖动回看。`); return; }
      frameId = requestAnimationFrame(step);
    }
    function play() {
      if (playing) return;
      if (time >= duration) time = 0;
      playing = true; previousFrame = null;
      status.textContent = '正在播放。点击暂停，或拖动滑块停在任意时刻。';
      render(); frameId = requestAnimationFrame(step);
    }
    function setTime(value) {
      const numeric = Number(value); if (!Number.isFinite(numeric)) return;
      time = Math.max(0, Math.min(duration, numeric));
      pause(`已暂停在 ${time.toFixed(1)} ms。main 与 worker 的 CPU 权重在右侧累计相加。`);
    }
    playButton.addEventListener('click', () => playing ? pause(`已暂停在 ${time.toFixed(1)} ms。`) : play());
    $('#demo-reset').addEventListener('click', () => { setTime(0); status.textContent = '已重置。拖动滑块，或点击播放。'; });
    slider.addEventListener('input', () => setTime(slider.value));
    document.addEventListener('visibilitychange', () => { if (document.hidden && playing) pause('页面进入后台，演示已暂停。'); });
    window.addEventListener('pagehide', () => pause());
    render();
    // Always paused initially, including prefers-reduced-motion environments.
    return {setTime, getState: snapshot, play, pause: () => pause(`已暂停在 ${time.toFixed(1)} ms。`)};
  }
  function init() { window.ProfilingCourse = {course: initCourse(), requestDemo: initDemo()}; }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
  else init();
})();
