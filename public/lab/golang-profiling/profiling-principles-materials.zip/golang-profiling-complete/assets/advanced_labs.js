(() => {
"use strict";
  const DEFAULT_SCENARIO = {
    durationMs: 20,
    main: [{start:0,end:4,state:'Running'}, {start:4,end:6,state:'Runnable'},
      {start:6,end:16,state:'Sleeping'}, {start:16,end:20,state:'Running'}],
    worker: [{start:1,end:16,state:'Running'}]
  };
  const $ = (selector, base = document) => base.querySelector(selector);
  const $$ = (selector, base = document) => Array.from(base.querySelectorAll(selector));
  const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function node(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }
  function initDemo() {
    const lifetime = new AbortController();
    const listen = (target, type, handler) => target.addEventListener(type, handler, {signal: lifetime.signal});
    const container = $('#request-demo'); if (!container) return null;
    const supplied = window.PROFILING_SCENARIO;
    const scenario = supplied && Number.isFinite(supplied.durationMs) && supplied.durationMs > 0 && Array.isArray(supplied.main) && Array.isArray(supplied.worker) ? supplied : DEFAULT_SCENARIO;
    const duration = scenario.durationMs;
    const slider = $('#demo-slider');
    const playButton = $('#demo-play');
    const playLabel = $('#demo-play-label');
    const status = $('#demo-status');
    let time = 0, playing = false, frameId = 0, previousFrame = null;
    const segmentElements = [];
    slider.max = String(duration);
    ['main', 'worker'].forEach(lane => {
      const element = $(`#demo-${lane}-lane`);
      element.replaceChildren();
      element.setAttribute('aria-label', `${lane}：${scenario[lane].map(s => `${s.start}至${s.end}毫秒 ${s.state}`).join('；')}`);
      scenario[lane].forEach(segment => {
        const block = node('span', `timeline-segment state-${segment.state.toLowerCase()}`, (segment.end - segment.start) / duration >= 0.14 ? segment.state : '');
        block.style.left = `${segment.start / duration * 100}%`;
        block.style.width = `${(segment.end - segment.start) / duration * 100}%`;
        block.title = `${lane}: ${segment.start}–${segment.end} ms · ${segment.state}`;
        element.append(block); segmentElements.push({block, segment});
      });
    });
    const ticks = $('#demo-ticks'); ticks.replaceChildren();
    for (let i = 0; i < 5; i++) ticks.append(node('span', '', `${Number((duration * i / 4).toFixed(2))}${i === 4 ? ' ms' : ''}`));
    const cpu = lane => scenario[lane].reduce((sum, segment) => sum + (segment.state === 'Running' ? Math.max(0, Math.min(time, segment.end) - segment.start) : 0), 0);
    function snapshot() { const main = cpu('main'), worker = cpu('worker'); return {time, wallMs: time, mainCpuMs: main, workerCpuMs: worker, cpuMs: main + worker, ratio: time > 0 ? (main + worker) / time : null, playing}; }
    function render() {
      const current = snapshot();
      $('#demo-wall').textContent = time.toFixed(1);
      $('#demo-cpu').textContent = current.cpuMs.toFixed(1);
      $('#demo-main-cpu').textContent = current.mainCpuMs.toFixed(1);
      $('#demo-worker-cpu').textContent = current.workerCpuMs.toFixed(1);
      $('#demo-ratio').textContent = current.ratio === null ? '—' : current.ratio.toFixed(2);
      $('#demo-ratio-unit').textContent = current.ratio === null ? '' : '核';
      $('#demo-time').textContent = `${time.toFixed(1)} / ${duration} ms`;
      $('#demo-cursor').style.left = `${time / duration * 100}%`;
      $('#demo-cursor-label').textContent = time.toFixed(1);
      slider.value = String(time);
      slider.style.setProperty('--range-progress', `${time / duration * 100}%`);
      slider.setAttribute('aria-valuetext', `当前时间 ${time.toFixed(1)} 毫秒，累计 CPU ${current.cpuMs.toFixed(1)} 毫秒`);
      playLabel.textContent = playing ? '暂停' : time >= duration ? '重播' : '播放';
      $('.play-icon', playButton).textContent = playing ? 'Ⅱ' : '▶';
      playButton.setAttribute('aria-label', playing ? '暂停时间线' : time >= duration ? '重新播放时间线' : '播放时间线');
      segmentElements.forEach(({block, segment}) => block.classList.toggle('is-current', time >= segment.start && time < segment.end));
    }
    function pause(message) {
      playing = false; cancelAnimationFrame(frameId); previousFrame = null; render();
      if (message) status.textContent = message;
    }
    function step(timestamp) {
      if (!playing) return;
      if (previousFrame !== null) time = Math.min(duration, time + (timestamp - previousFrame) * duration / 8000);
      previousFrame = timestamp;
      render();
      if (time >= duration) { pause(`到达终点：墙钟 ${duration} ms，累计 CPU ${snapshot().cpuMs.toFixed(1)} ms。可以重播或拖动回看。`); return; }
      frameId = requestAnimationFrame(step);
    }
    function play() {
      if (playing) return;
      if (time >= duration) time = 0;
      playing = true; previousFrame = null;
      status.textContent = '正在播放。点击暂停，或拖动滑块停在任意时刻。';
      render(); frameId = requestAnimationFrame(step);
    }
    function setTime(value) {
      const numeric = Number(value); if (!Number.isFinite(numeric)) return;
      time = Math.max(0, Math.min(duration, numeric));
      pause(`已暂停在 ${time.toFixed(1)} ms。main 与 worker 的 CPU 权重在累计 CPU 卡片中相加。`);
    }
    listen(playButton, 'click', () => playing ? pause(`已暂停在 ${time.toFixed(1)} ms。`) : play());
    listen($('#demo-reset'), 'click', () => { setTime(0); status.textContent = '已重置。拖动滑块，或点击播放。'; });
    listen(slider, 'input', () => setTime(slider.value));
    listen(document, 'visibilitychange', () => { if (document.hidden && playing) pause('页面进入后台，演示已暂停。'); });
    listen(window, 'pagehide', () => pause());
    render();
    // Always paused initially, including prefers-reduced-motion environments.
    return {destroy() { playing = false; cancelAnimationFrame(frameId); lifetime.abort(); }, setTime, getState: snapshot, play, pause: () => pause(`已暂停在 ${time.toFixed(1)} ms。`)};
  }

window.createRequestDemo = initDemo;
})();
/* Three independent teaching models. No network, timer, or automatic playback.
 * Embed mechanism_labs.html once, then this script and mechanism_labs.css.
 * All selectors and globals are namespaced to avoid the course UI.
 */
(() => {
  'use strict';
  const byId = id => document.getElementById(id);
  const copy = value => JSON.parse(JSON.stringify(value));
  const RING_STATES = [
    {a:'empty', b:'empty', reserved:[], submitted:[], consumed:[], blocked:false,
      title:'准备开始', note:'点击“前进一步”，让 A 先预留一条记录。', consumer:'consumer 位于 A 将要出现的位置'},
    {a:'busy', b:'empty', reserved:['A'], submitted:[], consumed:[], blocked:false,
      title:'A reserve', note:'A 占据第一条预留记录，BUSY = 1。它还没有提交，消费者尚不能读取这条记录。', consumer:'下一条将读取 A；A 尚未提交'},
    {a:'busy', b:'busy', reserved:['A','B'], submitted:[], consumed:[], blocked:false,
      title:'B reserve', note:'B 在 A 后面预留。两条记录都处于 busy 状态；预留顺序现在是 A → B。', consumer:'下一条将读取 A；A、B 均未提交'},
    {a:'busy', b:'ready', reserved:['A','B'], submitted:['B'], consumed:[], blocked:false,
      title:'B submit', note:'B 先完成提交，BUSY 清零。A 仍然 busy，所以 B 已提交并不等于消费者可以越过 A 读取 B。', consumer:'下一条仍是 A；B 提交不会改变预留顺序'},
    {a:'busy', b:'ready', reserved:['A','B'], submitted:['B'], consumed:[], blocked:true,
      title:'consumer 遇到 A busy', note:'消费者检查 A 的记录头，发现 BUSY = 1，于是停止本次消费。它不能跳过 A 直接消费已提交的 B。', consumer:'consumer 停在 A：BUSY = 1'},
    {a:'ready', b:'ready', reserved:['A','B'], submitted:['B','A'], consumed:[], blocked:false,
      title:'A submit', note:'A 完成提交，BUSY 清零。两条记录现在都可读；下一次消费可以从 A 继续，再到 B。', consumer:'consumer 可以从 A 继续前进'},
    {a:'consumed', b:'consumed', reserved:['A','B'], submitted:['B','A'], consumed:['A','B'], blocked:false,
      title:'consume A / B', note:'消费者先读 A，再读 B。提交顺序是 B → A，消费仍按预留顺序 A → B 进行。', consumer:'consumer 已依次越过 A、B'}
  ];
  const PROFILE_RECORDS = Object.freeze([
    Object.freeze({id:'first', name:'main.first_work', cpuMs:4}),
    Object.freeze({id:'worker', name:'worker.work', cpuMs:15}),
    Object.freeze({id:'finish', name:'main.finish_work', cpuMs:4})
  ]);
  function initRing() {
    const root = byId('ml-ring-lab'); if (!root) return null;
    let step = 0;
    const nextButton = byId('ml-ring-next');
    function render() {
      const state = RING_STATES[step];
      byId('ml-ring-step').textContent = `${step} / 6 步`;
      ['a','b'].forEach(key => {
        const status = state[key];
        const record = byId(`ml-ring-record-${key}`);
        record.className = `ml-ring-record ml-record-${status}`;
        byId(`ml-ring-status-${key}`).textContent = {empty:'尚未预留', busy:'已预留，未提交', ready:'已提交', consumed:'已消费'}[status];
        byId(`ml-ring-flag-${key}`).textContent = status === 'empty' ? '—' : `BUSY = ${status === 'busy' ? 1 : 0}`;
      });
      ['reserved','submitted','consumed'].forEach(key => { byId(`ml-ring-${key}`).textContent = state[key].join(' → ') || '—'; });
      byId('ml-ring-consumer').textContent = state.consumer;
      const note = byId('ml-ring-note');
      note.querySelector('strong').textContent = state.title;
      note.querySelector('span').textContent = state.note;
      root.querySelectorAll('[data-ml-step]').forEach(item => {
        const index = Number(item.dataset.mlStep);
        item.classList.toggle('ml-step-done', index < step);
        if (index === step) item.setAttribute('aria-current', 'step');
        else item.removeAttribute('aria-current');
      });
      nextButton.disabled = step === 6;
      nextButton.textContent = step === 6 ? '六步已完成 ✓' : '前进一步 →';
    }
    function next() { if (step < 6) { step++; render(); } }
    function reset() { step = 0; render(); }
    nextButton.addEventListener('click', next);
    byId('ml-ring-reset').addEventListener('click', reset);
    render();
    return {next, reset, getState: () => ({step, ...copy(RING_STATES[step])})};
  }

  function initPprof() {
    const root = byId('ml-pprof-lab'); if (!root) return null;
    let order = [0,1,2], shuffles = 0;
    function snapshot() {
      return {order: order.map(index => PROFILE_RECORDS[index].id),
        records: order.map(index => ({...PROFILE_RECORDS[index]})),
        totalCpuMs: order.reduce((total, index) => total + PROFILE_RECORDS[index].cpuMs, 0),
        flatMs: Object.fromEntries(PROFILE_RECORDS.map(record => [record.name, record.cpuMs])), shuffles};
    }
    function render(animate = false) {
      const list = byId('ml-pprof-samples');
      list.replaceChildren();
      order.forEach((recordIndex, position) => {
        const record = PROFILE_RECORDS[recordIndex];
        const item = document.createElement('li'); item.dataset.mlRecord = record.id;
        const number = document.createElement('span'); number.className = 'ml-sample-position'; number.textContent = String(position + 1);
        const name = document.createElement('code'); name.textContent = record.name;
        const weight = document.createElement('strong'); weight.append(document.createTextNode(String(record.cpuMs) + ' '));
        const unit = document.createElement('small'); unit.textContent = 'ms'; weight.append(unit);
        item.append(number, name, weight); list.append(item);
        if (animate && !window.matchMedia('(prefers-reduced-motion: reduce)').matches && item.animate) {
          item.animate([{opacity:.6, transform:'translateY(4px)'}, {opacity:1, transform:'translateY(0)'}], {duration:180, easing:'ease-out'});
        }
      });
      const current = snapshot();
      byId('ml-pprof-total').textContent = String(current.totalCpuMs);
      byId('ml-pprof-flat').textContent = 'first 4 / worker 15 / finish 4 ms';
      const sum = current.records.map(record => record.cpuMs).join(' + ');
      byId('ml-pprof-note').textContent = shuffles === 0
        ? `初始排列。三条记录的权重之和为 ${sum} = ${current.totalCpuMs} ms。`
        : `第 ${shuffles} 次换序：${sum} = ${current.totalCpuMs} ms。各函数 flat 保持不变；没有改变真实调用时间。`;
    }
    function shuffle() {
      const previous = order.join(',');
      const nextOrder = [...order];
      for (let i = nextOrder.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [nextOrder[i], nextOrder[j]] = [nextOrder[j], nextOrder[i]];
      }
      // Each explicit click must produce a different visible arrangement.
      if (nextOrder.join(',') === previous) nextOrder.push(nextOrder.shift());
      order = nextOrder; shuffles++; render(true);
    }
    function reset() { order = [0,1,2]; shuffles = 0; render(); }
    byId('ml-pprof-shuffle').addEventListener('click', shuffle);
    byId('ml-pprof-reset').addEventListener('click', reset);
    render();
    return {shuffle, reset, getState: snapshot};
  }

  function initPerfetto() {
    const root = byId('ml-perfetto-lab'); if (!root) return null;
    let inputCount = 0, policy = 'ring';
    const capacity = 4;
    const nextButton = byId('ml-perfetto-next');
    function snapshot() {
      const input = Array.from({length:inputCount}, (_, i) => i + 1);
      const retained = policy === 'ring' ? input.slice(-capacity) : input.slice(0, capacity);
      const lost = policy === 'ring' ? input.slice(0, Math.max(0, input.length - capacity)) : input.slice(capacity);
      return {policy, capacity, inputCount, input, retained, lost};
    }
    function render() {
      const current = snapshot();
      const name = policy === 'ring' ? 'RING_BUFFER' : 'DISCARD';
      root.querySelectorAll('input[name="ml-perfetto-policy"]').forEach(radio => {
        radio.checked = radio.value === policy;
        radio.parentElement.classList.toggle('ml-policy-selected', radio.checked);
      });
      byId('ml-perfetto-count').textContent = `${inputCount} / 6`;
      byId('ml-perfetto-inputs').querySelectorAll('li').forEach((item, index) => {
        const number = index + 1, seen = number <= inputCount, lost = current.lost.includes(number);
        item.classList.toggle('ml-input-seen', seen && !lost);
        item.classList.toggle('ml-input-lost', lost);
        item.setAttribute('aria-label', `块 ${number}，${!seen ? '尚未输入' : lost ? policy === 'ring' ? '被覆盖' : '被丢弃' : '已保留'}`);
      });
      byId('ml-perfetto-buffer').querySelectorAll('li').forEach((item, index) => {
        const value = current.retained[index];
        item.textContent = value === undefined ? '—' : String(value);
        item.classList.toggle('ml-slot-filled', value !== undefined);
        item.setAttribute('aria-label', value === undefined ? '空位' : `保留块 ${value}`);
      });
      nextButton.disabled = inputCount === 6;
      nextButton.textContent = inputCount === 6 ? '已输入六块 ✓' : '输入下一块 →';
      let note;
      if (!inputCount) note = `${name}：尚未输入。容量为 4 个抽象块。`;
      else if (inputCount <= capacity) note = `${name}：已输入 ${inputCount} 块，保留 ${current.retained.join('、')}。${inputCount === capacity ? '容量现在恰好填满。' : '尚未填满容量。'}`;
      else note = `${name}：已输入 ${inputCount} 块，保留 ${current.retained.join('、')}；${policy === 'ring' ? '旧块' : '新块'} ${current.lost.join('、')} 被${policy === 'ring' ? '覆盖' : '丢弃'}。`;
      byId('ml-perfetto-note').textContent = note;
    }
    function next() { if (inputCount < 6) { inputCount++; render(); } }
    function reset() { inputCount = 0; render(); }
    function setPolicy(value) { if (value === 'ring' || value === 'discard') { policy = value; render(); } }
    nextButton.addEventListener('click', next);
    byId('ml-perfetto-reset').addEventListener('click', reset);
    root.querySelectorAll('input[name="ml-perfetto-policy"]').forEach(radio => radio.addEventListener('change', () => setPolicy(radio.value)));
    render();
    return {next, reset, setPolicy, getState: snapshot};
  }
  function init() {
    const container = byId('ml-mechanism-labs');
    if (!container || container.dataset.mlInitialized === 'true') return;
    container.dataset.mlInitialized = 'true';
    window.MechanismLabs = {ring: initRing(), pprof: initPprof(), perfetto: initPerfetto()};
  }
  window.initMechanismLabs = init;
})();

(() => {
  window.disposeAdvancedLabs = () => {
    window.ProfilingCourse?.requestDemo?.destroy();
    window.ProfilingCourse = null;
    window.MechanismLabs = null;
    document.querySelectorAll('.advanced-interactives').forEach(root => root.getAnimations({subtree:true}).forEach(animation => animation.cancel()));
  };
  window.initAdvancedLabs = () => {
    const request = document.getElementById('request-demo');
    if (request && request.dataset.initialized !== 'true') {
      request.dataset.initialized = 'true';
      window.ProfilingCourse = {requestDemo: window.createRequestDemo()};
    }
    window.initMechanismLabs();
  };
})();
