#!/usr/bin/env python3
"""Independent real-Chromium regression check of the original merged course UI."""
import hashlib
import json
import os
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import sync_playwright
from course_errata import apply_data, ERRATA

ROOT = Path(__file__).resolve().parents[1]
URL = os.environ.get('COURSE_URL', 'http://127.0.0.1:8765/').rstrip('/') + '/'
OUT = ROOT / "verification/merged-original-ui-check.json"
BASE = apply_data(json.loads((ROOT / "base-course/course-data.json").read_text()))
REPORT = {"url": URL, "started_utc": datetime.now(timezone.utc).isoformat(),
          "tool": "Python Playwright, headless Chromium", "checks": {},
          "issues": [], "page_errors": [], "console_errors": [], "screenshots": []}
ONLY = set(sys.argv[1].split(',')) if len(sys.argv) > 1 else set()
if ONLY and OUT.exists():
    REPORT = json.loads(OUT.read_text())
    REPORT.setdefault('retests', []).append({'started_utc': datetime.now(timezone.utc).isoformat(), 'checks': sorted(ONLY)})


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def save():
    OUT.write_text(json.dumps(REPORT, ensure_ascii=False, indent=2))


def record(name, fn):
    if ONLY and name not in ONLY:
        return
    previous = REPORT['checks'].get(name)
    if previous and previous['status'] == 'failed':
        REPORT.setdefault('previous_failed_attempts', []).append({'check': name, **previous})
    REPORT['issues'] = [issue for issue in REPORT['issues'] if issue['check'] != name]
    begin = time.monotonic()
    try:
        result = fn()
        REPORT["checks"][name] = {"status": "passed", "seconds": round(time.monotonic() - begin, 2), **(result or {})}
        print(f"PASS {name}", flush=True)
    except Exception as exc:
        REPORT["checks"][name] = {"status": "failed", "seconds": round(time.monotonic() - begin, 2), "error": str(exc), "traceback": traceback.format_exc()}
        REPORT["issues"].append({"check": name, "error": str(exc)})
        print(f"FAIL {name}: {exc}", flush=True)
    save()


def go(page, route):
    page.goto(URL + "#" + route, wait_until="domcontentloaded")
    if route.startswith("chapter/"):
        chapter_id = route.split("/")[1]
        page.wait_for_selector(f'#section-{chapter_id}-0')
    else:
        page.wait_for_function("view => route.view === view", arg=route)


def snapshot(page):
    return page.evaluate("JSON.parse(JSON.stringify(state))")


def xp(page):
    return page.evaluate("totalXP()")


def screenshot(page, label):
    path = ROOT / "verification" / ("merged-original-" + label + ".png")
    page.screenshot(path=str(path), full_page=False, animations="disabled")
    REPORT["screenshots"].append(str(path.relative_to(ROOT)))


with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    REPORT["browser_version"] = browser.version
    context = browser.new_context(viewport={"width": 1440, "height": 1000}, reduced_motion="reduce", accept_downloads=True)
    page = context.new_page()
    page.set_default_timeout(7000)
    page.on("pageerror", lambda e: REPORT["page_errors"].append(str(e)))
    page.on("console", lambda m: REPORT["console_errors"].append(m.text) if m.type == "error" else None)
    page.on("dialog", lambda d: d.accept())
    page.goto(URL, wait_until="networkidle")
    DATA = page.evaluate("DATA")
    ORIGINAL = DATA["chapters"][:16]
    if ONLY and 'all_56_quizzes_wrong_review_xp_persistence' in ONLY:
        assert REPORT['checks']['all_original_sections_and_progress']['status'] == 'passed'
        seed = {'schema':1, 'course':'golab-go-profiling-v1', 'completed':{}, 'answers':{}, 'rewards':{}, 'lastChapter':'16', 'lastSection':6}
        for chapter in ORIGINAL:
            seed['completed'][chapter['id']] = list(range(len(chapter['sections'])))
            for index in range(len(chapter['sections'])):
                seed['rewards'][f"section:{chapter['id']}:{index}"] = '2026-10-05'
        page.evaluate("data => localStorage.setItem('golab.go-profiling.v1', JSON.stringify(data))", seed)
        page.reload(wait_until='domcontentloaded')
        REPORT['retests'][-1]['setup'] = 'Restore 103 completed sections / 1545 XP already verified by the full click-through; quizzes start unanswered.'

    def data_integrity():
        assert ORIGINAL == BASE["chapters"][:16], "Chapter data differs from frozen baseline plus documented errata"
        assert DATA["visuals"] == BASE["visuals"], "Original mechanism data differs from archived baseline"
        assert DATA["sources"][:73] == BASE["sources"][:73], "Original first 73 sources differ from archived baseline"
        counts = {"chapters": len(ORIGINAL), "sections": sum(len(c["sections"]) for c in ORIGINAL),
                  "quizzes": sum(len(c["quiz"]) for c in ORIGINAL), "visuals": len(DATA["visuals"]),
                  "steps": sum(len(v["steps"]) for v in DATA["visuals"])}
        assert counts == {"chapters": 16, "sections": 103, "quizzes": 56, "visuals": 39, "steps": 160}, counts
        return {"counts": counts, "baseline": "base-course/course-data.json", "chapters_sha256": digest(ORIGINAL),
                "visuals_sha256": digest(DATA["visuals"]), "sources73_sha256": digest(DATA["sources"][:73]), "comparison": "strict equality to frozen baseline plus explicit sentence errata", "errata": ERRATA}
    record("original_data_integrity", data_integrity)

    def sections_and_reading_progress():
        reached, expanded, completed = [], 0, 0
        for chapter in ORIGINAL:
            cid = chapter["id"]
            go(page, f"chapter/{cid}")
            for index, section in enumerate(chapter["sections"]):
                page.locator(f'.toc a[data-sec-index="{index}"]').click()
                page.wait_for_url(URL + f"#chapter/{cid}/{index}")
                block = page.locator(f"#section-{cid}-{index}")
                assert block.locator('.section-heading h2').inner_text() == section["title"]
                detail = block.locator("details.detail-reading")
                if detail.count():
                    if not detail.get_attribute("open") == "":
                        detail.locator("summary").click()
                    assert detail.evaluate("el => el.open"), f"Collapsed original text {cid}/{index}"
                    expanded += 1
                prose = block.locator(".prose").first
                assert prose.is_visible(), f"Original prose is hidden {cid}/{index}"
                assert len(prose.inner_text().strip()) > 80, f"Original prose unexpectedly empty {cid}/{index}"
                before = xp(page)
                button = block.locator('[data-action="complete-section"]')
                button.click()
                assert button.is_disabled(), f"Completion button failed {cid}/{index}"
                assert xp(page) == before + 15, f"Wrong section XP {cid}/{index}"
                assert index in snapshot(page)["completed"][cid]
                reached.append(f"{cid}/{index}")
                completed += 1
            print(f"  read chapter {cid}: {len(chapter['sections'])} sections", flush=True)
        assert len(reached) == 103 and xp(page) == 1545
        return {"reachable_sections": len(reached), "opened_complete_prose": expanded, "completed_sections": completed, "xp": xp(page), "routes": reached}
    record("all_original_sections_and_progress", sections_and_reading_progress)

    def animated_steps():
        tested = []
        for chapter in ORIGINAL:
            cid = chapter["id"]
            go(page, f"chapter/{cid}")
            for visual in [v for v in DATA["visuals"] if str(v["chapter"]) == cid]:
                card = page.locator(f'[data-viz-id="{visual["id"]}"]')
                assert card.count() == 1
                slider = card.locator(".viz-range")
                slider.evaluate("el => {el.value='0';el.dispatchEvent(new Event('input',{bubbles:true}));}")
                states = []
                for step_index, step in enumerate(visual["steps"]):
                    if step_index:
                        card.locator('[data-viz-action="next"]').click()
                    assert card.get_attribute("data-step") == str(step_index)
                    assert card.locator(".viz-stage-title").inner_text() == step["title"]
                    assert card.locator(".viz-stage-detail").inner_text() == step.get("detail", "")
                    assert card.locator(".viz-step-count").inner_text() == f'{step_index+1} / {len(visual["steps"])}'
                    assert card.locator(".viz-error").count() == 0
                    assert card.locator(".viz-canvas svg").count() > 0
                    states.append(digest(card.locator(".viz-canvas").inner_html()))
                assert len(set(states)) > 1, f"No scene change for {visual['id']}"
                assert card.locator('[data-viz-action="next"]').is_disabled()
                card.locator('[data-viz-action="previous"]').click()
                assert card.get_attribute("data-step") == str(len(visual["steps"])-2)
                slider.evaluate("el => {el.value='0';el.dispatchEvent(new Event('input',{bubbles:true}));}")
                assert card.locator('[data-viz-action="previous"]').is_disabled()
                tested.append({"id": visual["id"], "steps": len(states), "distinct_scenes": len(set(states)), "next_previous_slider": True})
            print(f"  mechanisms chapter {cid}", flush=True)
        assert len(tested) == 39 and sum(v["steps"] for v in tested) == 160
        return {"visuals": len(tested), "steps": sum(v["steps"] for v in tested), "details": tested}
    record("all_original_animated_steps", animated_steps)

    def gallery_and_playback():
        go(page, "labs")
        assert page.locator('[data-viz-id]').count() == 39
        page.locator('#visual-chapter-filter').select_option("15")
        assert page.locator('[data-viz-id]').count() == 7
        page.locator('#visual-chapter-filter').select_option("all")
        card = page.locator('[data-viz-id="01-evidence"]')
        card.locator('.viz-range').evaluate("el => {el.value='0';el.dispatchEvent(new Event('input',{bubbles:true}));}")
        card.locator('[data-viz-action="play"]').click()
        page.wait_for_function("document.querySelector('[data-viz-id=\"01-evidence\"]').dataset.step === '1'", timeout=5000)
        card.locator('[data-viz-action="play"]').click()
        assert card.locator('[data-viz-action="play"]').get_attribute('aria-pressed') == 'false'
        remembered = card.get_attribute('data-step')
        page.wait_for_timeout(2400)
        assert card.get_attribute('data-step') == remembered
        card.locator('[data-viz-action="play"]').click()
        go(page, "library")
        assert page.evaluate("visualControllers.size") == 0
        go(page, "labs")
        assert page.locator('[data-viz-id="01-evidence"]').get_attribute('data-step') == remembered
        return {"gallery_count": 39, "chapter15_filter": 7, "autoplay_advanced": True, "pause_stable": True, "route_disposal": True, "step_remembered": True}
    record("gallery_playback_and_lifecycle", gallery_and_playback)

    def original_simulator():
        go(page, "labs")
        page.locator('[data-lab-mode="model"]').click()
        rows = []
        for preset, total, ratio, conclusion in [("cpu",270,"92.6%","先调查 CPU 热点"),("io",400,"7.5%","等待主要发生在 I/O 阶段"),("lock",360,"11.1%","等待主要发生在锁竞争阶段")]:
            page.locator(f'[data-preset="{preset}"]').click()
            assert page.locator('#sim-wall').inner_text() == f"{total} ms"
            assert page.locator('#sim-ratio').inner_text() == ratio
            assert conclusion in page.locator('#sim-result').inner_text()
            rows.append({"preset":preset,"wall_ms":total,"cpu_ratio":ratio})
        page.locator('#sim-cpu').evaluate("el=>{el.value='1';el.dispatchEvent(new Event('input',{bubbles:true}));}")
        for selector in ['#sim-io','#sim-lock']:
            page.locator(selector).evaluate("el=>{el.value='0';el.dispatchEvent(new Event('input',{bubbles:true}));}")
        assert page.locator('#sim-wall').inner_text() == '1 ms'
        assert page.locator('#sim-ratio').inner_text() == '100.0%'
        page.locator('[data-lab-mode="practice"]').click()
        assert page.locator('.lab-card').count() > 0
        page.locator('[data-lab-mode="visuals"]').click()
        assert page.locator('[data-viz-id]').count() == 39
        return {"presets":rows,"boundary": "1+0+0=1ms, 100.0% CPU", "all_three_lab_tabs": True}
    record("original_serial_cpu_io_lock_simulator", original_simulator)

    def quizzes_and_review():
        initial_xp = xp(page)
        wrong = []
        for chapter in ORIGINAL:
            cid = chapter['id']
            go(page, f'chapter/{cid}')
            for index, question in enumerate(chapter['quiz']):
                key = f'{cid}:{index}'
                form = page.locator(f'form[data-quiz="{key}"]')
                choice = (question['answer'] + 1) % len(question['options'])
                form.locator(f'input[value="{choice}"]').check()
                form.locator('button[type="submit"]').click()
                assert form.locator('.feedback.wrong').is_visible()
                assert not snapshot(page)['answers'][key]['correct']
                assert xp(page) == initial_xp
                wrong.append(key)
            print(f"  answered chapter {cid}: {len(chapter['quiz'])} wrong-then-review cases", flush=True)
        go(page, 'review')
        assert page.locator('form[data-quiz]').count() == 56
        for step, key in enumerate(wrong):
            cid, index = key.split(':')
            q = next(c for c in ORIGINAL if c['id']==cid)['quiz'][int(index)]
            form = page.locator(f'form[data-quiz="{key}"]')
            form.locator(f'input[value="{q["answer"]}"]').check()
            form.locator('button[type="submit"]').click()
            assert form.count() == 0, f"Correct answer remained in review {key}"
            assert xp(page) == initial_xp + 25*(step+1)
        assert page.locator('form[data-quiz]').count() == 0
        assert '当前错题已清零' in page.locator('#main').inner_text()
        assert page.evaluate('completedChapters()') == 16
        final_xp = xp(page)
        go(page, 'chapter/01')
        form = page.locator('form[data-quiz="01:0"]')
        form.locator('button[type="submit"]').click()
        assert form.locator('.feedback.correct').is_visible() and xp(page)==final_xp
        assert snapshot(page)['answers']['01:0']['attempts']==3
        state_before_reload = snapshot(page)
        page.reload(wait_until='domcontentloaded')
        assert snapshot(page) == state_before_reload
        assert xp(page)==final_xp
        return {"questions":56,"wrong_answers_added":len(wrong),"review_maximum":56,"corrected_and_removed":56,
                "xp_after_sections":initial_xp,"xp_final":final_xp,"repeated_correct_no_extra_xp":True,
                "original_chapters_complete":16,"reload_preserves_state":True}
    record("all_56_quizzes_wrong_review_xp_persistence", quizzes_and_review)

    def import_export():
        go(page, 'resources')
        before = snapshot(page)
        with page.expect_download() as pending:
            page.locator('[data-action="export-progress"]').click()
        download = pending.value
        exported = json.loads(Path(download.path()).read_text())
        assert exported['exportedAt']
        assert {k:v for k,v in exported.items() if k!='exportedAt'} == before
        page.locator('[data-action="reset-progress"]').click()
        assert xp(page)==0 and not snapshot(page)['answers'] and not snapshot(page)['completed']
        empty = snapshot(page)
        page.locator('#import-file').set_input_files({"name":"invalid-course.json","mimeType":"application/json","buffer":json.dumps({"schema":1,"course":"foreign"}).encode()})
        page.wait_for_function("document.getElementById('toast').textContent.includes('导入失败')")
        assert snapshot(page)==empty
        page.locator('#import-file').set_input_files({"name":download.suggested_filename,"mimeType":"application/json","buffer":json.dumps(exported).encode()})
        page.wait_for_function("Object.keys(state.rewards).length > 0")
        assert snapshot(page)==before
        page.reload(wait_until='domcontentloaded')
        assert snapshot(page)==before and xp(page)==2945
        return {"exported_filename":download.suggested_filename,"exported_answers":len(exported['answers']),
                "exported_completed_sections":sum(len(v) for v in exported['completed'].values()),
                "export_matches_memory":True,"reset_clears_state":True,"invalid_import_rejected_without_change":True,
                "roundtrip_strict_equality":True,"reload_after_import":True,"xp":xp(page)}
    record("progress_export_reset_import_roundtrip", import_export)

    def appended_navigation_search():
        go(page, 'chapter/16')
        journey=['16']
        for cid in ['17','18','19','20','21','22']:
            page.locator(f'.chapter-nav [data-chapter="{cid}"]').click()
            page.wait_for_url(URL+f'#chapter/{cid}')
            page.wait_for_selector(f'#section-{cid}-0')
            assert page.locator(f'#section-{cid}-0').count()==1
            journey.append(cid)
        assert page.locator('.chapter-nav [data-nav="review"]').count()==1
        searches=[]
        for cid, index in [('05',0),('19',3)]:
            chapter=next(c for c in DATA['chapters'] if c['id']==cid)
            term=chapter['sections'][index]['title']
            page.locator('#open-search').click()
            page.locator('#search-input').fill(term)
            result=page.locator('#search-results [data-search-index]').first
            assert result.count()==1
            result.click()
            page.wait_for_url(URL+f'#chapter/{cid}/{index}')
            if page.locator(f'#section-{cid}-{index} details.detail-reading').count():
                page.wait_for_function("id => document.querySelector(id).open", arg=f'#section-{cid}-{index} details.detail-reading')
            searches.append({'chapter':cid,'query':term,'section':index,'navigated':True})
        return {'next_chapter_journey':journey,'search_old_and_new':searches}
    record("16_to_22_navigation_and_old_new_search", appended_navigation_search)

    def cross_chapter_position():
        go(page, 'chapter/16/6')
        assert snapshot(page)['lastSection'] == 6
        page.locator('[data-nav="library"]').first.click()
        page.wait_for_selector('#library-query')
        page.locator('#main [data-chapter="01"]').first.click()
        page.wait_for_selector('#section-01-0')
        assert snapshot(page)['lastChapter'] == '01'
        assert snapshot(page)['lastSection'] == 0, 'Cross-chapter route retained out-of-range lastSection'
        before = snapshot(page)
        page.reload(wait_until='domcontentloaded')
        page.wait_for_selector('#section-01-0')
        assert snapshot(page) == before
        go(page, 'resources')
        with page.expect_download() as pending:
            page.locator('[data-action="export-progress"]').click()
        exported = json.loads(Path(pending.value.path()).read_text())
        assert exported['lastChapter'] == '01' and exported['lastSection'] == 0
        page.locator('[data-action="reset-progress"]').click()
        page.locator('#import-file').set_input_files({'name':'position-check.json','mimeType':'application/json','buffer':json.dumps(exported).encode()})
        page.wait_for_function("document.getElementById('toast').textContent.includes('学习记录已恢复')")
        assert snapshot(page) == before
        page.reload(wait_until='domcontentloaded')
        assert snapshot(page) == before
        go(page, 'chapter/01/3')
        assert snapshot(page)['lastSection'] == 3
        go(page, 'library')
        page.locator('#main [data-chapter="01"]').first.click()
        page.wait_for_selector('#section-01-0')
        assert snapshot(page)['lastSection'] == 3, 'Same-chapter reading position changed'
        return {'journey':'chapter/16/6 → library → chapter/01', 'last_section_after_navigation':0,
                'reload_strict_equality':True,'export_import_refresh_strict_equality':True,
                'explicit_section_preserved':3,'same_chapter_position_preserved':True}
    record('cross_chapter_reading_position_and_export', cross_chapter_position)

    def legacy_url_compatibility():
        before = snapshot(page)
        cases=[]
        for old_number in range(1,7):
            new_id=str(old_number+16)
            for old_hash, new_hash in [(f'ch-{old_number}',f'chapter/{new_id}'),(f'ch-{old_number}-s-4',f'chapter/{new_id}/3')]:
                page.goto(URL+'#'+old_hash,wait_until='domcontentloaded')
                page.wait_for_url(URL+'#'+new_hash)
                page.wait_for_selector(f'#section-{new_id}-0')
                assert snapshot(page)['lastChapter']==new_id
                assert snapshot(page)['lastSection']==(3 if '-s-' in old_hash else 0)
                if '-s-' in old_hash:
                    page.wait_for_function("id => document.activeElement === document.querySelector(id+' h2')",arg=f'#section-{new_id}-3')
                cases.append({'old':old_hash,'canonical':new_hash})
        after=snapshot(page)
        for field in ['completed','answers','rewards']:
            assert after[field]==before[field], f'Legacy navigation changed {field}'
        return {'cases':cases,'chapter_links':6,'section_links':6,'original_progress_unchanged':True}
    record('legacy_chapter_and_section_url_compatibility', legacy_url_compatibility)

    def responsive_layout():
        checks=[]
        routes=['learn','library','labs','review','resources'] + [f'chapter/{c["id"]}' for c in DATA['chapters']]
        for width in [320,390,1440]:
            page.set_viewport_size({'width':width,'height':900 if width<500 else 1000})
            for route_name in routes:
                go(page, route_name)
                page.wait_for_timeout(70)
                result=page.evaluate("""() => ({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,
                    main:document.getElementById('main').getBoundingClientRect().toJSON(),
                    badVisuals:[...document.querySelectorAll('[data-visual-error]')].map(el=>el.dataset.vizId),
                    h1:document.querySelector('#main h1')?.getBoundingClientRect().toJSON()})""")
                assert result['scrollWidth']<=width+1, f"Page overflow at {width}px / {route_name}: {result['scrollWidth']}px"
                assert not result['badVisuals'], f"Broken mechanism at {width}px / {route_name}"
                assert result['h1']['width']>80
                checks.append({'viewport':width,'route':route_name,'document_width':result['scrollWidth']})
                if route_name in ['learn','chapter/01']:
                    screenshot(page,f'{width}-{route_name.replace("/","-")}')
            print(f"  responsive width {width}: {len(routes)} routes",flush=True)
        return {'route_viewport_pairs':len(checks),'no_horizontal_page_overflow':True,'checks':checks}
    record("320_390_1440_responsive_layout", responsive_layout)

    def legacy_six_chapter_migration():
        seeded=browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce')
        original={"schema":1,"course":"golab-go-profiling-v1","completed":{"01":[0]},"answers":{"01:0":{"choice":ORIGINAL[0]['quiz'][0]['answer'],"correct":True,"at":"2026-10-05T00:00:00Z","attempts":1}},"rewards":{"section:01:0":"2026-10-05","quiz:01:0":"2026-10-05"},"lastChapter":"01","lastSection":0}
        legacy={"current":"ch-6","completed":["ch-1","ch-6"],"answers":{"ch-1":DATA['chapters'][16]['quiz'][0]['answer'],"ch-6":DATA['chapters'][21]['quiz'][0]['answer']}}
        init="""if (!localStorage.getItem('test-seeded')) {localStorage.setItem('golab.go-profiling.v1', %s);localStorage.setItem('go-profiling-principles-2026-10-04-v1', %s);localStorage.setItem('test-seeded','1');}""" % (json.dumps(json.dumps(original)),json.dumps(json.dumps(legacy)))
        seeded.add_init_script(init)
        sp=seeded.new_page()
        sp.goto(URL,wait_until='domcontentloaded')
        migrated=snapshot(sp)
        assert migrated['completed']['01']==[0] and migrated['answers']['01:0']==original['answers']['01:0'] and migrated['rewards']==original['rewards']
        assert len(migrated['completed']['17'])==len(DATA['chapters'][16]['sections'])
        assert len(migrated['completed']['22'])==len(DATA['chapters'][21]['sections'])
        assert migrated['answers']['17:0']['correct'] and migrated['answers']['22:0']['correct']
        assert xp(sp)==40 and migrated['lastChapter']=='01'
        sp.on('dialog',lambda d:d.accept())
        go(sp,'resources')
        sp.locator('[data-action="reset-progress"]').click()
        sp.reload(wait_until='domcontentloaded')
        assert xp(sp)==0 and snapshot(sp)['completed']=={}
        seeded.close()
        return {'original_state_preserved':True,'completed_mapped':['17','22'],'answers_mapped':['17:0','22:0'],
                'xp_before_after':40,'current_chapter_preserved':'01','reset_does_not_reimport':True}
    record("actual_browser_six_chapter_progress_migration",legacy_six_chapter_migration)

    context.close()
    browser.close()

REPORT['finished_utc']=datetime.now(timezone.utc).isoformat()
REPORT['status']='passed' if not REPORT['issues'] and not REPORT['page_errors'] and not REPORT['console_errors'] else 'failed'
save()
print(json.dumps({'status':REPORT['status'],'passed_checks':sum(c['status']=='passed' for c in REPORT['checks'].values()),'issues':REPORT['issues'],'page_errors':REPORT['page_errors'],'report':str(OUT)},ensure_ascii=False),flush=True)
if REPORT['status'] != 'passed':
    raise SystemExit(1)
