#!/usr/bin/env python3
"""Fetch official Perfetto v58.2 Linux amd64 tools and verify release digest."""
from pathlib import Path
import hashlib,json,platform,subprocess,urllib.request,zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'examples/perfetto';OUT.mkdir(parents=True,exist_ok=True)
URL='https://github.com/google/perfetto/releases/download/v58.2/linux-amd64.zip'
DIGEST='32c739f71b2d39721afd294c0b038f2499a44a71b5b6bcdd85b83faca0b240b9'
if platform.system()!='Linux' or platform.machine() not in ['x86_64','amd64']:
    raise SystemExit('This verified download is for Linux amd64 only. Use the matching official release for your platform.')
p=OUT/'linux-amd64-v58.2.zip'
if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=DIGEST:
    temp=p.with_suffix('.partial')
    print('Downloading official v58.2 release...')
    with urllib.request.urlopen(URL,timeout=60) as r,temp.open('wb') as f:
        while True:
            block=r.read(65536)
            if not block:break
            f.write(block)
    if hashlib.sha256(temp.read_bytes()).hexdigest()!=DIGEST:
        raise SystemExit('Digest mismatch; downloaded file was not extracted.')
    temp.replace(p)
assert p.stat().st_size==14123443
with zipfile.ZipFile(p) as z:
    for name in z.namelist():
        if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('Unsafe archive path')
    z.extractall(OUT/'bin')
for f in (OUT/'bin/linux-amd64').iterdir():
    if f.is_file():f.chmod(f.stat().st_mode|0o111)
version=subprocess.check_output([str(OUT/'bin/linux-amd64/trace_processor_shell'),'--version'],text=True)
assert 'v58.2-add693d8b' in version,version
(OUT/'download.json').write_text(json.dumps({'version':'v58.2','url':URL,'sha256':DIGEST,'bytes':p.stat().st_size,'verified_against_official_release_digest':True},indent=2)+'\n')
print(version)
