import json,re,pathlib,subprocess,os
root=pathlib.Path(__file__).resolve().parents[1];out=root/'verification/examples';out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(GOTOOLCHAIN='go1.25.0',GOPATH=str(root/'lab/.gopath'),GOCACHE=str(root/'lab/.gocache'))
data=json.loads((root/'base-course/content/chapters-05-10.json').read_text());results=[]
for c in data:
 for s in c['sections']:
  for code in re.findall(r'```go\n(.*?)```',s['body'],re.S):
   if re.search(r'^package main\s',code):
    folder=out/(c['id']+'-'+str(len(results)));folder.mkdir(exist_ok=True)
    (folder/'main.go').write_text(code);(folder/'go.mod').write_text('module example.com/check\n\ngo 1.25\n')
    p=subprocess.run(['go','build','-o','example','.'],cwd=folder,env=env,capture_output=True,text=True,timeout=180)
    results.append(dict(chapter=c['id'],section=s['title'],exit_code=p.returncode,output=p.stdout+p.stderr,path=str(folder.relative_to(root))))
    print(c['id'],s['title'],p.returncode,p.stderr[:300],flush=True)
(out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
if any(r['exit_code'] for r in results):raise SystemExit(1)
