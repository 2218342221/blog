import json,pathlib,subprocess,os,socket,urllib.request,time
root=pathlib.Path(__file__).resolve().parents[1];base=root/'verification/examples';results=[]
env=os.environ.copy();env.update(GOTOOLCHAIN='go1.25.0',GOPATH=str(root/'lab/.gopath'),GOCACHE=str(root/'lab/.gocache'))
for folder in sorted(base.iterdir()):
 if not folder.is_dir():continue
 if folder.name=='10-6':continue
 p=subprocess.run([str(folder/'example')],cwd=folder,env=env,capture_output=True,text=True,timeout=30)
 (folder/'run.log').write_text(p.stdout+p.stderr);results.append(dict(example=folder.name,exit_code=p.returncode))
 print(folder.name,p.returncode,flush=True)
 if p.returncode:raise RuntimeError(folder.name)
 for profile in folder.glob('*.pprof'):
  p=subprocess.run(['go','tool','pprof','-top',str(profile)],cwd=folder,env=env,capture_output=True,text=True,timeout=30)
  (folder/(profile.name+'.top.txt')).write_text(p.stdout+p.stderr);results.append(dict(profile=str(profile.relative_to(root)),parse_exit_code=p.returncode))
  if p.returncode:raise RuntimeError('profile parse')
folder=base/'08-3'
p=subprocess.run(['go','tool','trace','-pprof=sched','flight.trace'],cwd=folder,env=env,capture_output=True,timeout=30)
(folder/'flight-sched.pb.gz').write_bytes(p.stdout);results.append(dict(check='FlightRecorder output parser',exit_code=p.returncode))
if p.returncode:raise RuntimeError(p.stderr)
# The unmodified program was already compiled. Runtime probe changes only its
# loopback port because 6060 belongs to a pre-existing process.
folder=base/'10-6';adapted=folder/'port-probe';adapted.mkdir(exist_ok=True)
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
(adapted/'main.go').write_text((folder/'main.go').read_text().replace('127.0.0.1:6060','127.0.0.1:'+str(port)))
p=subprocess.run(['go','build','-o','demo','main.go'],cwd=adapted,env=env,capture_output=True,text=True,timeout=30)
if p.returncode:raise RuntimeError(p.stderr)
proc=subprocess.Popen([str(adapted/'demo')],cwd=adapted,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 for i in range(60):
  try:
   with urllib.request.urlopen('http://127.0.0.1:'+str(port)+'/debug/pprof/goroutine',timeout=2) as r:payload=r.read()
   break
  except Exception:time.sleep(.05)
 else:raise RuntimeError('diagnostic endpoint timeout')
 (adapted/'goroutine.pb.gz').write_bytes(payload)
 results.append(dict(example='10-6',check='GET goroutine endpoint',bytes=len(payload),adaptation='Only loopback port changed to preserve existing 6060 service'))
finally:
 proc.terminate();proc.wait(timeout=5)
(base/'run-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('all executable examples checked',flush=True)
