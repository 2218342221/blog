#!/usr/bin/env python3
"""Code-native vector diagrams, rendered from one model to SVG and TikZ."""
from pathlib import Path
import html, json, math

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/figures'; OUT.mkdir(parents=True,exist_ok=True)
COLORS={'green':'#58A700','blue':'#1976D2','purple':'#8150B5','orange':'#BD6500','red':'#CB3A45','ink':'#233448','gray':'#637386','light':'#F2F8ED'}
def tex(s):
    return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)

class Figure:
    def __init__(self,id,ch,section,title,caption,height=340):
        self.id,self.ch,self.section,self.title,self.caption,self.h=id,ch,section,title,caption,height
        self.items=[]
    def text(self,x,y,s,color='ink',size=19,anchor='middle'):
        self.items.append(('text',x,y,s,color,size,anchor));return self
    def box(self,x,y,w,h,lines,color='blue'):
        self.items.append(('box',x,y,w,h,color))
        if isinstance(lines,str):lines=lines.split('|')
        for i,s in enumerate(lines):self.text(x+w/2,y+h/2+(i-(len(lines)-1)/2)*27,s,size=19 if i==0 else 17)
        return self
    def line(self,x1,y1,x2,y2,color='gray',arrow=False,dash=False):
        self.items.append(('line',x1,y1,x2,y2,color,arrow,dash));return self
    def arrow(self,x1,y1,x2,y2,label=''):
        self.line(x1,y1,x2,y2,arrow=True)
        if label:self.text((x1+x2)/2,(y1+y2)/2-15,label,size=16)
        return self
    def flow(self,labels,notes=None):
        n=len(labels); w=min(270,(900-(n-1)*35)/n);x=(960-n*w-(n-1)*35)/2
        for i,s in enumerate(labels):
            self.box(x+i*(w+35),75,w,112,s,['blue','purple','green','orange'][i%4])
            if i<n-1:self.arrow(x+i*(w+35)+w+3,130,x+(i+1)*(w+35)-4,130)
        if notes:
            for i,s in enumerate(notes):self.text(480,235+i*29,s,size=18)
        return self
    def save(self):
        svg=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 {self.h}" role="img" aria-labelledby="{self.id}-title {self.id}-desc"><title id="{self.id}-title">{html.escape(self.title)}</title><desc id="{self.id}-desc">{html.escape(self.caption)}</desc><defs><marker id="{self.id}-arrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="#637386"/></marker></defs><rect width="960" height="{self.h}" fill="white" rx="16"/>']
        tik=[r'\begin{tikzpicture}[x=0.016cm,y=-0.016cm]',fr'\path[use as bounding box] (0,0) rectangle (960,{self.h});']
        for item in self.items:
            k,*a=item
            if k=='text':
                x,y,s,c,size,anchor=a;c=COLORS.get(c,c)
                svg.append(f'<text x="{x}" y="{y}" fill="{c}" font-family="Noto Sans CJK SC,Microsoft YaHei,sans-serif" font-size="{size}" text-anchor="{anchor}" dominant-baseline="middle">{html.escape(s)}</text>')
                ta={'middle':'center','start':'west','end':'east'}[anchor]
                tik.append(fr'\node[anchor={ta},text={{rgb,255:red,{int(c[1:3],16)};green,{int(c[3:5],16)};blue,{int(c[5:7],16)}}},font=\fontsize{{{size*0.48:.1f}}}{{{size*0.58:.1f}}}\selectfont] at ({x},{y}) {{{tex(s)}}};')
            elif k=='box':
                x,y,w,h,c=a;c=COLORS.get(c,c)
                svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="13" fill="{c}" fill-opacity=".075" stroke="{c}" stroke-width="2"/>')
                rgb='{rgb,255:red,%d;green,%d;blue,%d}' % (int(c[1:3],16),int(c[3:5],16),int(c[5:7],16))
                tik.append(fr'\draw[rounded corners=5pt,draw={rgb},fill={rgb},fill opacity=.075] ({x},{y}) rectangle ({x+w},{y+h});')
            elif k=='line':
                x,y,xx,yy,c,arrow,dash=a;c=COLORS.get(c,c)
                tail=(f' marker-end="url(#{self.id}-arrow)"' if arrow else '')+(' stroke-dasharray="7 5"' if dash else '')
                svg.append(f'<line x1="{x}" y1="{y}" x2="{xx}" y2="{yy}" stroke="{c}" stroke-width="2.3"{tail}/>')
                opts=[f'draw={{rgb,255:red,{int(c[1:3],16)};green,{int(c[3:5],16)};blue,{int(c[5:7],16)}}}']
                if arrow:opts+=['-{Stealth[length=4pt]}']
                if dash:opts+=['dashed']
                tik.append(fr'\draw[{",".join(opts)}] ({x},{y}) -- ({xx},{yy});')
        svg.append('</svg>');tik.append(r'\end{tikzpicture}')
        (OUT/f'{self.id}.svg').write_text('\n'.join(svg))
        (OUT/f'{self.id}.tex').write_text('\n'.join(tik))
        return {'id':self.id,'chapter':self.ch,'section':self.section,'title':self.title,'caption':self.caption,'height':self.h}

figs=[]
def new(*args,**kwargs):
    f=Figure(*args,**kwargs);figs.append(f);return f

new('layers',1,1,'三种能力，三个层次','eBPF 是可编程采集机制；pprof 组织栈权重；Perfetto 组织时间事件。箭头表示一种可能的数据通路，不是内置的自动转换。').flow(['eBPF|事件触发与受限执行','pprof|栈 + 类型 + 权重','Perfetto|事件 + 身份 + 时间'],['可分别使用，也可通过明确的数据转换组合','采集能力、聚合语义与时间语义必须逐层说明'])

f=new('identities',1,3,'三种身份不能混为一谈','请求、Go goroutine、OS 线程分别有生命周期；箭头表示需显式建立的关联，不是ID相等。')
f.box(30,60,240,100,'业务请求|request=demo','green').box(360,60,240,100,'运行时任务|G / task','purple').box(690,60,240,100,'OS 执行实体|PID / TID','blue')
f.arrow(275,110,355,110).arrow(605,110,685,110)
f.text(480,220,'一个请求可涉及多个 G；一个 M 会执行不同 G')
f.text(480,258,'观察到时间重叠，只能得到候选关联，不能直接确认归属',size=18)

new('evidence',1,4,'观察到的热点怎样变成可检验的结论','优化需要控制工作量并进行干预。源码解释、合成输入验证与真实负载实验支持不同层次的结论。').flow(['控制条件|工作量 / 构建 / 环境','提出机制|热点 / 等待 / 队列','干预与复测|延迟 / CPU / 错误率'],['同时保存原始数据、配置、版本与缺失指标','图形是证据的呈现，不替代对照实验'])

new('bpf-lifecycle',2,1,'eBPF 的加载与运行生命周期','加载时验证程序，事件发生时执行程序；CO-RE 是加载前后的重定位环节之一，attach 决定何时触发。').flow(['用户态 loader|ELF / BTF / 重定位','内核加载|verifier → JIT 等路径','事件触发|执行 → map / 输出'],['加载成功与测量正确是两个判断','程序类型、attach 点、helper 和权限共同约束能力'])

f=new('bpf-verifier',2,3,'验证器跟踪的是抽象状态','示例表达空指针检查如何收窄指针状态。实际 verifier 还追踪标量范围、已知位、栈初始化、引用及路径等；图不覆盖全部规则。',380)
f.box(20,105,235,110,'map_lookup_elem|PTR_OR_NULL','blue')
f.box(350,20,260,105,'空指针分支|结束 / 不解引用','orange').box(350,220,260,105,'非空分支|有效 map value 指针','green')
f.arrow(260,150,345,75,'== NULL').arrow(260,170,345,265,'!= NULL')
f.box(715,220,220,105,'再检查偏移与边界|允许受限访问','purple').arrow(615,273,710,273)
f.text(785,80,'证明模型内安全',size=20).text(785,117,'不证明业务语义正确',size=17)

f=new('bpf-core',2,2,'CO-RE：把字段意图迁移到目标布局','图中字段偏移为示意数值。CO-RE 用 BTF 类型与 relocation 信息重写相应访问，不保证 helper、内核功能和语义都兼容。')
f.box(25,60,265,120,'编译时布局（示意）|字段 state：偏移 16','blue')
f.box(345,60,265,120,'BTF + relocation|定位同名结构成员','purple')
f.box(665,60,265,120,'目标布局（示意）|字段 state：偏移 24','green')
f.arrow(295,120,340,120).arrow(615,120,660,120)
f.text(480,240,'迁移的是结构访问意图；功能探测和语义兼容仍需另行处理')

f=new('bpf-ring',2,5,'ring buffer 的保留顺序与可见性','多生产者共享 ring buffer。较早记录仍 busy 时，消费者不能跳过它消费后面的已提交记录；reserve 失败必须计数。')
for i,(s,c) in enumerate([('A 已提交','green'),('B busy','orange'),('C 已提交','green'),('空闲容量','gray')]):f.box(35+225*i,90,210,80,s,c)
f.arrow(140,240,140,175).text(140,275,'消费者',size=18)
f.text(490,215,'读完 A 后在 B 等待',color='orange').text(490,255,'C 已提交也不能越过 B',size=18)

new('bpf-unwind',2,6,'取得用户栈并不是读取几个地址','PC、寄存器、映射和运行时元数据决定可展开范围。FP、DWARF 及语言运行时展开策略不同；失败应进入未知归因。').flow(['采样现场|PC / SP / 寄存器','展开与身份|FP / DWARF / runtime','符号化与归因|构建 ID / 内联 / 标签'],['CO-RE 不会自动修复 Go 的用户态栈展开','截断、缺失映射、原生代码和 G/M 切换都可能影响结果'])

new('pp-pipeline',3,1,'时间记录如何压缩为栈权重','Go CPU builder 忽略逐事件时间戳，按栈及标签聚合。编码字段只能保留被写入的信息。').flow(['底层观察|时间戳 / PCs / 标签','profile.proto|同栈同标签累加权重','分析报告|flat / cum / 火焰图'],['逐事件先后在聚合时丢失','重新排列已聚合的 Sample，不能恢复请求时间线'])

new('pp-cpu',3,2,'Go CPU 采样的两种执行环境','Go 1.25 Linux 路径的简化图：线程 CPU 时钟触发信号，受限信号处理器写有界日志，普通 goroutine 异步构建 profile。').flow(['CPU 时钟 → SIGPROF|名义 100 Hz','受限现场展开栈|有界日志 / 溢出计数','普通 goroutine|count × period'],['睡眠时间不会自动成为 CPU 样本','已知 lost 数量可保留部分总量，却无法恢复原业务栈'])

f=new('pp-heap',3,3,'按字节采样的包含概率','理想 Poisson 模型 q(s)=1-exp(-s/R)，R=512KiB。小对象更难入样，命中后携带更大的逆概率权重；实际实现有近似。',390)
f.line(90,300,610,300,arrow=True).line(90,300,90,35,arrow=True)
f.text(110,23,'q',size=20);f.text(350,343,'分配大小 s / R',size=18)
for i in range(4):
    x=90+i/3*480;f.text(x,323,str(i),size=16)
for i in range(3):f.text(58,300-i*125,str(i/2),size=16)
last=None
for i in range(61):
    s=i/20;x=90+s*160;y=300-(1-math.exp(-s))*250
    if last:f.line(*last,x,y,'green')
    last=x,y
f.box(655,65,275,100,'64 KiB：q ≈ 0.1175|权重倍数 ≈ 8.51','blue')
f.box(655,200,275,100,'512 KiB：q ≈ 0.6321|权重倍数 ≈ 1.58','purple')

new('pp-wait',3,4,'相似的等待，不同的归因','block 将特定同步阻塞归到等待位置；mutex 通常归到释放路径。二者会描述同一争用的不同视角，不能直接相加。').flow(['等待者|block：阻塞位置','锁持有者|mutex：释放路径','调度状态|runnable → running'],['等待权重是并发需求的累计，不是一次持锁时长','事件完成记账的窗口，不一定等于等待区间与窗口的交集'])

f=new('pp-proto',3,5,'profile.proto 的共享表与引用','Sample 的栈叶在前；一个 Location 可以包含多条内联 Line。ID 是文件内引用，不是地址。',380)
f.box(30,80,260,160,'Sample|location_id[]|value[] / label[]','blue')
f.box(360,50,250,105,'Location|address + Line[]','purple').box(360,220,250,95,'Mapping|构建 / 地址映射','orange')
f.box(690,50,240,105,'Function|名字 / 文件 / 行','green')
f.arrow(295,130,355,100).arrow(615,100,685,100).arrow(485,160,485,215)
f.text(800,260,'所有 value 列按',size=18).text(800,290,'sample_type 解释',size=18)

f=new('pp-denominator',3,6,'同一成本，两种正确的百分比','合成教学基线：全局480ms、route=A共320ms、A中的HashRound为80ms。默认分母和relative_percentages回答不同条件集合。')
f.box(50,70,390,150,'默认总量：480 ms|80 / 480 = 16.67%','blue')
f.box(520,70,390,150,'条件总量：320 ms|80 / 320 = 25%','green')
f.text(480,280,'变化的是分母，80 ms 的绝对成本没有变化')

f=new('pp-graph',3,7,'局部调用边不等于完整路径','两条原始栈 A→F→X 与 B→F→Y 的合并调用图会共享F；图上的连接不能证明 A→F→Y 曾出现。')
f.box(40,45,190,85,'A','blue').box(40,190,190,85,'B','blue').box(385,110,190,95,'F','purple').box(730,45,190,85,'X','green').box(730,190,190,85,'Y','green')
f.arrow(235,87,380,150).arrow(235,233,380,170).arrow(580,150,725,87).arrow(580,170,725,233)
f.text(480,305,'调用树 / 栈视图保留更多路径上下文',size=18)

new('pf-service',4,2,'Perfetto 的生产者、服务与消费者','Producer 通过共享内存提交数据；service 管理会话缓冲；consumer 配置和读取。共享内存减少传输开销，不代表全链路零拷贝。').flow(['Producer / DataSource|TraceWriter / 共享内存','Tracing service|会话缓冲 / 提交协议','Consumer|配置 / 读取 / 保存'],['写入、commit、flush、stop 是不同阶段','缓冲策略决定覆盖旧数据还是丢弃新数据等行为'])

new('pf-sequence',4,5,'增量状态为压缩提供上下文','InternedData 的标识在 packet sequence 等上下文内解释。丢失依赖的状态包会使后续引用无法可靠解析，需等待有效重置。').flow(['序列字典|iid 7 → 名字 Encode','后续 TrackEvent|引用 iid 7','解码器状态|序列有效才可解释'],['同一个 iid 在不同序列中不保证相同含义','文件仍可解析，不意味着每个事件都可完整恢复'])

new('pf-clock',4,5,'时间戳相同单位，不代表相同时间域','ClockSnapshot 提供不同时间域的关联依据。转换后仍需考虑采集精度、快照覆盖和误差；纳秒存储不等于纳秒准确度。').flow(['时钟 A|timestamp + clock id','同步信息|ClockSnapshot / 转换','统一分析时间|排序 / 区间 / 查询'],['先说明时钟来源，再做跨来源差值','观测间隔小于相对不确定度时，严格先后难以确定'])

new('pf-processing',4,6,'Trace Processor 的处理流水线','不同输入由相应 tokenizer/importer 接受；时间排序和语义解析后落入列式存储，再通过 SQL 表查询。').flow(['识别 / tokenize|包边界 / 增量状态','sort / parse|时间顺序 / 语义重建','storage / SQL|slice / sched / counter'],['通用 slice 与内核 sched_slice 表达不同事实','dur=-1 的未闭合区间要显式处理，不能当作负耗时'])

f=new('pf-import',4,7,'导入格式不等于恢复所有语义','Perfetto v58.2 可导入 pprof 聚合权重；本实验 slice 与 sched_slice 仍为空。原生 Go trace 的直接导入失败。')
f.box(35,65,265,105,'pprof 文件|栈 + 权重','blue').box(355,65,265,105,'aggregate_sample|4 / 15 / 4 ms','green').box(675,65,250,105,'时间线并未出现|slice / sched = 0','orange')
f.arrow(305,115,350,115).arrow(625,115,670,115)
f.text(480,245,'原生 Go trace → 本次 TP：Unknown trace type provided',size=18)

f=new('request-timeline',5,1,'同一请求的三种时间','合成模型，非内核实测。主线程运行8ms、可运行2ms、睡眠10ms；worker运行15ms。两线程已由模型明确归属于该请求。',380)
f.text(110,90,'main',anchor='end');f.text(110,195,'worker',anchor='end')
for a,b,label,color in [(0,4,'运行 4','green'),(4,6,'就绪 2','orange'),(6,16,'睡眠 10','blue'),(16,20,'运行 4','green')]:f.box(140+a*38,55,(b-a)*38,75,label,color)
f.box(178,160,570,75,'运行 15 ms','purple')
for t in [0,1,4,6,16,20]:f.line(140+38*t,250,140+38*t,260);f.text(140+38*t,285,str(t),size=17)
f.line(140,250,900,250);f.text(480,332,'墙钟 20 ms；CPU 8 + 15 = 23 ms；平均容量 1.15 核',size=20)

new('request-comparison',5,3,'同一模型经过两条数据通路','两种文件共享教学场景，并非互相无损转换。pprof验证聚合算法；ftrace输入由Perfetto重建调度与区间。').flow(['场景定义|确定归属 / 区间 / 栈','两份合成输入|request.pprof + ftrace','真实工具验证|pprof + Trace Processor'],['pprof：main 8 / worker 15 ms；CPU 总量 23 ms','Perfetto：主线程 Running 8 / R 2 / S 10 ms'])

new('selection',6,1,'按缺失的证据选择下一步','先写出尚不确定的问题，再选择能够增加所缺维度的采集。多个工具给出一致图形也不能替代研究设计。').flow(['成本分布不明|CPU / heap profile','时间原因不明|调度 / runtime trace','内核边界不明|有针对性的 eBPF'],['保存身份、构建、单位、窗口、过滤条件和缺失计数','采样降开销；聚合降传输；每种压缩都有信息代价'])

f=new('pf-chunk',4,3,'chunk 的正常交接状态','典型路径是 Free → BeingWritten → Complete → BeingRead → Free。packet 可跨 chunk，长度补丁还可能延后完成；图未列出全部例外路径。')
for i,(s,c) in enumerate([('Free','gray'),('BeingWritten','blue'),('Complete','green'),('BeingRead','purple')]):
    f.box(30+232*i,90,204,90,s,c)
    if i<3:f.arrow(238+232*i,135,258+232*i,135)
f.line(828,186,828,230).line(828,230,132,230).arrow(132,230,132,186)
f.text(480,282,'writer 写入与发布；service 拷贝后释放所有权',size=18)

f=new('pf-retention',4,4,'相同容量，两种保留政策','容量假设为四个等宽块，输入为1至6。示意块不是实际packet；真实可读窗口还依赖分片完整性与增量状态。')
f.text(160,100,'RING_BUFFER',anchor='end',size=18).text(160,215,'DISCARD',anchor='end',size=18)
for i in range(4):f.box(205+i*175,60,155,80,str(i+3),'green');f.box(205+i*175,175,155,80,str(i+1),'blue')
f.text(480,302,'保留较新数据                         保留较早的未读数据',size=18)

manifest=[f.save() for f in figs]
(ROOT/'assets/figure_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(f'Wrote {len(manifest)} SVG / TikZ figure pairs')
