#!/usr/bin/env python3
"""Check the integrated course's served bytes and inline PDF range contract."""
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parents[1]
URL = os.environ.get('COURSE_URL', 'http://127.0.0.1:8765/').rstrip('/') + '/'
checks, files = {}, {}


def request(path, headers=None, method='GET'):
    try:
        response = urlopen(Request(URL + path, headers=headers or {}, method=method), timeout=30)
    except HTTPError as error:
        response = error
    with response:
        return response.status, response.headers, response.read()


for name in ['index.html', 'pdf.html', 'golang-profiling.pdf', 'golang-profiling.tex',
             'golang-profiling.md', 'course-data.json', 'sources.json',
             'principles.pdf', 'principles.tex', 'principles.md']:
    local = (ROOT / 'dist' / name).read_bytes()
    code, headers, body = request(name)
    checks[name + '_http_200_exact_bytes'] = code == 200 and body == local
    files[name] = {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(),
                   'content_type': headers.get('Content-Type')}
    if name.endswith('.pdf'):
        checks[name + '_inline_filename'] = headers.get('Content-Disposition') == f'inline; filename="{name}"'
        checks[name + '_pdf_type'] = headers.get('Content-Type') == 'application/pdf'

pdf = (ROOT / 'dist/golang-profiling.pdf').read_bytes()
code, headers, body = request('golang-profiling.pdf', method='HEAD')
checks['head_pdf_length_no_body'] = code == 200 and not body and int(headers['Content-Length']) == len(pdf)
for value, expected, start, end in [('bytes=0-1023', pdf[:1024], 0, 1023),
                                   ('bytes=-1024', pdf[-1024:], len(pdf)-1024, len(pdf)-1),
                                   (f'bytes={len(pdf)-128}-', pdf[-128:], len(pdf)-128, len(pdf)-1)]:
    code, headers, body = request('golang-profiling.pdf', {'Range': value})
    checks[value + '_206_correct_range'] = code == 206 and body == expected and headers.get('Content-Range') == f'bytes {start}-{end}/{len(pdf)}'
code, headers, body = request('golang-profiling.pdf', {'Range': f'bytes={len(pdf)}-'})
checks['out_of_bounds_416'] = code == 416 and not body and headers.get('Content-Range') == f'bytes */{len(pdf)}'
code, headers, body = request('golang-profiling.pdf', {'Range': 'bytes=not-a-range'})
checks['malformed_range_full_response'] = code == 200 and body == pdf
code, headers, body = request('golang-profiling.pdf', {'Range': 'bytes=0-5', 'If-Range': 'unmatched-validator'})
checks['unmatched_if_range_full_response'] = code == 200 and body == pdf
report = {'status': 'passed' if all(checks.values()) else 'failed',
          'url': URL, 'checked_utc': datetime.now(timezone.utc).isoformat(),
          'checks': checks, 'files': files,
          'package_http_verification': 'Recorded separately in package-verification.json after archive generation.'}
(ROOT / 'verification/merged-http-check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'checks': len(checks), 'failed': [k for k,v in checks.items() if not v]}))
assert all(checks.values())
