#!/usr/bin/env python3
"""Render the appended mechanism chapters from reviewed Markdown."""
from pathlib import Path
import html,json,re,hashlib
import mistune
from latex2mathml.converter import convert as mathml

ROOT=Path(__file__).resolve().parents[1]
TITLE='eBPF、pprof 与 Perfetto 原理研读'
sources=[]
for name in ['ebpf','pprof','perfetto']:
    sources+=json.loads((ROOT/f'research/sources-{name}.json').read_text())
lookup={s['id']:i+1 for i,s in enumerate(sources)}
source_map={s['id']:s for s in sources}
assert len(lookup)==len(sources)
figures=json.loads((ROOT/'assets/figure_manifest.json').read_text())
inputs=['content/01-model.md','research/ebpf.md','research/pprof.md','research/perfetto.md','content/05-experiment.md','content/06-method.md']
parse=mistune.create_markdown(renderer='ast',plugins=['table','math'])

def esc(s):
    return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)
def inlinecode(s):
    if re.fullmatch(r'[a-f0-9]{24,}',s):
        return r'\texttt{'+r'\allowbreak{}'.join(s[i:i+8] for i in range(0,len(s),8))+'}'
    return r'\texttt{'+''.join(esc(c)+(r'\allowbreak{}' if c in '/._-,' else '') for c in s)+'}'
def children(t,mode):return ''.join(render(x,mode) for x in t.get('children',[]))
def table(t,mode):
    head=t['children'][0]['children']; rows=t['children'][1]['children'];n=len(head)
    if mode=='html':
        return '<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+children(c,mode)+'</th>' for c in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+children(c,mode)+'</td>' for c in r['children'])+'</tr>' for r in rows)+'</tbody></table></div>'
    width=(15.8-(n-1)*.38)/n
    widths=[width]*n
    if n==5 and '逻辑路径' in children(head[1],'html'):widths=[1.75,6.0,1.15,1.6,2.6]
    spec='@{}'+'@{\hspace{0.38cm}}'.join(f'p{{{w:.3f}cm}}' for w in widths)+'@{}'
    row=lambda cells:' & '.join(children(c,mode) for c in cells)+r' \\'+'\n'
    return '\n{\\small\n\\begin{longtable}{'+spec+'}\n\\toprule\n'+row(head)+r'\midrule\endhead'+'\n'+''.join(row(r['children']) for r in rows)+r'\bottomrule\end{longtable}}'+'\n'
def render(t,mode):
    typ=t['type'];raw=t.get('raw','');c=lambda:children(t,mode)
    if typ=='text':return html.escape(raw) if mode=='html' else esc(raw).replace('→',r'→\allowbreak{}').replace(r'\_',r'\_\allowbreak{}')
    if typ in ['softbreak','linebreak']:return '\n' if mode=='html' else ' '
    if typ=='codespan':return '<code>'+html.escape(raw)+'</code>' if mode=='html' else inlinecode(raw)
    if typ in ['inline_math','block_math']:
        if mode=='html':return mathml(raw,display='block' if typ=='block_math' else 'inline')
        return ('\\['+raw+'\\]' if typ=='block_math' else '\\('+raw+'\\)')
    if typ in ['paragraph','block_text']:
        return '<p>'+c()+'</p>\n' if mode=='html' else c()+'\n\n'
    if typ=='heading':
        n=t['attrs']['level']
        # Strip locally written section numbers; LaTeX numbers the hierarchy.
        cc=c();cc=re.sub(r'^\d+(?:\.\d+)*\.?(?:\s+)', '',cc)
        if mode=='html':return f'<h{n}>'+cc+f'</h{n}>\n'
        return '\\'+{1:'chapter',2:'section',3:'subsection',4:'subsubsection'}.get(n,'paragraph')+'{'+cc+'}\n'
    if typ=='strong':return '<strong>'+c()+'</strong>' if mode=='html' else r'\textbf{'+c()+'}'
    if typ=='emphasis':return '<em>'+c()+'</em>' if mode=='html' else r'\emph{'+c()+'}'
    if typ=='link':
        url=t['attrs']['url'];label=c()
        if url.startswith('#src-'):
            ident=url[5:];s=source_map[ident]
            if mode=='tex':return r'\cite{'+ident+'}'
            target=s['url'] if s.get('url','').startswith('http') else '#resources'
            return '<a class="cite" href="'+html.escape(target,quote=True)+'"'+(' target="_blank" rel="noopener noreferrer"' if target.startswith('http') else '')+' title="'+html.escape(s['title'],quote=True)+'">['+ident+']</a>'
        if mode=='html':return '<a href="'+html.escape(url,quote=True)+'">'+label+'</a>'
        if url.startswith('#'):return r'\hyperlink{'+esc(url[1:])+'}{'+label+'}'
        return r'\href{'+url.replace('%',r'\%')+'}{'+label+'}'
    if typ=='block_code':
        return '<pre><code>'+html.escape(raw)+'</code></pre>\n' if mode=='html' else '\n\\begin{codeblock}\n'+raw+'\\end{codeblock}\n'
    if typ=='block_quote':return '<blockquote>'+c()+'</blockquote>' if mode=='html' else '\n\\begin{quote}'+c()+'\\end{quote}\n'
    if typ=='list':
        ordered=t.get('attrs',{}).get('ordered',False)
        tag='ol' if ordered else 'ul';env='enumerate' if ordered else 'itemize'
        return '<'+tag+'>'+c()+'</'+tag+'>' if mode=='html' else '\n\\begin{'+env+'}\n'+c()+'\\end{'+env+'}\n'
    if typ=='list_item':return '<li>'+c()+'</li>' if mode=='html' else '\\item '+c()
    if typ=='table':return table(t,mode)
    if typ=='blank_line':return '\n'
    if typ=='thematic_break':return '<hr>' if mode=='html' else '\\medskip\\hrule\\medskip\n'
    raise ValueError(('Unhandled markdown token',typ))

def clean(text,n):
    # Figure-production notes become real vector diagrams in this edition.
    if n==2:
        text=re.sub(r'### 8\.2 七张原理图的制作约束.*?(?=### 8\.3)', '',text,flags=re.S)
        text=text.replace('8.3 练习与评分要点','8.2 练习与评分要点').replace('完整实验、图示规格与研究生练习','完整实验与研究生练习')
        text=text.replace('`ebpf/example/','`research/ebpf/example/').replace('`sources-ebpf.json`','`research/sources-ebpf.json`').replace('缓存见 `ebpf/`','缓存见 `research/ebpf/`')
    if n==3:text=re.sub(r'配套图按下列顺序讲授.*?\n\n','',text,flags=re.S)
    if n==4:text=re.sub(r'^\*\*图 \d+：.*?\n\n','',text,flags=re.M|re.S)
    found=set(re.findall(r'\[((?:eb|pp|pf)-[a-z0-9-]+)\]',text))
    assert found<=lookup.keys(),found-lookup.keys()
    text=re.sub(r'\[((?:eb|pp|pf)-[a-z0-9-]+)\]',lambda m:f'[[{m[1]}]](#src-{m[1]})',text)
    return text

