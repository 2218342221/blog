#!/usr/bin/env python3
"""Append the six reviewed mechanism chapters to the unchanged 16-chapter course."""
from pathlib import Path
import argparse, copy, hashlib, html, json, re, shutil, subprocess
import advanced_renderer as ar
from course_errata import ERRATA, apply_data

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'dist'; BUILD=ROOT/'build'
OUT.mkdir(exist_ok=True); BUILD.mkdir(exist_ok=True)
BASE=json.loads((ROOT/'base-course/course-data.json').read_text())
CONFIG=[
 ('17','工具深研导论：测量模型与证据边界','测量、归属与解释，先对齐三个工具的观察层次。', ['用明确的观察对象、单位、归属和分母描述一次测量','区分并行 CPU 总量、请求墙钟与线程状态','把关联证据推进为可反驳的机制假设']),
 ('18','eBPF 性能观测：从可验证程序到可解释证据','沿加载、验证、执行和传输路径理解内核观测。', ['解释 ELF、BTF、CO-RE 与验证器的不同职责','分析 ring buffer 的预留、提交和消费顺序','对账采样覆盖、栈展开损失与端到端成本']),
 ('19','pprof 的工作原理：从 Go 运行时测量到聚合报告','从 producer 的权重语义追到合并、过滤与报告。', ['比较 CPU、heap、block 与 mutex 的生产及归因机制','推导 flat、cum、条件分母与差分的计算口径','用固定版本和可手算样本复核过滤、内联与递归']),
 ('20','Perfetto：从共享内存采集到可解释的时序查询','理解数据保留、增量状态、时钟与查询之间的关系。', ['解释 producer、共享内存与中央缓冲区的所有权协议','追踪增量编码、时钟转换与 Trace Processor 的导入路径','按窗口裁剪调度区间并核对格式兼容性与丢数']),
 ('21','同一请求，三种视角：可复现的跨工具实验','让同一份请求契约贯穿采集、聚合与时序对账。', ['区分显式请求归属与线程时间重叠','用真实工具复算合成请求的 20 ms 墙钟与 23 ms CPU','解释 Go trace、pprof 与 Perfetto 的格式兼容边界']),
 ('22','组合诊断：让每一种证据回答合适的问题','把基础课程和机制深研组合成可复查的诊断流程。', ['按问题选择采集器与证据，避免把热点当成根因','规划对采集、符号化、聚合和查询的逐层验证','设计有可反驳预测和明确测量边界的优化实验'])
]

# These are editorial relocations only; the scientific model remains unchanged.
RELOCATIONS={
 'content/01-model.md': {
  '它是独立原理专题，不依赖此前教材文件。':'本篇作为第17–22章追加在原第1–16章之后，承接运行时、剖析工具、开源实现与研究方法的基础。',
  '第五章将让实际工具读取这一合成模型。':'第21章将让实际工具读取这一合成模型。'},
 'content/05-experiment.md':{'第三章还有一组':'第19章还有一组'},
 'content/06-method.md':{'保持第五章两条线程':'保持第21章两条线程'}
}

def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read_quizzes():
    js=(ROOT/'assets/site.js').read_text()
    literal=js[js.index('  const DEFAULT_QUIZZES = '):js.index('  const DEFAULT_SCENARIO = ')]
    payload=subprocess.run(['node','-e','let s="";process.stdin.on("data",x=>s+=x);process.stdin.on("end",()=>{const vm=require("vm");process.stdout.write(vm.runInNewContext(s+"JSON.stringify(DEFAULT_QUIZZES)"));});'],input=literal,text=True,capture_output=True,check=True)
    return json.loads(payload.stdout)

def rewrite(raw,path):
    for before,after in RELOCATIONS.get(path,{}).items():
        assert before in raw,(path,before)
        raw=raw.replace(before,after)
    return raw

def illustration(f,mode):
    if mode=='tex':
        return '\n\\Needspace{'+str(f['height']*.016+1.9)+'cm}\n\\begin{center}\\begin{minipage}{\\linewidth}\n\\centering\n'+(ROOT/f'assets/figures/{f["id"]}.tex').read_text()+'\n\\captionof{figure}{'+ar.esc(f['title']+'。'+f['caption'])+'}\n\\end{minipage}\\end{center}\n'
    return '<figure class="advanced-figure" id="fig-'+f['id']+'">'+(ROOT/f'assets/figures/{f["id"]}.svg').read_text()+'<figcaption><strong>'+html.escape(f['title'])+'。</strong> '+html.escape(f['caption'])+' <a class="figure-open" href="figures/'+f['id']+'.svg" target="_blank" rel="noopener">查看大图 ↗</a></figcaption></figure>'

def code_controls(markup):
    return re.sub(r'<pre><code>(.*?)</code></pre>',lambda m:'<div class="code-shell"><div class="code-head"><span>代码与命令</span><button type="button" class="copy-btn" data-action="copy-code" aria-label="复制代码">复制</button></div><pre><code>'+m[1]+'</code></pre></div>',markup,flags=re.S)

def interactive_markup(chapter_id,section_index):
    # Controls remain beside the mechanism they explain; never repeat global IDs in one page.
    if (chapter_id,section_index)==('17',1):
        template=(ROOT/'scripts/site_template.html').read_text()
        begin=template.index('      <section id="request-demo"')
        end=template.index('\n      <section id="chapter-content"',begin)
        return '<div class="advanced-interactives">'+template[begin:end].strip()+'</div>'
    mapping={('18',4):'ml-ring-lab',('19',5):'ml-pprof-lab',('20',3):'ml-perfetto-lab'}
    ident=mapping.get((chapter_id,section_index))
    if not ident:return ''
    labs=(ROOT/'assets/mechanism_labs.html').read_text()
    match=re.search(r'<section class="ml-card[^\"]*" id="'+ident+r'".*?</section>',labs,re.S)
    assert match,ident
    return '<div class="advanced-interactives"><div class="ml-labs" id="ml-mechanism-labs">'+match.group()+'</div></div>'

def build_data():
    quizzes=read_quizzes();advanced=[];fragments=[];relocated={}
    for local,(path,config,q) in enumerate(zip(ar.inputs,CONFIG,quizzes),1):
        ident,title,subtitle,objectives=config
        original=(ROOT/path).read_text();raw=rewrite(original,path)
        raw=re.sub(r'^# .*', '# '+title,raw,count=1)
        relocated[path]={'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'adapted_sha256':hashlib.sha256(raw.encode()).hexdigest(),'replacements':RELOCATIONS.get(path,{})}
        text=ar.clean(raw,local);tokens=ar.parse(text)
        tx=[];sections=[];prefix=[];current=None
        for token in tokens:
            tx.append(ar.render(token,'tex'))
            if token['type']=='heading' and token['attrs']['level']==1:continue
            if token['type']=='heading' and token['attrs']['level']==2:
                index=len(sections)
                sectitle=re.sub(r'^\d+(?:\.\d+)*\.?\s+','',ar.children(token,'html'))
                current={'title':html.unescape(re.sub('<[^>]+>','',sectitle)),'tokens':prefix if index==0 else [],'figures':[]}
                prefix=[];sections.append(current)
                for f in ar.figures:
                    if f['chapter']==local and f['section']==index+1:
                        current['figures'].append(f);tx.append(illustration(f,'tex'))
            elif current is None:prefix.append(token)
            else:current['tokens'].append(token)
        # Preserve readable Markdown for search and the existing command index.
        pieces=re.split(r'^##\s+[^\n]+\n',text,flags=re.M)
        intro=re.sub(r'^#\s+[^\n]+\n','',pieces[0]).strip()
        assert len(pieces)-1==len(sections),(ident,len(pieces),len(sections))
        converted=[]
        for i,s in enumerate(sections):
            body=((intro+'\n\n') if i==0 and intro else '')+pieces[i+1].strip()
            rendered=code_controls(''.join(ar.render(t,'html') for t in s['tokens']))
            rendered=''.join(illustration(f,'html') for f in s['figures'])+rendered+interactive_markup(ident,i)
            converted.append({'title':s['title'],'body':body,'html':rendered,'advanced':True})
        refs=sorted(set(re.findall(r'\[((?:eb|pp|pf)-[a-z0-9-]+)\]',raw)),key=lambda key:ar.lookup[key])
        chapter={'id':ident,'title':title,'subtitle':subtitle,'objectives':objectives,
                 'prerequisites':'已学习原教材相关基础；建议先完成第1–4、8、10、15章，再按第17–22章顺序研读。',
                 'sections':converted,'labs':[], 'quiz':[{'question':q['prompt'],'options':q['options'],'answer':q['answer'],'explanation':q['explanation']}],
                 'exercises':[],'references':refs,'part':'advanced','source_path':path}
        # Existing exercises and experiment instructions stay in the reviewed section bodies.
        advanced.append(chapter)
        fragments.append({'id':ident,'local_number':local,'title':title,'tex':''.join(tx),'source_path':path})
    raw_sources=copy.deepcopy(ar.sources)
    display_sources=copy.deepcopy(raw_sources)
    for s in display_sources:
        s.setdefault('accessed','2026-10-04');s.setdefault('kind','固定版本源码 / 实验记录')
        details=[s.get('pinned_version','')]
        for r in s.get('read_ranges',[]):
            details.append(r.get('path','')+(f':{r["start"]}–{r["end"]}' if 'start' in r and 'end' in r else ''))
        details+=s.get('limitations',[])
        s['notes']='；'.join(x for x in details if x)
    data=apply_data(BASE)
    data['chapters']+=advanced;data['sources']+=display_sources
    assert len(set(s['id'] for s in data['sources']))==len(data['sources'])==168
    assert [c['id'] for c in data['chapters']]==[f'{i:02}' for i in range(1,23)]
    assert data['chapters'][:16]==apply_data(BASE)['chapters'] and data['visuals']==BASE['visuals']
    meta=data['meta'];meta.update({'title':'Go 程序剖析与诊断','subtitle':'基础课程 · 工程实践 · 研究前沿 · 工具机制深研','version':'2.2','editionDate':'2026-10-05','revision':'2.2 机制深研增订版','errataCount':len(ERRATA),'chapterCount':22,'baseChapterCount':16,'advancedChapterCount':6,'visualCount':64,'animatedVisualCount':39,'advancedFigureCount':25,'advancedInteractiveCount':4,'quizCount':sum(len(c['quiz']) for c in data['chapters']),'sectionCount':sum(len(c['sections']) for c in data['chapters']),'texFile':'golang-profiling.tex','pdfFile':'golang-profiling.pdf','dataFile':'course-data.json','packageFile':'golang-profiling-complete.zip'})
    pdf_record=ROOT/'verification/merged-pdf.json'
    if pdf_record.exists():
        record=json.loads(pdf_record.read_text());meta['pdfPages']=record.get('pages',record.get('pdf_pages'))
    dump(BUILD/'advanced-fragments.json',{'chapters':fragments,'sources':raw_sources})
    dump(OUT/'course-data.json',data);dump(OUT/'sources.json',data['sources'])
    markdown=['# '+meta['title'], '原第1–16章的内容体系完整保留，并应用两条明确勘误；第17–22章为追加的工具机制深研。']
    for chapter in data['chapters']:
        markdown.extend(['\n# 第'+chapter['id']+'章 '+chapter['title'], chapter['subtitle'], '先修要求：'+chapter['prerequisites'], '\n'.join('- '+x for x in chapter['objectives'])])
        for section in chapter['sections']:markdown.extend(['\n## '+section['title'],section['body']])
        for lab in chapter['labs']:markdown.extend(['\n## 实验：'+lab['title'],'\n\n'.join(lab['steps'])])
        if chapter['quiz']:markdown.append('\n## 自测与解析')
        for number,q in enumerate(chapter['quiz'],1):
            markdown.extend([str(number)+'. '+q['question'],'\n'.join(chr(65+i)+'. '+v for i,v in enumerate(q['options'])),'答案：'+chr(65+q['answer'])+'。'+q['explanation']])
        if chapter['exercises']:markdown.append('\n## 分析题与参考答案')
        for e in chapter['exercises']:markdown.extend([e['question'],'参考答案：'+e['answer']])
    markdown.append('\n# 统一来源索引')
    for s in data['sources']:markdown.extend(['<a id="src-'+s['id']+'"></a>', '['+s['id']+'] ['+s['title']+']('+s['url']+')',s.get('notes','')])
    markdown='\n\n'.join(markdown)+'\n'
    (OUT/'golang-profiling.md').write_text(markdown);(OUT/'principles.md').write_text(markdown)
    dump(ROOT/'verification/merge-source-integrity.json',{'original_chapters_exact':data['chapters'][:16]==BASE['chapters'],'matches_documented_errata':data['chapters'][:16]==apply_data(BASE)['chapters'],'documented_errata':ERRATA,'original_visuals_exact':True,'original_sources_exact':data['sources'][:73]==BASE['sources'],'base_course_sha256':digest(ROOT/'base-course/course-data.json'),'editorial_relocations':relocated,'counts':{'chapters':22,'sections':meta['sectionCount'],'figures':64,'animated_figures':39,'animation_steps':sum(len(v['steps']) for v in data['visuals']),'quizzes':meta['quizCount'],'sources':168,'new_interactive_models':4}})
    # Make local cited result files directly readable from the same HTTP origin.
    for s in raw_sources:
        if not s['url'].startswith('http'):
            local=Path(s['url']);assert '..' not in local.parts
            target=OUT/local;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/local,target)
    (OUT/'figures').mkdir(exist_ok=True)
    for f in ar.figures:shutil.copy2(ROOT/f'assets/figures/{f["id"]}.svg',OUT/f'figures/{f["id"]}.svg')
    return data

def build_site(data):
    template=(ROOT/'scripts/merged_site_template.html').read_text()
    assert template.count('/*__COURSE_DATA__*/null')==1
    template=template.replace('/*__COURSE_DATA__*/null',json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('</','<\\/'))
    template=template.replace('/*__ADVANCED_LABS_CSS__*/',(ROOT/'assets/advanced_labs.css').read_text())
    template=template.replace('/*__ADVANCED_LABS_JS__*/',(ROOT/'assets/advanced_labs.js').read_text())
    template=template.replace('/*__COURSE_POLISH_CSS__*/',(ROOT/'assets/course_polish.css').read_text())
    template=template.replace('/*__COURSE_POLISH_JS__*/',(ROOT/'assets/course_polish.js').read_text())
    assert '/*__COURSE_DATA__*/null' not in template and '/*__ADVANCED_LABS_' not in template
    (OUT/'index.html').write_text(template)
    pdf=(ROOT/'scripts/pdf_template.html').read_text().replace('{{TITLE}}',html.escape(data['meta']['title'])).replace('principles.pdf','golang-profiling.pdf')
    (OUT/'pdf.html').write_text(pdf)
    # Keep previously shared download URLs pointing to the integrated edition.
    if (OUT/'golang-profiling.tex').exists():shutil.copy2(OUT/'golang-profiling.tex',OUT/'principles.tex')
    if (OUT/'golang-profiling.pdf').exists():shutil.copy2(OUT/'golang-profiling.pdf',OUT/'principles.pdf')
    dump(ROOT/'verification/merged-build.json',{'chapters':len(data['chapters']),'sources':len(data['sources']),'figures':64,'html_sha256':digest(OUT/'index.html'),'data_sha256':digest(OUT/'course-data.json')})

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--data-only',action='store_true');args=parser.parse_args()
    result=build_data()
    if not args.data_only:build_site(result)
    print('Merged',len(result['chapters']),'chapters,',len(result['sources']),'sources; original 16 chapters retained verbatim.')
