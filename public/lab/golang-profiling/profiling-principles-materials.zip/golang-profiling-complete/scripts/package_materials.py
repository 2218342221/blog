#!/usr/bin/env python3
"""Package the complete 22-chapter edition; --check-inputs performs no writes."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from course_errata import apply_data

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "golang-profiling-complete"
CANONICAL = Path("dist/golang-profiling-complete.zip")
ALIAS = Path("dist/profiling-principles-materials.zip")
MANIFEST = Path("dist/materials-manifest.json")
VERIFICATION = Path("verification/package-verification.json")
SCRIPTS = (
    "advanced_renderer.py", "audit_sources.py", "build_advanced_assets.py",
    "build_book.py", "build_merged.py", "course_errata.py", "check_examples.py", "fetch_perfetto.py",
    "figures.py", "merge_tex.py", "merged_site_template.html", "package_materials.py",
    "pdf_template.html", "run_examples.py", "serve_site.py", "site_template.html",
    "verify_lab.py", "verify_merged_advanced.py", "verify_merged_original_ui.py",
    "verify_merged_http.py", "verify_site.py", "verify_course_polish.py", "verify_blog_release.py",
)
REQUIRED = (
    "README.md", "requirements.txt", "THIRD_PARTY.md",
    "base-course/course-data.json", "base-course/golang-profiling.tex",
    "base-course/content/visuals.json", "base-course/requirements-build.txt",
    "lab/main.go", "lab/main_test.go", "lab/go.mod", "lab/flight/main.go",
    "assets/figure_manifest.json", "assets/advanced_labs.css", "assets/advanced_labs.js",
    "assets/site.css", "assets/site.js", "assets/mechanism_labs.html",
    "assets/mechanism_labs.css", "assets/mechanism_labs.js",
    "dist/index.html", "dist/pdf.html", "dist/golang-profiling.pdf",
    "dist/golang-profiling.tex", "dist/golang-profiling.md", "dist/course-data.json",
    "dist/sources.json", "dist/principles.pdf", "dist/principles.tex", "dist/principles.md",
    "examples/perfetto/download.json", "research/licenses/manifest.json",
    "research/pprof/google-pprof/LICENSE", "research/pprof/pprof-pin.json",
    "research/pprof/go-pin.json", "research/pprof/go-source-manifest.json",
    "research/ebpf/pins.json", "research/perfetto/pin.json",
    "verification/base-course-import.json", "verification/FINAL-VERIFICATION.md",
    "verification/merge-content-audit.json", "verification/merge-content-audit.md",
    "verification/merge-source-integrity.json", "verification/merged-build.json",
    "verification/merged-pdf.json", "verification/merged-original-ui-check.json",
    "verification/merged-advanced-check.json", "verification/merged-http-check.json",
    "verification/original-pyroscope-import.json",
    "verification/source-audit.json",
)
EVIDENCE = {
    "base-course-import.json", "FINAL-VERIFICATION.md", "source-audit.json",
    "pprof-independent-review.md", "go-trace-import.json", "pprof-perfetto-import.json",
    "request-perfetto.json", "request-perfetto.txt", "request-pprof.json", "request-pprof.txt",
    "mechanism-labs-verification.json", "original-pyroscope-import.json", "http-verification.json",
    "final-site-verification.json", "site-ui-verification.json", "UI-POLISH.md",
    "ui-polish-verification.json", "ui-polish-pdf.json", "native-latex.json",
    "pdf-verification.json", "pdf-web-build.json",
}
EVIDENCE_SUFFIXES = {".json", ".md", ".txt", ".png"}
EXCLUDED_PARTS = {"__pycache__", "node_modules", "merged-pdf-build", "package-smoke", "bin"}
EXCLUDED_SUFFIXES = {".zip", ".tar", ".gz", ".xz", ".pyc", ".pyo", ".aux", ".toc", ".lof", ".log", ".out", ".stdout", ".so"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()


def safe_relative(value) -> Path:
    raw = str(value)
    posix = PurePosixPath(raw)
    if posix.is_absolute() or ".." in posix.parts or "\\" in raw:
        raise ValueError(f"Unsafe package input path: {raw!r}")
    path = Path(posix)
    if not path.parts:
        raise ValueError("Empty package path")
    return path


def excluded(path: Path) -> bool:
    return (any(part.startswith(".") or part in EXCLUDED_PARTS for part in path.parts)
            or path.suffix.lower() in EXCLUDED_SUFFIXES
            or path in {CANONICAL, ALIAS, MANIFEST, VERIFICATION}
            or path.name == "verify_ui_polish.py")


def collect_inputs():
    files = set()
    missing, rejected = [], []

    def add(value, required=False):
        path = safe_relative(value)
        full = ROOT / path
        if excluded(path):
            if required:
                rejected.append(str(path))
            return
        if not full.is_file():
            if required:
                missing.append(str(path))
            return
        if full.is_symlink() or not full.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError(f"Package input is a symlink or outside task: {path}")
        files.add(path)

    def tree(value):
        base = ROOT / value
        if not base.is_dir():
            missing.append(str(value) + "/")
            return
        for folder, directories, names in os.walk(base, followlinks=False):
            directories[:] = sorted(d for d in directories
                                    if not d.startswith(".") and d not in EXCLUDED_PARTS
                                    and not (Path(folder) / d).is_symlink())
            for name in sorted(names):
                add((Path(folder) / name).relative_to(ROOT))

    for path in REQUIRED:
        add(path, required=True)
    for name in SCRIPTS:
        add(Path("scripts") / name, required=True)
    for folder in (
        "base-course", "lab", "content", "assets", "examples/request",
        "research/licenses", "research/ebpf/example", "research/pprof/teaching",
        "research/validation", "verification/pprof-review-repro", "verification/review-2026-10-05-research-repro",
        "dist/figures", "dist/research", "dist/verification",
    ):
        tree(folder)
    for tool in ("ebpf", "pprof", "perfetto"):
        add(f"research/{tool}.md", required=True)
        add(f"research/sources-{tool}.json", required=True)
    for tool in ("ebpf", "pprof"):
        for path in sorted((ROOT / "research" / tool).iterdir()):
            if path.is_file() and path.suffix in {".json", ".md", ".py"}:
                add(path.relative_to(ROOT))
    for path in sorted((ROOT / "verification").iterdir()):
        if (path.is_file() and path.suffix in EVIDENCE_SUFFIXES
                and (path.name in EVIDENCE or path.name.startswith(("merged-", "merge-", "review-2026-10-05-", "course-polish-")))
                and not path.name.startswith("merged-pdf-fontprobe")):
            add(path.relative_to(ROOT))
    source_audit = json.loads((ROOT / "verification/source-audit.json").read_text())
    for path in source_audit["resolved_files"]:
        add(path, required=True)
    return files, source_audit, sorted(set(missing)), sorted(set(rejected))


def inspect_inputs(files, source_audit, missing, rejected):
    errors = []
    if missing:
        errors.append({"missing_required_files": missing})
    if rejected:
        errors.append({"required_files_rejected_by_exclusion": rejected})
    if source_audit.get("status") != "passed" or source_audit.get("failures"):
        errors.append({"source_audit_not_passed": source_audit.get("status")})
    data = json.loads((ROOT / "dist/course-data.json").read_text())
    base = apply_data(json.loads((ROOT / "base-course/course-data.json").read_text()))
    checks = {
        "22_chapters_in_order": [c["id"] for c in data["chapters"]] == [f"{i:02}" for i in range(1, 23)],
        "base_16_chapters_match_documented_errata": data["chapters"][:16] == base["chapters"],
        "base_39_visuals_exact": data["visuals"] == base["visuals"] and len(data["visuals"]) == 39,
        "base_73_sources_exact": data["sources"][:73] == base["sources"],
        "all_168_sources": len(data["sources"]) == 168,
        "canonical_package_link": data["meta"]["packageFile"] == CANONICAL.name,
        "source_cache_coverage": all(Path(path) in files for path in source_audit["resolved_files"]),
    }
    figures = json.loads((ROOT / "assets/figure_manifest.json").read_text())
    expected_figures = {Path(f'dist/figures/{f["id"]}.svg') for f in figures}
    actual_figures = {path for path in files if path.parent == Path("dist/figures")}
    checks["all_25_downloadable_figures"] = len(expected_figures) == 25 and actual_figures == expected_figures
    checks["all_25_svg_and_tex_sources"] = all(Path(f'assets/figures/{f["id"]}.{ext}') in files
                                                   for f in figures for ext in ("svg", "tex"))
    for new, old in (("golang-profiling.pdf", "principles.pdf"), ("golang-profiling.tex", "principles.tex"), ("golang-profiling.md", "principles.md")):
        checks[f"alias_{old}_byte_identical"] = (ROOT / "dist" / new).read_bytes() == (ROOT / "dist" / old).read_bytes()
    build = json.loads((ROOT / "verification/merged-build.json").read_text())
    checks["published_html_matches_build_record"] = sha256((ROOT / "dist/index.html").read_bytes()) == build["html_sha256"]
    checks["published_data_matches_build_record"] = sha256((ROOT / "dist/course-data.json").read_bytes()) == build["data_sha256"]
    pyro = json.loads((ROOT / "verification/original-pyroscope-import.json").read_text())
    checks["original_pyroscope_reproduction_complete"] = len(pyro["files"]) == 13 and all(
        safe_relative(item["path"]) in files
        and sha256((ROOT / safe_relative(item["path"])).read_bytes()) == item["sha256"]
        for item in pyro["files"])
    for name in ("merged-original-ui-check.json", "merged-advanced-check.json", "merged-http-check.json", "merged-pdf.json"):
        record = json.loads((ROOT / "verification" / name).read_text())
        checks[f"evidence_{name}_passed"] = record.get("status") == "passed"
    for source in data["sources"]:
        url = source.get("url", "")
        if url and not url.startswith(("https://", "http://", "#")):
            relative = safe_relative(url.split("#", 1)[0])
            if Path("dist") / relative not in files:
                errors.append({"local_website_source_missing": url})
    for tool in ("ebpf", "pprof", "perfetto"):
        sources = json.loads((ROOT / f"research/sources-{tool}.json").read_text())
        for source in sources:
            cached = source.get("local_cache", source.get("cache_path"))
            if cached and source.get("sha256"):
                path = safe_relative(cached)
                if path not in files or sha256((ROOT / path).read_bytes()) != source["sha256"]:
                    errors.append({"cached_source_digest_mismatch": cached, "source": source["id"]})
    for path in files:
        if (ROOT / path).stat().st_size > 20 * 1024 * 1024:
            errors.append({"unexpected_large_input": str(path)})
        with (ROOT / path).open("rb") as stream:
            if stream.read(4) == b"\x7fELF":
                errors.append({"compiled_binary_in_input": str(path)})
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        errors.append({"failed_checks": failed})
    return {"status": "passed" if not errors else "failed", "mode": "input_check",
            "archive_root": PREFIX, "files_before_manifest": len(files),
            "uncompressed_bytes_before_manifest": sum((ROOT / path).stat().st_size for path in files),
            "source_cache_files": len(source_audit["resolved_files"]),
            "downloadable_figures": len(actual_figures),
            "license_files": len([p for p in files if p.parts[:2] == ("research", "licenses")]),
            "base_course_files": len([p for p in files if p.parts[0] == "base-course"]),
            "root_lab_files": len([p for p in files if p.parts[0] == "lab"]),
            "pyroscope_reproduction_files": len(pyro["files"]),
            "verification_evidence_files": len([p for p in files if p.parts[0] == "verification"]),
            "script_inputs": sorted(str(p) for p in files if p.parts[0] == "scripts"),
            "checks": checks, "errors": errors}


def atomic_write(path: Path, data: bytes):
    temporary = path.with_name("." + path.name + ".tmp")
    try:
        temporary.write_bytes(data)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def build_package(files, inspected):
    # The external package verification contains the archive digest and therefore
    # cannot itself be archived without introducing a circular checksum.
    payloads = {path: (ROOT / path).read_bytes() for path in sorted(files)}
    manifest = {path.as_posix(): sha256(data) for path, data in payloads.items()}
    manifest_bytes = json_bytes(manifest)
    payloads[MANIFEST] = manifest_bytes
    date = json.loads(payloads[Path("dist/course-data.json")])["meta"]["editionDate"]
    archive_time = datetime.strptime(date, "%Y-%m-%d").timetuple()[:6]
    temporary = ROOT / "dist/.golang-profiling-complete.zip.tmp"
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path, data in sorted(payloads.items()):
                info = zipfile.ZipInfo(f"{PREFIX}/{path.as_posix()}", archive_time)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError("ZIP CRC verification failed")
            expected = {f"{PREFIX}/{path.as_posix()}" for path in payloads}
            if set(archive.namelist()) != expected or len(archive.namelist()) != len(expected):
                raise ValueError("ZIP entry set differs from selected input files")
            for path, data in payloads.items():
                if archive.read(f"{PREFIX}/{path.as_posix()}") != data:
                    raise ValueError(f"ZIP byte verification failed: {path}")
        changed = [str(path) for path in files if sha256((ROOT / path).read_bytes()) != manifest[path.as_posix()]]
        if changed:
            raise ValueError(f"Inputs changed while packaging; rerun after editors finish: {changed}")
        zip_bytes = temporary.read_bytes()
        atomic_write(ROOT / MANIFEST, manifest_bytes)
        temporary.replace(ROOT / CANONICAL)
        atomic_write(ROOT / ALIAS, zip_bytes)
        if (ROOT / CANONICAL).read_bytes() != (ROOT / ALIAS).read_bytes():
            raise ValueError("Compatibility ZIP differs from canonical ZIP")
        verification = {**inspected, "status": "passed", "mode": "package_verification",
                        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
                        "zip": str(CANONICAL), "compatibility_zip": str(ALIAS),
                        "zip_bytes": len(zip_bytes), "sha256": sha256(zip_bytes),
                        "files": len(payloads), "manifest": str(MANIFEST), "manifest_entries": len(manifest),
                        "manifest_sha256": sha256(manifest_bytes), "archive_timestamp": list(archive_time),
                        "zip_crc_passed": True, "all_archived_file_bytes_verified": True,
                        "all_manifest_digests_verified": True, "compatibility_zip_byte_identical": True,
                        "inputs_unchanged_during_packaging": True,
                        "manifest_self_hash_excluded": True,
                        "external_verification_excluded_to_avoid_digest_cycle": str(VERIFICATION),
                        "exclusions": ["hidden caches and virtual environments", "browser downloads and compiled binaries",
                                       "large downloaded tool archives", "retired standalone UI validators and previews",
                                       "merged-pdf-build and LaTeX intermediates", "recursive package archives"]}
        atomic_write(ROOT / VERIFICATION, json_bytes(verification))
        return verification
    finally:
        temporary.unlink(missing_ok=True)


def smoke_test_package():
    smoke_parent = ROOT / "verification/package-smoke"
    smoke_parent.mkdir(exist_ok=True)
    run = Path(tempfile.mkdtemp(prefix="run-", dir=smoke_parent))
    with zipfile.ZipFile(ROOT / CANONICAL) as archive:
        for member in archive.infolist():
            safe_relative(member.filename)
            if not member.filename.startswith(PREFIX + "/"):
                raise ValueError(f"Unexpected archive root: {member.filename}")
        archive.extractall(run)
    extracted = run / PREFIX
    canonical = ["index.html", "pdf.html", "course-data.json", "sources.json",
                 "golang-profiling.tex", "golang-profiling.pdf", "golang-profiling.md"]
    expected = {name: sha256((ROOT / "dist" / name).read_bytes()) for name in canonical}
    command = [sys.executable, str(extracted / "scripts/build_book.py")]
    result = subprocess.run(command, cwd=extracted, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=240)
    (run / "build.stdout.txt").write_text(result.stdout)
    if result.returncode:
        raise ValueError(f"Extracted package rebuild failed ({result.returncode}): {result.stdout[-3000:]}")
    actual = {name: sha256((extracted / "dist" / name).read_bytes()) for name in canonical}
    mismatches = [name for name in canonical if expected[name] != actual[name]]
    if mismatches:
        raise ValueError(f"Extracted package rebuild changed canonical outputs: {mismatches}")
    data = json.loads((extracted / "dist/course-data.json").read_text())
    if len(data["chapters"]) != 22 or (extracted / "verification/merged-pdf-build").exists():
        raise ValueError("Extracted rebuild did not preserve 22 chapters and reuse the verified PDF")
    return {"status": "passed", "directory": str(run.relative_to(ROOT)),
            "python": sys.executable, "entrypoint": "scripts/build_book.py", "exit_code": result.returncode,
            "chapters": 22, "verified_pdf_cache_reused": True,
            "canonical_output_sha256": actual, "all_canonical_outputs_byte_identical": True,
            "stdout": result.stdout.strip()}


def verify_http_downloads(base_url):
    if not base_url.startswith(("http://", "https://")):
        raise ValueError("--verify-http needs an HTTP(S) course URL")
    expected = sha256((ROOT / CANONICAL).read_bytes())
    expected_size = (ROOT / CANONICAL).stat().st_size
    records = []
    for path in (CANONICAL, ALIAS):
        url = base_url.rstrip("/") + "/" + path.name
        digest, count = hashlib.sha256(), 0
        with urllib.request.urlopen(url, timeout=30) as response:
            status = response.status
            while chunk := response.read(1024 * 1024):
                digest.update(chunk)
                count += len(chunk)
        if status != 200 or count != expected_size or digest.hexdigest() != expected:
            raise ValueError(f"HTTP package bytes mismatch: {url}")
        records.append({"url": url, "status": status, "bytes": count, "sha256": digest.hexdigest()})
    return {"status": "passed", "downloads": records, "canonical_and_alias_match_disk": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-inputs", action="store_true", help="Validate current inputs without creating or updating output files")
    parser.add_argument("--smoke-test", action="store_true", help="Rebuild only from the extracted ZIP with this Python interpreter")
    parser.add_argument("--verify-http", metavar="COURSE_URL", help="Verify served bytes for both ZIP download URLs")
    args = parser.parse_args()
    if args.check_inputs and (args.smoke_test or args.verify_http):
        parser.error("--check-inputs cannot be combined with output-producing checks")
    files, audit, missing, rejected = collect_inputs()
    inspected = inspect_inputs(files, audit, missing, rejected)
    if args.check_inputs or inspected["errors"]:
        print(json.dumps(inspected, ensure_ascii=False, indent=2))
        return 0 if inspected["status"] == "passed" else 1
    verification = build_package(files, inspected)
    try:
        if args.smoke_test:
            verification["extracted_rebuild"] = smoke_test_package()
        if args.verify_http:
            verification["http_downloads"] = verify_http_downloads(args.verify_http)
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        verification.update(status="failed", post_package_error=str(error))
        atomic_write(ROOT / VERIFICATION, json_bytes(verification))
        raise
    atomic_write(ROOT / VERIFICATION, json_bytes(verification))
    print(json.dumps({k: verification[k] for k in ("status", "zip", "compatibility_zip", "files", "manifest_entries", "zip_bytes", "sha256")}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as error:
        print(json.dumps({"status": "failed", "error": str(error)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
