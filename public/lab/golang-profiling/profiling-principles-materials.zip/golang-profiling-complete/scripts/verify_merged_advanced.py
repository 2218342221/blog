#!/usr/bin/env python3
"""Validate appended chapters and teaching models through the published website."""
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin
from urllib.request import urlopen
import hashlib
import json
import os
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
URL = os.environ.get('COURSE_URL', 'http://127.0.0.1:8765/').rstrip('/') + '/'
DATA = json.loads((ROOT / 'dist/course-data.json').read_text())
checks, errors, figures, citations = {}, [], set(), set()
report = {'edition': '22-chapter integrated course', 'url': URL,
          'checked_utc': datetime.now(timezone.utc).isoformat(), 'checks': checks,
          'errors': errors, 'html_sha256': hashlib.sha256((ROOT / 'dist/index.html').read_bytes()).hexdigest()}


def check(name, passed):
    checks[name] = bool(passed)
    if not passed:
        raise AssertionError(name)


def go(page, chapter):
    page.goto(URL + '#chapter/' + chapter, wait_until='domcontentloaded')
    page.wait_for_selector('#section-' + chapter + '-0')
    page.evaluate('document.fonts.ready')


try:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
        report['browser_version'] = browser.version
        page = browser.new_page(viewport={'width': 1440, 'height': 1000}, reduced_motion='reduce')
        page.on('pageerror', lambda err: errors.append(str(err)))
        page.on('console', lambda msg: errors.append(msg.text) if msg.type == 'error' else None)
        page.set_default_timeout(10000)
        for chapter, figure_count in zip(DATA['chapters'][16:], [3, 5, 7, 7, 2, 1]):
            cid = chapter['id']
            go(page, cid)
            check(cid + '_all_sections', page.locator('[id^="section-' + cid + '-"]').count() == len(chapter['sections']))
            check(cid + '_all_figures', page.locator('figure.advanced-figure').count() == figure_count)
            check(cid + '_mathml', page.locator('math').count() > 0 or cid in ['18', '22'])
            figures.update(page.locator('figure.advanced-figure a.figure-open').evaluate_all('(els) => els.map(e => e.getAttribute("href"))'))
            citations.update(page.locator('.prose a').evaluate_all(r'(els) => els.filter(e => /^\[(eb|pp|pf)-/.test(e.textContent)).map(e => e.textContent.trim().slice(1,-1))'))
            check(cid + '_svg_labels_fit', page.evaluate('''() => [...document.querySelectorAll('figure.advanced-figure svg')].every(svg => [...svg.querySelectorAll('text')].every(t => {const b=t.getBBox(),v=svg.viewBox.baseVal; return b.x>=-1 && b.y>=-1 && b.x+b.width<=v.width+1 && b.y+b.height<=v.height+1;}))'''))
            for width in [1440, 390, 320]:
                page.set_viewport_size({'width': width, 'height': 900})
                page.evaluate('new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))')
                check(cid + '_' + str(width) + '_no_page_overflow', page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
            print('PASS chapter ' + cid, flush=True)

        page.set_viewport_size({'width': 1440, 'height': 1000})
        go(page, '17')
        check('request_starts_paused', not page.evaluate('ProfilingCourse.requestDemo.getState().playing'))
        for t, cpu in [(0, 0), (1, 1), (4, 7), (6, 9), (16, 19), (20, 23)]:
            result = page.evaluate('(t) => { ProfilingCourse.requestDemo.setTime(t); return ProfilingCourse.requestDemo.getState(); }', t)
            check('request_cpu_' + str(t), result['cpuMs'] == cpu and result['wallMs'] == t)
        check('request_8_plus_15_and_ratio', result['mainCpuMs'] == 8 and result['workerCpuMs'] == 15 and result['ratio'] == 1.15)
        check('cursor_value_on_one_line', page.locator('#demo-cursor-label').evaluate('(el) => getComputedStyle(el).whiteSpace === "nowrap" && el.getBoundingClientRect().height < 35'))
        page.locator('#request-demo').scroll_into_view_if_needed()
        page.screenshot(path=str(ROOT / 'verification/merged-advanced-request.png'))
        page.locator('#demo-reset').click()
        check('request_reset', page.evaluate('ProfilingCourse.requestDemo.getState().time') == 0)
        page.locator('#demo-slider').focus()
        page.keyboard.press('ArrowRight')
        check('request_keyboard', page.evaluate('ProfilingCourse.requestDemo.getState().time') > 0)
        page.locator('#demo-play').click()
        page.wait_for_function('ProfilingCourse.requestDemo.getState().time > 0.5')
        page.locator('#demo-play').click()
        check('request_play_pause', not page.evaluate('ProfilingCourse.requestDemo.getState().playing'))
        page.evaluate('window.oldRequestDemo=ProfilingCourse.requestDemo; oldRequestDemo.play(); navigate("chapter", "18")')
        page.wait_for_selector('#ml-ring-lab')
        check('request_disposed_on_navigation', page.evaluate('ProfilingCourse === null && !oldRequestDemo.getState().playing'))
        check('ring_only_relevant_lab', page.locator('.ml-card').count() == 1)
        for _ in range(4):
            page.locator('#ml-ring-next').click()
        ring = page.evaluate('MechanismLabs.ring.getState()')
        check('ring_busy_blocks_committed_b', ring['blocked'] and ring['submitted'] == ['B'] and ring['consumed'] == [])
        for _ in range(2):
            page.locator('#ml-ring-next').click()
        check('ring_consumes_reservation_order', page.evaluate('MechanismLabs.ring.getState().consumed') == ['A', 'B'])
        check('ring_end_button_disabled', page.locator('#ml-ring-next').is_disabled())
        page.locator('#ml-ring-reset').click()
        check('ring_reset', page.evaluate('MechanismLabs.ring.getState().step') == 0)

        go(page, '19')
        check('pprof_only_relevant_lab', page.locator('.ml-card').count() == 1)
        before = page.evaluate('MechanismLabs.pprof.getState()')
        for _ in range(4):
            page.evaluate('MechanismLabs.pprof.shuffle()')
        after = page.evaluate('MechanismLabs.pprof.getState()')
        check('pprof_shuffle_preserves_profile', after['totalCpuMs'] == 23 and after['flatMs'] == before['flatMs'] and after['shuffles'] == 4)
        go(page, '20')
        check('perfetto_only_relevant_lab', page.locator('.ml-card').count() == 1)
        page.evaluate('MechanismLabs.perfetto.reset(); MechanismLabs.perfetto.setPolicy("ring"); for(let i=0;i<6;i++)MechanismLabs.perfetto.next()')
        check('perfetto_ring_retains_tail', page.evaluate('MechanismLabs.perfetto.getState().retained') == [3, 4, 5, 6])
        page.evaluate('MechanismLabs.perfetto.setPolicy("discard")')
        check('perfetto_discard_retains_prefix', page.evaluate('MechanismLabs.perfetto.getState().retained') == [1, 2, 3, 4])
        page.set_viewport_size({'width': 390, 'height': 844})
        page.locator('#ml-perfetto-lab').scroll_into_view_if_needed()
        page.screenshot(path=str(ROOT / 'verification/merged-advanced-perfetto-mobile.png'))

        source_ids = {s['id'] for s in DATA['sources']}
        check('advanced_citations_resolve', len(citations) >= 90 and citations <= source_ids)
        report['distinct_advanced_citations'] = len(citations)
        page.goto(URL + '#resources', wait_until='domcontentloaded')
        page.wait_for_selector('#resource-list')
        check('unified_168_source_index', page.locator('#resource-list .resource').count() == 168)
        check('canonical_pdf_link', page.locator('a[href="golang-profiling.pdf"]').count() > 0)
        check('canonical_package_link', page.locator('a[href="golang-profiling-complete.zip"]').count() > 0)
        check('no_browser_errors', not errors)
        browser.close()

    check('all_25_figure_links_present', len(figures) == 25)
    live_files = sorted(figures) + [s['url'] for s in DATA['sources'] if not s['url'].startswith('http')]
    for relative in live_files:
        with urlopen(urljoin(URL, relative), timeout=15) as response:
            check('http_' + relative, response.status == 200 and response.read() == (ROOT / 'dist' / relative).read_bytes())
    for extension in ['pdf', 'tex', 'md']:
        canonical = (ROOT / 'dist' / ('golang-profiling.' + extension)).read_bytes()
        check('legacy_' + extension + '_identical', canonical == (ROOT / 'dist' / ('principles.' + extension)).read_bytes())
    report['status'] = 'passed'
except Exception as exc:
    report['status'] = 'failed'
    report['failure'] = str(exc)
    raise
finally:
    (ROOT / 'verification/merged-advanced-check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': report.get('status'), 'checks': len(checks), 'failed': [k for k,v in checks.items() if not v]}, ensure_ascii=False))
