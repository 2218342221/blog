#!/usr/bin/env python3
"""Check the revised reading controls and course entrance in real Chromium."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
URL=os.environ.get('COURSE_URL','http://127.0.0.1:8765/').rstrip('/')+'/'
checks={};errors=[];screens=[]
def verify(name, result):
    checks[name]=bool(result)
    assert result,name
try:
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        page=browser.new_page(viewport={'width':390,'height':844},reduced_motion='reduce')
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.on('console',lambda msg:errors.append(msg.text) if msg.type=='error' else None)
        page.goto(URL+'#learn',wait_until='networkidle')
        verify('mobile_hero_under_300px',page.locator('.hero').bounding_box()['height']<300)
        verify('mobile_learning_path_in_first_screen',page.locator('.path-unit').first.bounding_box()['y']<700)
        verify('mobile_downloads_single_row',page.locator('.course-download').evaluate_all('(els)=>new Set(els.map(el=>Math.round(el.getBoundingClientRect().top))).size===1'))
        page.goto(URL+'#chapter/01',wait_until='networkidle')
        verify('mobile_chapter_navigation_available',page.locator('#chapter-jump').is_visible())
        page.locator('#chapter-jump').select_option('1')
        page.wait_for_url(URL+'#chapter/01/1')
        page.wait_for_timeout(200)
        heading=page.locator('#section-01-1 .section-heading').bounding_box()
        tools=page.locator('.reader-tools').bounding_box()
        verify('section_heading_below_sticky_controls',heading['y']>=tools['y']+tools['height'])
        verify('section_heading_is_in_viewport',heading['y']+heading['height']<844)
        verify('jump_updates_reading_location',page.evaluate('state.lastSection')==1)
        before=page.evaluate('JSON.stringify(state)')
        page.locator('[data-reader-action="expanded"]').click()
        verify('expand_all_detail_sections',page.locator('.detail-reading').evaluate_all('(els)=>els.length>0&&els.every(el=>el.open)'))
        normal=page.locator('.prose').first.evaluate('el=>parseFloat(getComputedStyle(el).fontSize)')
        page.locator('[data-reader-action="large"]').click()
        verify('large_text_changes_font_size',page.locator('.prose').first.evaluate('el=>parseFloat(getComputedStyle(el).fontSize)')>normal)
        verify('reading_preferences_do_not_change_xp_or_answers',page.evaluate('JSON.stringify(state)')==before)
        page.reload(wait_until='networkidle')
        verify('display_preferences_survive_reload',page.locator('[data-reader-action="large"]').get_attribute('aria-pressed')=='true' and page.locator('.detail-reading').evaluate_all('(els)=>els.every(el=>el.open)'))
        page.locator('[data-reader-action="large"]').click()
        page.locator('[data-reader-action="expanded"]').click()
        verify('collapse_all_detail_sections',page.locator('.detail-reading').evaluate_all('(els)=>els.every(el=>!el.open)'))
        page.locator('#chapter-jump').select_option('quiz')
        page.wait_for_timeout(150)
        verify('quiz_jump_reaches_quiz',page.locator('#chapter-quiz').bounding_box()['y']<350)
        page.goto(URL+'#labs',wait_until='networkidle')
        verify('four_tools_accessible_in_labs',page.locator('.model-link').count()==4)
        for index,chapter in enumerate(['17','18','19','20']):
            page.goto(URL+'#labs',wait_until='domcontentloaded')
            page.locator('.model-link').nth(index).click()
            page.wait_for_selector('#section-'+chapter+'-0')
            verify('model_link_'+chapter,page.locator('.advanced-interactives').count()==1)
        for width in [320,390,768,1024,1440,1920]:
            page.set_viewport_size({'width':width,'height':1000})
            for route in ['learn','library','labs','chapter/01','chapter/19','resources']:
                page.goto(URL+'#'+route,wait_until='domcontentloaded')
                page.evaluate('document.fonts.ready')
                verify('layout_'+str(width)+'_'+route.replace('/','_'),page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
            if width in [390,1440]:
                page.goto(URL+'#learn',wait_until='domcontentloaded')
                path=ROOT/f'verification/course-polish-{width}.png';page.screenshot(path=str(path));screens.append(str(path.relative_to(ROOT)))
        verify('no_browser_errors',not errors)
        browser.close()
finally:
    record={'status':'passed' if checks and all(checks.values()) and not errors else 'failed',
            'url':URL,'checked_utc':datetime.now(timezone.utc).isoformat(),
            'html_sha256':hashlib.sha256((ROOT/'dist/index.html').read_bytes()).hexdigest(),
            'checks':checks,'errors':errors,'screenshots':screens}
    (ROOT/'verification/course-polish-check.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':record['status'],'checks':len(checks),'failed':[k for k,v in checks.items() if not v]},ensure_ascii=False))
