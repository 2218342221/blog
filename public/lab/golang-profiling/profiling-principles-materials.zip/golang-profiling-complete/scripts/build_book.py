#!/usr/bin/env python3
"""Rebuild the integrated course; compile the PDF only when its TeX changes."""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys
from build_merged import ROOT, build_data, build_site, dump
from merge_tex import assemble, compile_pdf

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile-pdf',action='store_true',help='Force PDF compilation even when TeX is unchanged.')
    args=parser.parse_args()
    subprocess.run([sys.executable,str(ROOT/'scripts/build_advanced_assets.py')],check=True)
    data=build_data()
    report_path=ROOT/'verification/merged-pdf.json'
    previous=json.loads(report_path.read_text()) if report_path.exists() else {}
    tex=ROOT/'dist/golang-profiling.tex';pdf=ROOT/'dist/golang-profiling.pdf'
    report=assemble(ROOT/'base-course/golang-profiling.tex', ROOT/'build/advanced-fragments.json', tex)
    pdf_current=pdf.exists() and hashlib.sha256(pdf.read_bytes()).hexdigest()==previous.get('compilation',{}).get('pdf_sha256')
    if args.compile_pdf or report['merged_tex_sha256']!=previous.get('merged_tex_sha256') or not pdf_current:
        report['compilation']=compile_pdf(tex);report['pages']=report['compilation']['pages']
        report['status']='passed' if all(report['compilation']['checks'].values()) else 'layout_review_required'
        dump(report_path,report)
        if report['status']!='passed':raise RuntimeError('PDF layout verification failed; see '+str(report_path))
    data=build_data()
    build_site(data)
    print(f'Built {len(data["chapters"])} chapters, {data["meta"]["visualCount"]} figures, {data["meta"].get("pdfPages")} PDF pages.')

if __name__=='__main__':main()
