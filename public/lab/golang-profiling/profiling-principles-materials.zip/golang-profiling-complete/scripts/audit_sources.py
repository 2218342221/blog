#!/usr/bin/env python3
"""Audit citations, cached source digests, read ranges, and packaged paths."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
sources=sum((json.loads((ROOT/f'research/sources-{n}.json').read_text()) for n in ['ebpf','pprof','perfetto']),[])
ids={s['id'] for s in sources}; failures=[];files=set();ranges=0;digests=0
for s in sources:
    cache=s.get('local_cache',s.get('cache_path'))
    prefix=None
    if cache:
        p=ROOT/cache
        if not p.is_file():failures.append({'id':s['id'],'missing_cache':cache});continue
        files.add(cache)
        if s.get('sha256'):
            digests+=1
            if hashlib.sha256(p.read_bytes()).hexdigest()!=s['sha256']:failures.append({'id':s['id'],'digest_mismatch':cache})
        u=s.get('url','')
        if '/blob/' in u:
            repo_path=u.split('/blob/')[1].split('/',1)[1].split('#')[0]
            if cache.endswith(repo_path):prefix=cache[:-len(repo_path)]
    for r in s.get('read_ranges',[]):
        rp=r.get('path')
        candidates=([ROOT/rp] if rp else [])+([ROOT/(prefix+rp)] if rp and prefix is not None else [])+([ROOT/cache] if cache and (not rp or cache.endswith(rp)) else [])
        p=next((p for p in candidates if p.is_file()),None)
        if p is None:
            failures.append({'id':s['id'],'unresolved_range':r});continue
        files.add(str(p.relative_to(ROOT)))
        if 'start'in r and 'end'in r:
            ranges+=1;n=len(p.read_text().splitlines())
            if not 1<=r['start']<=r['end']<=n:failures.append({'id':s['id'],'invalid_lines':r,'file_lines':n})
for f in [*ROOT.joinpath('content').glob('*.md'),*(ROOT/f'research/{n}.md' for n in ['ebpf','pprof','perfetto'])]:
    refs=set(re.findall(r'\[((?:eb|pp|pf)-[a-z0-9-]+)\]',f.read_text()))
    if refs-ids:failures.append({'file':str(f),'unknown_refs':sorted(refs-ids)})
record={'status':'passed' if not failures else 'failed','sources':len(sources),'checked_digests':digests,'checked_ranges':ranges,'resolved_files':sorted(files),'failures':failures}
(ROOT/'verification/source-audit.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='resolved_files'},ensure_ascii=False,indent=2))
if failures:raise SystemExit(1)
