#!/usr/bin/env python3
"""Adapt the existing four teaching models for chapter-by-chapter mounting."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
js=(ROOT/'assets/site.js').read_text()
scenario=js[js.index('  const DEFAULT_SCENARIO = '):js.index('  function loadState()')]
method=js[js.index('  function initDemo()'):js.index('  function init() { window.ProfilingCourse')]
method=method.replace('  function initDemo() {','  function initDemo() {\n    const lifetime = new AbortController();\n    const listen = (target, type, handler) => target.addEventListener(type, handler, {signal: lifetime.signal});')
for target in ['playButton',"$('#demo-reset')",'slider','document','window']:
    method=method.replace(target+'.addEventListener(', 'listen('+target+', ')
method=method.replace('return {setTime, getState: snapshot, play, pause:', 'return {destroy() { playing = false; cancelAnimationFrame(frameId); lifetime.abort(); }, setTime, getState: snapshot, play, pause:')
method=method.replace('CPU 权重在右侧累计相加。','CPU 权重在累计 CPU 卡片中相加。')
request='(() => {\n"use strict";\n'+scenario+method+'\nwindow.createRequestDemo = initDemo;\n})();\n'
mechanisms=(ROOT/'assets/mechanism_labs.js').read_text()
mechanisms=mechanisms.replace("  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});\n  else init();",'  window.initMechanismLabs = init;')
hooks='''
(() => {
  window.disposeAdvancedLabs = () => {
    window.ProfilingCourse?.requestDemo?.destroy();
    window.ProfilingCourse = null;
    window.MechanismLabs = null;
    document.querySelectorAll('.advanced-interactives').forEach(root => root.getAnimations({subtree:true}).forEach(animation => animation.cancel()));
  };
  window.initAdvancedLabs = () => {
    const request = document.getElementById('request-demo');
    if (request && request.dataset.initialized !== 'true') {
      request.dataset.initialized = 'true';
      window.ProfilingCourse = {requestDemo: window.createRequestDemo()};
    }
    window.initMechanismLabs();
  };
})();
'''
(ROOT/'assets/advanced_labs.js').write_text(request+mechanisms+hooks)

def selectors(text):
    start=0;depth=0;quote=None
    for i,char in enumerate(text):
        if quote:
            if char==quote and (i==0 or text[i-1]!='\\'):quote=None
        elif char in '\"\'':quote=char
        elif char in '([':depth+=1
        elif char in ')]':depth-=1
        elif char==',' and depth==0:yield text[start:i].strip();start=i+1
    yield text[start:].strip()

def scoped(css):
    css=re.sub(r'/\*.*?\*/','',css,flags=re.S);out=[];pos=0
    while pos<len(css):
        begin=css.find('{',pos)
        if begin<0:break
        header=css[pos:begin].strip();depth=1;end=begin+1;quote=None
        while depth:
            char=css[end]
            if quote:
                if char==quote and css[end-1]!='\\':quote=None
            elif char in '\"\'':quote=char
            elif char=='{':depth+=1
            elif char=='}':depth-=1
            end+=1
        body=css[begin+1:end-1];pos=end
        if header.startswith(('@media','@container','@supports')):out.append(header+'{\n'+scoped(body)+'\n}')
        elif header.startswith('@'):raise ValueError('Unexpected CSS at-rule: '+header)
        else:
            scoped_selectors=[('.advanced-interactives' if s==':root' else '.advanced-interactives '+s) for s in selectors(header)]
            out.append(',\n'.join(scoped_selectors)+'{'+body+'}')
    return '\n'.join(out)
css=scoped((ROOT/'assets/site.css').read_text())+'\n'+scoped((ROOT/'assets/mechanism_labs.css').read_text())
css+='''
.advanced-interactives { margin: 24px 0; max-width:100%; min-width:0; }
.advanced-interactives .request-demo { margin-top:0; }
.advanced-interactives .ml-labs { margin:0; }
.advanced-interactives .ml-card { margin:0; }
.advanced-interactives .timeline-cursor > span { white-space:nowrap; min-width:max-content; }
.prose .advanced-figure { margin:24px 0; padding:18px; border:1px solid #deead6; border-radius:16px; background:#fbfdf8; max-width:100%; }
.prose .advanced-figure svg { display:block; width:100%; height:auto; }
.prose .advanced-figure figcaption { font-size:12px; color:#607454; line-height:1.9; margin-top:12px; }
.prose .advanced-figure .figure-open { display:inline-block; margin-left:9px; font-size:12px; color:#347e6a; text-underline-offset:3px; }
.prose math { font-size:1.06em; }
.prose math:not([display="block"]) { display:inline-block; max-width:100%; overflow-x:auto; vertical-align:middle; }
.prose math[display="block"] { display:block; max-width:100%; overflow-x:auto; margin:18px 0; padding:12px 2px; }
@media(max-width:580px) { .prose .advanced-figure { padding:10px; } }
'''
(ROOT/'assets/advanced_labs.css').write_text(css)
print('Built scoped styles and lifecycle-safe teaching models.')
