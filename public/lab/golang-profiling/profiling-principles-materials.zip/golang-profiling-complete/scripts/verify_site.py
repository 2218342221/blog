#!/usr/bin/env python3
"""Run both browser validators for the integrated course."""
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]
for name in ('verify_merged_original_ui.py', 'verify_merged_advanced.py'):
    subprocess.run([sys.executable, str(ROOT / 'scripts' / name)], cwd=ROOT, check=True)
