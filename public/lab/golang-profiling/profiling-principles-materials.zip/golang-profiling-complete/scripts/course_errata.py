"""Apply explicit, audited sentence corrections while keeping frozen inputs intact."""
from pathlib import Path
import copy
import json

ROOT=Path(__file__).resolve().parents[1]
ERRATA=json.loads((ROOT/'content/errata.json').read_text())

def apply_data(base):
    data=copy.deepcopy(base)
    for item in ERRATA:
        chapter=next(c for c in data['chapters'] if c['id']==item['chapter'])
        section=chapter['sections'][item['section']]
        if section['body'].count(item['before'])!=1:
            raise ValueError('Erratum does not uniquely match source: '+item['id'])
        section['body']=section['body'].replace(item['before'],item['after'],1)
    return data

def apply_tex(core):
    for item in ERRATA:
        # These corrections contain no TeX special characters; explicit guards
        # reject a changed frozen source rather than silently patching elsewhere.
        if core.count(item['before'])!=1:
            raise ValueError('Erratum does not uniquely match TeX: '+item['id'])
        core=core.replace(item['before'],item['after'],1)
    return core
