#!/usr/bin/env python3
"""Verify the blog entry, its base path, published bytes, and native PDF viewer."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.request import urlopen
from urllib.parse import urljoin
import argparse, base64, hashlib, json
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url',required=True,help='Blog root ending in /blog/')
parser.add_argument('--phase',choices=['preview','live'],required=True)
args=parser.parse_args();base=args.url.rstrip('/')+'/';course=urljoin(base,'lab/golang-profiling/')
checks={};errors=[];downloads={};screens=[]
def check(name,value):
    checks[name]=bool(value)
    assert value,name
def get(url):
    with urlopen(url,timeout=45) as r:
        assert r.status==200
        return r.read()

try:
    for name in ['index.html','pdf.html','golang-profiling.pdf','golang-profiling.tex','golang-profiling.md','course-data.json','golang-profiling-complete.zip']:
        data=get(course+name);sha=hashlib.sha256(data).hexdigest()
        check('published_bytes_'+name,sha==hashlib.sha256((ROOT/'dist'/name).read_bytes()).hexdigest())
        downloads[name]={'bytes':len(data),'sha256':sha}
    index=json.loads(get(base+'search-index.json'))
    check('search_index_includes_course',any('Go 程序剖析与诊断' in item.get('title','') and '/blog/lab/golang-profiling/' in json.dumps(item,ensure_ascii=False) for item in index))
    check('rss_links_directly_to_course',b'/blog/lab/golang-profiling/' in get(base+'rss.xml'))
    for path in ['','topics/','archive/']:
        check('blog_entry_'+(path or 'home'),b'/blog/lab/golang-profiling/' in get(base+path))
    figures=json.loads((ROOT/'assets/figure_manifest.json').read_text())
    for figure in figures:
        name='figures/'+figure['id']+'.svg'
        check('figure_'+figure['id'],get(course+name)==(ROOT/'dist'/name).read_bytes())
    data=json.loads((ROOT/'dist/course-data.json').read_text())
    for source in data['sources']:
        if not source['url'].startswith('http'):
            check('local_source_'+source['id'],get(course+source['url'])==(ROOT/'dist'/source['url']).read_bytes())
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,channel='chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1440,'height':1000},reduced_motion='reduce')
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(base,wait_until='networkidle')
        check('visible_blog_course_card',page.locator('a[href="/blog/lab/golang-profiling/"]').count()>0)
        page.goto(course+'#learn',wait_until='networkidle')
        check('course_22_chapters',page.evaluate('DATA.chapters.length')==22)
        page.locator('.hero-actions [data-chapter]').first.click()
        page.wait_for_selector('#chapter-jump')
        page.locator('#chapter-jump').select_option('1')
        check('chapter_jump_preserves_base_path','/blog/lab/golang-profiling/#chapter/01/1' in page.url)
        page.locator('[data-reader-action="large"]').click()
        check('reader_controls_work',page.locator('[data-reader-action="large"]').get_attribute('aria-pressed')=='true')
        page.goto(course+'#labs',wait_until='networkidle')
        page.locator('.model-link').nth(2).click()
        page.wait_for_selector('#ml-pprof-lab')
        check('advanced_model_works',page.evaluate('MechanismLabs.pprof.getState().totalCpuMs')==23)
        for width in [1440,390]:
            page.set_viewport_size({'width':width,'height':1000 if width==1440 else 844})
            page.goto(course+'#learn',wait_until='networkidle')
            check('course_layout_'+str(width),page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
            path=ROOT/f'verification/blog-{args.phase}-course-{width}.png';page.screenshot(path=str(path));screens.append(str(path.relative_to(ROOT)))
            page.goto(course+'pdf.html',wait_until='networkidle')
            page.wait_for_timeout(1300)
            check('pdf_layout_'+str(width),page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
            check('pdf_canonical_target_'+str(width),'golang-profiling.pdf' in page.locator('iframe').get_attribute('src'))
            path=ROOT/f'verification/blog-{args.phase}-pdf-{width}.png'
            image=page.context.new_cdp_session(page).send('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False})
            path.write_bytes(base64.b64decode(image['data']));screens.append(str(path.relative_to(ROOT)))
        check('no_javascript_errors',not errors)
        browser.close()
except Exception as error:
    errors.append(str(error))
    raise
finally:
    report={'phase':args.phase,'blog_url':base,'course_url':course,
            'checked_utc':datetime.now(timezone.utc).isoformat(),
            'status':'passed' if checks and all(checks.values()) and not errors else 'failed',
            'checks':checks,'errors':errors,'downloads':downloads,'screenshots':screens}
    (ROOT/f'verification/blog-{args.phase}-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'checks':len(checks),'failed':[k for k,v in checks.items() if not v]}))
