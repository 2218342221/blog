#!/usr/bin/env python3
"""Bounded GoLab verification; never touches existing services."""
import concurrent.futures,json,os,pathlib,socket,subprocess,time,urllib.request,sys,threading
ROOT=pathlib.Path(__file__).resolve().parents[1]
LAB=ROOT/'lab'; OUT=ROOT/'verification/lab';OUT.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env.update(GOPATH=str(LAB/'.gopath'),GOCACHE=str(LAB/'.gocache'))
env.setdefault('GOTOOLCHAIN','go1.25.0')
results=[]
def free_port():
 with socket.socket() as sock:
  sock.bind(("127.0.0.1",0));return sock.getsockname()[1]
APP_PORT=free_port();DIAG_PORT=free_port()
while DIAG_PORT==APP_PORT:DIAG_PORT=free_port()
def run(name,args,cwd=LAB,timeout=180):
 p=subprocess.run(args,cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (OUT/(name+'.txt')).write_text(p.stdout)
 results.append(dict(check=name,command=args,exit_code=p.returncode))
 print(name,p.returncode,flush=True)
 if p.returncode:raise RuntimeError(name+' failed: '+p.stdout[-600:])
 return p.stdout
def get(path,port=None):
 if port is None:port=APP_PORT
 with urllib.request.urlopen('http://127.0.0.1:'+str(port)+path,timeout=20) as r:return r.read()
def save_profile(name,path):
 data=get('/debug/pprof/'+path,DIAG_PORT);(OUT/name).write_bytes(data)
 if len(data)<40:raise RuntimeError('empty profile '+name)
 results.append(dict(check='capture '+name,bytes=len(data)))
def load_for(seconds,route,workers=4):
 end=time.monotonic()+seconds
 def worker():
  n=0
  while time.monotonic()<end:get(route);n+=1
  return n
 with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:return sum(pool.map(lambda _:worker(),range(workers)))
def main():
 results.append(dict(check='isolated loopback ports',application=APP_PORT,diagnostics=DIAG_PORT))
 run('go-version',['go','version'])
 run('unit',['go','test','./...'])
 run('race',['go','test','-race','./...'])
 run('vet',['go','vet','./...'])
 run('bench',['go','test','-run=^$','-bench=BenchmarkEncode','-benchmem','-benchtime=200ms','-count=5'])
 run('bench-profile',['go','test','-run=^$','-bench=BenchmarkEncodeSlow','-benchtime=2s','-cpuprofile='+str(OUT/'bench.cpu.pb.gz'),'-memprofile='+str(OUT/'bench.mem.pb.gz'),'-o',str(OUT/'golab.test')])
 run('build',['go','build','-o',str(OUT/'golab'),'.'])
 run('pgo-build',['go','build','-pgo='+str(OUT/'bench.cpu.pb.gz'),'-o',str(OUT/'golab-pgo'),'.'])
 for port in (APP_PORT,DIAG_PORT):
  with socket.socket() as sock:
   try:sock.bind(('127.0.0.1',port))
   except OSError:raise RuntimeError('Port occupied; existing process preserved: '+str(port))
 with (OUT/'server.log').open('w') as log:
  proc=subprocess.Popen([str(OUT/'golab'),'-app-port='+str(APP_PORT),'-diag-port='+str(DIAG_PORT)],cwd=LAB,env=env,stdout=log,stderr=log)
  try:
   for _ in range(100):
    if proc.poll() is not None:raise RuntimeError('server exited')
    try:
     if get('/health').startswith(b'ok'):break
    except Exception:time.sleep(.05)
   else:raise RuntimeError('health timeout')
   with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:
    f=p.submit(load_for,5,'/cpu?n=2000',4)
    time.sleep(.15);save_profile('cpu.pb.gz','profile?seconds=3');n=f.result()
    results.append(dict(check='bounded CPU load',successful_requests=n))
   for _ in range(8):get('/retain')
   save_profile('heap-retained.pb.gz','heap?gc=1')
   get('/alloc?n=2000&size=512');save_profile('allocs.pb.gz','allocs')
   req=urllib.request.Request('http://127.0.0.1:'+str(APP_PORT)+'/reset',method='POST')
   with urllib.request.urlopen(req,timeout=10) as r:r.read()
   save_profile('heap-reset.pb.gz','heap?gc=1')
   load_for(2,'/lock?ms=10',8)
   save_profile('mutex.pb.gz','mutex');save_profile('block.pb.gz','block')
   save_profile('goroutine.pb.gz','goroutine')
   with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:
    f=p.submit(load_for,4,'/wait?ms=20',4)
    time.sleep(.1);save_profile('trace.out','trace?seconds=2');f.result()
  finally:
   proc.terminate()
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
 for f in ['cpu','heap-retained','heap-reset','allocs','mutex','block','goroutine']:
  run('pprof-'+f,['go','tool','pprof','-top',str(OUT/'golab'),str(OUT/(f+'.pb.gz'))])
 for metric in ['alloc_objects','alloc_space','inuse_objects','inuse_space']:
  run('heap-'+metric,['go','tool','pprof','-sample_index='+metric,'-top',str(OUT/'golab'),str(OUT/'heap-retained.pb.gz')])
 trace=subprocess.run(['go','tool','trace','-pprof=sched',str(OUT/'trace.out')],cwd=LAB,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 if trace.returncode:raise RuntimeError(trace.stderr.decode())
 (OUT/'sched.pb.gz').write_bytes(trace.stdout)
 run('trace-sched',['go','tool','pprof','-top',str(OUT/'sched.pb.gz')])
 results.append(dict(check='scope',notes='Short functional validation only; no production canary, no statistically powered optimization claim, no perf/eBPF/core/Delve execution.'))
try:main()
except Exception as e:
 results.append(dict(check='failure',error=str(e)));raise
finally:(OUT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
