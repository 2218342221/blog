#!/usr/bin/env python3
"""Append the six mechanism chapters to the preserved 16-chapter textbook."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
from course_errata import ERRATA, apply_tex
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHAPTER_RE = re.compile(r"^\\chapter(?:\[[^\n]*\])?\{", re.M)
BIB_RE = re.compile(r"^\\bibitem\{([^}]+)\}", re.M)
PART_TITLE = "第五篇 · eBPF、pprof 与 Perfetto 机制深研"


def digest(text: str | bytes) -> str:
    return hashlib.sha256(text.encode() if isinstance(text, str) else text).hexdigest()


def display_path(path: Path) -> str:
    try:
        return str(path.relative_to(ROOT))
    except ValueError:
        return str(path)


def replace_once(text: str, old: str, new: str) -> str:
    if text.count(old) != 1:
        raise ValueError(f"Expected exactly one occurrence: {old[:100]!r}")
    return text.replace(old, new, 1)


def escape(text: str) -> str:
    replacements = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%",
                    "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{",
                    "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
    text = "".join(replacements.get(char, char) for char in str(text))
    return re.sub(r"\b[0-9a-f]{32,64}\b", lambda match: r"\texttt{" +
                  r"\allowbreak{}".join(match[0][i:i + 8] for i in range(0, len(match[0]), 8)) + "}", text)


def literal_path(text: str) -> str:
    if any(char in str(text) for char in "{}\n\r"):
        raise ValueError(f"Unsupported URL/path syntax: {text!r}")
    return r"\nolinkurl{" + str(text) + "}"


def source_item(source: dict) -> str:
    ident = source["id"]
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", ident):
        raise ValueError(f"Invalid citation key: {ident!r}")
    url = source.get("url", "")
    if any(char in url for char in "{}\n\r"):
        raise ValueError(f"Unsupported source URL: {url!r}")
    lines = [r"\bibitem{" + ident + "} " + escape(source["title"]) + r".\par"]
    if url:
        lines.append((r"\url{" if url.startswith(("http://", "https://")) else r"\nolinkurl{") + url + r"}\par")
    lines.append(r"{\small\raggedright 固定版本：" + escape(source.get("pinned_version", "")) + r"。\par")
    ranges = []
    for item in source.get("read_ranges", []):
        label = literal_path(item.get("path", "")) if item.get("path") else ""
        if "start" in item and "end" in item:
            label += f"：{item['start']}–{item['end']} 行"
        elif item.get("scope"):
            label += "：" + escape(item["scope"])
        if label:
            ranges.append(label)
    if ranges:
        lines.append("阅读范围：" + "；".join(ranges) + r"。\par")
    if source.get("limitations"):
        lines.append("证据边界：" + "；".join(escape(item) for item in source["limitations"]) + "。")
    lines.append("}\n")
    return "\n".join(lines)


def update_frontmatter(front: str) -> str:
    front = replace_once(front, r"\usepackage{xcolor", r"\usepackage{amsmath,amssymb,capt-of,needspace}" + "\n" + r"\usepackage{xcolor")
    front = replace_once(front, "pdftitle={Go 程序剖析与诊断}", "pdftitle={Go 程序剖析与诊断：机制深研增订版}")
    front = replace_once(front, "中文研究生课程教材\\quad ·\\quad 2.1 校订版", "中文研究生课程教材\\quad ·\\quad 机制深研增订版")
    front = replace_once(front, "编制与检索日期：2026 年 10 月 2 日\\par", "原教材检索日期：2026 年 10 月 2 日\\par\n机制深研查证：2026 年 10 月 4 日；增订：2026 年 10 月 5 日\\par")
    front = replace_once(front,
        "全书按“基础—工具—应用—实现—研究”组织。第十五章研究成熟开源项目的实现，第十六章研究近五年前沿工作。每章包含学习目标、先修要求、正文、实验、测验解析和分析题答案。课程建议 16 周，每周 6 小时；项目评分量规见第十四章。",
        "本增订版保留原教材第 1–16 章，并在其后追加第 17–22 章机制深研。原教材按“基础—工具—应用—实现—研究”组织：第十五章研究成熟开源项目的实现，第十六章研究近五年前沿工作；这些章节的内容体系完整保留，并依据勘误记录修正 PGO 空输入边界及 trace 注解表述。第十七章重建测量契约，第十八至二十章分别深入 eBPF、pprof 与 Perfetto 的实现，第二十一章完成同一请求的跨工具实验，第二十二章形成组合诊断方法。\n\n原教材各章包含学习目标、先修要求、正文、实验、测验解析和分析题答案，基础课程建议 16 周、每周 6 小时；项目评分量规见第十四章。完成基础课程后，可继续按六章深研的顺序学习，结合固定源码、图解、交互实验与推导练习复核工具机制。")
    front = replace_once(front, "最后一章的检索窗口为", "第十六章的检索窗口为")
    front = replace_once(front, "重写最后两章", "重写第十五、十六章")
    front = replace_once(front,
        "本文件为独立 LaTeX 源码，无需外部图片、章节文件或 BibTeX 项目。",
        "增订版统一了 22 章的目录、64 张同源机制图和 168 条参考来源；HTML 与 PDF 使用相同章节顺序。原教材的 39 张机制图保留，新增 25 张 SVG/TikZ 同源图及四项交互实验。所有图均为教学机制示意，原理实验中的合成输入不代表生产采样。本文件为独立 LaTeX 源码，无需外部图片、章节文件或 BibTeX 项目。")
    return front


def assemble(base_path: Path, fragments_path: Path, output: Path) -> dict:
    base = base_path.read_text()
    data = json.loads(fragments_path.read_text())
    chapters, sources = data["chapters"], data["sources"]
    if len(chapters) != 6 or len(sources) != 95:
        raise ValueError("Expected six advanced chapters and 95 advanced sources")
    if base.count(r"\mainmatter") != 1 or base.count(r"\backmatter") != 1:
        raise ValueError("Base textbook must have one mainmatter and one backmatter")
    front, remaining = base.split("\\mainmatter\n", 1)
    frozen_core, back = remaining.split("\\backmatter\n", 1)
    core = apply_tex(frozen_core)
    if len(CHAPTER_RE.findall(core)) != 16:
        raise ValueError("Base textbook must contain 16 numbered chapters")
    old_ids = BIB_RE.findall(back)
    new_ids = [source["id"] for source in sources]
    if len(old_ids) != 73 or len(set(old_ids + new_ids)) != 168:
        raise ValueError("Citation keys must be unique across the 73 + 95 sources")
    front = update_frontmatter(front)
    advanced = ["% BEGIN APPENDED MECHANISM CHAPTERS\n", r"\begingroup",
                "% Scope Unicode-capable Latin/monospace fonts to the added chapters only.",
                r"\setmainfont{DejaVu Serif}", r"\setsansfont{DejaVu Sans}",
                r"\setmonofont[Scale=.85]{DejaVu Sans Mono}", r"\part*{" + PART_TITLE + "}",
                r"\addcontentsline{toc}{part}{" + PART_TITLE + "}",
                "本篇接续前四篇的测量、工具、工程与研究基础，从固定版本源码追踪数据如何产生、传输与解释。"
                "正文和图示说明算法及其边界；共享教学输入用于验证格式、聚合和查询，不冒充运行时采样或生产收益。\n",
                "源码基线为 Linux v6.12、libbpf v1.5.0、Go 1.25.0、固定提交的 google/pprof 与 Perfetto v58.2。"
                "实际分析客户端为 Go 1.22.12 内置 pprof 与官方 Perfetto v58.2；eBPF 实验完成源码与 API 校验，未进行特权加载。"
                "这些边界与原教材各工具实验的验证范围分别保留。\n"]
    chapter_hashes = []
    for index, chapter in enumerate(chapters, 17):
        if str(chapter["id"]) != str(index) or int(chapter["local_number"]) != index - 16:
            raise ValueError(f"Unexpected chapter order: {chapter['id']!r}")
        fragment = chapter["tex"]
        if len(CHAPTER_RE.findall(fragment)) != 1:
            raise ValueError(f"Expected one chapter command in chapter {index}")
        if re.search(r"\\(?:documentclass|begin\{document\}|end\{document\}|backmatter|frontmatter|mainmatter)", fragment):
            raise ValueError(f"Standalone document markup in chapter {index}")
        if r"\hyperlink{src-" in fragment:
            raise ValueError("Advanced source references must use the shared citation keys")
        if "独立原理专题，不依赖此前教材文件" in fragment:
            raise ValueError("Advanced introduction still describes a separate textbook")
        # A legal break in the identifier avoids a measured 9.8 pt overflow
        # with the Unicode-capable monospace font; the token itself is unchanged.
        fragment = fragment.replace(r"\texttt{MemProfileRate}", r"\texttt{Mem\allowbreak{}Profile\allowbreak{}Rate}")
        if r"\label{ch:" + str(index) + "}" not in fragment:
            fragment = re.sub(r"(^\\chapter[^\n]*\n)", lambda match: match[0] + r"\label{ch:" + str(index) + "}\n", fragment, count=1, flags=re.M)
        chapter_hashes.append({"chapter": index, "source_tex_sha256": digest(chapter["tex"]), "merged_tex_sha256": digest(fragment)})
        advanced.append(fragment)
    advanced.extend([r"\clearpage", r"\endgroup", "% END APPENDED MECHANISM CHAPTERS\n"])
    back = replace_once(back, r"\begin{thebibliography}{99}", r"\begin{thebibliography}{999}")
    back = replace_once(back, r"\end{thebibliography}", "\n".join(source_item(source) for source in sources) + "\n" + r"\end{thebibliography}")
    merged = front + "\\mainmatter\n" + core + "\n".join(advanced) + "\\backmatter\n" + back
    merged_core = merged.split("\\mainmatter\n", 1)[1].split("% BEGIN APPENDED MECHANISM CHAPTERS", 1)[0]
    cites = {key.strip() for group in re.findall(r"\\cite(?:\[[^]]*\])?\{([^}]+)\}", merged) for key in group.split(",")}
    labels = re.findall(r"\\label\{([^}]+)\}", merged)
    checks = {"base_technical_body_matches_documented_errata": merged_core == apply_tex(frozen_core),
              "numbered_chapters_22": len(CHAPTER_RE.findall(merged)) == 22,
              "bibliography_items_168": len(BIB_RE.findall(merged)) == 168,
              "all_citations_resolve": cites <= set(old_ids + new_ids),
              "unique_labels": len(labels) == len(set(labels)),
              "single_document": merged.count(r"\begin{document}") == merged.count(r"\end{document}") == 1,
              "single_bibliography": merged.count(r"\begin{thebibliography}") == merged.count(r"\end{thebibliography}") == 1,
              "single_mainmatter": merged.count(r"\mainmatter") == 1,
              "base_bibliography_entries_preserved": all(item in back for item in re.findall(r"\\bibitem\{.*?(?=\\bibitem\{|\\end\{thebibliography\})", base, re.S))}
    if not all(checks.values()):
        raise ValueError({"failed_checks": [key for key, passed in checks.items() if not passed]})
    output.parent.mkdir(exist_ok=True)
    output.write_text(merged)
    return {"status": "assembled", "base": display_path(base_path),
            "fragments": display_path(fragments_path), "tex": display_path(output),
            "base_tex_sha256": digest(base), "base_technical_body_sha256": digest(frozen_core),
            "corrected_base_body_sha256": digest(core), "documented_errata": ERRATA,
            "merged_tex_sha256": digest(merged), "chapter_inputs": chapter_hashes,
            "base_sources": len(old_ids), "advanced_sources": len(new_ids), "checks": checks}


def compile_pdf(tex: Path, max_passes: int = 5) -> dict:
    work = ROOT / "verification/merged-pdf-build"
    work.mkdir(exist_ok=True)
    state = None
    passes = []
    for number in range(1, max_passes + 1):
        transcript = work / f"pass-{number:02}.txt"
        with transcript.open("w") as stream:
            result = subprocess.run(["xelatex", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error",
                                     "-output-directory=" + str(work), str(tex)], cwd=ROOT, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=240)
        if result.returncode:
            raise RuntimeError(f"XeLaTeX pass {number} failed; see {transcript}")
        next_state = {suffix: digest((work / (tex.stem + suffix)).read_bytes())
                      for suffix in (".aux", ".toc", ".lof", ".out") if (work / (tex.stem + suffix)).exists()}
        log = (work / (tex.stem + ".log")).read_text(errors="replace")
        pending = bool(re.search(r"Rerun to get|Label\(s\) may have changed|There were undefined references|Citation .* undefined|Reference .* undefined", log))
        passes.append({"pass": number, "pending_references": pending, "auxiliary_state": next_state})
        if number >= 3 and next_state == state and not pending:
            break
        state = next_state
    else:
        raise RuntimeError("LaTeX references or auxiliary files did not converge")
    target = tex.with_suffix(".pdf")
    shutil.copyfile(work / target.name, target)
    info = subprocess.check_output(["pdfinfo", str(target)], text=True)
    fonts = subprocess.check_output(["pdffonts", str(target)], text=True)
    (ROOT / "verification/merged-pdf-info.txt").write_text(info)
    (ROOT / "verification/merged-pdf-fonts.txt").write_text(fonts)
    extracted = ROOT / "verification/merged-pdf-extracted.txt"
    subprocess.run(["pdftotext", "-layout", str(target), str(extracted)], check=True)
    aux = (work / (tex.stem + ".aux")).read_text()
    toc = (work / (tex.stem + ".toc")).read_text()
    lof = (work / (tex.stem + ".lof")).read_text()
    issues = {"missing_characters": re.findall(r"Missing character:.*", log),
              "overfull_hbox": re.findall(r"Overfull \\hbox .*", log),
              "overfull_vbox": re.findall(r"Overfull \\vbox .*", log),
              "font_warnings": re.findall(r"(?:LaTeX Font Warning:|Package fontspec Warning:).*", log),
              "latex_warnings": re.findall(r"LaTeX Warning:.*", log)}
    font_rows = [row.split() for row in fonts.splitlines()[2:] if row.strip()]
    checks = {"references_converged": not pending,
              "compiled_bibliography_entries_168": len(re.findall(r"\\bibcite\{", aux)) == 168,
              "toc_has_22_numbered_chapters": len(re.findall(r"\\contentsline \{chapter\}\{\\numberline", toc)) == 22,
              "compiled_figures_64": len(re.findall(r"\\contentsline \{figure\}", lof)) == 64,
              "all_fonts_embedded": bool(font_rows) and all(row[-5] == "yes" for row in font_rows),
              "no_missing_characters": not issues["missing_characters"],
              "no_overfull_hbox": not issues["overfull_hbox"],
              "no_overfull_vbox": not issues["overfull_vbox"]}
    return {"pdf": str(target.relative_to(ROOT)), "pdf_sha256": digest(target.read_bytes()),
            "pages": int(re.search(r"^Pages:\s+(\d+)", info, re.M)[1]),
            "passes": passes, "checks": checks, "issues": issues}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=ROOT / "base-course/golang-profiling.tex")
    parser.add_argument("--fragments", type=Path, default=ROOT / "build/advanced-fragments.json")
    parser.add_argument("--output", type=Path, default=ROOT / "dist/golang-profiling.tex")
    parser.add_argument("--compile", action="store_true")
    args = parser.parse_args()
    report = assemble(args.base.resolve(), args.fragments.resolve(), args.output.resolve())
    if args.compile:
        report["compilation"] = compile_pdf(args.output.resolve())
        report["pages"] = report["compilation"]["pages"]
        report["status"] = "passed" if all(report["compilation"]["checks"].values()) else "layout_review_required"
    target = ROOT / "verification/merged-pdf.json"
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "tex_sha256": report["merged_tex_sha256"],
                      "pages": report.get("compilation", {}).get("pages"),
                      "failed_checks": [name for name, passed in report.get("compilation", {}).get("checks", {}).items() if not passed]},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
