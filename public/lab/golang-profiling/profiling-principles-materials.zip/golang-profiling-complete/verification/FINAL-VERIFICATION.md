# 2026-10-05 校订与发布核对

本记录对应完整 22 章课程：231 页 PDF、142 节正文、64 张图、168 项来源。第 1–16 章保留原课程结构，第 17–22 章追加工具机制深研。冻结基础输入不修改，两条原章句子勘误通过 `content/errata.json` 同步应用于课程数据与 LaTeX。

## 技术语义审读

本轮分别通读基础 14 章（89 节）、原研究两章（14 节）和新增六章（39 节），检查正文、相关测验、图解、实验及分析题；针对关键断言核对固定源码、论文和已有工具证据。详细覆盖及证据见 `review-2026-10-05-core.md`、`review-2026-10-05-research.md`、`review-2026-10-05-advanced.md`。

本次修正四处边界表述：

1. 第 11.5 节：Go 1.25 编译器可忽略空文件或无样本的 PGO profile；非空全零样本可能先在 start_line 检查失败，不能笼统说零权重输入都会被忽略。
2. 第 16.5 节：FlightRecorder 请求关联需要明确的 trace task/region/log 注解，不能假定 pprof 标签自动成为 trace 注解。
3. 第 20.3 节：Perfetto v58.2 持续耗尽达到固定实现的 300 次 stall 阈值时，kStall 触发 PERFETTO_FATAL，kStallThenDrop 返回无效 Chunk；该阈值不是稳定 API 或固定超时时间。
4. 第 21 章：合成 pprof 输入只有逻辑函数和调用栈，省略 Location.Address 与 Mapping；没有伪造真实 ELF 地址。

两条新增题目中的多余中文词间空格也已清理。落实记录见 `review-2026-10-05-resolutions.json`。新增机制审读另完成 25 项独立算术检查；Pyroscope 三组隔离函数复现本轮重新运行通过，见 `review-2026-10-05-research-repro/`。

## UI 与交互

首页压缩手机首屏，下载卡片改为紧凑一行；章节阅读页新增小节跳转、全文展开、大字阅读；实验室提供四组机制模型入口。跳转尊重系统减少动态效果设置。阅读偏好与课程 XP、答案分开存储，既有进度兼容。

- `course-polish-check.json`：55 项检查通过，覆盖阅读控件、偏好持久化、四模型入口及 320–1920 px 的六种宽度。
- `merged-original-ui-check.json`：12 组回归通过，包括原 103 节完成操作、39 图/160 步、56 道题、错题、XP、导入导出、旧链接与旧进度迁移。内容勘误后定向复测数据保真和阅读位置；完整动画回归不重复计数。
- `merged-advanced-check.json`：103 项检查通过，覆盖六章、25 图、95 条新增引用、公式、四模型及资源链接。
- `merged-http-check.json`：21 项检查通过，核对实际内容、PDF MIME/内联文件名、HEAD 和 Range 请求。

## 文档、来源与构建

`merge-content-audit.json` 检查当前产物与输入的一致性，并明确原章仅有两条白名单勘误；原 73 条来源与 39 张动画数据保持不变。`source-audit.json` 核对 95 个新增来源摘要和 188 处阅读区间，全部通过。来源完整性检查不等于每条技术命题的独立实验复现。

`merged-pdf.json` 记录本次 231 页 PDF 的连续编译收敛、64 图、168 条书目、字体嵌入、无缺字/未解析引用/overfull box。当前 PDF SHA-256：`e741e5dc96ccdaba3f0f7defdb28300e81e820e44edd8fa1569c24bfea95b8f9`；LaTeX：`288fbffd0e20dc3cf5080dd5a241f6010fede14052d416565c80b67bbea272ff`。旧 `merged-pdf-web.json` 属于合订初版的在线阅读证据，最终博客阅读以 `blog-preview-check.json` 与 `blog-live-check.json` 为准。

当前入口为 `scripts/build_book.py`；图源更改先运行 `scripts/figures.py`。完整材料包由 `scripts/package_materials.py --smoke-test` 生成；CRC、逐文件摘要、解压重建和下载字节见包外 `package-verification.json`。博客前缀、入口、实际发布字节及 PDF 浏览器截图由 `scripts/verify_blog_release.py` 检查。包验证与博客发布报告包含 ZIP 摘要，因此不纳入被验证的 ZIP，避免循环哈希。

## 日期与实际验证边界

原前沿研究窗口仍为 2021-10-02—2026-10-02；新增机制源码与工具实验查证于 2026-10-04，本次语义审读与发布校订于 2026-10-05，不将校订日期冒充新一轮前沿文献检索截止日期。

主课程 16 个 Go 实验本轮未重跑；本轮新增执行的是浏览器/构建/HTTP验证、确定性算术和 Pyroscope 隔离函数复现。专题阶段的 pprof CLI、Perfetto 查询、ScaleN 子包与原生 Go trace 导入负例仍保留为历史技术证据，详见各记录时间和版本。

合成 profile/ftrace 验证解析、聚合和计算，不代表生产采样。eBPF 示例没有编译 BPF 对象或进行特权内核加载；未进行生产负载、heap 随机收敛、SMB 压力或 Go viewer JSON 完整转换实测。源码基线 Go 1.25.0 与专题 CLI Go 1.22.12 分开，固定 pprof 仅编译过反例需要的 profile 子包。
