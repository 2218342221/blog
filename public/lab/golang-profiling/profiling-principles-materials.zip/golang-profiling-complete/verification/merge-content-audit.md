# 合订内容只读整合审计

审计日期：2026-10-05。针对两处技术修正后的当前产物重新运行全部合订检查：33/33 通过。另行检查修正传播，结果：全部通过。

本轮只读取当前任务目录，以 base-course 冻结副本为原课程基线；没有打开历史任务目录，没有修改教材、生成器或模板。按既有授权保留原 1–16 章并应用两项明确勘误，再追加第 17–22 章。

## 规模与保真

| 项目 | 原课程 | 追加 | 合订 |
| --- | ---: | ---: | ---: |
| 章节 | 16 | 6 | 22 |
| 知识小节 | 103 | 39 | 142 |
| 来源 ID | 73 | 95 | 168 |
| 图 | 39 可播放机制图 | 25 静态原理图 | 64 |
| 交互选择题 | 56 | 6 | 62 |
| 结构化分析题 | 35 | 正文内保留 | 35 |
| 结构化实验 | 16 | 正文内保留 | 16 |

原图共 160 个动画步骤，新增部分另有 4 项交互模型。97 项结构化问答指 62 道选择题与 35 道分析题；新增正文的 20 项练习/检验和 2 项研究扩展不重复计入测验。

- 原 16 章仅第 11.5、16.5 节各有一处白名单句段替换；其余字段逐项相等，覆盖题干、选项、答案、代码和动画步骤。原 73 条来源与 39 张图仍与冻结基线逐字段相等。
- 原 LaTeX mainmatter 经同两处明确句段替换后与合订保留区间逐字节相等，未发现其他变化；冻结输入的原始散列未变。
- 原四个 chapter JSON 与基线 course-data.json 的 39 处差异仅为小节标题删除重复编号，没有正文差异。
- 新六章全部 39 节正文按明确变换白名单处理后精确相等；5 个围栏代码块另行对比。
- 8 段既有制图工作说明一致过滤，25 张实际静态原理图各出现一次。
- HTML 内嵌 COURSE 与下载 JSON 相等；168 个来源、章/图引用和 LaTeX cite 均可解析；4 个本地来源 URL 与 dist 文件字节相等。

## 新增章节技术修正传播

| 修正 | 源文件 | JSON/HTML/MD/TeX | PDF 文本 |
| --- | --- | --- | --- |
| ADV-01 | True | True | True |
| ADV-02 | True | True | True |

ADV-01 补齐 Perfetto v58.2 的 300 次 stall 计数阈值、kStall 的 PERFETTO_FATAL 与 kStallThenDrop 无效 Chunk 边界；pf-arbiter 来源断言已同步。ADV-02 纠正三条权重 profile 的生成器说明：逻辑函数与调用栈没有写入 Location.Address 或 Mapping。原句及源码证据见相邻 review-2026-10-05-advanced.json/.md。

## 当前产物与别名

| 主文件 / principles 别名 | 字节相等 | SHA-256 |
| --- | --- | --- |
| golang-profiling.md / principles.md | True | 4c1e3f4ebaab45ad9b1b29613f35484469ec0440f4a672938ecece5c8136cf23 |
| golang-profiling.tex / principles.tex | True | 288fbffd0e20dc3cf5080dd5a241f6010fede14052d416565c80b67bbea272ff |
| golang-profiling.pdf / principles.pdf | True | e741e5dc96ccdaba3f0f7defdb28300e81e820e44edd8fa1569c24bfea95b8f9 |

pdfinfo 独立读取当前 PDF 为 231 页，PDF 与 TeX 的摘要均匹配最新 merged-pdf.json。本轮未再编译，只核对文件、文本和记录。

当前 HTML SHA-256：e79df5e1e91e6c5af3d300137f39c7cc6c3fa3d30e4cb264841746110f91251a。

当前 course-data.json SHA-256：31202d834caef3ba5696dc154a241bda13e1a9a4e8df24c2c953a5fb688adadd。

网站主下载名仍为 golang-profiling-complete.zip、golang-profiling.pdf、golang-profiling.tex。ZIP 内容和 HTTP/浏览器验收由父任务负责，本报告不认证包快照。

## 33 项检查

| 检查 | 结果 |
| --- | --- |
| original_16_chapter_objects_match_documented_errata | 通过 |
| original_73_source_objects_equal | 通过 |
| original_39_visual_objects_equal | 通过 |
| original_tex_technical_body_matches_documented_errata | 通过 |
| original_research_window_unchanged | 通过 |
| merged_chapter_ids_01_to_22 | 通过 |
| source_ids_unique_168 | 通过 |
| advanced_fragment_sources_match_source_manifests | 通过 |
| new_source_original_fields_preserved | 通过 |
| base_content_file_differences_are_only_heading_prefix_normalization | 通过 |
| new_six_chapter_bodies_preserved | 通过 |
| new_fenced_code_blocks_preserved | 通过 |
| figure_production_notes_absent_from_cleaned_body_and_html | 通过 |
| all_declared_chapter_and_visual_source_refs_resolve | 通过 |
| html_embedded_course_matches_course_json | 通过 |
| merged_tex_has_22_numbered_chapters | 通过 |
| merged_tex_has_168_unique_bibitems | 通过 |
| merged_tex_citations_resolve | 通过 |
| old_and_new_figure_ids_do_not_collide | 通过 |
| advanced_declared_figures_rendered_once | 通过 |
| old_third_fifth_chapter_refs_absent_from_advanced_payload | 通过 |
| standalone_topic_positioning_absent_from_merged_payload | 通过 |
| last_chapter_research_wording_absent_from_merged_preface | 通过 |
| no_source_id_collision_between_parts | 通过 |
| canonical_markdown_has_22_ordered_chapters | 通过 |
| canonical_markdown_contains_all_section_bodies | 通过 |
| canonical_markdown_relocations_current | 通过 |
| md_compatibility_alias_byte_identical | 通过 |
| tex_compatibility_alias_byte_identical | 通过 |
| pdf_compatibility_alias_byte_identical | 通过 |
| pdf_matches_completed_231_page_compilation_record | 通过 |
| site_downloads_use_merged_canonical_names | 通过 |
| all_local_source_urls_resolve_to_matching_dist_files | 通过 |

## 原课程两条明确勘误

冻结 base-course 没有修改；不再断言原 16 章全文逐字相同。独立递归比较仅发现以下两个 section.body 值不同，且每个差异严格等于清单指定的单次替换；合订原 mainmatter 也严格等于同两次替换后的结果。

| 位置 | 修改前 | 修改后 |
| --- | --- | --- |
| 11.5 | Go 1.25 编译器明确接受并忽略空文件、无样本或有效权重为零的 profile | Go 1.25 编译器接受并忽略空文件或无样本的 profile |
| 16.5 | 快照可能同时涵盖多个请求、异步后台工作和继承的采样标签；应按第 08 章的方法重建时间线，辨认与异常有关的活动。 | 快照可能同时涵盖多个请求和异步后台工作；请求关联需结合显式的 trace task/region/log 注解，不能假定 pprof 标签会自动成为 trace 注解。应按第 08 章的方法重建时间线，辨认与异常有关的活动。 |

两条清单均已核对 JSON、Markdown、TeX 与 PDF 提取文本，旧句消失、新句存在。content/errata.json 与 scripts/course_errata.py 摘要已记入输入清单。原章节对象 raw equality=false、原 mainmatter raw equality=false 被如实记录，33 项验收中的两项已更名为 matches_documented_errata。

## 引用、日期与验证边界

新增旧专题第三/第五章引用已重定位为第 19/21 章，独立专题定位已调整。原课程 44 处显式章号引用保留；原前沿检索窗口仍为 2021-10-02 — 2026-10-02。新增源码与实验验证日期为 2026-10-04，本轮合订审阅日期为 2026-10-05，没有重新检索前沿文献。

同名 JSON 保留完整输入摘要、逐节保真结果、8 段过滤清单、44 处原引用和 39 处标题规范化记录。对象摘要使用注明的规范 JSON 序列化，文件摘要直接使用原字节。

本审计不代替真实性能实验、特权 BPF、浏览器交互、HTTP、ZIP 内容或 PDF 视觉验收。教材再变更时应刷新本报告。
