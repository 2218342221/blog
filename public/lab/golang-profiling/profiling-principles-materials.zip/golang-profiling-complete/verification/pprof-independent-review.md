# pprof 章节独立源码与数值复核

复核日期：2026-10-04。对象为 `research/pprof.md`、`research/sources-pprof.json`、`research/pprof/figures.json` 和配套证据。源码边界：Go 1.25.0；google/pprof `ebaad5f31b4d25e6f51abf4d91b9611cff92db7b`。审读没有修改这些由原作者维护的文件。

结论：CPU 周期权重、heap 包含概率与缩放、block/mutex 计量、flat/cum、内联/递归、过滤分母和六组差分数值均得到支持。发布前建议补充以下两处实现边界；第二处已经用未经修改的固定版本源码包实际复现，不是只按注释推断。

## 发现一：goroutine profile 的并发采栈描述需要限定 debug 入口

**优先级 P2；正文第 4 节，原第 75 行。** 当前文字描述两次短暂停顿与并发协调采集，然后说不能认为“整个遍历始终停世界”。这适用于 `debug=0/1` 的 goroutine profile，但容易被读者推广到常用的 `/debug/pprof/goroutine?debug=2`。

实际 Go 1.25 源码：

- `research/pprof/go1.25.0/src/runtime/pprof/pprof.go:743–769`：`debug>=2` 直接走 `writeGoroutineStacks`，反复调用 `runtime.Stack(buf,true)`；buffer 从 1 MiB 倍增，达到 64 MiB 后允许截断。
- `research/pprof/go1.25.0/src/runtime/mprof.go:1248–1259`：普通 profile 进入 `goroutineProfileWithLabelsConcurrent`。
- 同文件 `1630–1661`：`Stack(...,true)` 在 `stopTheWorld(stwAllGoroutinesStack)` 与 `startTheWorld` 之间格式化当前及其他 goroutine 的 traceback。

建议将本段开头限定为“Go 1.25 的普通 goroutine profile（debug=0/1）”。并补：

> `debug=2` 的文本栈转储走另一条路径：它调用 `runtime.Stack(buf,true)`，在全量 traceback 格式化期间暂停世界；缓冲区不足时可能重新采集。因此两类输出的开销与采集时点不能混为一谈。

来源台账应为相应条目补充上述两个未列入原 read_ranges 的区间。此发现不推翻现有普通 profile 的状态机解释，也没有测量具体暂停时长。

## 发现二：固定版本 ScaleN 的混合比例边界不止是取整误差

**优先级 P2；正文第 6 节，原第 113 行；可作为实现局限脚注。** 文中将 Normalize 解释为逐维乘 `B_j/S_j`，并注明 ScaleN 取整。理想数学操作成立，但固定源码的 `ScaleN` 在比例有的等于 1、有的不等于 1 时存在额外行为：`keepSample` 仅在 `ratios[i]!=1` 的分支更新，完全未计入保持原值的列。

证据：`research/pprof/google-pprof/profile/profile.go:808–824`。对样本 `[2,0]` 调用 `ScaleN([1,0.5])`，逐维数学结果应仍为 `[2,0]`；实际该 Sample 被删除，因为第二列缩放后为零、第一列从未令 `keepSample` 为真。

本次独立复现直接复制固定源码 `profile` 包的非测试 Go 文件，未改动源码，用隔离 go.mod 和本机 Go 1.22.12 编译执行真实 `Profile.ScaleN`，结果如下：

```json
{"input":[2,0],"ratios":[1,0.5],"expected_nonzero_sample":[2,0],"actual_sample_count":0,"actual_samples":[]}
```

证据保存在：

- `verification/pprof-review-repro/main.go`：实际调用入口。
- `verification/pprof-review-repro/source-manifest.json`：复制来源与 SHA-256。
- `verification/pprof-review-repro/result.json`：真实输出。

建议说明“逐维缩放式是期望操作；固定版本在混合缩放率、部分列为零时有删样本边界，不能一概将所有差异归因于取整”。本章 CPU 教学记录的 count 与 CPU 权重同尺度缩放，不受此反例影响；无需改动现有 960→480 ms 归一化示例。

验证范围也应精准更新：主教学 CLI 查询仍使用 Go 1.22.12 内置 pprof，未构建最新完整 CLI；但本次确实编译执行了固定 google/pprof 的 profile 子包。因此原“未编译执行所读 google/pprof 提交”可改为“教学 CLI 未使用该提交构建；独立边界验证仅编译执行该提交的 profile 子包”。不要把这个局部验证写成最新 CLI 全部功能已运行。

## 已通过的关键核对

| 项目 | 源码或重算结果 |
|---|---|
| CPU 周期 | 100 Hz 对应 10,000,000 ns；count×period 的向量和 480/400=1.2 一致 |
| Linux CPU 时钟 | `CLOCK_THREAD_CPUTIME_ID`、随机首次间隔、定时器失败回退和 `validSIGPROF` 来源选择均有源码支持 |
| 有界日志 | `2^17` 个 64 位字为 1 MiB，64 栈槽和约 1900 条容量估计一致；signalLock 与 profBuf 无锁边界区分正确 |
| Heap | R=524288，s=65536 时 q=0.1175030974154、1/q=8.510413955；s=524288 时 q=0.6321205588286、1/q=1.581976707 |
| Heap 输出 | `scaleHeapSample` 按 avgSize 校正、最后截断到 int64；四维输出顺序与文中一致 |
| Block | 短事件 count 加 r/d、cycles 加 r，长事件计真实量；文章已明确“理想包含概率” |
| Mutex 图 | 源码近似 `10+(10+4)/2×2=24 ms`，逐等待者示意真和 `10+8+4=22 ms`，图中两者有意区分且正确 |
| 窗口 | `blockevent` 在结束路径发布，不能当作所有等待区间与墙钟窗口的精确交集 |
| 普通图 | seenNode/seenEdge、递归去重、根到叶处理与叶节点 flat 符合 `newGraph`；调用树另有路径上下文 |
| 聚合 | Aggregate 丢弃内联时保留最后一条外层 Line；Merge 重建本地 ID 映射，不能按整数 ID 直接跨文件认同 |
| 过滤分母 | 默认先建 Report 后 focus；relative 模式先 focus；80/480=16.67%、80/320=25% |
| 差分 | diff_base 标签、归一化当前源、基线乘负一再合并的顺序一致；computeTotal 的绝对值与 diff 基线分母说明正确 |
| 教学算术 | 48 条、A=320 ms、B=160 ms、HashRound=180 ms、Encode cum=140 ms；差值净和 0、绝对和 200 ms，函数级抵消均一致 |

独立重算的 14 项算术断言全部通过，保存在 `verification/pprof-review-repro/arithmetic.json`。原教学证据确有 15 个工具查询、14 项通过断言；本次只核验已有原始记录，没有无理由重复执行这些已通过的 CLI 查询。

## 可选的精度补充

`blocksampled`（Go mprof.go:519–524）使用离散随机数和 `> cycles` 判断。忽略取模偏差时，短事件实际通过概率更接近 `(cycles+1)/rate`，不是严格的连续 `cycles/rate`；纳秒到 tick 的转换也有量化。正文已经称之为“理想包含概率”，所以不是阻断性问题。若希望进一步对齐研究生教材标准，可在脚注补一句离散边界与取模近似，不需要修改主要推导。

尚未验证真实 CPU 信号压力、heap 随机采样收敛、生产服务开销、真实 ELF 符号化或最新完整 CLI。这些边界在原章中已有明确说明，应继续保留。
