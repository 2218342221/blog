# 原基础章节 01–14 技术与语言审校

审校日期：2026-10-05。审校者：`/root/tool_chapters/alias_verify`。范围为原始章节编号 01–14，采用逐项内容审读、官方源码核对与独立数值复算。

结论：14 章的 89 节、48 道测验、28 道分析练习和 14 个实验均已审读，没有发现错误的测验答案或计算结果。发现 1 处 PGO 接受范围过宽的技术表述，以及 8 处可选语言统一。主代理已报告通过勘误修正 PGO 表述并完成 PDF 编译；本报告保留原始快照证据，不声称再次验证修订版。

完整逐节断言、题目/答案、JSON Pointer、原文件行号以及源码摘录见同目录 [JSON 审校记录](review-2026-10-05-core.json)。

## 覆盖范围

| 原章号 | 标题 | 正文节 | 测验 | 分析练习 | 实验 | 结果 |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| 01 | 性能剖析的科学方法 | 6 | 3 | 2 | 1 | 未发现技术问题 |
| 02 | Go 运行时与系统模型 | 6 | 3 | 2 | 1 | 未发现技术问题 |
| 03 | 基准测试与实验设计 | 6 | 3 | 2 | 1 | 未发现技术问题 |
| 04 | pprof 的数据模型与读图方法 | 6 | 3 | 2 | 1 | 未发现技术问题 |
| 05 | CPU 剖析 | 6 | 4 | 2 | 1 | 未发现技术问题 |
| 06 | 内存、分配与垃圾回收 | 6 | 4 | 2 | 1 | 未发现技术问题 |
| 07 | 并发、阻塞与锁竞争 | 6 | 4 | 2 | 1 | 未发现技术问题 |
| 08 | 执行追踪与时序分析 | 7 | 4 | 2 | 1 | 未发现技术问题 |
| 09 | Delve、崩溃与现场调试 | 6 | 4 | 2 | 1 | 未发现技术问题 |
| 10 | 运行时诊断与操作系统工具 | 8 | 4 | 2 | 1 | 未发现技术问题 |
| 11 | 优化决策与 PGO | 6 | 3 | 2 | 1 | 见 T01；其余未发现技术问题 |
| 12 | 生产环境持续剖析 | 6 | 3 | 2 | 1 | 未发现技术问题 |
| 13 | 综合案例与证据链 | 6 | 3 | 2 | 1 | 未发现技术问题 |
| 14 | 实验课程与研究项目 | 8 | 3 | 2 | 1 | 未发现技术问题 |

所有章节的学习目标、先修要求、正文、选项与答案解释、练习参考答案及实验步骤均已阅读。JSON 为每节保留独立检查断言及其证据 ID，并分别标记所有测验、练习和实验的审阅状态。

## T01：PGO 对零权重 profile 的接受范围

- 优先级：P2；置信度：高。
- 位置：原第 11 章第 5 节，`/chapters/10/sections/4/body`，快照第 1153 行。
- 原句：“Go 1.25 编译器明确接受并忽略空文件、无样本或有效权重为零的 profile；构建信息记录 -pgo 路径也不证明有优化发生。”
- 建议：“Go 1.25 编译器会接受并忽略空文件或无样本的 profile；构建信息记录 -pgo 路径也不证明有优化发生。”

Go 1.25.0 的 `FromPProf` 对空文件和无 Sample 的 profile 提前接受；但非空、选定权重全为零的 profile 并不保证被忽略。一个含 `samples/count`、有效函数起始行、单个 `Value=[0]` 样本的输入，会经过以下控制流：

1. `internal/profile` 的解码和 `postDecode` 保留该样本，`len(p.Sample)` 仍为 1。
2. `NewGraph` 跳过零权重样本，随后删除 flat/cum 均为零的节点，形成空图。
3. `createNamedEdgeMap` 在空图上保持 `seenStartLine=false`，返回 `profile missing Function.start_line data`。
4. 错误在 `totalWeight==0` 忽略分支之前返回。

证据为固定版本的源码控制流，没有执行新的 Go 输入构造或编译复现。删除“或有效权重为零”即可保留本节要点。测验中“也可能被接受”的存在性表述不构成同样的泛化问题。

官方证据：

- [Go 1.25 PGO FromPProf](https://github.com/golang/go/blob/go1.25.0/src/cmd/internal/pgo/pprof.go#L19)：19–60、73–103 行。
- [profile 图构建](https://github.com/golang/go/blob/go1.25.0/src/internal/profile/graph.go#L241)：241–255、304–324 行。
- [profile 解析](https://github.com/golang/go/blob/go1.25.0/src/internal/profile/profile.go#L122)：122–172、183–196 行。
- [profile 解码](https://github.com/golang/go/blob/go1.25.0/src/internal/profile/encode.go#L137)：137–151、209–295、318–334 行。

## 关键核验

- 运行时：G/M/P、Go 1.25 容器感知 GOMAXPROCS、兼容默认值、GC 软限制口径、runtime/metrics 的 CPU 容量与 histogram 存储复用。
- pprof：CPU 100 Hz、停止时写入完成、四种 heap sample type、字节抽样及逆概率校正、GC 可见性、block/mutex 缩放及释放栈归因、Go 1.22 mutex 语义变化。
- 分析工具：flat/cum 与递归去重、过滤作用对象、默认/相对百分比分母、base/diff_base/normalize、差分火焰图的宽度和净变化区别。
- 标签和替代采集器：CPU/goroutine 的原生 labels 支持、既有 worker 的标签安装边界；fgprof v0.9.5 的全 goroutine wall-clock 采样、输出字段及其与 CPU PGO 的语义差异。
- Trace：task/region/log 生命周期、四类导出 profile；Go 1.25 FlightRecorder 与普通 trace 可并存、MinAge/MaxBytes 提示性质及 WriteTo 并发边界。
- 调试和系统工具：Delve v1.25.2 的构建/版本/DWARF 条件、断点和上下文命令、core 匹配、SetCrashOutput；perf unwind 模式和 strace CPU/墙钟口径。
- 实验：基准 B.N/B.Loop/ResetTimer/RunParallel 语义；第 14 章内嵌 `main.go` 和 `main_test.go` 与当前实验文件在仅去除两端空白后完全一致。

独立复算覆盖 Amdahl、Little 定律、单位请求 CPU、采样标准误与样本量、内存增量、等待并发、重叠关键路径、持续剖析存储预算、flight recorder 容量模型和 PGO 工作负载权重。代表结果为：样本量 3458；0.8 GiB/200000≈4295 B/请求；12 MiB/s×15 s=180 MiB；32 MiB 在恒定速率模型中约 2.67 s；A/B CPU 权重约 31.03%/68.97%。

## 可选语言统一

| ID | 原章/位置 | 原文 | 建议 |
| --- | --- | --- | --- |
| L01 | 11 / /chapters/10/sections/0/body | `sync.Pool`可以 | `sync.Pool` 可以 |
| L02 | 12 / /chapters/11/sections/1/body | Go 原生`runtime/pprof`在 | Go 原生 `runtime/pprof` 在 |
| L03 | 13 / /chapters/12/sections/1/body | `gc=1`会 | `gc=1` 会 |
| L04 | 13 / /chapters/12/sections/2/body | lab 的/lock | lab 的 /lock |
| L05 | 13 / /chapters/12/sections/3/body | 对比/cpu 和/wait | 对比 /cpu 和 /wait |
| L06 | 14 / /chapters/13/sections/1/body | `list`输出 | `list` 输出 |
| L07 | 14 / /chapters/13/sections/2/body | 上述`-o`参数 | 上述 `-o` 参数 |
| L08 | 14 / /chapters/13/quiz/1/question | 自动烟测可以替代长期性能统计吗？ | 自动冒烟测试可以替代长期性能统计吗？ |

以上均为 P3，不改变技术结论；JSON 中保留快照行号和修改理由。

## 证据和限制

审阅输入：`/data00/home/xiaoxing.sn/go/src/code.byted.org/xiaoxing.sn/codex-app-workspace/2026-10-04-3/base-course/course-data.json`。

输入 SHA-256：`de9789974356fb0afda775166ba791ef2ccad9fc72441f9ccfea118b2f3b9868`。

记录包含 26 项本地快照证据、29 项官方远端源码证据及独立推理/计算记录；源码均保留位置、SHA-256 和实际摘录。

- 本报告只描述 input_snapshot 所列 SHA-256 的原始章节 01–14；不代表主代理随后修订版本已重新逐字审阅。
- 本轮未运行性能基准、CPU/heap/block/mutex 采集、trace producer、FlightRecorder、Delve、perf/strace 或 PGO 构建复现；源码核对不能替代实际环境验证。
- 未执行教材/网站构建、浏览器交互测试或博客发布；这些由主代理另行处理。
- 源码行为以所列固定版本/缓存的精确 SHA-256 为准；不外推其他 Go、Delve、内核或采集器版本。
- 未审查其他章节；第 15–16 和新增工具章节由其他审校者覆盖。

