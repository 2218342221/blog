module review.local/pprof

go 1.22
