package main
import (
 "encoding/json"
 "os"
 "review.local/pprof/profile"
)
func main() {
 p := &profile.Profile{SampleType:[]*profile.ValueType{{Type:"samples",Unit:"count"},{Type:"cpu",Unit:"nanoseconds"}}, Sample:[]*profile.Sample{{Value:[]int64{2,0}}}}
 err := p.ScaleN([]float64{1,0.5})
 if err != nil {panic(err)}
 result := map[string]interface{}{"method":"ScaleN", "input":[]int64{2,0}, "ratios":[]float64{1,0.5}, "expected_nonzero_sample":[]int64{2,0}, "actual_sample_count":len(p.Sample), "actual_samples":p.Sample, "source":"google/pprof ebaad5f31b4d25e6f51abf4d91b9611cff92db7b profile package copied without changes", "client":"Go 1.22.12; isolated go.mod"}
 json.NewEncoder(os.Stdout).Encode(result)
}
