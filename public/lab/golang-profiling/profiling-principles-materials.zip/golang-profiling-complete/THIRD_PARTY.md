# 上游来源

材料包包含 sources.json 所引用的固定版本源文件，内容及原版权头保持不变。许可适用于相应上游文件；教学正文和图解不构成上游项目的官方文档或支持承诺。

- Linux v6.12：`research/licenses/linux-COPYING`、`linux-GPL-2.0`；各文件的 SPDX 声明进一步界定其许可。
- libbpf v1.5.0：`research/licenses/libbpf-LICENSE`、`libbpf-BSD-2-Clause`、`libbpf-LGPL-2.1`，按各文件声明适用。
- Go 1.25.0：`research/licenses/go-LICENSE`。
- google/pprof ebaad5f31b4d25e6f51abf4d91b9611cff92db7b：`research/pprof/google-pprof/LICENSE`。
- Perfetto v58.2：`research/licenses/perfetto-LICENSE`；保留各源文件头部的详细声明。
- 原教材的 Pyroscope v1.14.0 函数复现：`research/validation/pyroscope-delta-repro/UPSTREAM-LICENSE` 与 `UPSTREAM-LICENSING.md`；复制的 `pkg/phlaredb` 源码适用上游默认 AGPL-3.0-only，详细范围见同目录 README 和 provenance.json。

源码的不可变 HTTPS 地址、读取区间及 SHA-256 在 `dist/sources.json`；许可下载来源在 `research/licenses/manifest.json`。浏览器、Go 工具链、Perfetto 二进制与构建缓存不随材料包分发。
