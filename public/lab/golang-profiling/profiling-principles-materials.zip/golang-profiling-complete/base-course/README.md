# GoLab：Go 程序剖析与诊断 · 2.1 校订版

157 页中文 LaTeX/PDF 教材、离线 HTML 学习网站、39 张机制图与 160 个动画步骤，以及可执行 Go 实验和来源证据。

## 直接使用

- 双击 `index.html` 打开学习网站。绿色立体按钮、关卡路径与原创学习伙伴采用 Duolingo 风格；图解支持播放、暂停、单步和拖动，展开“深入阅读”可看完整正文。
- 打开 `golang-profiling.pdf` 阅读或打印；`golang-profiling.tex` 是独立源文件，图形内嵌为 TikZ，无外部图片、章节文件或 BibTeX 依赖。
- `lab/README.md` 提供实验说明。`verification/proofread-v3/PROOFREAD.md` 是本轮全文校订报告；`verification/REPORT.md` 说明验证范围。

网站无需服务器、CDN 或登录，包含全文搜索、56 道解析测验、错题复习、XP、进度导入导出和命令复制。动画默认暂停，支持减少动态效果设置。进度保存在当前浏览器；移动文件或切换浏览器前可导出备份。外部参考链接需要联网。

## 课程结构

|章节|内容|
|---|---|
|01—04|科学测量、Go 运行时、实验统计、pprof 数据模型与读图|
|05—10|CPU、内存与 GC、并发、trace、Delve、runtime/debug 及系统工具|
|11—14|PGO 与优化、持续剖析、综合诊断、实验与研究项目|
|15（倒数第二章）|成熟项目的采样、栈展开、pprof 归并、Pyroscope 存储与差分、Parca 查询、Delve 交叉验证|
|16（最后一章）|Scalene、硬件测量、ePPing 论文深读；PGO、trace/FlightRecorder、OTel Profiles 与研究设计|

共 16 章、103 个正文小节、56 道测验、35 道分析题、16 个实验、73 项来源记录，约 73,856 个汉字。工程语义基线为 Go 1.25.0，基础实验兼容 Go 1.22+，新增 API 另标版本。文献窗口为 2021-10-02 至 2026-10-02。固定版本用于复查，不代表最新补丁版本；官方发布、规范快照与论文分别标注。

## 本轮校订

逐项阅读全部 820 个章节自然语言字段，以及全部图解文字和 160 个步骤。修正 pprof 归一化对象、hide/ignore 语义、吞吐量与时间分母、sync.Pool 契约、前驱查找算例、聚合不可逆性等问题；统一中英文间距、累计量与增量的表达，并修复表格分隔行。

差异清单按字段列出原文和新文，共 255 个章节字段、210 个图解文字字段发生变化；字段数不等于错误数。具体原因与证据见各章校订记录。

最后两章保留固定源码与论文方法、评价和局限的深读。Pyroscope 多栈重置案例是 v1.14.0 原函数的隔离复现，不代表完整服务器部署。Scalene 原文泄漏概率公式的一致性疑问仍明确标为未决。

## 重建

`content/chapters-*.json`、`content/visuals.json` 与 `research/sources-*.json` 是统一内容源，`site-template.html` 是模板。在本目录运行：

```bash
python3 -m pip install -r requirements-build.txt
python3 scripts/build.py
```

此命令同步生成 HTML 与 LaTeX。直接编辑 `.tex` 后，再次运行 build 会覆盖手工编辑结果。历史章节初始化脚本不是重建入口。

LaTeX 可在内置编辑器编译；已有 XeLaTeX 环境可运行 `python3 scripts/export_pdf.py`。需要 ctexbook、Fandol、fvextra、TikZ 等常用 TeX Live 组件。内置编译器本轮调用未返回成功结果；源文件仍保留在原编辑器。交付 PDF 已由本机已有 XeLaTeX 两遍编译并验证。

实验验证入口：

```bash
python3 scripts/verify_lab.py
python3 scripts/check_examples.py
python3 scripts/run_examples.py
```

`verify_lab.py` 默认使用 Go 1.25.0，可通过 GOTOOLCHAIN 覆盖；`check_examples.py` 与 `run_examples.py` 固定使用 Go 1.25.0，以覆盖新增 API。工具链、缓存和产物保留在当前任务目录。实验服务绑定回环地址。本次最后验收另纠正题干的 MB/MiB 不一致及部分栈例子的失败帧位置，并准确说明脚本的工具链选择规则；详见最终核查报告。此次校订未修改 Go 源码。此前 hide/ignore 实测继续保留；最后验收另对解压后的 Go 实验执行了功能测试，并从压缩包独立重建和检查网站，详见 `verification/final-release-check/FINAL-CHECK.md`。

## 浏览器验收复现（可选）

```bash
npm install --prefix verification/browser --no-save playwright@1.63.0
PLAYWRIGHT_BROWSERS_PATH="$PWD/verification/browser-cache" node verification/browser/node_modules/playwright/cli.js install chromium
PLAYWRIGHT_BROWSERS_PATH="$PWD/verification/browser-cache" node verification/final-release-check/site-visual-test.cjs
```

本轮 15 组验收覆盖全部机制图与步骤、103 节正文、13 张表、引用和代码保真，以及 390/320 像素屏幕。最终核验的截图和结果在 `verification/final-release-check/`。`scripts/proofread_report.py` 用于内部对照校订前完整备份；为避免重复打包旧教材，该备份仅保留在工作目录，不放入学习包。构建与浏览器验收不依赖旧备份。

## 来源与分发

界面未使用 Duolingo 商标或官方吉祥物。第三方论文与完整仓库缓存不放入学习包，保留原始 URL、版本和阅读证据。Pyroscope 隔离复现中的原函数保留上游许可说明。历史验证结果仍标注原轮次；当前文件指纹见 `verification/final-summary.json`。
