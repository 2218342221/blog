# 第二版机制图数据契约

`content/visuals.json` 与章节JSON是统一内容源；`scripts/build.py`将其写入网站数据和独立LaTeX的TikZ图。当前39图、160步，全部教学数值明确注明，研究机制配一手来源。

```text
{
 id, chapter: "01", section: 0, title,
 type: flow|timeline|stack|heap|queue|pipeline|matrix|causal,
 caption, sourceRefs: [source IDs],
 nodes: [{id,label,detail,kind?,lane?,start?,end?}],
 edges: [{from,to,label}],
 steps: [{title,detail,active:[node IDs],
          states?:{nodeID:state}, values?:{nodeID:number},
          cursor?:number, activeEdges?:[edge indexes]}],
 snapshotStep?: index,
 snapshotSteps?: [before index,after index],
 unit?: string
}
```

`section`、边索引和快照索引均从0计数。`activeEdges`未给出时展示所有结构边；显式空数组表示本步没有边，不能回退全边。GMP每步仅显示当前真实资源/等待关系。`active`是高亮节点，不代表所有其他节点不存在。

状态区分：`queued`就绪/排队，`running`执行，`waiting`等待，`held`持有，`idle`空闲；`live`可达，`unreachable`失去引用但尚待GC，`freed`GC已回收，`disabled`此状态不纳入。回收不等同于向OS归还页面。heap图中只有kind=root/object构成对象图；账本计数器不能当作根。

stack图的values表示flat权重，缺失值为0；cum从真实父子边递归累计，不能因数组排列顺序画出不存在的调用关系。本组教学树无递归，不能替代pprof图聚合中的递归去重规则。timeline使用真实start/end/lane和同一时间坐标，单位必须标明。

网站将图放在相应小节正文之前；有图小节的完整推导默认折叠且仍能搜索。机制按播放/暂停/前后步/滑块呈现，默认暂停、离页停播、尊重减少动态效果偏好。LaTeX静态图使用同一数据及指定帧，不依赖外部图片。

若要重新生成图数据，`scripts/write_visuals.py`顺序调用基础定义及`amend_visuals_v2.py`的已审校修订；普通双端重建只运行`build.py`。改变图数据之后，应重新运行语义检查与浏览器验收，不能仅检查页面能打开。
