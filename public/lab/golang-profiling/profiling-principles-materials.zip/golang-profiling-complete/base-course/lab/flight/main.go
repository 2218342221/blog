//go:build go1.25

package main

import (
	"context"
	"os"
	"runtime/trace"
	"time"
)

func request() {
	ctx, task := trace.NewTask(context.Background(), "request")
	defer task.End()
	done := make(chan struct{})
	go func() {
		defer close(done)
		trace.WithRegion(ctx, "backend", func() {
			time.Sleep(40 * time.Millisecond)
			trace.Log(ctx, "backend", "completed")
		})
	}()
	trace.WithRegion(ctx, "wait-result", func() { <-done })
}

func main() {
	fr := trace.NewFlightRecorder(trace.FlightRecorderConfig{
		MinAge:   2 * time.Second,
		MaxBytes: 8 << 20,
	})
	if err := fr.Start(); err != nil {
		panic(err)
	}
	defer fr.Stop()
	for i := 0; i < 20; i++ {
		request()
	}
	f, err := os.Create("flight.trace")
	if err != nil {
		panic(err)
	}
	if _, err := fr.WriteTo(f); err != nil {
		f.Close()
		panic(err)
	}
	if err := f.Close(); err != nil {
		panic(err)
	}
}
