package main

import "testing"

var result string

func TestEncoders(t *testing.T) {
	for _, in := range [][]byte{nil, {}, []byte("hello"), {0, 1, 15, 16, 127, 128, 255}} {
		if a, b := encodeSlow(in), encodeFast(in); a != b {
			t.Fatalf("encode mismatch: %q != %q", a, b)
		}
	}
}
func BenchmarkEncodeSlow(b *testing.B) {
	input := []byte("profiling-with-go-0123456789abcdef")
	b.ReportAllocs()
	b.SetBytes(int64(len(input)))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		result = encodeSlow(input)
	}
}
func BenchmarkEncodeFast(b *testing.B) {
	input := []byte("profiling-with-go-0123456789abcdef")
	b.ReportAllocs()
	b.SetBytes(int64(len(input)))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		result = encodeFast(input)
	}
}
