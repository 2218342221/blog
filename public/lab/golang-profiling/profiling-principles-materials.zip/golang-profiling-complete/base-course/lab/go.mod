module example.com/golab

go 1.22
