// GoLab: bounded, local-only diagnostics laboratory. See README.md.
package main

import (
	"context"
	"encoding/hex"
	"flag"
	"fmt"
	"log"
	"net/http"
	"net/http/pprof"
	"runtime"
	rpprof "runtime/pprof"
	"runtime/trace"
	"strconv"
	"sync"
	"sync/atomic"
	"time"
)

var retained struct {
	sync.Mutex
	blobs [][]byte
}
var serial sync.Mutex

// This counts finished handlers, including canceled or rejected requests.
var finishedHandlers atomic.Uint64

func encodeSlow(src []byte) string {
	out := ""
	for _, b := range src {
		out += fmt.Sprintf("%02x", b)
	}
	return out
}
func encodeFast(src []byte) string { return hex.EncodeToString(src) }
func bounded(r *http.Request, key string, fallback, max int) int {
	v, err := strconv.Atoi(r.URL.Query().Get(key))
	if err != nil || v < 1 {
		return fallback
	}
	if v > max {
		return max
	}
	return v
}
func annotate(kind string, next func(context.Context, http.ResponseWriter, *http.Request)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		rpprof.Do(r.Context(), rpprof.Labels("workload", kind), func(ctx context.Context) {
			ctx, task := trace.NewTask(ctx, "request")
			defer task.End()
			trace.Log(ctx, "route", kind)
			region := trace.StartRegion(ctx, kind)
			defer region.End()
			next(ctx, w, r)
			finishedHandlers.Add(1)
		})
	}
}
func main() {
	appPort := flag.Int("app-port", 8080, "loopback application port")
	diagPort := flag.Int("diag-port", 6060, "loopback diagnostics port")
	flag.Parse()
	appAddr := fmt.Sprintf("127.0.0.1:%d", *appPort)
	diagAddr := fmt.Sprintf("127.0.0.1:%d", *diagPort)
	// Aggressive rates make short lab runs visible. Do not copy into production.
	runtime.SetBlockProfileRate(1)
	runtime.SetMutexProfileFraction(1)
	diagnostic := http.NewServeMux()
	diagnostic.HandleFunc("/debug/pprof/", pprof.Index)
	diagnostic.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	diagnostic.HandleFunc("/debug/pprof/profile", pprof.Profile)
	diagnostic.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
	diagnostic.HandleFunc("/debug/pprof/trace", pprof.Trace)
	go func() {
		log.Println("diagnostics http://" + diagAddr + "/debug/pprof/")
		log.Fatal(http.ListenAndServe(diagAddr, diagnostic))
	}()
	app := http.NewServeMux()
	app.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "ok finished_handlers=%d\n", finishedHandlers.Load())
	})
	app.HandleFunc("/cpu", annotate("cpu", func(ctx context.Context, w http.ResponseWriter, r *http.Request) {
		src := []byte("profiling-with-go-0123456789abcdef")
		iterations := bounded(r, "n", 1000, 100000)
		fast := r.URL.Query().Get("fast") == "1"
		var value string
		for i := 0; i < iterations; i++ {
			if i%256 == 0 {
				select {
				case <-ctx.Done():
					return
				default:
				}
			}
			if fast {
				value = encodeFast(src)
			} else {
				value = encodeSlow(src)
			}
		}
		fmt.Fprintln(w, value)
	}))
	app.HandleFunc("/alloc", annotate("alloc", func(ctx context.Context, w http.ResponseWriter, r *http.Request) {
		n := bounded(r, "n", 2000, 20000)
		size := bounded(r, "size", 512, 4096)
		// Retain the batch within this request so allocations cannot disappear.
		blobs := make([][]byte, n)
		for i := range blobs {
			blobs[i] = make([]byte, size)
			blobs[i][0] = byte(i)
		}
		fmt.Fprintf(w, "temporary=%d checksum=%d\n", n*size, blobs[n-1][0])
		runtime.KeepAlive(blobs)
	}))
	app.HandleFunc("/retain", annotate("retain", func(ctx context.Context, w http.ResponseWriter, r *http.Request) {
		retained.Lock()
		defer retained.Unlock()
		if len(retained.blobs) >= 64 {
			http.Error(w, "64 MiB lab cap reached; call POST /reset", http.StatusTooManyRequests)
			return
		}
		b := make([]byte, 1<<20)
		for i := 0; i < len(b); i += 4096 {
			b[i] = 1
		}
		retained.blobs = append(retained.blobs, b)
		fmt.Fprintf(w, "retained=%d MiB\n", len(retained.blobs))
	}))
	app.HandleFunc("/reset", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "POST required", http.StatusMethodNotAllowed)
			return
		}
		retained.Lock()
		retained.blobs = nil
		retained.Unlock()
		fmt.Fprintln(w, "references released; next GC determines reclamation")
	})
	app.HandleFunc("/wait", annotate("wait", func(ctx context.Context, w http.ResponseWriter, r *http.Request) {
		timer := time.NewTimer(time.Duration(bounded(r, "ms", 40, 500)) * time.Millisecond)
		defer timer.Stop()
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
			fmt.Fprintln(w, "waited")
		}
	}))
	app.HandleFunc("/lock", annotate("lock", func(ctx context.Context, w http.ResponseWriter, r *http.Request) {
		// Intentionally bad: hold a shared mutex while sleeping.
		serial.Lock()
		time.Sleep(time.Duration(bounded(r, "ms", 10, 100)) * time.Millisecond)
		serial.Unlock()
		fmt.Fprintln(w, "serialized")
	}))
	server := &http.Server{Addr: appAddr, Handler: app, ReadHeaderTimeout: 3 * time.Second}
	log.Println("application http://" + appAddr)
	log.Fatal(server.ListenAndServe())
}
