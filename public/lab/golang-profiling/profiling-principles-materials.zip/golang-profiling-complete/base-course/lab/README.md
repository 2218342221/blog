# GoLab 实验包

基础服务和基准要求 Go 1.22+，FlightRecorder 子目录要求 Go 1.25+。本次验证以 Go 1.25.0 linux/amd64 为主，基础测试也经 Go 1.22.12 验证。

```bash
go test ./...
go test -race ./...
go test -run='^$' -bench=BenchmarkEncode -benchmem -count=10
go run .
```

业务地址 `http://127.0.0.1:8080`，诊断地址 `http://127.0.0.1:6060/debug/pprof/`。默认端口被占用时使用 `go run . -app-port=18080 -diag-port=16060`。程序始终绑定回环地址。

|路径|用途|边界|
|---|---|---|
|`/cpu?n=1000&fast=0`|格式化与字符串拼接的 CPU 负载|n 最大为 100000|
|`/cpu?n=1000&fast=1`|标准库编码器对照|与慢实现输出相同|
|`/alloc?n=2000&size=512`|暂时分配|n 最大为 20000，size 最大为 4096|
|`/retain`|保留 1 MiB 对象|全局最多保留 64 MiB，达到上限后返回 HTTP 429|
|`POST /reset`|释放保留引用|对象回收及内存归还 OS 的时机仍由运行时决定|
|`/lock?ms=10`|锁内等待|ms 最大为 100|
|`/wait?ms=40`|定时器等待|ms 最大为 500|
|`/health`|服务健康状态与处理器结束次数|finished_handlers 包含取消与失败的处理器调用，不能作为成功请求数|

这是受控本地教学服务。block 和 mutex 使用高采样率；不要直接复用到生产环境。并发发压时自行控制请求总量。验证脚本会自动选择空闲端口，并只停止自己启动的服务。

Go 1.25+ 飞行记录器实验：

```bash
go run ./flight
go tool trace flight.trace
```

以上 Go 命令应在 lab 目录执行，运行产物也保存在该目录。也可以从上级目录运行 `python3 scripts/verify_lab.py`，把证据保存到 `verification/lab/`。教材第 14 章包含完整实验协议；自动构建与运行检查不能替代重复统计研究。
