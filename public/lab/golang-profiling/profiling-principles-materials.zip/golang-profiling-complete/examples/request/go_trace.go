// A genuine native Go execution trace for an import compatibility negative test.
package main

import (
	"os"
	"runtime/trace"
)

func main() {
	f, err := os.Create("examples/request/native-go.trace")
	if err != nil { panic(err) }
	defer f.Close()
	if err := trace.Start(f); err != nil { panic(err) }
	done := make(chan struct{})
	go func() { close(done) }()
	<-done
	trace.Stop()
}
