#!/usr/bin/env python3
"""Run real Trace Processor on a synthetic ftrace model; keep raw evidence."""
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
TP=Path(sys.argv[1]).absolute() if len(sys.argv)>1 else ROOT/'examples/perfetto/bin/linux-amd64/trace_processor_shell'
TRACE=ROOT/'examples/request/request.ftrace'
subprocess.run([sys.executable,str(TRACE.parent/'generate_trace.py')],check=True)
version=subprocess.check_output([str(TP),'--version'],text=True).strip()
assert 'v58.2-add693d8b' in version,version
queries={name:(TRACE.parent/f'{name}.sql').read_text() for name in ['state_totals','cpu_totals']}
queries['slices']='SELECT name,ts,dur FROM slice ORDER BY ts,name;'
queries['stats']="SELECT name,severity,value FROM stats WHERE value != 0 ORDER BY name;"
results={}
for name,sql in queries.items():
    r=subprocess.run([str(TP),'query',str(TRACE)],input=sql,text=True,capture_output=True)
    assert r.returncode==0,r.stderr
    rows=list(csv.DictReader(io.StringIO(r.stdout)))
    results[name]={'sql':sql,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'rows':rows}
states={r['state']:float(r['ms']) for r in results['state_totals']['rows']}
cpu={int(r['tid']):float(r['cpu_ms']) for r in results['cpu_totals']['rows']}
slices={r['name']:int(r['dur']) for r in results['slices']['rows']}
checks={'main_running_8ms':states['Running']==8,'main_runnable_2ms':states['R']==2,
        'main_sleep_10ms':states['S']==10,'main_cpu_8ms':cpu[101]==8,
        'worker_cpu_15ms':cpu[102]==15,'request_cpu_23ms':sum(cpu.values())==23,
        'request_wall_20ms':slices['request']==20000000,
        'join_wait_10ms':slices['join_wait']==10000000}
assert all(checks.values()),checks
record={'status':'passed','kind':'synthetic model processed by real official binary',
        'version':version,'sha256_ftrace':hashlib.sha256(TRACE.read_bytes()).hexdigest(),
        'checks':checks,'queries':results}
out=ROOT/'verification/request-perfetto.json'
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
(out.parent/'request-perfetto.txt').write_text(version+'\n\n'+'\n\n'.join(f'[{k}]\n'+v['stdout'] for k,v in results.items()))
print(json.dumps({'version':version,'checks':checks},ensure_ascii=False,indent=2))
