#!/usr/bin/env python3
"""Generate an explicitly synthetic, weighted request CPU profile.

This is not a CPU sampling experiment and does not model Go's 100 Hz producer.
There are exactly three Sample messages, containing CPU weights in nanoseconds.
Run with --verify to record actual local `go tool pprof` output and checks.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / 'verification'
FUNCTIONS = [
    'main.first_work', 'main.handle_request', 'worker.work',
    'worker.loop', 'main.finish_work',
]
SAMPLES = [
    {'location_ids': [1, 2], 'cpu_ns': 4_000_000, 'request': 'demo', 'execution': 'main'},
    {'location_ids': [3, 4], 'cpu_ns': 15_000_000, 'request': 'demo', 'execution': 'worker'},
    {'location_ids': [5, 2], 'cpu_ns': 4_000_000, 'request': 'demo', 'execution': 'main'},
]


def varint(value):
    result = bytearray()
    while value >= 128:
        result.append((value & 127) | 128)
        value >>= 7
    result.append(value)
    return bytes(result)


def integer(field, value):
    return varint(field << 3) + varint(value)


def blob(field, value):
    if isinstance(value, str):
        value = value.encode('utf-8')
    return varint((field << 3) | 2) + varint(len(value)) + value


def generate():
    comment = (
        'SYNTHETIC TEACHING DATA: three weighted CPU costs, not observed '
        'Go CPU samples. Request ownership is explicitly supplied by labels. '
        'No event timestamps, scheduler states, executable, or real source locations.'
    )
    strings = ['', 'cpu', 'nanoseconds', 'request', 'demo', 'execution',
               'main', 'worker', *FUNCTIONS, comment]
    index = {s: i for i, s in enumerate(strings)}
    profile = blob(1, integer(1, index['cpu']) + integer(2, index['nanoseconds']))
    for row in SAMPLES:
        sample = blob(1, b''.join(varint(i) for i in row['location_ids']))
        sample += blob(2, varint(row['cpu_ns']))
        for key in ['request', 'execution']:
            sample += blob(3, integer(1, index[key]) + integer(2, index[row[key]]))
        profile += blob(2, sample)
    for i, name in enumerate(FUNCTIONS, 1):
        # Address and Mapping intentionally omitted: these are logical teaching frames.
        profile += blob(4, integer(1, i) + blob(4, integer(1, i)))
        profile += blob(5, integer(1, i) + integer(2, index[name]) + integer(3, index[name]))
    for item in strings:
        profile += blob(6, item)
    profile += integer(10, 20_000_000)  # Synthetic request wall duration.
    # No period or count type: do not imply a measured sampling rate or event count.
    profile += integer(13, index[comment]) + integer(14, index['cpu'])
    data = gzip.compress(profile, mtime=0)
    path = HERE / 'request.pprof'
    path.write_bytes(data)
    return path, data


def verify(path, data):
    OUT.mkdir(parents=True, exist_ok=True)
    version = subprocess.run(['go', 'version'], text=True, capture_output=True, check=True).stdout.strip()
    common = ['go', 'tool', 'pprof', '-symbolize=none', '-nodecount=0',
              '-nodefraction=0', '-edgefraction=0']
    cases = []
    transcript = [f'Client: {version}', 'Input: synthetic weighted CPU profile; not runtime sampling.']
    for name, args in [('top', ['-top']), ('request-filter', ['-top', '-tagfocus=request=demo']),
                       ('raw', ['-raw'])]:
        argv = common + args + [str(path.relative_to(ROOT))]
        result = subprocess.run(argv, cwd=ROOT, text=True, capture_output=True)
        cases.append({'name': name, 'argv': argv, 'returncode': result.returncode,
                      'stdout': result.stdout, 'stderr': result.stderr})
        transcript.extend(['', f'CASE: {name}', '$ ' + ' '.join(argv),
                           'STDOUT:', result.stdout, 'STDERR:', result.stderr])
    top = cases[0]['stdout']
    nodes = {}
    for line in top.splitlines():
        match = re.match(r'^\s*([\d.]+)(ms)?\s+\S+%\s+\S+%\s+([\d.]+)(ms)?\s+\S+%\s+(\S+)\s*$', line)
        if match:
            nodes[match.group(5)] = {'flat_ms': float(match.group(1)), 'cum_ms': float(match.group(3))}
    raw = cases[2]['stdout']
    checks = {
        'all_queries_return_zero': all(c['returncode'] == 0 for c in cases),
        'client_is_go12212': version == 'go version go1.22.12 linux/amd64',
        'wall_20ms_cpu_23ms_115percent': bool(re.search(r'Duration: 20ms, Total samples = 23ms \(115.00%\)', top)),
        'three_flat_weights': all(nodes.get(k, {}).get('flat_ms') == v for k, v in {
            'main.first_work': 4, 'worker.work': 15, 'main.finish_work': 4}.items()),
        'main_cum_8ms_worker_cum_15ms': nodes.get('main.handle_request', {}).get('cum_ms') == 8 and nodes.get('worker.loop', {}).get('cum_ms') == 15,
        'request_filter_retains_all_weight': 'Showing nodes accounting for 23ms, 100% of 23ms total' in cases[1]['stdout'],
        'raw_contains_three_request_labels': len(re.findall(r'request:\[demo\]', raw)) == 3,
        'no_sampling_period_or_count_column': 'Period: 0' in raw and 'cpu/nanoseconds' in raw and 'samples/count' not in raw,
    }
    evidence = {
        'data_kind': 'synthetic weighted CPU costs, not runtime samples',
        'generator': str(Path(__file__).resolve().relative_to(ROOT)),
        'profile': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(data).hexdigest(),
        'sample_messages': 3, 'sample_types': [{'type': 'cpu', 'unit': 'nanoseconds'}],
        'duration_ns': 20_000_000, 'cpu_total_ns': 23_000_000,
        'samples': SAMPLES, 'client': version, 'observed_nodes': nodes,
        'cases': cases, 'checks': checks, 'all_passed': all(checks.values()),
        'limitations': [
            'No Go producer was run; no 100 Hz or other sampling process was validated.',
            'The request label is an explicit teaching premise, not inferred from a worker stack.',
            'CPU stacks do not encode the main thread Running/Runnable/Sleep intervals.',
            'No event ordering or timestamps can be recovered from these three weighted records.',
            'No binary symbolization or performance overhead measurement was performed.'
        ],
    }
    (OUT / 'request-pprof.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'request-pprof.txt').write_text('\n'.join(transcript) + '\n')
    print(json.dumps({'client': version, 'checks': checks, 'all_passed': evidence['all_passed']}, indent=2))
    if not evidence['all_passed']:
        raise SystemExit('Some checks failed; inspect verification/request-pprof.json')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', action='store_true', help='run and record local go tool pprof queries')
    args = parser.parse_args()
    profile_path, profile_data = generate()
    print(profile_path)
    if args.verify:
        verify(profile_path, profile_data)
