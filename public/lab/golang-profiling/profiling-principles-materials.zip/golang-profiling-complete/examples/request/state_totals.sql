-- Synthetic ftrace; known, completed states clipped to the request window.
WITH request_window AS (
  SELECT s.ts AS lo, s.ts+s.dur AS hi
  FROM slice s JOIN thread_track tt ON s.track_id=tt.id
  JOIN thread t ON tt.utid=t.utid
  WHERE s.name='request' AND t.tid=101 AND s.dur>=0
), clipped AS (
  SELECT t.tid, s.state,
         MIN(s.ts+s.dur,w.hi)-MAX(s.ts,w.lo) AS ns
  FROM thread_state s JOIN thread t USING(utid)
  CROSS JOIN request_window w
  WHERE t.tid=101 AND s.dur>=0
    AND s.ts<w.hi AND s.ts+s.dur>w.lo
)
SELECT tid,state,SUM(ns)/1e6 AS ms
FROM clipped GROUP BY tid,state ORDER BY state;
