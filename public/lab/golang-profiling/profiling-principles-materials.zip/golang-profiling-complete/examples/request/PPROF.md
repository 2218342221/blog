# 贯穿案例：同一请求的 23 ms CPU 与 20 ms 墙钟

本例是手工编码的教学 profile，**不是 Go 运行时的 CPU 采样结果**。它有三条加权 Sample，只含 `cpu/nanoseconds` 一列；没有样本计数列或采样周期。这样不把精确的 4/15/4 ms 教学权重冒充 Go 标准 100 Hz 采样所测出的三个区间。

| 栈，叶到根 | request 标签 | execution 标签 | CPU 权重 |
| --- | --- | --- | ---: |
| main.first_work → main.handle_request | demo | main | 4 ms |
| worker.work → worker.loop | demo | worker | 15 ms |
| main.finish_work → main.handle_request | demo | main | 4 ms |

三项均通过 `request=demo` 明确归属于同一请求。worker 的栈仍以 worker.loop 为调用者；没有凭空把主线程 的 handler 放进另一个线程 的物理调用栈。`execution` 是本例自定义的教学标签，不是 操作系统自动生成的线程 ID。

profile 的 `duration_nanos` 被设置为 20,000,000，三项权重合计 23,000,000 ns。本机 **Go 1.22.12** 的实际输出是：

```text
Duration: 20ms, Total samples = 23ms (115.00%)
      flat  flat%   sum%        cum   cum%
      15ms 65.22% 65.22%       15ms 65.22%  worker.work
       4ms 17.39% 82.61%        4ms 17.39%  main.finish_work
       4ms 17.39%   100%        4ms 17.39%  main.first_work
         0     0%   100%        8ms 34.78%  main.handle_request
         0     0%   100%       15ms 65.22%  worker.loop
```

`Total samples = 23ms` 中的 samples 是 pprof 报告用语，当前显示的是带单位 CPU 权重，不是 23 条 protobuf 消息。CPU / wall = 23/20 = 1.15，表示本教学窗口内累计占用 1.15 个核的容量尺度。三个 flat 百分比都以 23 ms CPU 为分母；worker 的 65.22% 不是请求延迟的 65.22%。

主线程 的状态分解是另外一套时序证据：Running 8 ms、Runnable 2 ms、Sleep 10 ms，合计 20 ms。pprof 中 main 的两项 CPU 权重相加为 8 ms，但 profile 不保存这三个状态区间，无法从三条栈记录重建工作先后、重叠或唤醒依赖。worker 的 15 ms 可以与 main 的状态区间重叠，不能把 `23+2+10` 当成请求耗时。具体时序与因果关系需要配套 ftrace/Perfetto 记录证明。本贯穿案例的状态按操作系统线程与内核 sched_switch 语义解释，不是 Go G 调度状态。

在任务根目录重放：

```sh
python3 examples/request/generate_pprof.py --verify
go tool pprof -symbolize=none -top examples/request/request.pprof
go tool pprof -symbolize=none -top -tagfocus=request=demo examples/request/request.pprof
```

生成器仅使用 Python 标准库。`verification/request-pprof.json` 保存客户端版本、文件 SHA-256、三条输入权重、真实命令、原始输出和 8 项通过的断言；`verification/request-pprof.txt` 是可直接阅读的完整终端记录。三次查询全部返回成功，标签过滤后仍保留全部 23 ms。

验证范围包括 profile 格式读取、数值求和、flat/cum 和标签筛选。未运行真实 CPU producer、线程调度实验或二进制符号化；20 ms duration 和跨 worker 的请求归属是显式输入前提。此案例与 `research/pprof/teaching/` 的递归、内联和归一化示例彼此独立。
