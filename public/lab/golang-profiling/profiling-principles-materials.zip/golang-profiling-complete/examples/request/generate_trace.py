#!/usr/bin/env python3
"""Generate synthetic ftrace input, NOT data captured from Linux or Go."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
lines = ['# tracer: nop', '# Synthetic scheduler scenario. Not a kernel capture.']

def event(ms, cpu, comm, tid, tgid, name, payload):
    lines.append(f'{comm:>16}-{tid:<5} ({tgid:>5}) [{cpu:03d}] .... {10 + ms / 1000:.6f}: {name}: {payload}')

def switch(ms, cpu, prev, prev_tid, prev_tgid, state, nxt, next_tid):
    event(ms, cpu, prev, prev_tid, prev_tgid, 'sched_switch',
          f'prev_comm={prev} prev_pid={prev_tid} prev_prio=120 prev_state={state} ==> next_comm={nxt} next_pid={next_tid} next_prio=120')

def mark(ms, cpu, comm, tid, payload):
    event(ms, cpu, comm, tid, 100, 'tracing_mark_write', payload)

switch(0, 0, 'swapper', 0, 0, 'R', 'main', 101)
mark(0, 0, 'main', 101, 'B|100|request')
mark(0, 0, 'main', 101, 'B|100|first_work')
switch(1, 1, 'swapper', 0, 0, 'R', 'worker', 102)
mark(1, 1, 'worker', 102, 'B|100|worker_work')
mark(4, 0, 'main', 101, 'E|100')
switch(4, 0, 'main', 101, 100, 'R', 'noise', 201)
switch(6, 0, 'noise', 201, 200, 'R', 'main', 101)
mark(6, 0, 'main', 101, 'B|100|join_wait')
switch(6, 0, 'main', 101, 100, 'S', 'noise', 201)
mark(16, 1, 'worker', 102, 'E|100')
event(16, 1, 'worker', 102, 100, 'sched_waking', 'comm=main pid=101 prio=120 target_cpu=000')
switch(16, 1, 'worker', 102, 100, 'S', 'swapper', 0)
switch(16, 0, 'noise', 201, 200, 'R', 'main', 101)
mark(16, 0, 'main', 101, 'E|100')
mark(16, 0, 'main', 101, 'B|100|finish_work')
mark(20, 0, 'main', 101, 'E|100')
mark(20, 0, 'main', 101, 'E|100')
switch(20, 0, 'main', 101, 100, 'S', 'swapper', 0)
# Advance the known trace end without extending the request.
event(21, 0, 'swapper', 0, 0, 'sched_waking', 'comm=noise pid=201 prio=120 target_cpu=000')
(ROOT / 'request.ftrace').write_text('\n'.join(lines) + '\n')
scenario = {
    'kind': 'synthetic teaching model; not a production measurement',
    'unit': 'ms', 'request_wall': 20,
    'attribution_assumption': 'main and worker CPU belong explicitly to request=demo; overlap alone is insufficient',
    'threads': {
        'main': {'tid': 101, 'states': [
            {'start': 0, 'end': 4, 'state': 'Running'},
            {'start': 4, 'end': 6, 'state': 'Runnable'},
            {'start': 6, 'end': 16, 'state': 'Sleeping'},
            {'start': 16, 'end': 20, 'state': 'Running'}]},
        'worker': {'tid': 102, 'states': [{'start': 1, 'end': 16, 'state': 'Running'}]}
    },
    'expected': {'main_cpu_ms': 8, 'worker_cpu_ms': 15, 'request_cpu_ms': 23,
                 'main_runnable_ms': 2, 'main_sleep_ms': 10}
}
(ROOT / 'scenario.json').write_text(json.dumps(scenario, ensure_ascii=False, indent=2) + '\n')
print('Generated request.ftrace and scenario.json')
