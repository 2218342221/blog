-- The selected tids are explicitly assigned to this request by the scenario.
-- In real traces, time overlap alone does not establish request attribution.
WITH request_window AS (
  SELECT s.ts AS lo, s.ts+s.dur AS hi
  FROM slice s JOIN thread_track tt ON s.track_id=tt.id
  JOIN thread t ON tt.utid=t.utid
  WHERE s.name='request' AND t.tid=101 AND s.dur>=0
), clipped AS (
  SELECT t.tid, MIN(s.ts+s.dur,w.hi)-MAX(s.ts,w.lo) AS ns
  FROM sched_slice s JOIN thread t USING(utid)
  CROSS JOIN request_window w
  WHERE t.tid IN (101,102) AND s.dur>=0
    AND s.ts<w.hi AND s.ts+s.dur>w.lo
)
SELECT tid,SUM(ns)/1e6 AS cpu_ms FROM clipped GROUP BY tid ORDER BY tid;
