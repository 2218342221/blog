# GoLab：Go 程序剖析与诊断 · 2.2 机制深研增订版

完整中文研究生课程：22 章、231 页 LaTeX/PDF、142 个正文小节，配套 Duolingo 风格的 HTML 学习网站。原第 01–16 章保留完整课程结构，并应用两条有据可查的句子勘误，其后追加第 17–22 章 eBPF、pprof 与 Perfetto 机制深研；统一目录、来源索引、学习进度与下载入口。

## 阅读与下载

- [学习网站](https://2218342221.github.io/blog/lab/golang-profiling/)：章节路径、分层阅读、全文搜索、解析测验、错题复习、XP、进度导入导出与命令复制。
- [PDF 在线阅读](https://2218342221.github.io/blog/lab/golang-profiling/pdf.html) · [231 页 PDF](https://2218342221.github.io/blog/lab/golang-profiling/golang-profiling.pdf) · [LaTeX 源码](https://2218342221.github.io/blog/lab/golang-profiling/golang-profiling.tex)。
- [完整材料包](https://2218342221.github.io/blog/lab/golang-profiling/golang-profiling-complete.zip)：文件名为 `golang-profiling-complete.zip`；当前交付与包验证记录以 [最终核对记录](verification/FINAL-VERIFICATION.md) 为准。
- 本地打开 `dist/index.html` 可离线学习；请保留整个 `dist/` 目录，以便访问 PDF、原图和本地来源文件。外部参考链接需要联网。

2026-10-05 再校订：压缩手机首页、新增小节跳转、全文展开和大字阅读，在实验室集中提供四组工具模型入口；核对全书技术断言，修正 PGO 空输入边界、FlightRecorder 请求注解、Perfetto 持续耗尽的失败边界和合成 profile 的地址说明。原章两条修正集中记录在 `content/errata.json`，冻结基础文件不改。详见 `verification/review-2026-10-05-*.md` 与 `course-polish-check.json`。

主产物为 `dist/golang-profiling.{md,tex,pdf}`、`dist/index.html` 和 `dist/course-data.json`。`dist/principles.{md,tex,pdf}` 是完整 22 章的兼容别名，与相应主文件逐字节相等。`dist/profiling-principles-materials.zip` 同样更新为完整材料包的兼容别名。

以上为博客发布地址。本地工作区阅读服务仍为 `http://10.37.76.39:8765/`。`scripts/serve_site.py` 只提供 `dist/`，支持 PDF 内联显示与字节范围请求；服务运行记录见 `verification/http-server.json`。也可按下文自行启动本地服务。

## 课程结构与学习顺序

| 章节 | 内容与目标 |
| --- | --- |
| 01–04 | 科学测量、Go 运行时、实验统计、pprof 数据模型与读图；先建立单位、分母、归因和误差意识。 |
| 05–10 | CPU、内存与 GC、并发、runtime trace、Delve、runtime/debug 及系统工具；掌握实际诊断路径。 |
| 11–14 | PGO 与优化、持续剖析、综合诊断、实验与研究项目；把测量转为可反驳的优化结论。 |
| 15 | 成熟开源项目：采样、栈展开、pprof 归并、Pyroscope 存储与差分、Parca 查询、Delve 交叉验证。 |
| 16 | 原课程的近五年前沿研究：论文方法与评价、PGO、trace/FlightRecorder、OTel Profiles 与研究设计。 |
| 17–20 | 追加机制深研：测量模型、eBPF 加载/验证/执行、pprof producer/聚合/报告、Perfetto 记录协议与时序查询。 |
| 21–22 | 同一请求的跨工具实验、兼容性负例、组合诊断和研究练习。 |

初学者按章学习；有诊断经验的读者可在复习第 01–04、08、10、15 章后进入第 17–22 章。第 15、16 章保留原主课程的项目研究和前沿章节定位；本增订版在其后追加工具深研。

全书有 64 张图：39 张原课程可播放机制图（160 个步骤）和 25 张新增静态原理图；另有 4 项新增交互模型。62 道交互选择题与 35 道原课程分析题共计 97 项结构化问答，不能把它们都计作交互选择题。原课程 16 个实验完整保留；新增正文另含 20 项练习/检验和 2 项研究扩展，未重复计入测验数量。

## 日期、版本与证据边界

| 范围 | 日期或版本 |
| --- | --- |
| 原第 16 章研究检索窗口 | 2021-10-02 — 2026-10-02 |
| 新增机制材料的源码与实验查证 | 2026-10-04 |
| 合订增订版 | 2026-10-05，版本 2.2 |
| 主要源码基线 | Go 1.25.0、Linux v6.12、libbpf v1.5.0、Perfetto v58.2 |
| google/pprof 源码 | `ebaad5f31b4d25e6f51abf4d91b9611cff92db7b` |
| 专题阶段教学工具实测 | Go 1.22.12 内置 pprof、官方 Perfetto v58.2；固定 pprof 另编译了反例所需的 `profile` 子包。 |

来源总计 168 项：原课程 73 项和追加材料 95 项。固定提交、阅读区间、源码摘要与断言边界见 `dist/sources.json`。原研究窗口未因增订日期而延长，也未把源码更新记录当成新的前沿论文检索。

本轮合并验证检查了内容保真、来源引用、真实浏览器交互、PDF 编译与在线阅读；原 16 个 Go 实验本轮未重跑。新增章节沿用专题阶段已执行的真实工具实验，其输入为合成教学模型，验证解析、聚合和计算语义；不代表生产负载采样。未进行 eBPF 特权内核加载。详细结果和未覆盖范围见 [最终核对记录](verification/FINAL-VERIFICATION.md)。

## 包内输入与当前构建入口

- `base-course/course-data.json` 与 `base-course/golang-profiling.tex` 是原 16 章的冻结基础输入。`content/errata.json` 对这份快照应用两条明确的句子修正。当前完整合订本可仅凭包内这些输入与追加材料独立重建，不需要原任务目录。
- `content/01-model.md`、`research/{ebpf,pprof,perfetto}.md`、`content/05-experiment.md` 和 `content/06-method.md` 是新增六章正文；合并时只做章号重定位、导论定位和既有渲染清理。
- `research/sources-*.json` 记录追加来源；`scripts/figures.py` 生成新增 25 组 SVG/TikZ 及图清单。
- `scripts/build_book.py` 是当前统一构建入口，负责新增交互资源、课程数据、合并 LaTeX、按需编译 PDF、网站和兼容别名。

`base-course/README.md` 与其 `requirements-build.txt` 是原版归档说明，不是当前构建入口。当前包不承诺通过原版脚本从归档的章节 JSON 重新生成原版基础输入；直接修改 `base-course/content/` 不会自动更新冻结的 `course-data.json` 或 TeX。当前增订渲染器使用根目录 `requirements.txt`，不要混用归档依赖。

## 重建文档与网站

需要 Python 3、Node.js、XeLaTeX 和 Poppler 命令行工具。Node 用于读取 JavaScript 中的测验数据，无需安装 npm 包。PDF 构建会调用 `pdfinfo`、`pdffonts` 和 `pdftotext`；XeLaTeX 环境需包含 ctex/Fandol、DejaVu 字体以及 TikZ、fvextra、xurl、needspace、capt-of 等模板组件。

根目录 `requirements.txt` 固定 Python 依赖：Mistune 3.1.3、latex2mathml 3.78.1 和 Playwright 1.55.0。在材料根目录执行：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/figures.py
.venv/bin/python scripts/build_book.py --compile-pdf
```

`--compile-pdf` 强制重新编译 PDF。省略该参数时，构建器在 TeX 改变、PDF 缺失或 PDF 摘要与编译记录不符时自动编译；否则复用已经验证的 PDF。编译会检查引用收敛、字体嵌入、缺字与版面溢出，并写入 `verification/merged-pdf.json`。`build_book.py` 自动生成交互资源，但不自动运行 `figures.py`；修改图模型后需要先重建图。

HTML、Markdown 与合并 TeX 都是生成产物；直接修改后再次构建会被覆盖。

## 启动服务与浏览器验收

安装 Chromium，并在安装和运行时使用相同的缓存路径：

```bash
PLAYWRIGHT_BROWSERS_PATH="$PWD/.browsers" .venv/bin/python -m playwright install chromium
.venv/bin/python scripts/serve_site.py --bind 127.0.0.1 --port 8765
```

保持服务运行，在第二个终端、同一材料根目录执行：

```bash
COURSE_URL=http://127.0.0.1:8765/ PLAYWRIGHT_BROWSERS_PATH="$PWD/.browsers" .venv/bin/python scripts/verify_site.py
```

`verify_site.py` 顺序运行两个合订版检查入口：`verify_merged_original_ui.py` 检查原课程内容与交互，`verify_merged_advanced.py` 检查第 17–22 章及新增模型。两者默认使用回环地址 8765，也可通过 `COURSE_URL` 指定已启动的服务。检查结果分别写入 `verification/merged-original-ui-check.json` 和 `verification/merged-advanced-check.json`，两者的 `status` 都应为 `passed`。

当前合并验证报告包括：`merge-content-audit.json`、`merged-pdf.json`、上述两个浏览器报告、`merged-pdf-web.json` 和 `merged-http-check.json`。专题阶段的 `final-site-verification.json`、`ui-polish-verification.json` 等保留为历史证据，不能代替当前合订产物验收。

## 复现追加章节的教学实验

以下入口复现专题阶段的测量模型；重新运行会产生新的输入和验证记录，应同时记录实际工具版本：

```bash
python3 examples/request/generate_pprof.py --verify
python3 research/pprof/make_teaching_profile.py
python3 research/pprof/verify_teaching.py
python3 scripts/fetch_perfetto.py
python3 examples/request/verify_perfetto.py
python3 scripts/audit_sources.py
```

这些工具实验还需要 Go 与相应 Perfetto 二进制。`fetch_perfetto.py` 限定 Linux amd64，核对固定发行包的官方摘要和实际 `--version`；大型工具二进制、浏览器和构建缓存不随材料包分发。其他平台应选择对应官方发行物，并重新记录验证范围。

ScaleN 子包反例在 `verification/pprof-review-repro/`，可进入该目录执行 `go run .`。原生 Go trace 直接导入负例的输入为 `examples/request/native-go.trace`；`go run examples/request/go_trace.go` 可重建输入，内容及大小可能改变。原记录见 `verification/go-trace-import.json`，没有宣称完成 Go viewer JSON 转换实验。

eBPF C/libbpf 示例及环境要求见 `research/ebpf/example/README.md`。它观察目标进程的调度切出并对账，不是完整 off-CPU 或 goroutine profiler。原课程实验入口保留在 `lab/README.md`，本轮未重跑。

## 来源与分发

第三方源文件保留原版权和许可标识，许可与范围见 [THIRD_PARTY.md](THIRD_PARTY.md) 和 `research/licenses/`。原课程 Pyroscope v1.14.0 隔离复现的源码、许可及原运行结果也已完整保留，导入清单见 `verification/original-pyroscope-import.json`；它不代表完整 Pyroscope 服务部署。网站采用绿色关卡学习风格，未使用 Duolingo 商标或官方吉祥物。
