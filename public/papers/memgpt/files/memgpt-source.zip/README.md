# MemGPT 中文阅读版源码包

原论文：**MemGPT: Towards LLMs as Operating Systems**  
版本：arXiv:2310.08560v2，2024 年 2 月 12 日  
来源：https://arxiv.org/abs/2310.08560v2  
原始源码：https://arxiv.org/src/2310.08560v2  
整理日期：2026 年 10 月 5 日

## 文件

- `memgpt-zh.tex`：可独立编译的简体中文 LaTeX 阅读译稿。
- `memgpt-arxiv-source-v2.tar.gz`：未经修改的 arXiv v2 原始源码包。
- `ATTRIBUTION.md`：原作者署名及翻译、排版修改说明。
- `LICENSE.md`：论文、译稿的许可说明。

网页另提供原论文 PDF、21 页中文 PDF 和独立的中文 TeX 下载。

## 编译中文译稿

需要支持 XeLaTeX 的 TeX 发行版，以及 ctex、Fandol 中文字体、TikZ、mdframed、fvextra、natbib 等常用宏包；完整 TeX Live 可提供这些依赖。在解压后的目录运行两遍：

```sh
xelatex -interaction=nonstopmode -halt-on-error memgpt-zh.tex
xelatex -interaction=nonstopmode -halt-on-error memgpt-zh.tex
```

无需 BibTeX，无需额外图片文件，也无需 shell-escape。源文件内含参考文献、图形及表格。

## 阅读范围与修改说明

译稿覆盖正文、附录、图表标题及图内说明。6 张对话和系统示意图根据原图内容用中文重绘；2 张实验图由原图矢量路径转换，并翻译文字标签。作者姓名、参考文献题名、模型/API 标识和实验数值保留原文。单文件排版与原版分页不同。

本译稿由 Codex 辅助翻译和排版，经 Clearer Notes 整理发布，**非原作者审定译本**。附录提示词的中文翻译用于阅读理解；复现实验应以原始英文源码、提示词和实验设置为准。阅读笔记是对论文与历史版本代码的学习整理，不属于原论文。

论文及中文译稿采用 CC BY 4.0，转载或改编时请保留原作者、论文来源、许可链接和修改说明。详见 `LICENSE.md` 与 `ATTRIBUTION.md`。

原始源码包 SHA-256：

```text
96731dbe107daedd7f198319383ba6ba9d0b50ab1de80e203327f814e52384a7
```
