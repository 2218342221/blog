# 许可

原论文 **MemGPT: Towards LLMs as Operating Systems**（arXiv:2310.08560v2）及本包中文阅读译稿，均按 **Creative Commons Attribution 4.0 International（CC BY 4.0）** 提供。

- 许可摘要：https://creativecommons.org/licenses/by/4.0/
- 完整法律文本：https://creativecommons.org/licenses/by/4.0/legalcode
- 原作者、来源及修改声明：见 `ATTRIBUTION.md`。

你可以在遵守该许可的条件下分享、复制和改编这些内容，包括商业使用。请提供适当署名、许可链接，并说明是否作过修改；不得暗示原作者为你的使用背书。完整权利和义务以链接中的许可法律文本为准。

原始 arXiv 源码包内随附的第三方排版宏包、样式文件等，保留其各自的版权及许可声明；本说明不替换或扩大这些第三方文件的许可。
