# 署名与修改说明

**原作品**：MemGPT: Towards LLMs as Operating Systems  
**作者**：Charles Packer、Sarah Wooders、Kevin Lin、Vivian Fang、Shishir G. Patil、Ion Stoica、Joseph E. Gonzalez  
**机构**：University of California, Berkeley  
**版本与日期**：arXiv:2310.08560v2，2024 年 2 月 12 日  
**永久来源**：https://arxiv.org/abs/2310.08560v2  
**许可**：Creative Commons Attribution 4.0 International（CC BY 4.0）  
**许可链接**：https://creativecommons.org/licenses/by/4.0/

中文译稿由 Codex 辅助翻译与排版，Clearer Notes 整理发布（2026 年 10 月 5 日）。修改包括简体中文翻译、单文件 XeLaTeX 排版、6 张示意图中文重绘，以及 2 张实验图的原矢量路径转换与标签翻译。原始 arXiv 源码包保持不变。

译稿不是作者审定或授权背书的译本。中文附录提示词仅供阅读，实验复现请使用原始英文材料。上述署名与许可说明不表示原作者认可本译稿或相关阅读笔记。
