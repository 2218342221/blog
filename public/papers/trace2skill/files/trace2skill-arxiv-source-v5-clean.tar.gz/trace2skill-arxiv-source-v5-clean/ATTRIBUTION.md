# Attribution and changes

## Original work

**Trace2Skill: Distill Trajectory-Local Lessons into Transferable Agent Skills**

Jingwei Ni, Yihao Liu, Xinpeng Liu, Yutao Sun, Mengyu Zhou, Pengyu Cheng,
Dexin Wang, Erchao Zhao, Xiaoxi Jiang, and Guanjun Jiang.

- Source: https://arxiv.org/abs/2603.25158v5
- Version: arXiv v5, 2026-06-04
- License: Creative Commons Attribution 4.0 International
  https://creativecommons.org/licenses/by/4.0/

## Chinese translation and redistribution changes

The non-official Chinese translation and reading materials were prepared by
**Clearer Notes**. The paper text and tables were translated; formulas,
citations, labels, model names, dataset names, code literals, and text embedded
inside figures were retained. Chinese typesetting and pagination were adjusted.

For this clean source bundle, separately licensed TeX class, style, and
bibliography-style files from the arXiv upload were omitted. The two main TeX
files were adapted to the standard `article` class and `plainnat`; this changes
layout but not the paper content. This translation and source adaptation are not
endorsed by the original authors.

## Code reference

The reading report discusses the official repository at commit
`3d0b52a140f002a512930252b613c49048f7d5ac`. The repository is not bundled.
Its README declares Apache-2.0 for the project, while some released skill
artifacts carry separate restrictive licenses; consult each path before reuse.
