# Third-party build files omitted

The official arXiv v5 source archive contains LaTeX class, style, and
bibliography-style files governed by licenses separate from the paper's CC BY
4.0 license, including LPPL and CC BY-SA material. At least one bundled style
also requires its original documented source when redistributed.

To keep this download unambiguous, those files are not included. The clean main
files use standard `article` and `plainnat` instead. Install required packages
through a normal TeX distribution. The untouched official archive remains
available from https://arxiv.org/src/2603.25158v5.
