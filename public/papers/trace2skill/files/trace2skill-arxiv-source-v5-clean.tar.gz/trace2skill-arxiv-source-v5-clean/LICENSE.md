# License notice

The original paper materials included here are redistributed under the
**Creative Commons Attribution 4.0 International License (CC BY 4.0)**:

https://creativecommons.org/licenses/by/4.0/

The Chinese translation is an adapted work distributed under the same terms.
Redistributors must credit the original authors and the translation source,
link the license, indicate changes, and must not imply endorsement by the
original authors.

This bundle intentionally excludes separately licensed TeX build files and the
Trace2Skill software repository. This notice is a practical summary and does
not replace the license text.
