# Trace2Skill 论文与中文译稿清洁源码包

本包对应 *Trace2Skill: Distill Trajectory-Local Lessons into Transferable Agent Skills*，
arXiv:2603.25158v5（2026-06-04）。

- `original-source/`：作者论文正文、表格、参考文献与图片的清洁源码副本。
- `translated-source/`：非官方中文译稿的可维护 LaTeX 源码。
- `ATTRIBUTION.md`：作者、来源、翻译及修改说明。
- `LICENSE.md`：论文材料和译稿的 CC BY 4.0 说明。
- `THIRD-PARTY-NOTICE.md`：为何不附带原始 arXiv 包中的构建依赖。

为避免错误再分发单独许可的 TeX 构建文件，本包不含原始 arXiv 压缩包里的
`.cls`、`.sty`、`.bst` 文件；两个主文件均改用标准 `article` 与 `plainnat`。
如需逐字核对官方上传包，请从 arXiv 获取：

https://arxiv.org/src/2603.25158v5

本包不包含模型权重、评测数据、API 凭证、执行日志或官方代码仓库副本。
代码实现仅链接固定版本：

https://github.com/Qwen-Applications/Trace2Skill/tree/3d0b52a140f002a512930252b613c49048f7d5ac
