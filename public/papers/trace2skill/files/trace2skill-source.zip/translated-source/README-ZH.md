# Trace2Skill 中文翻译源码

本文档目录基于 arXiv:2603.25158v5 的官方 LaTeX 源码翻译。

- 主文件：`main_v2.tex`
- 正文与附录：`sections_v2/`
- 表格：`tables_v2/`
- 图片：`figures/`（按要求保持原文，不翻译图内文字）
- 参考文献：`main_v2.bib`（保留原文）

这是便于再分发的清洁版源码：已移除原始 arXiv 包内采用独立许可的
`googledeepmind.cls`、`.sty` 和 `.bst` 文件，并将主文件改为标准 `article`
版式及 `plainnat`。正文、表格与图片内容保持不变，排版可能与随附 PDF
略有差异。

推荐在完整 TeX Live 环境中使用 pdfLaTeX 编译（源码通过 `ctex` 提供全局中文排版支持）：

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main_v2.tex
```

译文保留模型名、数据集名、公式、引用键、标签和代码字面量，以便与原论文及实验材料对应。
